
const MACHINES = [
  { no: 1, process: 'OP10-1', code: 'IMC-45', standardMt: 158 },
  { no: 2, process: 'OP10-2', code: 'IMC-229', standardMt: 157 },
  { no: 3, process: 'OP-20', code: 'IDH-23', standardMt: 299 },
  { no: 4, process: 'OP30-1', code: 'IMC-251', standardMt: 270 },
  { no: 5, process: 'OP30-1', code: 'IMC-61', standardMt: 265 },
  { no: 6, process: 'OP70', code: 'IMC-94', standardMt: 314 },
  { no: 7, process: 'OP70', code: 'IMC-103', standardMt: 329 },
  { no: 8, process: 'OP80-1', code: 'IMC-19', standardMt: 974 },
  { no: 9, process: 'OP80-1', code: 'IMC-20', standardMt: 892 },
  { no: 10, process: 'OP80-3', code: 'IMC-21', standardMt: 913 },
  {
    no: 11,
    process: 'OP80-4',
    code: 'IMC-29',
    standardMt: 1012,
    baseTable: 'rh_imc_29',
    runTable: 'rh_imc_29_run',
    troubleTable: 'rh_imc_29_trouble',
  },
  {
    no: 12,
    process: 'OP80-5',
    code: 'IMC-40',
    standardMt: 865,
    baseTable: 'rh_imc_40',
    runTable: 'rh_imc_40_run',
    troubleTable: 'rh_imc_40_trouble',
  },
  {
    no: 13,
    process: 'OP80-6',
    code: 'IMC-28',
    standardMt: 917,
    baseTable: 'rh_imc_28',
    runTable: 'rh_imc_28_run',
    troubleTable: 'rh_imc_28_trouble',
  },
  {
    no: 14,
    process: 'OP80-7',
    code: 'IMC-10',
    standardMt: 77,
    baseTable: 'rh_imc_10',
    runTable: 'rh_imc_10_run',
    troubleTable: 'rh_imc_10_trouble',
  },
  { no: 15, process: 'OP90', code: 'IPO-6', standardMt: null },
  { no: 16, process: 'OP100', code: 'ISC-11', standardMt: null },
  { no: 17, process: 'OP110', code: 'ISC-4', standardMt: null },
  { no: 18, process: 'OP120', code: 'IAM-13', standardMt: null },
];

const MACHINE_MAP = new Map(MACHINES.map((machine) => [machine.code.toUpperCase(), machine]));

function getMachineByCode(code) {
  return MACHINE_MAP.get(String(code || '').toUpperCase()) || null;
}

module.exports = { MACHINES, getMachineByCode };
