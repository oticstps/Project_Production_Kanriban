const mysql = require("mysql2/promise");
require('dotenv').config();

const pool = mysql.createPool({
  host: "192.168.137.241",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_energy_listrik",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  timezone: '+07:00',
  dateStrings: true,
  charset: 'utf8mb4'
});

module.exports = pool;