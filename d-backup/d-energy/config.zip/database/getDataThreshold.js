// getLastData.js

// 1. Import konfigurasi database
// Pastikan path ini sesuai dengan struktur folder Anda
const db = require('../config/db_core');

// 2. Daftar Tabel yang diminta
const tables = [
    'tb_energy_snapshot',
    'tb_kub1_active_power',
    'tb_kub1_pershift',
    'tb_kub1_total_kwh',
    'tb_kub2_63_active_power',
    'tb_kub2_63_apparent_power',
    'tb_kub2_63_current',
    'tb_kub2_63_frequency',
    'tb_kub2_63_power_factor',
    'tb_kub2_63_reactive_power',
    'tb_kub2_63_voltage_ll',
    'tb_kub2_63_voltage_ln',
    'tb_kub2_64_active_power',
    'tb_kub2_64_apparent_power',
    'tb_kub2_64_current',
    'tb_kub2_64_frequency',
    'tb_kub2_64_power_factor',
    'tb_kub2_64_reactive_power',
    'tb_kub2_64_voltage_ll',
    'tb_kub2_64_voltage_ln',
    'tb_kub2_panel63',
    'tb_kub2_panel64',
    'tb_kub2_panel_1_total_kwh',
    'tb_kub2_panel_2_total_kwh',
    'tb_kub_active_power',
    'tb_kub_apparent_power',
    'tb_kub_comp_19',
    'tb_kub_comp_19_shiftly',
    'tb_kub_comp_20_shiftly',
    'tb_kub_comp_21',
    'tb_kub_comp_21_shiftly',
    'tb_kub_comp_24',
    'tb_kub_comp_24_shiftly',
    'tb_kub_current',
    'tb_kub_current_update',
    'tb_kub_frequency',
    'tb_kub_panel_16_ap',
    'tb_kub_panel_16_wh',
    'tb_kub_panel_17_ap',
    'tb_kub_panel_17_wh',
    'tb_kub_panel_20_ap',
    'tb_kub_panel_20_wh',
    'tb_kub_plant2_report',
    'tb_kub_power_factor',
    'tb_kub_reactive_power',
    'tb_kub_voltage_ll',
    'tb_kub_voltage_ln',
    'tb_layout_otics_1',
    'tb_lpdmtc',
    'tb_lpf1',
    'tb_lpf2',
    'tb_lpqad',
    'tb_lpsec',
    'tb_lputils',
    'tb_lp_dmtc',
    'tb_pm200_bs1',
    'tb_pm200_bs2',
    'tb_pm200_cc1',
    'tb_pm200_cc234',
    'tb_pm200_chab',
    'tb_pm200_chcd',
    'tb_pm200_chef',
    'tb_pm200_chsaa',
    'tb_pm200_chsab',
    'tb_pm200_chsac',
    'tb_pm200_chsac_b',
    'tb_pm200_conn',
    'tb_pm200_cr1',
    'tb_pm200_cr2',
    'tb_pm200_cr3',
    'tb_pm200_cr4',
    'tb_pm200_cr5',
    'tb_pm200_cr6',
    'tb_pm200_cr7',
    'tb_pm200_cr8',
    'tb_pm200_cr9',
    'tb_pm200_cr10',
    'tb_pm200_cr11',
    'tb_pm200_cr12',
    'tb_pm200_ct',
    'tb_pm200_hla',
    'tb_pm200_ra',
    'tb_pm200_ret',
    'tb_pm200_weng',
    'tb_pm220_bs1',
    'tb_pm220_bs2',
    'tb_pm220_cc1',
    'tb_pm220_cc234',
    'tb_pm220_chab',
    'tb_pm220_chcd',
    'tb_pm220_chef',
    'tb_pm220_chsaa',
    'tb_pm220_chsab',
    'tb_pm220_chsac',
    'tb_pm220_chsac_b',
    'tb_pm220_conn',
    'tb_pm220_cr1',
    'tb_pm220_cr2',
    'tb_pm220_cr3',
    'tb_pm220_cr4',
    'tb_pm220_cr5',
    'tb_pm220_cr6',
    'tb_pm220_cr7',
    'tb_pm220_cr8',
    'tb_pm220_cr9',
    'tb_pm220_cr10',
    'tb_pm220_cr11',
    'tb_pm220_cr12',
    'tb_pm220_ct',
    'tb_pm220_hla',
    'tb_pm220_lpf3',
    'tb_pm220_ra',
    'tb_pm220_ret'
];

// Fungsi utama untuk mengambil data
async function getLastData() {
    console.log("Memulai pengambilan data terakhir...\n");

    // Loop melalui setiap tabel
    for (const tableName of tables) {
        try {
            // Query SQL: Ambil 1 data terakhir berdasarkan ID descending
            // CATATAN: Pastikan tabel memiliki kolom 'id' atau ubah 'ORDER BY id DESC' 
            // menjadi 'ORDER BY created_at DESC' jika menggunakan timestamp.
            const query = `SELECT * FROM ${tableName} ORDER BY date_time DESC LIMIT 1`;
            
            // Eksekusi query (Menyesuaikan dengan library db Anda, contoh menggunakan mysql2/promise)
            // Jika db_core.js menggunakan callback, Anda perlu membungkusnya dengan Promise.
            const [rows] = await db.query(query);

            if (rows && rows.length > 0) {
                // Format output sesuai permintaan: name_tabel : data
                // Data diubah ke JSON string agar terbaca semua kolomnya
                console.log(`${tableName} : ${JSON.stringify(rows[0])}`);
            } else {
                console.log(`${tableName} : (Tabel Kosong)`);
            }

        } catch (error) {
            // Handle error jika tabel tidak ada atau query gagal
            console.error(`Gagal mengambil data dari ${tableName}: ${error.message}`);
        }
    }

    console.log("\nSelesai.");
    
    // Tutup koneksi jika perlu (tergantung konfigurasi db_core.js Anda)
    // if (db.end) await db.end(); 
}

// Jalankan fungsi
getLastData();