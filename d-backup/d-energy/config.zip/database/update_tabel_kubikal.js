const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

// ==================== KONFIGURASI ====================
const dbConfig = {
  host: '172.27.63.180',        // IP tujuan database
  port: 3306,                   // Port MySQL (biasanya 3306)
  user: 'otics_tps',        // ← GANTI dengan username DB
  password: 'sukatno_ali',    // ← GANTI dengan password DB
  database: 'database_tps_master', // ← GANTI dengan nama database tujuan
  multipleStatements: true,     // Penting agar bisa jalankan banyak statement sekaligus
  connectTimeout: 300000,       // 5 menit (untuk file besar)
  acquireTimeout: 300000
};

// Path file SQL (sesuai lokasi kamu)
const sqlFilePath = 'C:\\Users\\234066\\Downloads\\tb_kub1_total_kwh (3).sql';
// =====================================================

async function migrate() {
  let connection;
  try {
    console.log('🔌 Menghubungkan ke database target...');
    connection = await mysql.createConnection(dbConfig);

    console.log('📂 Membaca file SQL...');
    const sqlContent = fs.readFileSync(sqlFilePath, 'utf8');

    if (!sqlContent || sqlContent.trim() === '') {
      throw new Error('File SQL kosong atau tidak bisa dibaca!');
    }

    console.log(`✅ File berhasil dibaca (${(sqlContent.length / 1024 / 1024).toFixed(2)} MB)`);
    console.log('🚀 Menjalankan migrasi (CREATE + INSERT)...');

    const [result] = await connection.query(sqlContent);

    console.log('🎉 MIGRASI BERHASIL!');
    console.log('Result:', result);

  } catch (error) {
    console.error('❌ ERROR saat migrasi:');
    console.error(error.message);
    if (error.code) console.error('Error Code:', error.code);
    if (error.sqlMessage) console.error('SQL Message:', error.sqlMessage);
  } finally {
    if (connection) {
      await connection.end();
      console.log('🔌 Koneksi database ditutup.');
    }
  }
}

// Jalankan program
migrate();