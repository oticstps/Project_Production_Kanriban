const { exec } = require('child_process');
const path = require('path');

// ==================== KONFIGURASI ====================
const SOURCE = {
  host: '192.168.137.131',
  user: 'otics_tps',      // ← GANTI
  password: 'sukatno_ali',  // ← GANTI
  database: 'database_tps_master'
};

const TARGET = {
  host: '192.168.137.241',
  user: 'otics_tps',      // ← GANTI
  password: 'sukatno_ali',  // ← GANTI
  database: 'database_tps_master'  // nama database di target (bisa sama)
};

const DUMP_FILE = path.join(__dirname, 'database_tps_master.sql');
// =====================================================

function runCommand(command) {
  return new Promise((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(stdout || stderr);
    });
  });
}

async function migrateDatabase() {
  try {
    console.log('🚀 Mulai migrasi database_tps_master...');
    console.log(`Dari : ${SOURCE.host}`);
    console.log(`Ke   : ${TARGET.host}`);

    // 1. Dump dari source
    console.log('📤 Membuat dump dari source...');
    const dumpCommand = `mysqldump -h ${SOURCE.host} -u ${SOURCE.user} -p${SOURCE.password} ${SOURCE.database} --routines --triggers --events > "${DUMP_FILE}"`;
    
    await runCommand(dumpCommand);
    console.log('✅ Dump berhasil dibuat!');

    // 2. Import ke target
    console.log('📥 Mengimpor ke target host...');
    const importCommand = `mysql -h ${TARGET.host} -u ${TARGET.user} -p${TARGET.password} ${TARGET.database} < "${DUMP_FILE}"`;
    
    await runCommand(importCommand);

    console.log('🎉 MIGRASI DATABASE BERHASIL 100%!');
    console.log(`Database ${SOURCE.database} sudah dipindahkan ke ${TARGET.host}`);

  } catch (error) {
    console.error('❌ ERROR saat migrasi:');
    console.error(error.message);
  }
}

// Jalankan
migrateDatabase();