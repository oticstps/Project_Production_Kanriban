




tb_kub1_active_power : {"date_time":"2026-03-18 10:48:19","power_meter":"DA_30","value":"1425.563720703125","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_kub1_total_kwh : {"date_time":"2026-03-18 10:50:21","power_meter":"DA_01","value":"21375972919","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_kub2_63_active_power : {"date_time":"2026-03-18 10:47:13","panel":"kub63_ap","active_power_total":"103.421","active_power_a":"40.449","active_power_b":"31.131","active_power_c":"31.841","reserved_1":null,"reserved_2":null}
tb_kub2_63_apparent_power : {"date_time":"2026-03-18 08:39:47","panel":"kub63_apr","apparent_power_total":"105.227","apparent_power_a":"39.500","apparent_power_b":"33.054","apparent_power_c":"32.702","metadata_1":null,"metadata_2":null}
tb_kub2_63_current : {"date_time":"2026-03-18 09:38:32","panel":"kub63_c","current_avg":"158.361","current_a":"174.936","current_b":"148.555","current_c":"151.592","current_n":"35.014","metadata_1":null,"metadata_2":null}
tb_kub2_63_frequency : {"date_time":"2026-03-18 09:55:23","panel":"kub63_freq","data_freq":"50.053","metadata_1":null,"metadata_2":null}
tb_kub2_63_power_factor : {"date_time":"2026-03-18 09:39:56","panel":"kub63_pk","power_factor_total":"0.984","power_factor_a":"0.983","power_factor_b":"0.981","power_factor_c":"0.988","metadata_1":null,"metadata_2":null}
tb_kub2_63_reactive_power : {"date_time":"2026-03-18 08:33:08","panel":"kub63_rp","reactive_power_total":"17.812","reactive_power_a":"6.876","reactive_power_b":"6.082","reactive_power_c":"4.854","metadata_1":null,"metadata_2":null}
tb_kub2_63_voltage_ll : {"date_time":"2026-03-18 09:29:06","panel":"kub63_vll","voltage_ll_avg":"395.539","voltage_ab":"396.132","voltage_bc":"396.072","voltage_ca":"394.413","metadata_1":null,"metadata_2":null}
tb_kub2_63_voltage_ln : {"date_time":"2026-03-18 10:45:17","panel":"kub63_vln","voltage_ln_avg":"231.670","voltage_an":"231.194","voltage_bn":"232.557","voltage_cn":"231.260","metadata_1":null,"metadata_2":null}
tb_kub2_64_active_power : {"date_time":"2026-03-18 10:40:50","panel":"kub64_ap","active_power_total":"393.695","active_power_a":"132.928","active_power_b":"144.701","active_power_c":"116.066","reserved_1":null,"reserved_2":null}
tb_kub2_64_apparent_power : {"date_time":"2026-03-18 10:44:57","panel":"kub64_apr","apparent_power_total":"422.917","apparent_power_a":"139.659","apparent_power_b":"155.449","apparent_power_c":"128.258","metadata_1":null,"metadata_2":null}
tb_kub2_64_current : {"date_time":"2026-03-18 09:53:24","panel":"kub64_c","current_avg":"1291.705","current_a":"1279.149","current_b":"1417.561","current_c":"1178.405","current_n":"0.000","metadata_1":null,"metadata_2":null}
tb_kub2_64_frequency : {"date_time":"2026-03-18 10:47:16","panel":"kub64_freq","data_freq":"50.064","metadata_1":null,"metadata_2":null}
tb_kub2_64_power_factor : {"date_time":"2026-03-18 10:42:26","panel":"kub64_pk","power_factor_total":"0.908","power_factor_a":"0.931","power_factor_b":"0.909","power_factor_c":"0.876","metadata_1":null,"metadata_2":null}
tb_kub2_64_reactive_power : {"date_time":"2026-03-18 10:48:34","panel":"kub64_rp","reactive_power_total":"193.177","reactive_power_a":"52.944","reactive_power_b":"71.425","reactive_power_c":"68.808","metadata_1":null,"metadata_2":null}
tb_kub2_64_voltage_ll : {"date_time":"2026-03-18 10:37:29","panel":"kub64_vll","voltage_ll_avg":"198.715","voltage_ab":"198.768","voltage_bc":"199.160","voltage_ca":"198.216","metadata_1":null,"metadata_2":null}
tb_kub2_64_voltage_ln : {"date_time":"2026-03-18 09:51:15","panel":"kub64_vln","voltage_ln_avg":"114.164","voltage_an":"113.196","voltage_bn":"114.300","voltage_cn":"114.997","metadata_1":null,"metadata_2":null}
tb_kub2_panel63 : {"date_time":"2026-03-18 10:32:45","power_meter":"DA_01","value":"1485791383","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_kub2_panel64 : {"date_time":"2026-03-18 10:45:47","power_meter":"DA_01","value":"6298202285","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_kub_active_power : {"date_time":"2026-03-18 10:50:47","panel":"kub_ap","active_power_total":"1468.391","active_power_a":"471.001","active_power_b":"517.938","active_power_c":"479.452","reserved_1":null,"reserved_2":null}
tb_kub_apparent_power : {"date_time":"2026-03-18 10:49:44","panel":"kub_apr","apparent_power_total":"1455.931","apparent_power_a":"471.236","apparent_power_b":"512.454","apparent_power_c":"473.207","metadata_1":null,"metadata_2":null}
tb_kub_comp_19 : {"date_time":"2026-03-10 12:15:22","panel":"panel_19","wh":210125424,"av":0}
tb_kub_comp_21 : {"date_time":"2026-03-10 12:15:32","panel":"panel_21","wh":423682240,"av":0}
tb_kub_comp_24 : {"date_time":"2026-03-10 12:14:42","panel":"panel_24","wh":531053600,"av":0}
tb_kub_current : {"date_time":"2026-03-18 10:49:29","panel":"kub_c","current_avg":"41.553","current_a":"40.396","current_b":"43.747","current_c":"40.517","current_n":"0.000"}
tb_kub_current_update : {"date_time":"2026-02-26 11:58:42","panel":"kub_c","current_avg":"51.180","current_a":"48.666","current_b":"53.388","current_c":"51.487","current_n":"0.000"}
tb_kub_frequency : {"date_time":"2026-03-18 10:50:36","panel":"kub_freq","data_freq":"50.047","metadata_1":null,"metadata_2":null}
tb_kub_panel_16_ap : {"date_time":"2026-03-18 10:47:12","panel":"panel_16","data_wh":"265.6221618652344"}
tb_kub_panel_16_wh : {"date_time":"2026-03-18 10:47:11","panel":"panel_16","wh":"3736924203"}
tb_kub_panel_17_ap : {"date_time":"2026-03-17 19:47:21","panel":"panel_17","data_wh":"172.0572967529297"}
tb_kub_panel_17_wh : {"date_time":"2026-03-18 10:39:21","panel":"panel_17","wh":"9359636344"}
tb_kub_panel_20_ap : {"date_time":"2026-03-18 10:43:02","panel":"panel_20","data_wh":"168.72113037109375"}
tb_kub_panel_20_wh : {"date_time":"2026-03-18 10:33:01","panel":"panel_20","wh":"1367351040"}
tb_kub_power_factor : {"date_time":"2026-03-18 10:50:10","panel":"kub_pk","power_factor_total":"0.950","power_factor_a":"0.961","power_factor_b":"0.955","power_factor_c":"0.934","metadata_1":null,"metadata_2":null}
tb_kub_reactive_power : {"date_time":"2026-03-18 10:48:32","panel":"kub_rp","reactive_power_total":"511.319","reactive_power_a":"142.935","reactive_power_b":"181.656","reactive_power_c":"186.728","metadata_1":null,"metadata_2":null}
tb_kub_voltage_ll : {"date_time":"2026-03-18 10:48:26","panel":"kub_vll","voltage_ll_avg":"20228.455","voltage_ab":"20206.939","voltage_bc":"20295.285","voltage_ca":"20183.141","metadata_1":null,"metadata_2":null}
tb_kub_voltage_ln : {"date_time":"2026-03-18 10:48:00","panel":"kub_vln","voltage_ln_avg":"11688.981","voltage_an":"11669.879","voltage_bn":"11718.997","voltage_cn":"11678.072","metadata_1":null,"metadata_2":null}
tb_lpdmtc : {"id":216203,"date_time":"2026-03-18 10:49:08","fasa":"t","power":"2423.00","energy":"4458543.00","current":"47.72","voltage":"226.20","total_energy":"17840102.00"}
tb_lpf1 : {"date_time":"2026-03-18 10:50:40","fasa":"r","power":"2281.60","energy":"6984339.00","current":"10.62","voltage":"230.60","total_energy":"6984339.00"}
tb_lpf2 : {"date_time":"2026-03-18 10:50:31","fasa":"r","power":"508.7","energy":"3085609.2","current":"2.8","voltage":"230.2","total_energy":"10464966.0"}
tb_lpqad : {"date_time":"2026-03-18 10:47:37","fasa":"s","power":"1715.70","energy":"10190768.00","current":"8.89","voltage":"231.20","total_energy":"34869344.00"}
tb_lpsec : (Tabel Kosong)
tb_lputils : (Tabel Kosong)
tb_lp_dmtc : {"date_time":"2025-12-01 14:42:54","fasa":"t","power":"1161.30","energy":"952464.00","current":"42.91","voltage":"227.20","total_energy":"3684212.00"}
tb_pm200_bs1 : {"date_time":"2026-03-18 10:50:27","power_meter":"PM 200","value":"571877376","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_bs2 : {"date_time":"2026-03-18 10:46:21","power_meter":"PM 200","value":"268426400","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cc1 : {"date_time":"2026-03-18 10:50:42","power_meter":"PM 200","value":"55077388","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cc234 : {"date_time":"2026-03-18 10:49:26","power_meter":"PM_200V","value":"12474144","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_chab : {"date_time":"2026-03-18 10:30:26","power_meter":"PM-200V","value":"574606784","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_chcd : {"date_time":"2026-03-18 10:47:26","power_meter":"PM-3F","value":"574365952","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_chef : {"date_time":"2026-03-18 10:50:50","power_meter":"PM_200V","value":"233431024","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_chsaa : {"date_time":"2026-03-18 10:50:23","power_meter":"PM_200V","value":"660365696","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_chsab : {"date_time":"2026-03-18 10:50:32","power_meter":"PM_220V","value":"640138368","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_chsac : {"date_time":"2026-01-07 07:53:51","power_meter":"PM_200V","value":"177825952","shift":"shift_1","day":"7","week":"2","month":"January","year":"2026"}
tb_pm200_conn : {"date_time":"2026-03-18 10:50:48","power_meter":"PM 200","value":"363264","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr1 : {"date_time":"2026-03-18 10:48:23","power_meter":"PM 200","value":"135530000","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr2 : {"date_time":"2026-03-18 10:48:45","power_meter":"PM 200","value":"178753936","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr3 : {"date_time":"2026-03-18 10:50:36","power_meter":"PM 200","value":"117512336","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr4 : {"date_time":"2026-03-18 10:50:57","power_meter":"PM 200","value":"185871392","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr5 : {"date_time":"2026-03-18 10:49:58","power_meter":"PM 200","value":"24210668","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr6 : {"date_time":"2026-03-18 10:50:18","power_meter":"PM 200","value":"165989248","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr7 : {"date_time":"2026-03-18 10:43:08","power_meter":"PM_200V","value":"48393628","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr8 : {"date_time":"2026-03-18 10:50:39","power_meter":"PM 200","value":"216703312","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr9 : {"date_time":"2026-03-18 10:50:45","power_meter":"PM 200","value":"235658576","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr10 : {"date_time":"2026-03-18 10:51:05","power_meter":"PM 200","value":"202782784","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr11 : {"date_time":"2026-03-18 10:51:00","power_meter":"PM 200","value":"202018816","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_cr12 : {"date_time":"2026-03-18 10:50:29","power_meter":"PM 200","value":"211824704","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_ct : {"date_time":"2026-03-18 10:50:40","power_meter":"PM_200V","value":"2986476.50","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_hla : {"date_time":"2026-03-18 08:54:43","power_meter":"PM_200V","value":"759670592","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_ra : {"date_time":"2026-03-18 10:50:13","power_meter":"PM 200","value":"1106110","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_ret : {"date_time":"2026-03-18 10:37:17","power_meter":"PM_200V","value":"237236496","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm200_weng : {"date_time":"2026-03-18 10:50:17","power_meter":"PM_200_1","value":"13939226","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}




tb_pm220_bs1 : {"date_time":"2026-03-18 10:50:16","power_meter":"PM 220","value":"692105","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_bs2 : {"date_time":"2026-03-18 10:50:38","power_meter":"PM 220","value":"25201104","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cc1 : {"date_time":"2026-03-18 10:50:10","power_meter":"PM 220","value":"142922","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cc234 : {"date_time":"2026-03-18 10:48:50","power_meter":"PM_220V","value":"3229420","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_chab : {"date_time":"2026-03-18 10:50:52","power_meter":"PM-220V","value":"16945786","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_chcd : {"date_time":"2026-03-18 10:47:36","power_meter":"PM-1F","value":"7014885","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_chef : {"date_time":"2026-03-18 10:50:14","power_meter":"PM_220V","value":"17003486","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_chsaa : {"date_time":"2026-03-18 10:50:15","power_meter":"PM_220V","value":"15668410","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_chsab : {"date_time":"2026-03-18 10:50:41","power_meter":"PM_200V","value":"32870066","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_chsac : {"date_time":"2026-03-17 22:18:39","power_meter":"PM_220V","value":"12434220","shift":"shift_2","day":"17","week":"3","month":"March","year":"2026"}
tb_pm220_conn : (Tabel Kosong)
tb_pm220_cr1 : {"date_time":"2026-03-18 10:50:53","power_meter":"PM 220","value":"2592061","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr2 : {"date_time":"2026-03-18 10:50:22","power_meter":"PM 220","value":"1412502","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr3 : {"date_time":"2026-03-18 10:50:26","power_meter":"PM 220","value":"4867871","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr4 : {"date_time":"2026-03-18 10:50:47","power_meter":"PM 220","value":"1850790","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr5 : {"date_time":"2026-03-18 10:49:47","power_meter":"PM 220","value":"243037","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr6 : {"date_time":"2026-03-18 10:51:00","power_meter":"PM 220","value":"1394030","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr7 : {"date_time":"2026-03-18 10:50:07","power_meter":"PM 220","value":"1779339","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr8 : {"date_time":"2026-03-18 10:51:09","power_meter":"PM 220","value":"1464889","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr9 : {"date_time":"2026-03-18 10:48:00","power_meter":"PM 220","value":"8874979","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr10 : {"date_time":"2026-03-18 10:50:55","power_meter":"PM 220","value":"1096373","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr11 : {"date_time":"2026-03-18 10:49:07","power_meter":"PM 220","value":"1757348","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_cr12 : {"date_time":"2026-03-18 10:47:44","power_meter":"PM 220","value":"2180449","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_ct : {"date_time":"2026-03-18 10:46:44","power_meter":"PM_220V","value":"44607344.00","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_hla : (Tabel Kosong)
tb_pm220_lpf3 : {"id":68991,"date_time":"2026-03-18 10:49:40","power_meter":"PM 220","value":"5569232","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_ra : {"date_time":"2026-03-18 10:51:04","power_meter":"PM 220","value":"4124337","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}
tb_pm220_ret : {"date_time":"2026-03-18 10:40:29","power_meter":"PM_220V","value":"23113484","shift":"shift_1","day":"18","week":"3","month":"March","year":"2026"}





Gagal mengambil data dari tb_kub2_panel_1_total_kwh: Table 'database_tps_master.tb_kub2_panel_1_total_kwh' doesn't exist
Gagal mengambil data dari tb_kub2_panel_2_total_kwh: Table 'database_tps_master.tb_kub2_panel_2_total_kwh' doesn't exist
Gagal mengambil data dari tb_kub_comp_19_shiftly: Table 'database_tps_master.tb_kub_comp_19_shiftly' doesn't exist
Gagal mengambil data dari tb_kub_comp_20_shiftly: Table 'database_tps_master.tb_kub_comp_20_shiftly' doesn't exist
Gagal mengambil data dari tb_kub_comp_21_shiftly: Table 'database_tps_master.tb_kub_comp_21_shiftly' doesn't exist
Gagal mengambil data dari tb_kub_comp_24_shiftly: Table 'database_tps_master.tb_kub_comp_24_shiftly' doesn't exist
Gagal mengambil data dari tb_kub_plant2_report: Unknown column 'date_time' in 'ORDER BY'
Gagal mengambil data dari tb_layout_otics_1: Table 'database_tps_master.tb_layout_otics_1' doesn't exist
Gagal mengambil data dari tb_pm200_chsac_b: Table 'database_tps_master.tb_pm200_chsac_b' doesn't exist
Gagal mengambil data dari tb_pm220_chsac_b: Table 'database_tps_master.tb_pm220_chsac_b' doesn't exist
Gagal mengambil data dari tb_kub1_pershift: Table 'database_tps_master.tb_kub1_pershift' doesn't exist
Gagal mengambil data dari tb_energy_snapshot: Table 'database_tps_master.tb_energy_snapshot' doesn't exist
