const express = require("express");
const router = express.Router();

const PltsRealtimeController = require("../controllers/PltsRealtimeController");

/*
  plant hanya boleh:
  - plant-1
  - plant-2
*/

// Ambil semua data realtime
router.get("/:plant/realtime", PltsRealtimeController.getAllData);

// Ambil data realtime terbaru
router.get("/:plant/realtime/latest", PltsRealtimeController.getLatestData);

// Ambil data realtime berdasarkan range tanggal
router.get("/:plant/realtime/range", PltsRealtimeController.getDataByDateRange);

// Tambah data realtime
router.post("/:plant/realtime", PltsRealtimeController.insertData);

// Hapus data realtime berdasarkan idPrimary
router.delete("/:plant/realtime/:id", PltsRealtimeController.deleteData);

module.exports = router;