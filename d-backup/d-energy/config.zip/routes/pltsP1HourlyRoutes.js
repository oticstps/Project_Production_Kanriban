const express = require("express");

const {
  bulkImportHourly,
  getHourlyByDate,
} = require("../controllers/pltsP1HourlyController");

const router = express.Router();

router.post("/bulk", bulkImportHourly);

router.get("/", getHourlyByDate);

router.get("/date/:date", getHourlyByDate);

module.exports = router;