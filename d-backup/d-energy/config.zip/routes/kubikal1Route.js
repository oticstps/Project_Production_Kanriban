const express = require('express');
const router = express.Router();
const realtimeController = require('../controllers/kubikal1Controller');

// Endpoint umum
router.get('/', realtimeController.getCurrent);
router.put('/', realtimeController.update);
router.delete('/', realtimeController.delete); // opsional

// Endpoint khusus
router.put('/current', realtimeController.updateCurrent);
router.put('/voltage-ll', realtimeController.updateVoltageLL);
router.put('/voltage-ln', realtimeController.updateVoltageLN);
router.put('/active-power', realtimeController.updateActivePower);
router.put('/apparent-power', realtimeController.updateApparentPower);
router.put('/power-factor', realtimeController.updatePowerFactor);
router.put('/reactive-power', realtimeController.updateReactivePower);
router.put('/frequency', realtimeController.updateFrequency);

module.exports = router;