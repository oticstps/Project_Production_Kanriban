const express = require('express');
const router = express.Router();
const comp19ControllerShiftly = require('../controllers/tb_comp19ControllerShiftly');

router.get('/', comp19ControllerShiftly.getAll);
router.get('/:id', comp19ControllerShiftly.getById);
router.post('/', comp19ControllerShiftly.create);
router.put('/:id', comp19ControllerShiftly.update);
router.delete('/:id', comp19ControllerShiftly.delete);

module.exports = router;