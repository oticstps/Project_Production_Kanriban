const express = require('express');
const router = express.Router();
const comp20ControllerShiftly = require('../controllers/tb_comp20ControllerShiftly');

router.get('/', comp20ControllerShiftly.getAll);
router.get('/:id', comp20ControllerShiftly.getById);
router.post('/', comp20ControllerShiftly.create);
router.put('/:id', comp20ControllerShiftly.update);
router.delete('/:id', comp20ControllerShiftly.delete);

module.exports = router;