// routes/kubCurrentRoute.js
const express = require('express');
const router = express.Router();
const kubCurrentController = require('../controllers/kubCurrentController');

router.get('/', kubCurrentController.getData);
router.post('/', kubCurrentController.addData);
router.put('/:dateTime', kubCurrentController.updateData);
router.delete('/:dateTime', kubCurrentController.deleteData);
module.exports = router;