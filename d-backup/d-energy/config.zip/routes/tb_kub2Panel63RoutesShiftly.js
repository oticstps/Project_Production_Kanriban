const express = require('express');
const TbKub2Panel63ControllerShiftly = require('../controllers/tb_kub2Panel63ControllerShiftly');

const router = express.Router();

/**
 * Base URL yang disarankan:
 * /api/kub2/panel63/shiftly
 */

// Ringkasan harus diletakkan sebelum route /:id.
router.get('/summary', TbKub2Panel63ControllerShiftly.getSummary);

// CRUD.
router.get('/', TbKub2Panel63ControllerShiftly.getAll);
router.get('/:id', TbKub2Panel63ControllerShiftly.getById);
router.post('/', TbKub2Panel63ControllerShiftly.create);
router.post('/upsert', TbKub2Panel63ControllerShiftly.upsert);
router.put('/:id', TbKub2Panel63ControllerShiftly.update);
router.patch('/:id', TbKub2Panel63ControllerShiftly.update);
router.delete('/:id', TbKub2Panel63ControllerShiftly.delete);

module.exports = router;
