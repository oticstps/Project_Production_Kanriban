const express = require('express');
const router = express.Router();
const CompressorController = require('../controllers/compressor.controller');

// trigger rekap
router.post('/rekap/shiftly', CompressorController.runShiftly);
router.post('/rekap/daily', CompressorController.runDaily);
router.post('/rekap/weekly', CompressorController.runWeekly);
router.post('/rekap/monthly', CompressorController.runMonthly);

// ambil data
router.get('/:period/:panel', CompressorController.getData);

module.exports = router;