const express = require('express');
const router = express.Router();
const PltsP1HourlyControllerFullStack = require('../controllers/pltsP1HourlyControllerFullStack');

router.get('/', PltsP1HourlyControllerFullStack.index);
router.get('/latest', PltsP1HourlyControllerFullStack.latest);
router.get('/daily-summary', PltsP1HourlyControllerFullStack.dailySummary);
router.get('/:energy_date', PltsP1HourlyControllerFullStack.show);
router.post('/', PltsP1HourlyControllerFullStack.store);
router.post('/upsert', PltsP1HourlyControllerFullStack.upsert);
router.put('/:energy_date', PltsP1HourlyControllerFullStack.update);
router.delete('/:energy_date', PltsP1HourlyControllerFullStack.destroy);

module.exports = router;
