'use strict';

const express = require('express');
const controller = require('../controllers/pltsPlant1Plant2Controller');

const router = express.Router();

// GET /api/plts-plant-1-plant-2?page=1&limit=20&status=Healthy
// GET /api/plts-plant-1-plant-2?start_date=2026-07-24 00:00:00&end_date=2026-07-24 23:59:59
router.get('/', controller.getAll);

// Harus diletakkan sebelum route /:id.
router.get('/latest', controller.getLatest);
router.get('/range', controller.getByRange);

router.get('/:id', controller.getById);
router.post('/', controller.create);
router.put('/:id', controller.update);
router.patch('/:id', controller.update);
router.delete('/:id', controller.remove);

module.exports = router;
