const express = require('express');
const router = express.Router();
const { getHikitori, getSummary } = require('../controllers/hikitoriController');

router.get('/', getHikitori);
router.get('/summary', getSummary);

module.exports = router;