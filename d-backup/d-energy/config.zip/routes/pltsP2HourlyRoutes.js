const express = require("express");

const {
  bulkImportP2Hourly,
  getP2HourlyByDate,
} = require("../controllers/pltsP2HourlyController");

const router = express.Router();

router.post("/bulk", bulkImportP2Hourly);
router.get("/", getP2HourlyByDate);
router.get("/date/:date", getP2HourlyByDate);

module.exports = router;