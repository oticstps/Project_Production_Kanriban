const express = require('express');
const router = express.Router();
const controller = require('../controllers/MonthlyReportController');

router.get('/:table', controller.getAll);
router.get('/:table/year/:year', controller.getByYear);
router.get('/:table/:pm_type/:line_table/:year/:month', controller.getByComposite);
router.post('/:table', controller.create);
router.put('/:table/:pm_type/:line_table/:year/:month', controller.update);
router.delete('/:table/:pm_type/:line_table/:year/:month', controller.delete);

module.exports = router;