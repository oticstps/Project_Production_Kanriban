const express = require('express');
const router = express.Router();
const comp21ControllerMonthly = require('../controllers/tb_comp21ControllerMonthly');

router.get('/', comp21ControllerMonthly.getAll);
router.get('/:id', comp21ControllerMonthly.getById);
router.post('/', comp21ControllerMonthly.create);
router.put('/:id', comp21ControllerMonthly.update);
router.delete('/:id', comp21ControllerMonthly.delete);

module.exports = router;