const express = require('express');
const router = express.Router();
const kubController = require('../controllers/kubController');

router.get('/power-meters', kubController.getPowerMeters);

router.get('/shiftly/:power_meter', kubController.getShiftly);
router.get('/daily/:power_meter', kubController.getDaily);
router.get('/weekly/:power_meter', kubController.getWeekly);
router.get('/monthly/:power_meter', kubController.getMonthly);

router.post('/rekap/shiftly', kubController.rekapShiftly);
router.post('/rekap/daily', kubController.rekapDaily);
router.post('/rekap/weekly', kubController.rekapWeekly);
router.post('/rekap/monthly', kubController.rekapMonthly);

module.exports = router;
