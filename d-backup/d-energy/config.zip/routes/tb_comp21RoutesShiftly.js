const express = require('express');
const router = express.Router();
const comp21ControllerShiftly = require('../controllers/tb_comp21ControllerShiftly');

router.get('/', comp21ControllerShiftly.getAll);
router.get('/:id', comp21ControllerShiftly.getById);
router.post('/', comp21ControllerShiftly.create);
router.put('/:id', comp21ControllerShiftly.update);
router.delete('/:id', comp21ControllerShiftly.delete);

module.exports = router;