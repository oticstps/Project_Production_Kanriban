const express = require('express');
const router = express.Router();
const comp20ControllerMonthly = require('../controllers/tb_comp20ControllerMonthly');

router.get('/', comp20ControllerMonthly.getAll);
router.get('/:id', comp20ControllerMonthly.getById);
router.post('/', comp20ControllerMonthly.create);
router.put('/:id', comp20ControllerMonthly.update);
router.delete('/:id', comp20ControllerMonthly.delete);

module.exports = router;