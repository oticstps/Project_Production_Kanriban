const express = require('express');
const router = express.Router();

const PltsP2DailyControllerFullStack = require('../controllers/pltsP2DailyControllerFullStack');

router.get('/', PltsP2DailyControllerFullStack.getAll);

router.get('/:energy_date', PltsP2DailyControllerFullStack.getByDate);

router.post('/', PltsP2DailyControllerFullStack.create);

router.put('/:energy_date', PltsP2DailyControllerFullStack.update);

router.delete('/:energy_date', PltsP2DailyControllerFullStack.delete);

module.exports = router;