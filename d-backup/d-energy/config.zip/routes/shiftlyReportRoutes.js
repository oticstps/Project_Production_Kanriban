const express = require('express');
const router = express.Router();
const controller = require('../controllers/ShiftlyReportController');

router.get('/:table', controller.getAll);
router.get('/:table/range', controller.getByDateRange);
router.get('/:table/:pm_type/:line_table/:shift/:shift_date', controller.getByComposite);
router.post('/:table', controller.create);
router.put('/:table/:pm_type/:line_table/:shift/:shift_date', controller.update);
router.delete('/:table/:pm_type/:line_table/:shift/:shift_date', controller.delete);

module.exports = router;