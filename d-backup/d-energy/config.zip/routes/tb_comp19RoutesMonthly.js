const express = require('express');
const router = express.Router();
const comp19ControllerMonthly = require('../controllers/tb_comp19ControllerMonthly');

router.get('/', comp19ControllerMonthly.getAll);
router.get('/:id', comp19ControllerMonthly.getById);
router.post('/', comp19ControllerMonthly.create);
router.put('/:id', comp19ControllerMonthly.update);
router.delete('/:id', comp19ControllerMonthly.delete);

module.exports = router;