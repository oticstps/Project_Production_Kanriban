const express = require("express");
const router = express.Router();
const fullTextController = require("../controllers/fullTextController");

router.get("/", fullTextController.getAll);
router.get("/latest", fullTextController.getLatest);
router.get("/:id", fullTextController.getById);
router.post("/", fullTextController.create);
router.put("/:id", fullTextController.update);
router.delete("/:id", fullTextController.remove);

module.exports = router;