const express = require('express');
const TbKub1TotalKwhShiftlyController = require('../controllers/tb_kub1_total_kwh_shiftly');

const router = express.Router();

// Route statis harus ditempatkan sebelum route dinamis /:id.
router.get('/', TbKub1TotalKwhShiftlyController.getAll);
router.get('/date-range', TbKub1TotalKwhShiftlyController.getByDateRange);
router.get('/shift/:shift', TbKub1TotalKwhShiftlyController.getByShift);
router.get('/line-table/:line_table', TbKub1TotalKwhShiftlyController.getByLineTable);
router.get('/pm-type/:pm_type', TbKub1TotalKwhShiftlyController.getByPmType);

// Alias kompatibilitas untuk endpoint frontend lama.
router.get('/power-meter/:power_meter', TbKub1TotalKwhShiftlyController.getByPowerMeter);

router.get('/:id', TbKub1TotalKwhShiftlyController.getById);
router.post('/', TbKub1TotalKwhShiftlyController.create);
router.put('/:id', TbKub1TotalKwhShiftlyController.update);
router.delete('/:id', TbKub1TotalKwhShiftlyController.remove);

module.exports = router;
