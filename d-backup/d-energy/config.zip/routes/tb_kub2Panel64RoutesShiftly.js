const express = require('express');
const TbKub2Panel64ControllerShiftly = require('../controllers/tb_kub2Panel64ControllerShiftly');

const router = express.Router();

/**
 * Base URL yang disarankan:
 * /api/kub2/panel64/shiftly
 */

// Ringkasan harus diletakkan sebelum route /:id.
router.get('/summary', TbKub2Panel64ControllerShiftly.getSummary);

// CRUD.
router.get('/', TbKub2Panel64ControllerShiftly.getAll);
router.get('/:id', TbKub2Panel64ControllerShiftly.getById);
router.post('/', TbKub2Panel64ControllerShiftly.create);
router.post('/upsert', TbKub2Panel64ControllerShiftly.upsert);
router.put('/:id', TbKub2Panel64ControllerShiftly.update);
router.patch('/:id', TbKub2Panel64ControllerShiftly.update);
router.delete('/:id', TbKub2Panel64ControllerShiftly.delete);

module.exports = router;
