const express = require('express');
const router = express.Router();

const PltsP1DailyControllerFullStack = require('../controllers/pltsP1DailyControllerFullStack');

router.get('/', PltsP1DailyControllerFullStack.getAll);

router.get('/:energy_date', PltsP1DailyControllerFullStack.getByDate);

router.post('/', PltsP1DailyControllerFullStack.create);

router.put('/:energy_date', PltsP1DailyControllerFullStack.update);

router.delete('/:energy_date', PltsP1DailyControllerFullStack.delete);

module.exports = router;