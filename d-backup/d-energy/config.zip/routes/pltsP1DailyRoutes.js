const express = require("express");
const router = express.Router();

const {
  getAllData,
  getDataByDate,
  createOrUpdateData,
  bulkCreateOrUpdateData,
  updateData,
  deleteData,
} = require("../controllers/pltsP1DailyController");

router.get("/", getAllData);
router.get("/:energy_date", getDataByDate);
router.post("/", createOrUpdateData);
router.post("/bulk", bulkCreateOrUpdateData);
router.put("/:energy_date", updateData);
router.delete("/:energy_date", deleteData);

module.exports = router;