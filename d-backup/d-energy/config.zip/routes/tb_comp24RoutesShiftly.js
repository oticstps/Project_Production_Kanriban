const express = require('express');
const router = express.Router();
const comp24ControllerShiftly = require('../controllers/tb_comp24ControllerShiftly');

router.get('/', comp24ControllerShiftly.getAll);
router.get('/:id', comp24ControllerShiftly.getById);
router.post('/', comp24ControllerShiftly.create);
router.put('/:id', comp24ControllerShiftly.update);
router.delete('/:id', comp24ControllerShiftly.delete);

module.exports = router;