const express = require('express');
const upload = require('../middleware/upload.middleware');
const importController = require('../controllers/import.controller');

const router = express.Router();

router.post('/', upload.single('file'), importController.importFile);
router.get('/batches', importController.listBatches);
router.get('/batches/:id/records', importController.listBatchRecords);

module.exports = router;
