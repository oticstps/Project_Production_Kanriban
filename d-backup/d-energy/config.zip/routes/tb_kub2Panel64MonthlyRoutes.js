const express = require('express');

const router = express.Router();

const controller = require(
    '../controllers/tb_kub2Panel64MonthlyController'
);

// Ringkasan tahunan harus diletakkan sebelum route parameter.
router.get('/summary/yearly', controller.getYearlySummary);

// Mengambil seluruh data dengan filter dan pagination.
router.get('/', controller.getAll);

// Mengambil satu data berdasarkan composite key.
router.get(
    '/:pmType/:lineTable/:year/:month',
    controller.getByKey
);

// Menambahkan data baru.
router.post('/', controller.create);

// Memperbarui sebagian atau seluruh field non-composite-key.
router.put(
    '/:pmType/:lineTable/:year/:month',
    controller.update
);

router.patch(
    '/:pmType/:lineTable/:year/:month',
    controller.update
);

// Menghapus data.
router.delete(
    '/:pmType/:lineTable/:year/:month',
    controller.remove
);

module.exports = router;