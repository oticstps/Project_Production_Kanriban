const express = require('express');
const router = express.Router();
const comp24ControllerMonthly = require('../controllers/tb_comp24ControllerMonthly');

router.get('/', comp24ControllerMonthly.getAll);
router.get('/:id', comp24ControllerMonthly.getById);
router.post('/', comp24ControllerMonthly.create);
router.put('/:id', comp24ControllerMonthly.update);
router.delete('/:id', comp24ControllerMonthly.delete);

module.exports = router;