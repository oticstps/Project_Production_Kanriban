const express = require('express');
const router = express.Router();
const FullTextController = require('../controllers/fullTextController_p1');

router.get('/', FullTextController.getAll);
router.get('/latest', FullTextController.getLatest);
router.get('/:id', FullTextController.getById);
router.post('/', FullTextController.create);
router.put('/:id', FullTextController.update);
router.delete('/:id', FullTextController.delete);

module.exports = router;