const express = require('express');
const powerMeterController = require('../controllers/powerMeterController');

const router = express.Router();

router.get('/tables', powerMeterController.getTables);
router.get('/:table/latest', powerMeterController.getLatest);
router.get('/:table/date-bounds', powerMeterController.getDateBounds);
router.get('/:table/data', powerMeterController.getDataByDateTime);

module.exports = router;
