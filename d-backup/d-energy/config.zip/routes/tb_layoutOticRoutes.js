const express = require('express');
const router = express.Router();
const layoutOticController = require('../controllers/tb_layoutOticController');

router.get('/', layoutOticController.getAllData);
router.get('/:id', layoutOticController.getDataById);
router.post('/', layoutOticController.createData);
router.put('/:id', layoutOticController.updateData);
router.delete('/:id', layoutOticController.deleteData);

module.exports = router;