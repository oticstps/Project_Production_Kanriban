const express = require('express');
const router = express.Router();
const PltsP2HourlyControllerFullStack = require('../controllers/pltsP2HourlyControllerFullStack');

router.get('/', PltsP2HourlyControllerFullStack.index);
router.get('/latest', PltsP2HourlyControllerFullStack.latest);
router.get('/daily-summary', PltsP2HourlyControllerFullStack.dailySummary);
router.get('/:energy_date', PltsP2HourlyControllerFullStack.show);
router.post('/', PltsP2HourlyControllerFullStack.store);
router.post('/upsert', PltsP2HourlyControllerFullStack.upsert);
router.put('/:energy_date', PltsP2HourlyControllerFullStack.update);
router.delete('/:energy_date', PltsP2HourlyControllerFullStack.destroy);

module.exports = router;
