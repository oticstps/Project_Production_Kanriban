const db = require('../config/database');

const TABLE_NAME = 'tb_kub2_panel64_monthly';

const selectableColumns = `
    pm_type,
    line_table,
    line_name,
    start_kwh,
    end_kwh,
    total_kwh,
    year,
    month,
    month_name,
    month_start_date,
    month_end_date,
    month_start_datetime,
    month_end_datetime,
    created_at,
    updated_at
`;

/**
 * Mendapatkan seluruh data dengan filter dan pagination.
 */
const findAll = async ({
    pmType,
    lineTable,
    lineName,
    year,
    month,
    page = 1,
    limit = 20,
}) => {
    const conditions = [];
    const values = [];

    if (pmType) {
        conditions.push('pm_type = ?');
        values.push(pmType);
    }

    if (lineTable) {
        conditions.push('line_table = ?');
        values.push(lineTable);
    }

    if (lineName) {
        conditions.push('line_name LIKE ?');
        values.push(`%${lineName}%`);
    }

    if (year !== undefined && year !== null && year !== '') {
        conditions.push('year = ?');
        values.push(Number(year));
    }

    if (month !== undefined && month !== null && month !== '') {
        conditions.push('month = ?');
        values.push(Number(month));
    }

    const whereClause = conditions.length
        ? `WHERE ${conditions.join(' AND ')}`
        : '';

    const safePage = Math.max(Number(page) || 1, 1);
    const safeLimit = Math.min(Math.max(Number(limit) || 20, 1), 100);
    const offset = (safePage - 1) * safeLimit;

    const countQuery = `
        SELECT COUNT(*) AS total
        FROM ${TABLE_NAME}
        ${whereClause}
    `;

    const dataQuery = `
        SELECT ${selectableColumns}
        FROM ${TABLE_NAME}
        ${whereClause}
        ORDER BY year DESC, month DESC, pm_type ASC
        LIMIT ? OFFSET ?
    `;

    const [countRows] = await db.execute(countQuery, values);

    const [rows] = await db.execute(dataQuery, [
        ...values,
        safeLimit,
        offset,
    ]);

    const total = Number(countRows[0].total);
    const totalPages = Math.ceil(total / safeLimit);

    return {
        rows,
        pagination: {
            page: safePage,
            limit: safeLimit,
            total,
            totalPages,
        },
    };
};

/**
 * Mendapatkan satu data berdasarkan composite key.
 */
const findByKey = async (pmType, lineTable, year, month) => {
    const query = `
        SELECT ${selectableColumns}
        FROM ${TABLE_NAME}
        WHERE pm_type = ?
          AND line_table = ?
          AND year = ?
          AND month = ?
        LIMIT 1
    `;

    const [rows] = await db.execute(query, [
        pmType,
        lineTable,
        Number(year),
        Number(month),
    ]);

    return rows[0] || null;
};

/**
 * Menambahkan data bulanan baru.
 */
const create = async (data) => {
    const query = `
        INSERT INTO ${TABLE_NAME} (
            pm_type,
            line_table,
            line_name,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            month_start_date,
            month_end_date,
            month_start_datetime,
            month_end_datetime
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
        data.pm_type,
        data.line_table,
        data.line_name ?? null,
        data.start_kwh ?? null,
        data.end_kwh ?? null,
        data.total_kwh ?? null,
        data.year,
        data.month,
        data.month_name ?? null,
        data.month_start_date ?? null,
        data.month_end_date ?? null,
        data.month_start_datetime ?? null,
        data.month_end_datetime ?? null,
    ];

    await db.execute(query, values);

    return findByKey(
        data.pm_type,
        data.line_table,
        data.year,
        data.month
    );
};

/**
 * Memperbarui data berdasarkan composite key.
 *
 * Composite key tidak diubah:
 * pm_type, line_table, year, month.
 */
const update = async (pmType, lineTable, year, month, data) => {
    const allowedFields = [
        'line_name',
        'start_kwh',
        'end_kwh',
        'total_kwh',
        'month_name',
        'month_start_date',
        'month_end_date',
        'month_start_datetime',
        'month_end_datetime',
    ];

    const updates = [];
    const values = [];

    for (const field of allowedFields) {
        if (Object.prototype.hasOwnProperty.call(data, field)) {
            updates.push(`${field} = ?`);
            values.push(data[field]);
        }
    }

    if (updates.length === 0) {
        return {
            affectedRows: 0,
            data: await findByKey(pmType, lineTable, year, month),
        };
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');

    const query = `
        UPDATE ${TABLE_NAME}
        SET ${updates.join(', ')}
        WHERE pm_type = ?
          AND line_table = ?
          AND year = ?
          AND month = ?
    `;

    values.push(
        pmType,
        lineTable,
        Number(year),
        Number(month)
    );

    const [result] = await db.execute(query, values);

    return {
        affectedRows: result.affectedRows,
        data:
            result.affectedRows > 0
                ? await findByKey(pmType, lineTable, year, month)
                : null,
    };
};

/**
 * Menghapus data berdasarkan composite key.
 */
const remove = async (pmType, lineTable, year, month) => {
    const query = `
        DELETE FROM ${TABLE_NAME}
        WHERE pm_type = ?
          AND line_table = ?
          AND year = ?
          AND month = ?
    `;

    const [result] = await db.execute(query, [
        pmType,
        lineTable,
        Number(year),
        Number(month),
    ]);

    return result.affectedRows;
};

/**
 * Ringkasan konsumsi per tahun.
 */
const getYearlySummary = async ({
    pmType,
    lineTable,
    lineName,
    year,
}) => {
    const conditions = [];
    const values = [];

    if (pmType) {
        conditions.push('pm_type = ?');
        values.push(pmType);
    }

    if (lineTable) {
        conditions.push('line_table = ?');
        values.push(lineTable);
    }

    if (lineName) {
        conditions.push('line_name = ?');
        values.push(lineName);
    }

    if (year !== undefined && year !== null && year !== '') {
        conditions.push('year = ?');
        values.push(Number(year));
    }

    const whereClause = conditions.length
        ? `WHERE ${conditions.join(' AND ')}`
        : '';

    const query = `
        SELECT
            year,
            pm_type,
            line_table,
            line_name,
            COUNT(*) AS total_months,
            SUM(total_kwh) AS yearly_total_kwh,
            AVG(total_kwh) AS average_monthly_kwh,
            MIN(total_kwh) AS minimum_monthly_kwh,
            MAX(total_kwh) AS maximum_monthly_kwh
        FROM ${TABLE_NAME}
        ${whereClause}
        GROUP BY
            year,
            pm_type,
            line_table,
            line_name
        ORDER BY year DESC, pm_type ASC
    `;

    const [rows] = await db.execute(query, values);

    return rows;
};

module.exports = {
    findAll,
    findByKey,
    create,
    update,
    remove,
    getYearlySummary,
};