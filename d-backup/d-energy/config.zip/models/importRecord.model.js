async function bulkInsertImportRecords(connection, { batchId, importDate, rows }) {
  const values = rows.map((row, index) => [
    batchId,
    importDate,
    index + 1,
    JSON.stringify(row)
  ]);

  const [result] = await connection.query(
    `INSERT INTO import_records (batch_id, import_date, row_number, payload)
     VALUES ?`,
    [values]
  );

  return result.affectedRows;
}

async function getRecordsByBatchId(connection, batchId, limit = 100) {
  const [rows] = await connection.query(
    `SELECT id, batch_id, import_date, row_number, payload, created_at
     FROM import_records
     WHERE batch_id = ?
     ORDER BY row_number ASC
     LIMIT ?`,
    [batchId, Number(limit)]
  );

  return rows;
}

module.exports = {
  bulkInsertImportRecords,
  getRecordsByBatchId
};
