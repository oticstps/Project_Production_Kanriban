const db = require('../config/database');

class kubikal1CompPanel24 {
    // Ambil data terkini (hanya baris dengan id=1)
    static async getCurrent() {
        const [rows] = await db.query('SELECT * FROM tb_realtime_comp_24 WHERE id = 1');
        return rows.length ? rows[0] : null;
    }

    // Update umum (partial) – field dikirim dalam objek (nama field harus sesuai tabel)
    static async update(data) {
        delete data.id; // jangan ubah primary key
        const fields = Object.keys(data);
        if (fields.length === 0) return null;

        const placeholders = fields.map(() => '?').join(', ');
        const updates = fields.map(f => `${f} = VALUES(${f})`).join(', ') + ', timestamp = NOW()';

        const sql = `
            INSERT INTO tb_realtime_comp_24 (id, ${fields.join(', ')})
            VALUES (1, ${placeholders})
            ON DUPLICATE KEY UPDATE ${updates}
        `;
        const values = fields.map(f => data[f]);
        const [result] = await db.query(sql, values);
        return result;
    }

    // 1. Arus (Current) per fasa
    static async updateCurrent(data) {
        const { current_avg_ext, current_a_ext, current_b_ext, current_c_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, current_avg_ext, current_a_ext, current_b_ext, current_c_ext)
            VALUES (1, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                current_avg_ext = VALUES(current_avg_ext),
                current_a_ext = VALUES(current_a_ext),
                current_b_ext = VALUES(current_b_ext),
                current_c_ext = VALUES(current_c_ext),
                timestamp = NOW()
        `;
        const values = [current_avg_ext, current_a_ext, current_b_ext, current_c_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 2. Tegangan Line‑to‑Line (Voltage LL)
    static async updateVoltageLL(data) {
        const { voltage_ab_ext, voltage_bc_ext, voltage_ca_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, voltage_ab_ext, voltage_bc_ext, voltage_ca_ext)
            VALUES (1, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                voltage_ab_ext = VALUES(voltage_ab_ext),
                voltage_bc_ext = VALUES(voltage_bc_ext),
                voltage_ca_ext = VALUES(voltage_ca_ext),
                timestamp = NOW()
        `;
        const values = [voltage_ab_ext, voltage_bc_ext, voltage_ca_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 3. Tegangan Line‑to‑Neutral (Voltage LN)
    static async updateVoltageLN(data) {
        const { voltage_an_ext, voltage_bn_ext, voltage_cn_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, voltage_an_ext, voltage_bn_ext, voltage_cn_ext)
            VALUES (1, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                voltage_an_ext = VALUES(voltage_an_ext),
                voltage_bn_ext = VALUES(voltage_bn_ext),
                voltage_cn_ext = VALUES(voltage_cn_ext),
                timestamp = NOW()
        `;
        const values = [voltage_an_ext, voltage_bn_ext, voltage_cn_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 4. Daya Aktif (Active Power)
    static async updateActivePower(data) {
        const { active_power_a_ext, active_power_b_ext, active_power_c_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, active_power_a_ext, active_power_b_ext, active_power_c_ext)
            VALUES (1, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                active_power_a_ext = VALUES(active_power_a_ext),
                active_power_b_ext = VALUES(active_power_b_ext),
                active_power_c_ext = VALUES(active_power_c_ext),
                timestamp = NOW()
        `;
        const values = [active_power_a_ext, active_power_b_ext, active_power_c_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 5. Daya Semu (Apparent Power)
    static async updateApparentPower(data) {
        const { apparent_power_a_ext, apparent_power_b_ext, apparent_power_c_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, apparent_power_a_ext, apparent_power_b_ext, apparent_power_c_ext)
            VALUES (1, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                apparent_power_a_ext = VALUES(apparent_power_a_ext),
                apparent_power_b_ext = VALUES(apparent_power_b_ext),
                apparent_power_c_ext = VALUES(apparent_power_c_ext),
                timestamp = NOW()
        `;
        const values = [apparent_power_a_ext, apparent_power_b_ext, apparent_power_c_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 6. Faktor Daya (Power Factor)
    static async updatePowerFactor(data) {
        const { power_factor_a_ext, power_factor_b_ext, power_factor_c_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, power_factor_a_ext, power_factor_b_ext, power_factor_c_ext)
            VALUES (1, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                power_factor_a_ext = VALUES(power_factor_a_ext),
                power_factor_b_ext = VALUES(power_factor_b_ext),
                power_factor_c_ext = VALUES(power_factor_c_ext),
                timestamp = NOW()
        `;
        const values = [power_factor_a_ext, power_factor_b_ext, power_factor_c_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 7. Daya Reaktif (Reactive Power)
    static async updateReactivePower(data) {
        const { reactive_power_a_ext, reactive_power_b_ext, reactive_power_c_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, reactive_power_a_ext, reactive_power_b_ext, reactive_power_c_ext)
            VALUES (1, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                reactive_power_a_ext = VALUES(reactive_power_a_ext),
                reactive_power_b_ext = VALUES(reactive_power_b_ext),
                reactive_power_c_ext = VALUES(reactive_power_c_ext),
                timestamp = NOW()
        `;
        const values = [reactive_power_a_ext, reactive_power_b_ext, reactive_power_c_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 8. Frekuensi (Frequency)
    static async updateFrequency(data) {
        const { frequency_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, frequency_ext)
            VALUES (1, ?)
            ON DUPLICATE KEY UPDATE
                frequency_ext = VALUES(frequency_ext),
                timestamp = NOW()
        `;
        const values = [frequency_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 9. Energi Forward (kVAh, kWh, kVARh induktif & kapasitif)
    static async updateForwardEnergy(data) {
        const { fwdVAh_ext, fwdWh_ext, fwdVARh_ind_ext, fwdVARh_cap_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, fwdVAh_ext, fwdWh_ext, fwdVARh_ind_ext, fwdVARh_cap_ext)
            VALUES (1, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                fwdVAh_ext = VALUES(fwdVAh_ext),
                fwdWh_ext = VALUES(fwdWh_ext),
                fwdVARh_ind_ext = VALUES(fwdVARh_ind_ext),
                fwdVARh_cap_ext = VALUES(fwdVARh_cap_ext),
                timestamp = NOW()
        `;
        const values = [fwdVAh_ext, fwdWh_ext, fwdVARh_ind_ext, fwdVARh_cap_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 10. Energi Reverse (kVAh, kWh, kVARh induktif & kapasitif)
    static async updateReverseEnergy(data) {
        const { revVAh_ext, revWh_ext, revVARh_ind_ext, revVARh_cap_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, revVAh_ext, revWh_ext, revVARh_ind_ext, revVARh_cap_ext)
            VALUES (1, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                revVAh_ext = VALUES(revVAh_ext),
                revWh_ext = VALUES(revWh_ext),
                revVARh_ind_ext = VALUES(revVARh_ind_ext),
                revVARh_cap_ext = VALUES(revVARh_cap_ext),
                timestamp = NOW()
        `;
        const values = [revVAh_ext, revWh_ext, revVARh_ind_ext, revVARh_cap_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 11. Demand (saat ini dan maksimum)
    static async updateDemand(data) {
        const { present_demand_ext, rising_demand_ext } = data;
        const sql = `
            INSERT INTO tb_realtime_comp_24 
                (id, present_demand_ext, rising_demand_ext)
            VALUES (1, ?, ?)
            ON DUPLICATE KEY UPDATE
                present_demand_ext = VALUES(present_demand_ext),
                rising_demand_ext = VALUES(rising_demand_ext),
                timestamp = NOW()
        `;
        const values = [present_demand_ext, rising_demand_ext];
        const [result] = await db.query(sql, values);
        return result;
    }

    // Hapus data (opsional)
    static async delete() {
        const sql = 'DELETE FROM tb_realtime_comp_24 WHERE id = 1';
        const [result] = await db.query(sql);
        return result;
    }
}

module.exports = kubikal1CompPanel24;