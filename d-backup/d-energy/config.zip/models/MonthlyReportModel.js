const db = require('../config/database');
const { MONTHLY_TABLES } = require('../constants/reportTables');
const validateTable = require('../helpers/validateTable');

const MonthlyReportModel = {
    getAll: async (tableName, limit = 500) => {
        validateTable(tableName, MONTHLY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName} ORDER BY year DESC, month DESC LIMIT ?`,
            [limit]
        );
        return rows;
    },

    getByComposite: async (tableName, pm_type, line_table, year, month) => {
        validateTable(tableName, MONTHLY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE pm_type = ? AND line_table = ? AND year = ? AND month = ?`,
            [pm_type, line_table, year, month]
        );
        return rows[0];
    },

    create: async (tableName, data) => {
        validateTable(tableName, MONTHLY_TABLES);

        const {
            pm_type, line_table, line_name,
            year, month, month_name,
            month_start_date, month_end_date,
            month_start_datetime, month_end_datetime,
            start_kwh, end_kwh, total_kwh
        } = data;

        await db.execute(
            `INSERT INTO ${tableName}
            (pm_type, line_table, line_name, year, month, month_name,
             month_start_date, month_end_date,
             month_start_datetime, month_end_datetime,
             start_kwh, end_kwh, total_kwh, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [
                pm_type, line_table, line_name,
                year, month, month_name,
                month_start_date, month_end_date,
                month_start_datetime, month_end_datetime,
                start_kwh, end_kwh, total_kwh
            ]
        );

        return { pm_type, line_table, year, month };
    },

    update: async (tableName, pm_type, line_table, year, month, data) => {
        validateTable(tableName, MONTHLY_TABLES);

        const {
            line_name, month_name,
            month_start_date, month_end_date,
            month_start_datetime, month_end_datetime,
            start_kwh, end_kwh, total_kwh
        } = data;

        const [result] = await db.execute(
            `UPDATE ${tableName}
             SET line_name = ?, month_name = ?,
                 month_start_date = ?, month_end_date = ?,
                 month_start_datetime = ?, month_end_datetime = ?,
                 start_kwh = ?, end_kwh = ?, total_kwh = ?,
                 updated_at = NOW()
             WHERE pm_type = ? AND line_table = ? AND year = ? AND month = ?`,
            [
                line_name, month_name,
                month_start_date, month_end_date,
                month_start_datetime, month_end_datetime,
                start_kwh, end_kwh, total_kwh,
                pm_type, line_table, year, month
            ]
        );

        return result.affectedRows;
    },

    delete: async (tableName, pm_type, line_table, year, month) => {
        validateTable(tableName, MONTHLY_TABLES);
        const [result] = await db.execute(
            `DELETE FROM ${tableName}
             WHERE pm_type = ? AND line_table = ? AND year = ? AND month = ?`,
            [pm_type, line_table, year, month]
        );
        return result.affectedRows;
    },

    getByYear: async (tableName, year) => {
        validateTable(tableName, MONTHLY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE year = ?
             ORDER BY month DESC`,
            [year]
        );
        return rows;
    }
};

module.exports = MonthlyReportModel;