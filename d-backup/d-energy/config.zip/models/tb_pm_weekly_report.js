const db = require('../config/database');

const TbWeeklyWh = {
    // Mendapatkan semua data, diurutkan berdasarkan tahun dan minggu terbaru
    getAll: async (limit = 500) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_weekly_report ORDER BY year DESC, week_number DESC LIMIT ?',
            [limit]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan kombinasi unik (pm_type, line_table, year, week_number)
    getByComposite: async (pm_type, line_table, year, week_number) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_weekly_report WHERE pm_type = ? AND line_table = ? AND year = ? AND week_number = ?',
            [pm_type, line_table, year, week_number]
        );
        return rows[0];
    },

    // Membuat data baru
    create: async (data) => {
        const { pm_type, line_table, line_name, start_datetime, end_datetime,
                start_wh, last_wh, total_wh, year, week_number, week_name } = data;
        const [result] = await db.execute(
            `INSERT INTO tb_pm_weekly_report 
            (pm_type, line_table, line_name, start_datetime, end_datetime, 
             start_wh, last_wh, total_wh, year, week_number, week_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [pm_type, line_table, line_name, start_datetime, end_datetime,
             start_wh, last_wh, total_wh, year, week_number, week_name]
        );
        // Mengembalikan informasi kombinasi unik (karena tidak ada auto increment)
        return { pm_type, line_table, year, week_number };
    },

    // Memperbarui data berdasarkan kombinasi unik
    update: async (pm_type, line_table, year, week_number, data) => {
        const { line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh, week_name } = data;
        const [result] = await db.execute(
            `UPDATE tb_pm_weekly_report 
            SET line_name = ?, start_datetime = ?, end_datetime = ?, 
                start_wh = ?, last_wh = ?, total_wh = ?, week_name = ?, created_at = NOW()
            WHERE pm_type = ? AND line_table = ? AND year = ? AND week_number = ?`,
            [line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh, week_name,
             pm_type, line_table, year, week_number]
        );
        return result.affectedRows;
    },

    // Menghapus data berdasarkan kombinasi unik
    delete: async (pm_type, line_table, year, week_number) => {
        const [result] = await db.execute(
            'DELETE FROM tb_pm_weekly_report WHERE pm_type = ? AND line_table = ? AND year = ? AND week_number = ?',
            [pm_type, line_table, year, week_number]
        );
        return result.affectedRows;
    },

    // Mendapatkan data berdasarkan rentang tanggal (menggunakan start_datetime)
    getByDateRange: async (startDate, endDate) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_weekly_report WHERE start_datetime BETWEEN ? AND ? ORDER BY year DESC, week_number DESC',
            [startDate, endDate]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan line_table
    getByLineTable: async (line_table) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_weekly_report WHERE line_table = ? ORDER BY year DESC, week_number DESC',
            [line_table]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan pm_type
    getByPmType: async (pm_type) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_weekly_report WHERE pm_type = ? ORDER BY year DESC, week_number DESC',
            [pm_type]
        );
        return rows;
    }
};

module.exports = TbWeeklyWh;