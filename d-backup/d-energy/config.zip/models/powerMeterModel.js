const db = require('../config/database');
const {
  POWER_METER_TABLES,
  POWER_METER_TABLE_SET,
} = require('../constants/powerMeterTables');
const HttpError = require('../utils/httpError');

const SELECT_COLUMNS = [
  'idPrimary',
  'date_time',
  'power_meter',
  'value',
  'shift',
  'day',
  'week',
  'month',
  'year',
].map((column) => `\`${column}\``).join(', ');

function assertAllowedTable(tableName) {
  if (!POWER_METER_TABLE_SET.has(tableName)) {
    throw new HttpError(400, 'Nama tabel tidak diizinkan.', {
      table: tableName,
    });
  }

  return tableName;
}

function buildWhere(filters = {}) {
  const clauses = [];
  const params = [];

  if (filters.exactDateTime) {
    clauses.push('`date_time` = ?');
    params.push(filters.exactDateTime);
  }

  if (filters.dayStart && filters.dayEndExclusive) {
    clauses.push('`date_time` >= ? AND `date_time` < ?');
    params.push(`${filters.dayStart} 00:00:00`, `${filters.dayEndExclusive} 00:00:00`);
  }

  if (filters.startDateTime) {
    clauses.push('`date_time` >= ?');
    params.push(filters.startDateTime);
  }

  if (filters.endDateTime) {
    clauses.push('`date_time` <= ?');
    params.push(filters.endDateTime);
  }

  return {
    whereSql: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '',
    params,
  };
}

async function findRows({
  tableName,
  filters,
  order = 'DESC',
  limit = 100,
  offset = 0,
}) {
  const table = assertAllowedTable(tableName);
  const safeOrder = order === 'ASC' ? 'ASC' : 'DESC';
  const { whereSql, params } = buildWhere(filters);

  // limit dan offset sudah divalidasi sebagai integer oleh controller.
  const dataSql = `
    SELECT ${SELECT_COLUMNS}
    FROM \`${table}\`
    ${whereSql}
    ORDER BY \`date_time\` ${safeOrder}, \`idPrimary\` ${safeOrder}
    LIMIT ${limit} OFFSET ${offset}
  `;

  const countSql = `
    SELECT COUNT(*) AS total
    FROM \`${table}\`
    ${whereSql}
  `;

  const [[rows], [countRows]] = await Promise.all([
    db.execute(dataSql, params),
    db.execute(countSql, params),
  ]);

  return {
    rows,
    total: Number(countRows[0]?.total || 0),
  };
}

async function findLatest({ tableName, limit = 1 }) {
  const table = assertAllowedTable(tableName);

  const sql = `
    SELECT ${SELECT_COLUMNS}
    FROM \`${table}\`
    ORDER BY \`date_time\` DESC, \`idPrimary\` DESC
    LIMIT ${limit}
  `;

  const [rows] = await db.execute(sql);
  return rows;
}

async function getDateBounds(tableName) {
  const table = assertAllowedTable(tableName);

  const sql = `
    SELECT
      MIN(\`date_time\`) AS oldest_date_time,
      MAX(\`date_time\`) AS newest_date_time,
      COUNT(*) AS total_rows
    FROM \`${table}\`
  `;

  const [rows] = await db.execute(sql);

  return {
    oldest_date_time: rows[0]?.oldest_date_time || null,
    newest_date_time: rows[0]?.newest_date_time || null,
    total_rows: Number(rows[0]?.total_rows || 0),
  };
}

function getAllowedTables() {
  return POWER_METER_TABLES;
}

module.exports = {
  findRows,
  findLatest,
  getDateBounds,
  getAllowedTables,
  assertAllowedTable,
};
