const db = require("../config/database");

const TABLE_NAME = "tb_plts_p2_hourly";

const bulkUpsertP2Hourly = async (rows) => {
  if (!Array.isArray(rows) || rows.length === 0) {
    return { affectedRows: 0 };
  }

  const values = rows.map((row) => [
    row.energy_date,
    row.purchased_from_grid_kwh,
    row.generated_by_pv_kwh,
    row.fed_to_grid_kwh,
    row.consumed_by_appliances_kwh,
  ]);

  const sql = `
    INSERT INTO ${TABLE_NAME}
      (
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      )
    VALUES ?
    ON DUPLICATE KEY UPDATE
      purchased_from_grid_kwh = VALUES(purchased_from_grid_kwh),
      generated_by_pv_kwh = VALUES(generated_by_pv_kwh),
      fed_to_grid_kwh = VALUES(fed_to_grid_kwh),
      consumed_by_appliances_kwh = VALUES(consumed_by_appliances_kwh)
  `;

  const [result] = await db.query(sql, [values]);
  return result;
};

const findP2HourlyByDate = async (dateCustom) => {
  const sql = `
    SELECT
      DATE_FORMAT(energy_date, '%Y-%m-%d %H:%i:%s') AS energy_date,
      TIME_FORMAT(TIME(energy_date), '%H:%i') AS time_value,
      purchased_from_grid_kwh,
      generated_by_pv_kwh,
      fed_to_grid_kwh,
      consumed_by_appliances_kwh
    FROM ${TABLE_NAME}
    WHERE energy_date >= ?
      AND energy_date < DATE_ADD(?, INTERVAL 1 DAY)
    ORDER BY energy_date ASC
  `;

  const [rows] = await db.query(sql, [dateCustom, dateCustom]);
  return rows;
};

module.exports = {
  bulkUpsertP2Hourly,
  findP2HourlyByDate,
};