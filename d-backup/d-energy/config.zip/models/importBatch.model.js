async function createImportBatch(connection, { importDate, originalFilename, totalRows }) {
  const [result] = await connection.query(
    `INSERT INTO import_batches (import_date, original_filename, total_rows)
     VALUES (?, ?, ?)`,
    [importDate, originalFilename, totalRows]
  );

  return result.insertId;
}

async function getImportBatches(connection, limit = 20) {
  const [rows] = await connection.query(
    `SELECT id, import_date, original_filename, total_rows, created_at
     FROM import_batches
     ORDER BY created_at DESC
     LIMIT ?`,
    [Number(limit)]
  );

  return rows;
}

module.exports = {
  createImportBatch,
  getImportBatches
};
