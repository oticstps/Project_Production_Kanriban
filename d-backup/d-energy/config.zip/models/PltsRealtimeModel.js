const db = require("../config/database");

const tableMap = {
  "plant-1": "tb_plts_plant_1_realtime",
  "plant-2": "tb_plts_plant_2_realtime",
};

function getTableName(plant) {
  const tableName = tableMap[plant];

  if (!tableName) {
    throw new Error("Plant tidak valid. Gunakan plant-1 atau plant-2.");
  }

  return tableName;
}

class PltsRealtimeModel {
  static async getAllData(plant, limit = 100) {
    const tableName = getTableName(plant);

    const [rows] = await db.query(
      `
      SELECT 
        idPrimary,
        date_time,
        power,
        kwh
      FROM ${tableName}
      ORDER BY date_time DESC
      LIMIT ?
      `,
      [Number(limit)]
    );

    return rows;
  }

  static async getLatestData(plant) {
    const tableName = getTableName(plant);

    const [rows] = await db.query(
      `
      SELECT 
        idPrimary,
        date_time,
        power,
        kwh
      FROM ${tableName}
      ORDER BY date_time DESC
      LIMIT 1
      `
    );

    return rows[0] || null;
  }

  static async getDataByDateRange(plant, startDate, endDate) {
    const tableName = getTableName(plant);

    const [rows] = await db.query(
      `
      SELECT 
        idPrimary,
        date_time,
        power,
        kwh
      FROM ${tableName}
      WHERE date_time BETWEEN ? AND ?
      ORDER BY date_time ASC
      `,
      [startDate, endDate]
    );

    return rows;
  }

  static async insertData(plant, data) {
    const tableName = getTableName(plant);

    const { date_time, power, kwh } = data;

    const [result] = await db.query(
      `
      INSERT INTO ${tableName} 
      (date_time, power, kwh)
      VALUES (?, ?, ?)
      `,
      [date_time, power, kwh]
    );

    return {
      idPrimary: result.insertId,
      date_time,
      power,
      kwh,
    };
  }

  static async deleteData(plant, idPrimary) {
    const tableName = getTableName(plant);

    const [result] = await db.query(
      `
      DELETE FROM ${tableName}
      WHERE idPrimary = ?
      `,
      [idPrimary]
    );

    return result.affectedRows;
  }
}

module.exports = PltsRealtimeModel;