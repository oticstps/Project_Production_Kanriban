const db = require('../config/database');

const TABLE_NAME = 'tb_kub2_panel63_shiftly';

const COLUMNS = `
    id,
    pm_type,
    line_table,
    line_name,
    shift,
    shift_date,
    shift_start_datetime,
    shift_end_datetime,
    start_kwh,
    end_kwh,
    total_kwh,
    year,
    month,
    month_name,
    day,
    day_name,
    created_at,
    updated_at
`;

/**
 * Mendukung konfigurasi database mysql/mysql2 callback
 * maupun mysql2/promise.
 */
const query = (sql, params = []) => {
    if (!db || typeof db.query !== 'function') {
        return Promise.reject(
            new Error('Database connection tidak valid. Pastikan db.query tersedia.')
        );
    }

    // mysql/mysql2 callback style.
    if (db.query.length >= 3) {
        return new Promise((resolve, reject) => {
            db.query(sql, params, (error, results) => {
                if (error) {
                    reject(error);
                    return;
                }

                resolve(results);
            });
        });
    }

    // mysql2/promise style.
    return Promise.resolve(db.query(sql, params)).then((result) => {
        if (Array.isArray(result) && result.length === 2) {
            return result[0];
        }

        return result;
    });
};

const INSERTABLE_FIELDS = [
    'pm_type',
    'line_table',
    'line_name',
    'shift',
    'shift_date',
    'shift_start_datetime',
    'shift_end_datetime',
    'start_kwh',
    'end_kwh',
    'total_kwh',
    'year',
    'month',
    'month_name',
    'day',
    'day_name'
];

const UPDATABLE_FIELDS = [...INSERTABLE_FIELDS];

class TbKub2Panel63ModelShiftly {
    static async findAll(filters = {}) {
        const conditions = [];
        const params = [];

        if (filters.pm_type) {
            conditions.push('pm_type = ?');
            params.push(filters.pm_type);
        }

        if (filters.line_table) {
            conditions.push('line_table = ?');
            params.push(filters.line_table);
        }

        if (filters.line_name) {
            conditions.push('line_name = ?');
            params.push(filters.line_name);
        }

        if (filters.shift) {
            conditions.push('shift = ?');
            params.push(filters.shift);
        }

        if (filters.shift_date) {
            conditions.push('shift_date = ?');
            params.push(filters.shift_date);
        }

        if (filters.start_date) {
            conditions.push('shift_date >= ?');
            params.push(filters.start_date);
        }

        if (filters.end_date) {
            conditions.push('shift_date <= ?');
            params.push(filters.end_date);
        }

        if (filters.year !== undefined) {
            conditions.push('year = ?');
            params.push(filters.year);
        }

        if (filters.month !== undefined) {
            conditions.push('month = ?');
            params.push(filters.month);
        }

        if (filters.day !== undefined) {
            conditions.push('day = ?');
            params.push(filters.day);
        }

        if (filters.q) {
            conditions.push(`(
                pm_type LIKE ?
                OR line_table LIKE ?
                OR line_name LIKE ?
                OR shift LIKE ?
            )`);

            const keyword = `%${filters.q}%`;
            params.push(keyword, keyword, keyword, keyword);
        }

        const whereClause = conditions.length
            ? `WHERE ${conditions.join(' AND ')}`
            : '';

        const allowedSortColumns = new Set([
            'id',
            'pm_type',
            'line_table',
            'line_name',
            'shift',
            'shift_date',
            'shift_start_datetime',
            'shift_end_datetime',
            'start_kwh',
            'end_kwh',
            'total_kwh',
            'year',
            'month',
            'day',
            'created_at',
            'updated_at'
        ]);

        const sortBy = allowedSortColumns.has(filters.sort_by)
            ? filters.sort_by
            : 'shift_date';

        const sortOrder =
            String(filters.sort_order).toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

        const page = Math.max(Number.parseInt(filters.page, 10) || 1, 1);
        const limit = Math.min(
            Math.max(Number.parseInt(filters.limit, 10) || 20, 1),
            500
        );
        const offset = (page - 1) * limit;

        const dataSql = `
            SELECT ${COLUMNS}
            FROM ${TABLE_NAME}
            ${whereClause}
            ORDER BY ${sortBy} ${sortOrder}, id ${sortOrder}
            LIMIT ${limit} OFFSET ${offset}
        `;

        const countSql = `
            SELECT COUNT(*) AS total
            FROM ${TABLE_NAME}
            ${whereClause}
        `;

        const [rows, countRows] = await Promise.all([
            query(dataSql, params),
            query(countSql, params)
        ]);

        const total = Number(countRows?.[0]?.total || 0);

        return {
            rows,
            pagination: {
                page,
                limit,
                total,
                total_pages: Math.ceil(total / limit)
            }
        };
    }

    static async findById(id) {
        const sql = `
            SELECT ${COLUMNS}
            FROM ${TABLE_NAME}
            WHERE id = ?
            LIMIT 1
        `;

        const rows = await query(sql, [id]);
        return rows[0] || null;
    }

    static async create(payload) {
        const fields = INSERTABLE_FIELDS.filter(
            (field) => payload[field] !== undefined
        );

        if (fields.length === 0) {
            throw new Error('Tidak ada data yang dapat disimpan.');
        }

        const placeholders = fields.map(() => '?').join(', ');
        const values = fields.map((field) => payload[field]);

        const sql = `
            INSERT INTO ${TABLE_NAME}
                (${fields.join(', ')}, created_at, updated_at)
            VALUES
                (${placeholders}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `;

        const result = await query(sql, values);
        return this.findById(result.insertId);
    }

    static async update(id, payload) {
        const fields = UPDATABLE_FIELDS.filter(
            (field) => payload[field] !== undefined
        );

        if (fields.length === 0) {
            return this.findById(id);
        }

        const assignments = fields.map((field) => `${field} = ?`);
        const values = fields.map((field) => payload[field]);

        assignments.push('updated_at = CURRENT_TIMESTAMP');
        values.push(id);

        const sql = `
            UPDATE ${TABLE_NAME}
            SET ${assignments.join(', ')}
            WHERE id = ?
        `;

        const result = await query(sql, values);

        if (!result.affectedRows) {
            return null;
        }

        return this.findById(id);
    }

    static async upsert(payload) {
        const fields = INSERTABLE_FIELDS.filter(
            (field) => payload[field] !== undefined
        );

        if (fields.length === 0) {
            throw new Error('Tidak ada data yang dapat disimpan.');
        }

        const placeholders = fields.map(() => '?').join(', ');
        const values = fields.map((field) => payload[field]);

        const updateFields = fields.filter(
            (field) => !['line_table', 'shift_date', 'shift'].includes(field)
        );

        const updateAssignments = updateFields.map(
            (field) => `${field} = VALUES(${field})`
        );

        updateAssignments.push(
            'id = LAST_INSERT_ID(id)',
            'updated_at = CURRENT_TIMESTAMP'
        );

        const sql = `
            INSERT INTO ${TABLE_NAME}
                (${fields.join(', ')}, created_at, updated_at)
            VALUES
                (${placeholders}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
                ${updateAssignments.join(', ')}
        `;

        const result = await query(sql, values);
        return this.findById(result.insertId);
    }

    static async delete(id) {
        const sql = `DELETE FROM ${TABLE_NAME} WHERE id = ?`;
        const result = await query(sql, [id]);
        return result.affectedRows > 0;
    }

    static async getSummary(filters = {}) {
        const conditions = [];
        const params = [];

        if (filters.pm_type) {
            conditions.push('pm_type = ?');
            params.push(filters.pm_type);
        }

        if (filters.line_table) {
            conditions.push('line_table = ?');
            params.push(filters.line_table);
        }

        if (filters.line_name) {
            conditions.push('line_name = ?');
            params.push(filters.line_name);
        }

        if (filters.shift) {
            conditions.push('shift = ?');
            params.push(filters.shift);
        }

        if (filters.shift_date) {
            conditions.push('shift_date = ?');
            params.push(filters.shift_date);
        }

        if (filters.start_date) {
            conditions.push('shift_date >= ?');
            params.push(filters.start_date);
        }

        if (filters.end_date) {
            conditions.push('shift_date <= ?');
            params.push(filters.end_date);
        }

        if (filters.year !== undefined) {
            conditions.push('year = ?');
            params.push(filters.year);
        }

        if (filters.month !== undefined) {
            conditions.push('month = ?');
            params.push(filters.month);
        }

        const whereClause = conditions.length
            ? `WHERE ${conditions.join(' AND ')}`
            : '';

        const sql = `
            SELECT
                shift,
                COUNT(*) AS total_records,
                COALESCE(SUM(total_kwh), 0) AS total_kwh,
                COALESCE(AVG(total_kwh), 0) AS average_kwh,
                COALESCE(MIN(total_kwh), 0) AS minimum_kwh,
                COALESCE(MAX(total_kwh), 0) AS maximum_kwh,
                MIN(shift_date) AS first_shift_date,
                MAX(shift_date) AS last_shift_date
            FROM ${TABLE_NAME}
            ${whereClause}
            GROUP BY shift
            ORDER BY shift ASC
        `;

        return query(sql, params);
    }
}

module.exports = TbKub2Panel63ModelShiftly;
