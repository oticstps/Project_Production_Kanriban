const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

// Ambil semua data (urut berdasarkan created_at terbaru)
const getAll = async () => {
  const [rows] = await db.query('SELECT * FROM tb_comp_24_monthly ORDER BY created_at DESC');
  return rows;
};

// Ambil data berdasarkan ID (UUID)
const getById = async (id) => {
  const [rows] = await db.query('SELECT * FROM tb_comp_24_monthly WHERE id = ?', [id]);
  return rows[0];
};

// Tambah data baru
const create = async (data) => {
  const id = uuidv4(); // generate UUID v4
  const {
    pm_type, line_table, line_name, shift, shift_date,
    shift_start_datetime, shift_end_datetime, start_kwh, end_kwh,
    total_kwh, year, month, month_name, day, day_name
  } = data;

  const query = `
    INSERT INTO tb_comp_24_monthly (
      id, pm_type, line_table, line_name, shift, shift_date,
      shift_start_datetime, shift_end_datetime, start_kwh, end_kwh,
      total_kwh, year, month, month_name, day, day_name
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const params = [
    id, pm_type, line_table, line_name, shift, shift_date,
    shift_start_datetime, shift_end_datetime, start_kwh, end_kwh,
    total_kwh, year, month, month_name, day, day_name
  ];

  await db.query(query, params);

  // Ambil data yang baru saja dimasukkan (termasuk created_at dan updated_at)
  const [newRow] = await db.query('SELECT * FROM tb_comp_24_monthly WHERE id = ?', [id]);
  return newRow[0];
};

// Update data berdasarkan ID
const update = async (id, data) => {
  const {
    pm_type, line_table, line_name, shift, shift_date,
    shift_start_datetime, shift_end_datetime, start_kwh, end_kwh,
    total_kwh, year, month, month_name, day, day_name
  } = data;

  const query = `
    UPDATE tb_comp_24_monthly
    SET pm_type = ?, line_table = ?, line_name = ?, shift = ?, shift_date = ?,
        shift_start_datetime = ?, shift_end_datetime = ?, start_kwh = ?, end_kwh = ?,
        total_kwh = ?, year = ?, month = ?, month_name = ?, day = ?, day_name = ?
    WHERE id = ?
  `;

  const params = [
    pm_type, line_table, line_name, shift, shift_date,
    shift_start_datetime, shift_end_datetime, start_kwh, end_kwh,
    total_kwh, year, month, month_name, day, day_name, id
  ];

  const [result] = await db.query(query, params);
  return result.affectedRows > 0;
};

// Hapus data berdasarkan ID
const deleteById = async (id) => {
  const [result] = await db.query('DELETE FROM tb_comp_24_monthly WHERE id = ?', [id]);
  return result.affectedRows > 0;
};

module.exports = {
  getAll,
  getById,
  create,
  update,
  deleteById
};