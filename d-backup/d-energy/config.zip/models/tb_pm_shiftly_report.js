const db = require('../config/database');

const TbShiftlyWh = {
    // Mendapatkan semua data, diurutkan berdasarkan shift_date terbaru dan shift
    getAll: async (limit = 1000) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_shiftly_report ORDER BY shift_date DESC, shift LIMIT ?',
            [limit]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan kombinasi unik (primary key komposit)
    getByComposite: async (pm_type, line_table, line_name, shift_date, shift) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_shiftly_report WHERE pm_type = ? AND line_table = ? AND line_name = ? AND shift_date = ? AND shift = ?',
            [pm_type, line_table, line_name, shift_date, shift]
        );
        return rows[0];
    },

    // Membuat data baru
    create: async (data) => {
        const { pm_type, line_table, line_name, shift, shift_date,
                shift_start_datetime, shift_end_datetime,
                start_kwh, end_kwh, total_kwh,
                year, month, month_name, day, day_name } = data;
        const [result] = await db.execute(
            `INSERT INTO tb_pm_shiftly_report 
            (pm_type, line_table, line_name, shift, shift_date,
             shift_start_datetime, shift_end_datetime,
             start_kwh, end_kwh, total_kwh,
             year, month, month_name, day, day_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [pm_type, line_table, line_name, shift, shift_date,
             shift_start_datetime, shift_end_datetime,
             start_kwh, end_kwh, total_kwh,
             year, month, month_name, day, day_name]
        );
        // Mengembalikan objek berisi kombinasi unik (karena tidak ada auto increment)
        return { pm_type, line_table, line_name, shift_date, shift };
    },

    // Memperbarui data berdasarkan kombinasi unik
    update: async (pm_type, line_table, line_name, shift_date, shift, data) => {
        const { shift_start_datetime, shift_end_datetime,
                start_kwh, end_kwh, total_kwh,
                month_name, day_name } = data;
        const [result] = await db.execute(
            `UPDATE tb_pm_shiftly_report 
            SET shift_start_datetime = ?, shift_end_datetime = ?,
                start_kwh = ?, end_kwh = ?, total_kwh = ?,
                month_name = ?, day_name = ?, created_at = NOW()
            WHERE pm_type = ? AND line_table = ? AND line_name = ? AND shift_date = ? AND shift = ?`,
            [shift_start_datetime, shift_end_datetime,
             start_kwh, end_kwh, total_kwh,
             month_name, day_name,
             pm_type, line_table, line_name, shift_date, shift]
        );
        return result.affectedRows;
    },

    // Menghapus data berdasarkan kombinasi unik
    delete: async (pm_type, line_table, line_name, shift_date, shift) => {
        const [result] = await db.execute(
            'DELETE FROM tb_pm_shiftly_report WHERE pm_type = ? AND line_table = ? AND line_name = ? AND shift_date = ? AND shift = ?',
            [pm_type, line_table, line_name, shift_date, shift]
        );
        return result.affectedRows;
    },

    // Mendapatkan data berdasarkan rentang tanggal shift_date
    getByDateRange: async (startDate, endDate) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_shiftly_report WHERE shift_date BETWEEN ? AND ? ORDER BY shift_date DESC, shift',
            [startDate, endDate]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan shift (shift_1 atau shift_2)
    getByShift: async (shift) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_shiftly_report WHERE shift = ? ORDER BY shift_date DESC',
            [shift]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan line_table
    getByLineTable: async (line_table) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_shiftly_report WHERE line_table = ? ORDER BY shift_date DESC, shift',
            [line_table]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan pm_type
    getByPmType: async (pm_type) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_shiftly_report WHERE pm_type = ? ORDER BY shift_date DESC, shift',
            [pm_type]
        );
        return rows;
    }
};

module.exports = TbShiftlyWh;