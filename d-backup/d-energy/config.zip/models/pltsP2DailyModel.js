const pool = require("../config/database");

const TABLE_NAME = "tb_plts_p2_daily";

const toNullIfEmpty = (value) => {
  if (value === undefined || value === null || value === "") {
    return null;
  }
  return value;
};

const normalizeDecimal = (value) => {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  let text = String(value).trim();

  // Format Indonesia: 1.234,56
  if (/^\d{1,3}(\.\d{3})*,\d+$/.test(text)) {
    text = text.replace(/\./g, "").replace(",", ".");
  }
  // Format sederhana: 12,5
  else if (text.includes(",") && !text.includes(".")) {
    text = text.replace(",", ".");
  }
  // Format English: 1,234.56
  else {
    text = text.replace(/,/g, "");
  }

  const number = Number(text);

  return Number.isNaN(number) ? null : number;
};

const normalizeDate = (value) => {
  if (!value) return null;

  const text = String(value).trim();

  // Format YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    return text;
  }

  // Format DD/MM/YYYY atau DD-MM-YYYY
  const match = text.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (match) {
    const day = match[1].padStart(2, "0");
    const month = match[2].padStart(2, "0");
    const year = match[3];

    return `${year}-${month}-${day}`;
  }

  const parsedDate = new Date(text);
  if (!Number.isNaN(parsedDate.getTime())) {
    return parsedDate.toISOString().slice(0, 10);
  }

  return null;
};

const normalizeRow = (row) => {
  return {
    energy_date: normalizeDate(row.energy_date),
    purchased_from_grid_kwh: normalizeDecimal(row.purchased_from_grid_kwh),
    generated_by_pv_kwh: normalizeDecimal(row.generated_by_pv_kwh),
    fed_to_grid_kwh: normalizeDecimal(row.fed_to_grid_kwh),
    consumed_by_appliances_kwh: normalizeDecimal(row.consumed_by_appliances_kwh),
  };
};

const getAll = async ({ startDate, endDate, limit = 100, offset = 0 }) => {
  let sql = `SELECT * FROM ${TABLE_NAME}`;
  const params = [];

  if (startDate && endDate) {
    sql += " WHERE energy_date BETWEEN ? AND ?";
    params.push(startDate, endDate);
  } else if (startDate) {
    sql += " WHERE energy_date >= ?";
    params.push(startDate);
  } else if (endDate) {
    sql += " WHERE energy_date <= ?";
    params.push(endDate);
  }

  sql += " ORDER BY energy_date DESC LIMIT ? OFFSET ?";
  params.push(Number(limit), Number(offset));

  const [rows] = await pool.query(sql, params);
  return rows;
};

const getByDate = async (energyDate) => {
  const [rows] = await pool.query(
    `SELECT * FROM ${TABLE_NAME} WHERE energy_date = ?`,
    [energyDate]
  );

  return rows[0] || null;
};

const upsert = async (payload) => {
  const data = normalizeRow(payload);

  if (!data.energy_date) {
    throw new Error("energy_date wajib diisi dengan format tanggal yang valid.");
  }

  const sql = `
    INSERT INTO ${TABLE_NAME} (
      energy_date,
      purchased_from_grid_kwh,
      generated_by_pv_kwh,
      fed_to_grid_kwh,
      consumed_by_appliances_kwh
    )
    VALUES (?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      purchased_from_grid_kwh = VALUES(purchased_from_grid_kwh),
      generated_by_pv_kwh = VALUES(generated_by_pv_kwh),
      fed_to_grid_kwh = VALUES(fed_to_grid_kwh),
      consumed_by_appliances_kwh = VALUES(consumed_by_appliances_kwh)
  `;

  const params = [
    data.energy_date,
    data.purchased_from_grid_kwh,
    data.generated_by_pv_kwh,
    data.fed_to_grid_kwh,
    data.consumed_by_appliances_kwh,
  ];

  const [result] = await pool.query(sql, params);

  return result;
};

const bulkUpsert = async (rows) => {
  if (!Array.isArray(rows)) {
    throw new Error("Data harus berupa array JSON.");
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    let successCount = 0;
    const failedRows = [];

    for (let index = 0; index < rows.length; index++) {
      try {
        const data = normalizeRow(rows[index]);

        if (!data.energy_date) {
          failedRows.push({
            index,
            row: rows[index],
            error: "energy_date tidak valid.",
          });
          continue;
        }

        const sql = `
          INSERT INTO ${TABLE_NAME} (
            energy_date,
            purchased_from_grid_kwh,
            generated_by_pv_kwh,
            fed_to_grid_kwh,
            consumed_by_appliances_kwh
          )
          VALUES (?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            purchased_from_grid_kwh = VALUES(purchased_from_grid_kwh),
            generated_by_pv_kwh = VALUES(generated_by_pv_kwh),
            fed_to_grid_kwh = VALUES(fed_to_grid_kwh),
            consumed_by_appliances_kwh = VALUES(consumed_by_appliances_kwh)
        `;

        await connection.query(sql, [
          data.energy_date,
          data.purchased_from_grid_kwh,
          data.generated_by_pv_kwh,
          data.fed_to_grid_kwh,
          data.consumed_by_appliances_kwh,
        ]);

        successCount++;
      } catch (error) {
        failedRows.push({
          index,
          row: rows[index],
          error: error.message,
        });
      }
    }

    await connection.commit();

    return {
      successCount,
      failedCount: failedRows.length,
      failedRows,
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

const updateByDate = async (energyDate, payload) => {
  const data = normalizeRow({
    ...payload,
    energy_date: energyDate,
  });

  const sql = `
    UPDATE ${TABLE_NAME}
    SET
      purchased_from_grid_kwh = ?,
      generated_by_pv_kwh = ?,
      fed_to_grid_kwh = ?,
      consumed_by_appliances_kwh = ?
    WHERE energy_date = ?
  `;

  const [result] = await pool.query(sql, [
    data.purchased_from_grid_kwh,
    data.generated_by_pv_kwh,
    data.fed_to_grid_kwh,
    data.consumed_by_appliances_kwh,
    data.energy_date,
  ]);

  return result;
};

const deleteByDate = async (energyDate) => {
  const [result] = await pool.query(
    `DELETE FROM ${TABLE_NAME} WHERE energy_date = ?`,
    [energyDate]
  );

  return result;
};

module.exports = {
  getAll,
  getByDate,
  upsert,
  bulkUpsert,
  updateByDate,
  deleteByDate,
};