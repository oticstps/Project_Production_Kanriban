const pool = require('../config/database');

const energyElectricalModelMonthly = {
  // Mendapatkan semua data, diurutkan berdasarkan tahun dan bulan terbaru
  getAllPmMonthlyReport: async () => {
    try {
      const [rows] = await pool.execute(`
        SELECT * FROM tb_pm_monthly_report 
        ORDER BY year DESC, FIELD(month,
          'January','February','March','April','May','June',
          'July','August','September','October','November','December'
        ) DESC
      `);
      return rows;
    } catch (error) {
      throw new Error(`Error fetching PM monthly report: ${error.message}`);
    }
  },

  // Mendapatkan data berdasarkan kombinasi unik (primary key komposit)
  getPmMonthlyReportByComposite: async (pm_type, line_table, month, year) => {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM tb_pm_monthly_report WHERE pm_type = ? AND line_table = ? AND month = ? AND year = ?',
        [pm_type, line_table, month, year]
      );
      return rows[0];
    } catch (error) {
      throw new Error(`Error fetching PM monthly report by composite key: ${error.message}`);
    }
  },

  // Mendapatkan data berdasarkan pm_type
  getPmMonthlyReportByPmType: async (pmType) => {
    try {
      const [rows] = await pool.execute(`
        SELECT * FROM tb_pm_monthly_report 
        WHERE pm_type = ? 
        ORDER BY year DESC, FIELD(month,
          'January','February','March','April','May','June',
          'July','August','September','October','November','December'
        ) DESC
      `, [pmType]);
      return rows;
    } catch (error) {
      throw new Error(`Error fetching PM monthly report by pm_type: ${error.message}`);
    }
  },

  // Mendapatkan data berdasarkan line_table
  getPmMonthlyReportByLineTable: async (lineTable) => {
    try {
      const [rows] = await pool.execute(`
        SELECT * FROM tb_pm_monthly_report 
        WHERE line_table = ? 
        ORDER BY year DESC, FIELD(month,
          'January','February','March','April','May','June',
          'July','August','September','October','November','December'
        ) DESC
      `, [lineTable]);
      return rows;
    } catch (error) {
      throw new Error(`Error fetching PM monthly report by line_table: ${error.message}`);
    }
  },

  // Mendapatkan data berdasarkan bulan dan tahun
  getPmMonthlyReportByMonthYear: async (month, year) => {
    try {
      const [rows] = await pool.execute(`
        SELECT * FROM tb_pm_monthly_report 
        WHERE month = ? AND year = ? 
        ORDER BY year DESC, FIELD(month,
          'January','February','March','April','May','June',
          'July','August','September','October','November','December'
        ) DESC
      `, [month, year]);
      return rows;
    } catch (error) {
      throw new Error(`Error fetching PM monthly report by month and year: ${error.message}`);
    }
  },

  // Mendapatkan data berdasarkan rentang tanggal (menggunakan start_datetime)
  getPmMonthlyReportByDateRange: async (startDate, endDate) => {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM tb_pm_monthly_report WHERE start_datetime BETWEEN ? AND ? ORDER BY start_datetime DESC',
        [startDate, endDate]
      );
      return rows;
    } catch (error) {
      throw new Error(`Error fetching PM monthly report by date range: ${error.message}`);
    }
  },

  // Membuat data baru
  createPmMonthlyReport: async (data) => {
    try {
      const { pm_type, line_table, line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh, month, year } = data;
      const [result] = await pool.execute(
        `INSERT INTO tb_pm_monthly_report 
        (pm_type, line_table, line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh, month, year, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [pm_type, line_table, line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh, month, year]
      );
      return { pm_type, line_table, month, year }; // Mengembalikan kunci komposit
    } catch (error) {
      throw new Error(`Error creating PM monthly report: ${error.message}`);
    }
  },

  // Memperbarui data berdasarkan kunci komposit
  updatePmMonthlyReport: async (pm_type, line_table, month, year, data) => {
    try {
      const { line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh } = data;
      const [result] = await pool.execute(
        `UPDATE tb_pm_monthly_report 
        SET line_name = ?, start_datetime = ?, end_datetime = ?, start_wh = ?, last_wh = ?, total_wh = ?, created_at = NOW()
        WHERE pm_type = ? AND line_table = ? AND month = ? AND year = ?`,
        [line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh, pm_type, line_table, month, year]
      );
      return result.affectedRows;
    } catch (error) {
      throw new Error(`Error updating PM monthly report: ${error.message}`);
    }
  },

  // Menghapus data berdasarkan kunci komposit
  deletePmMonthlyReport: async (pm_type, line_table, month, year) => {
    try {
      const [result] = await pool.execute(
        'DELETE FROM tb_pm_monthly_report WHERE pm_type = ? AND line_table = ? AND month = ? AND year = ?',
        [pm_type, line_table, month, year]
      );
      return result.affectedRows;
    } catch (error) {
      throw new Error(`Error deleting PM monthly report: ${error.message}`);
    }
  }
};

module.exports = energyElectricalModelMonthly;