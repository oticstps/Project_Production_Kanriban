const db = require('../config/database');

const TbMonthlyKubWh = {
    // Mendapatkan semua data, diurutkan berdasarkan tahun dan bulan terbaru
    getAll: async (limit = 500) => {
        const [rows] = await db.execute(
            `SELECT * FROM tb_kub1_total_kwh_monthly 
             ORDER BY year DESC, FIELD(month, 
                'January','February','March','April','May','June',
                'July','August','September','October','November','December'
             ) DESC LIMIT ?`,
            [limit]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan kombinasi unik (primary key komposit)
    getByComposite: async (pm_type, line_table, month, year) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_kub1_total_kwh_monthly WHERE pm_type = ? AND line_table = ? AND month = ? AND year = ?',
            [pm_type, line_table, month, year]
        );
        return rows[0];
    },

    // Membuat data baru
    create: async (data) => {
        const { 
            pm_type, line_table, line_name, 
            start_datetime, end_datetime,
            start_wh, last_wh, total_wh, 
            month, year 
        } = data;
        
        const [result] = await db.execute(
            `INSERT INTO tb_kub1_total_kwh_monthly 
            (pm_type, line_table, line_name, start_datetime, end_datetime,
             start_wh, last_wh, total_wh, month, year, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [pm_type, line_table, line_name, start_datetime, end_datetime,
             start_wh, last_wh, total_wh, month, year]
        );
        
        // Mengembalikan objek berisi kombinasi unik
        return { pm_type, line_table, month, year };
    },

    // Memperbarui data berdasarkan kombinasi unik
    update: async (pm_type, line_table, month, year, data) => {
        const { 
            line_name, start_datetime, end_datetime,
            start_wh, last_wh, total_wh 
        } = data;
        
        const [result] = await db.execute(
            `UPDATE tb_kub1_total_kwh_monthly 
            SET line_name = ?, start_datetime = ?, end_datetime = ?, 
                start_wh = ?, last_wh = ?, total_wh = ?, created_at = NOW()
            WHERE pm_type = ? AND line_table = ? AND month = ? AND year = ?`,
            [line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh,
             pm_type, line_table, month, year]
        );
        return result.affectedRows;
    },

    // Menghapus data berdasarkan kombinasi unik
    delete: async (pm_type, line_table, month, year) => {
        const [result] = await db.execute(
            'DELETE FROM tb_kub1_total_kwh_monthly WHERE pm_type = ? AND line_table = ? AND month = ? AND year = ?',
            [pm_type, line_table, month, year]
        );
        return result.affectedRows;
    },

    // Mendapatkan data berdasarkan rentang tanggal (menggunakan start_datetime)
    getByDateRange: async (startDate, endDate) => {
        const [rows] = await db.execute(
            `SELECT * FROM tb_kub1_total_kwh_monthly 
             WHERE start_datetime BETWEEN ? AND ? 
             ORDER BY year DESC, FIELD(month, 
                'January','February','March','April','May','June',
                'July','August','September','October','November','December'
             ) DESC`,
            [startDate, endDate]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan line_table
    getByLineTable: async (line_table) => {
        const [rows] = await db.execute(
            `SELECT * FROM tb_kub1_total_kwh_monthly 
             WHERE line_table = ? 
             ORDER BY year DESC, FIELD(month, 
                'January','February','March','April','May','June',
                'July','August','September','October','November','December'
             ) DESC`,
            [line_table]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan pm_type
    getByPmType: async (pm_type) => {
        const [rows] = await db.execute(
            `SELECT * FROM tb_kub1_total_kwh_monthly 
             WHERE pm_type = ? 
             ORDER BY year DESC, FIELD(month, 
                'January','February','March','April','May','June',
                'July','August','September','October','November','December'
             ) DESC`,
            [pm_type]
        );
        return rows;
    }
};

module.exports = TbMonthlyKubWh;