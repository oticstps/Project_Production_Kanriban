const db = require('../config/database');

const TbKub1ActivePower = {

  getAll: async (limit = 100) => {
    const [rows] = await db.execute(
        'SELECT * FROM tb_kub1_active_power ORDER BY date_time DESC LIMIT ?',
        [limit]
    );
    return rows;
  },


  getById: async (id) => {
    const [rows] = await db.execute('SELECT * FROM tb_kub1_active_power WHERE id = ?', [id]);
    return rows[0];
  },

  create: async (data) => {
    const { date_time, power_meter, value, shift, day, week, month, year } = data;
    const [result] = await db.execute(
      'INSERT INTO tb_kub1_active_power (date_time, power_meter, value, shift, day, week, month, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [date_time, power_meter, value, shift, day, week, month, year]
    );
    return result.insertId;
  },

  update: async (id, data) => {
    const { date_time, power_meter, value, shift, day, week, month, year } = data;
    const [result] = await db.execute(
      'UPDATE tb_kub1_active_power SET date_time = ?, power_meter = ?, value = ?, shift = ?, day = ?, week = ?, month = ?, year = ? WHERE id = ?',
      [date_time, power_meter, value, shift, day, week, month, year, id]
    );
    return result.affectedRows;
  },

  delete: async (id) => {
    const [result] = await db.execute('DELETE FROM tb_kub1_active_power WHERE id = ?', [id]);
    return result.affectedRows;
  },

  getByDateRange: async (startDate, endDate) => {
    const [rows] = await db.execute(
      'SELECT * FROM tb_kub1_active_power WHERE date_time BETWEEN ? AND ? ORDER BY date_time DESC',
      [startDate, endDate]
    );
    return rows;
  },

  getByShift: async (shift) => {
    const [rows] = await db.execute('SELECT * FROM tb_kub1_active_power WHERE shift = ?', [shift]);
    return rows;
  },

  getByPowerMeter: async (power_meter) => {
    const [rows] = await db.execute('SELECT * FROM tb_kub1_active_power WHERE power_meter = ?', [power_meter]);
    return rows;
  }
};

module.exports = TbKub1ActivePower;