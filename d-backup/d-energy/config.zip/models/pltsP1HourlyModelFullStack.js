const db = require('../config/database');

const TABLE_NAME = 'tb_plts_p1_hourly';

function normalizeDateTime(value) {
  if (!value) return null;
  return String(value).replace('T', ' ').slice(0, 19);
}

function normalizeDate(value) {
  if (!value) return null;
  return String(value).slice(0, 10);
}

function toDecimalOrNull(value) {
  if (value === undefined || value === null || value === '') return null;
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return null;
  return numberValue;
}

class PltsP1HourlyModelFullStack {
  static selectColumns() {
    return `
      DATE_FORMAT(energy_date, '%Y-%m-%d %H:%i:%s') AS energy_date,
      DATE_FORMAT(date_custom, '%Y-%m-%d') AS date_custom,
      production_kwh,
      production_kwh AS plts_production_kwh,
      inverter1_kwh,
      inverter2_kwh
    `;
  }

  static buildWhere(filters = {}) {
    const { date, startDate, endDate } = filters;
    const where = [];
    const params = [];

    if (date) {
      where.push('date_custom = ?');
      params.push(normalizeDate(date));
    }

    if (startDate && endDate) {
      where.push('energy_date BETWEEN ? AND ?');
      params.push(normalizeDateTime(startDate), normalizeDateTime(endDate));
    } else if (startDate) {
      where.push('energy_date >= ?');
      params.push(normalizeDateTime(startDate));
    } else if (endDate) {
      where.push('energy_date <= ?');
      params.push(normalizeDateTime(endDate));
    }

    return { where, params };
  }

  static async getAll(filters = {}) {
    const { limit = 5000, offset = 0, order = 'ASC' } = filters;
    const { where, params } = this.buildWhere(filters);

    const safeLimit = Math.min(Math.max(Number(limit) || 5000, 1), 20000);
    const safeOffset = Math.max(Number(offset) || 0, 0);
    const safeOrder = String(order).toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    const sql = `
      SELECT ${this.selectColumns()}
      FROM ${TABLE_NAME}
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY energy_date ${safeOrder}
      LIMIT ? OFFSET ?
    `;

    const [rows] = await db.execute(sql, [...params, safeLimit, safeOffset]);
    return rows;
  }

  static async count(filters = {}) {
    const { where, params } = this.buildWhere(filters);

    const sql = `
      SELECT COUNT(*) AS total
      FROM ${TABLE_NAME}
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    `;

    const [rows] = await db.execute(sql, params);
    return Number(rows[0]?.total || 0);
  }

  static async findByEnergyDate(energyDate) {
    const sql = `
      SELECT ${this.selectColumns()}
      FROM ${TABLE_NAME}
      WHERE energy_date = ?
      LIMIT 1
    `;

    const [rows] = await db.execute(sql, [normalizeDateTime(energyDate)]);
    return rows[0] || null;
  }

  static async getLatest() {
    const sql = `
      SELECT ${this.selectColumns()}
      FROM ${TABLE_NAME}
      ORDER BY energy_date DESC
      LIMIT 1
    `;

    const [rows] = await db.execute(sql);
    return rows[0] || null;
  }

  static async dailySummary(date) {
    const sql = `
      SELECT
        DATE_FORMAT(date_custom, '%Y-%m-%d') AS date_custom,
        COUNT(*) AS total_record,
        SUM(production_kwh) AS total_production_kwh,
        SUM(production_kwh) AS total_plts_production_kwh,
        SUM(inverter1_kwh) AS total_inverter1_kwh,
        SUM(inverter2_kwh) AS total_inverter2_kwh,
        AVG(production_kwh) AS avg_production_kwh,
        MAX(production_kwh) AS max_production_kwh,
        MIN(production_kwh) AS min_production_kwh
      FROM ${TABLE_NAME}
      WHERE date_custom = ?
      GROUP BY date_custom
      LIMIT 1
    `;

    const [rows] = await db.execute(sql, [normalizeDate(date)]);
    return rows[0] || null;
  }

  static async create(data) {
    const energyDate = normalizeDateTime(data.energy_date);
    const dateCustom = data.date_custom ? normalizeDate(data.date_custom) : normalizeDate(energyDate);

    const sql = `
      INSERT INTO ${TABLE_NAME} (
        energy_date,
        date_custom,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      )
      VALUES (?, ?, ?, ?, ?)
    `;

    await db.execute(sql, [
      energyDate,
      dateCustom,
      toDecimalOrNull(data.production_kwh ?? data.plts_production_kwh),
      toDecimalOrNull(data.inverter1_kwh),
      toDecimalOrNull(data.inverter2_kwh),
    ]);

    return this.findByEnergyDate(energyDate);
  }

  static async upsert(data) {
    const energyDate = normalizeDateTime(data.energy_date);
    const dateCustom = data.date_custom ? normalizeDate(data.date_custom) : normalizeDate(energyDate);

    const sql = `
      INSERT INTO ${TABLE_NAME} (
        energy_date,
        date_custom,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      )
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        date_custom = VALUES(date_custom),
        production_kwh = VALUES(production_kwh),
        inverter1_kwh = VALUES(inverter1_kwh),
        inverter2_kwh = VALUES(inverter2_kwh)
    `;

    await db.execute(sql, [
      energyDate,
      dateCustom,
      toDecimalOrNull(data.production_kwh ?? data.plts_production_kwh),
      toDecimalOrNull(data.inverter1_kwh),
      toDecimalOrNull(data.inverter2_kwh),
    ]);

    return this.findByEnergyDate(energyDate);
  }

  static async update(energyDate, data) {
    const fields = [];
    const params = [];

    if (Object.prototype.hasOwnProperty.call(data, 'date_custom')) {
      fields.push('date_custom = ?');
      params.push(normalizeDate(data.date_custom));
    }

    if (Object.prototype.hasOwnProperty.call(data, 'production_kwh') || Object.prototype.hasOwnProperty.call(data, 'plts_production_kwh')) {
      fields.push('production_kwh = ?');
      params.push(toDecimalOrNull(data.production_kwh ?? data.plts_production_kwh));
    }

    if (Object.prototype.hasOwnProperty.call(data, 'inverter1_kwh')) {
      fields.push('inverter1_kwh = ?');
      params.push(toDecimalOrNull(data.inverter1_kwh));
    }

    if (Object.prototype.hasOwnProperty.call(data, 'inverter2_kwh')) {
      fields.push('inverter2_kwh = ?');
      params.push(toDecimalOrNull(data.inverter2_kwh));
    }

    if (!fields.length) return this.findByEnergyDate(energyDate);

    const sql = `
      UPDATE ${TABLE_NAME}
      SET ${fields.join(', ')}
      WHERE energy_date = ?
    `;

    await db.execute(sql, [...params, normalizeDateTime(energyDate)]);
    return this.findByEnergyDate(energyDate);
  }

  static async delete(energyDate) {
    const existing = await this.findByEnergyDate(energyDate);
    if (!existing) return null;

    await db.execute(`DELETE FROM ${TABLE_NAME} WHERE energy_date = ?`, [normalizeDateTime(energyDate)]);
    return existing;
  }
}

module.exports = PltsP1HourlyModelFullStack;
