const pool = require('../config/database');

// Semua kolom kecuali id dan date_time (date_time default)
const columns = [
    'tb_kub1_total_kwh_value',
    'tb_area_cr1cr2_value',
    'tb_kub1_active_power_value',
    'tb_kub2_panel63_value',
    'tb_kub2_panel64_value',
    'tb_kub2_panel_1_total_kwh_value',
    'tb_kub2_panel_2_total_kwh_value',
    'tb_kub_panel_20_wh_value',
    'tb_kub_panel_16_wh_value',
    'tb_kub_panel_17_wh_value',
    'tb_kub_comp_19_value',
    'tb_kub_comp_21_value',
    'tb_kub_comp_24_value',
    'tb_lpdmtc_value',
    'tb_lpf1_value',
    'tb_lpf2_value',
    'tb_lpqad_value',
    'tb_lpsec_value',
    'tb_lputils_value',
    'tb_lp_dmtc_value',
    'tb_pm200_bs1_value',
    'tb_pm200_bs2_value',
    'tb_pm200_cc1_value',
    'tb_pm200_cc234_value',
    'tb_pm200_chab_value',
    'tb_pm200_chcd_value',
    'tb_pm200_chef_value',
    'tb_pm200_chsaa_value',
    'tb_pm200_chsab_value',
    'tb_pm200_chsac_value',
    'tb_pm200_conn_value',
    'tb_pm200_cr1_value',
    'tb_pm200_cr2_value',
    'tb_pm200_cr3_value',
    'tb_pm200_cr4_value',
    'tb_pm200_cr5_value',
    'tb_pm200_cr6_value',
    'tb_pm200_cr7_value',
    'tb_pm200_cr8_value',
    'tb_pm200_cr9_value',
    'tb_pm200_cr10_value',
    'tb_pm200_cr11_value',
    'tb_pm200_cr12_value',
    'tb_pm200_ct_value',
    'tb_pm200_hla_value',
    'tb_pm200_ra_value',
    'tb_pm200_ret_value',
    'tb_pm200_weng_value',
    'tb_pm220_bs1_value',
    'tb_pm220_bs2_value',
    'tb_pm220_cc1_value',
    'tb_pm220_cc234_value',
    'tb_pm220_chab_value',
    'tb_pm220_chcd_value',
    'tb_pm220_chef_value',
    'tb_pm220_chsaa_value',
    'tb_pm220_chsab_value',
    'tb_pm220_chsac_value',
    'tb_pm220_conn_value',
    'tb_pm220_cr1_value',
    'tb_pm220_cr2_value',
    'tb_pm220_cr3_value',
    'tb_pm220_cr4_value',
    'tb_pm220_cr5_value',
    'tb_pm220_cr6_value',
    'tb_pm220_cr7_value',
    'tb_pm220_cr8_value',
    'tb_pm220_cr9_value',
    'tb_pm220_cr10_value',
    'tb_pm220_cr11_value',
    'tb_pm220_cr12_value',
    'tb_pm220_ct_value',
    'tb_pm220_hla_value',
    'tb_pm220_lpf3_value',
    'tb_pm220_ra_value',
    'tb_pm220_ret_value'
];

const tableName = 'tb_layout_otics_1';

async function getAll() {
    const [rows] = await pool.query(`SELECT * FROM ${tableName} ORDER BY id DESC`);
    return rows;
}

async function getById(id) {
    const [rows] = await pool.query(`SELECT * FROM ${tableName} WHERE id = ?`, [id]);
    return rows[0];
}

async function create(data) {
    const validData = {};
    columns.forEach(col => {
        if (data[col] !== undefined) validData[col] = data[col];
    });

    if (Object.keys(validData).length === 0) {
        throw new Error('Tidak ada data valid untuk dimasukkan');
    }

    const keys = Object.keys(validData);
    const values = Object.values(validData);
    const placeholders = keys.map(() => '?').join(', ');
    const query = `INSERT INTO ${tableName} (${keys.join(', ')}) VALUES (${placeholders})`;
    const [result] = await pool.query(query, values);
    return result.insertId;
}

async function update(id, data) {
    const validData = {};
    columns.forEach(col => {
        if (data[col] !== undefined) validData[col] = data[col];
    });

    if (Object.keys(validData).length === 0) {
        throw new Error('Tidak ada data valid untuk diupdate');
    }

    const keys = Object.keys(validData);
    const values = Object.values(validData);
    const setClause = keys.map(key => `${key} = ?`).join(', ');
    const query = `UPDATE ${tableName} SET ${setClause} WHERE id = ?`;
    const [result] = await pool.query(query, [...values, id]);
    return result.affectedRows > 0;
}

async function deleteById(id) {
    const [result] = await pool.query(`DELETE FROM ${tableName} WHERE id = ?`, [id]);
    return result.affectedRows > 0;
}

module.exports = {
    getAll,
    getById,
    create,
    update,
    deleteById
};





















