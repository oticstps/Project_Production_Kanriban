'use strict';

const dbCore = require('../config/database');

// Mendukung:
// 1. mysql2/promise
// 2. mysql2 pool biasa yang menyediakan method .promise()
const db =
  typeof dbCore.promise === 'function'
    ? dbCore.promise()
    : dbCore;

const TABLE_NAME = 'plts_plant_1_plant_2';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 20;
const MAX_PAGE_LIMIT = 100;
const DEFAULT_CHART_LIMIT = 5000;
const MAX_CHART_LIMIT = 10000;

const WRITABLE_FIELDS = Object.freeze([
  'recorded_at',
  'otics_power',
  'otics_phase_1_inv1',
  'otics_phase_1_inv2',
  'otics_pv_energy_today',
  'otics_pv_energy_monthly',
  'otics_pv_energy_total',
  'otics_irradiation',
  'otics_pr',
  'otics_weather_temp',
  'otics_weather_date',
  'otics_co2_reduced',
  'otics_status',
  'otics_comm_monitoring_last',
  'huawei_temperature',
  'huawei_yield_today',
  'huawei_supply_from_grid_today',
  'huawei_total_yield',
  'huawei_inverter_rated_power',
  'huawei_installed_pv_capacity',
  'huawei_standard_coal_saved',
  'huawei_co2_avoided',
  'huawei_equivalent_trees_planted',
  'huawei_pv_output_kw',
  'huawei_mains_power_kw',
  'huawei_irradiance_wm2',
  'huawei_consumed_by_appliances_kw',
  'raw_payload_json',
]);

/**
 * Mengubah nilai menjadi bilangan bulat positif yang aman.
 */
function toPositiveInteger(value, fallback, maximum) {
  const parsed = Number.parseInt(value, 10);

  if (!Number.isFinite(parsed) || parsed < 1) {
    return fallback;
  }

  return Math.min(parsed, maximum);
}

/**
 * Memastikan ID berbentuk bilangan bulat positif.
 */
function normalizeId(id) {
  const parsed = Number.parseInt(id, 10);

  if (!Number.isInteger(parsed) || parsed < 1) {
    throw new TypeError('ID harus berupa bilangan bulat positif.');
  }

  return parsed;
}

/**
 * Memastikan nilai tanggal memiliki format YYYY-MM-DD
 * dan benar-benar merupakan tanggal kalender yang valid.
 */
function isValidDateOnly(value) {
  if (typeof value !== 'string') return false;

  const normalized = value.trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
    return false;
  }

  const [year, month, day] = normalized.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));

  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
}

/**
 * Menambahkan sejumlah hari pada string tanggal YYYY-MM-DD.
 * Perhitungan dilakukan menggunakan UTC agar tidak bergeser
 * akibat timezone server.
 */
function addDaysToDateOnly(dateString, days = 1) {
  if (!isValidDateOnly(dateString)) {
    throw new TypeError('Tanggal harus menggunakan format YYYY-MM-DD.');
  }

  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + days));

  return date.toISOString().slice(0, 10);
}

/**
 * Menghapus field yang tidak diperbolehkan masuk ke query INSERT/UPDATE.
 */
function sanitizePayload(payload = {}) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return {};
  }

  return WRITABLE_FIELDS.reduce((result, field) => {
    if (Object.prototype.hasOwnProperty.call(payload, field)) {
      result[field] = payload[field];
    }

    return result;
  }, {});
}

/**
 * Menormalisasi raw_payload_json.
 * Object/array akan disimpan sebagai JSON string.
 */
function normalizePayloadData(payload = {}) {
  const data = sanitizePayload(payload);

  if (
    Object.prototype.hasOwnProperty.call(data, 'raw_payload_json') &&
    data.raw_payload_json !== null &&
    typeof data.raw_payload_json === 'object'
  ) {
    data.raw_payload_json = JSON.stringify(data.raw_payload_json);
  }

  return data;
}

/**
 * Mengambil daftar data dengan pagination dan filter opsional.
 *
 * @param {Object} options
 * @param {number} options.page
 * @param {number} options.limit
 * @param {string} options.startDate - MySQL datetime, misalnya 2026-07-24 00:00:00
 * @param {string} options.endDate   - MySQL datetime, misalnya 2026-07-24 23:59:59
 * @param {string} options.status
 */
async function findAll({
  page = DEFAULT_PAGE,
  limit = DEFAULT_LIMIT,
  startDate,
  endDate,
  status,
} = {}) {
  const safePage = toPositiveInteger(
    page,
    DEFAULT_PAGE,
    Number.MAX_SAFE_INTEGER,
  );

  const safeLimit = toPositiveInteger(
    limit,
    DEFAULT_LIMIT,
    MAX_PAGE_LIMIT,
  );

  const offset = (safePage - 1) * safeLimit;

  const conditions = [];
  const params = [];

  if (startDate) {
    conditions.push('recorded_at >= ?');
    params.push(startDate);
  }

  if (endDate) {
    conditions.push('recorded_at <= ?');
    params.push(endDate);
  }

  if (status) {
    conditions.push('otics_status = ?');
    params.push(status);
  }

  const whereClause =
    conditions.length > 0
      ? `WHERE ${conditions.join(' AND ')}`
      : '';

  const dataSql = `
    SELECT *
    FROM ${TABLE_NAME}
    ${whereClause}
    ORDER BY recorded_at DESC, id DESC
    LIMIT ? OFFSET ?
  `;

  const countSql = `
    SELECT COUNT(*) AS total
    FROM ${TABLE_NAME}
    ${whereClause}
  `;

  const [rows] = await db.execute(dataSql, [
    ...params,
    safeLimit,
    offset,
  ]);

  const [countRows] = await db.execute(countSql, params);

  const total = Number(countRows[0]?.total || 0);
  const totalPages = total > 0
    ? Math.ceil(total / safeLimit)
    : 1;

  return {
    data: rows,
    pagination: {
      page: safePage,
      limit: safeLimit,
      total,
      totalPages,
    },
  };
}

/**
 * Mengambil satu record berdasarkan ID.
 */
async function findById(id) {
  const safeId = normalizeId(id);

  const [rows] = await db.execute(
    `
      SELECT *
      FROM ${TABLE_NAME}
      WHERE id = ?
      LIMIT 1
    `,
    [safeId],
  );

  return rows[0] || null;
}

/**
 * Mengambil record terbaru.
 */
async function findLatest() {
  const [rows] = await db.execute(
    `
      SELECT *
      FROM ${TABLE_NAME}
      ORDER BY recorded_at DESC, id DESC
      LIMIT 1
    `,
  );

  return rows[0] || null;
}

/**
 * Mengambil tanggal terbaru yang tersedia dalam database.
 *
 * Return:
 * - "2026-07-24" jika tersedia
 * - null jika tabel kosong
 */
async function findLatestRecordedDate() {
  const [rows] = await db.execute(
    `
      SELECT DATE_FORMAT(MAX(recorded_at), '%Y-%m-%d') AS latest_date
      FROM ${TABLE_NAME}
    `,
  );

  return rows[0]?.latest_date || null;
}

/**
 * Mengambil data berdasarkan rentang waktu.
 *
 * Rentang menggunakan:
 * recorded_at >= startDate
 * recorded_at < endDate
 *
 * Dengan demikian endDate bersifat eksklusif.
 */
async function findByRecordedAtRange(
  startDate,
  endDate,
  limit = DEFAULT_CHART_LIMIT,
) {
  if (!startDate || !endDate) {
    throw new TypeError(
      'startDate dan endDate wajib diisi.',
    );
  }

  const safeLimit = toPositiveInteger(
    limit,
    DEFAULT_CHART_LIMIT,
    MAX_CHART_LIMIT,
  );

  const [rows] = await db.execute(
    `
      SELECT *
      FROM ${TABLE_NAME}
      WHERE recorded_at >= ?
        AND recorded_at < ?
      ORDER BY recorded_at ASC, id ASC
      LIMIT ?
    `,
    [startDate, endDate, safeLimit],
  );

  return rows;
}

/**
 * Mengambil seluruh data dalam satu tanggal kalender.
 *
 * Contoh:
 * findByDate('2026-07-24')
 *
 * Query yang terbentuk:
 * recorded_at >= '2026-07-24 00:00:00'
 * recorded_at <  '2026-07-25 00:00:00'
 */
async function findByDate(
  date,
  limit = DEFAULT_CHART_LIMIT,
) {
  const normalizedDate =
    typeof date === 'string'
      ? date.trim()
      : '';

  if (!isValidDateOnly(normalizedDate)) {
    throw new TypeError(
      'Tanggal harus valid dan menggunakan format YYYY-MM-DD.',
    );
  }

  const nextDate = addDaysToDateOnly(normalizedDate, 1);

  return findByRecordedAtRange(
    `${normalizedDate} 00:00:00`,
    `${nextDate} 00:00:00`,
    limit,
  );
}

/**
 * Mengambil data grafik harian.
 *
 * Jika date tidak diberikan, fungsi otomatis memakai
 * tanggal terbaru yang tersedia dalam database.
 *
 * Return:
 * {
 *   date: '2026-07-24',
 *   total: 2880,
 *   data: [...]
 * }
 */
async function findDailyChart({
  date,
  limit = DEFAULT_CHART_LIMIT,
} = {}) {
  let selectedDate =
    typeof date === 'string'
      ? date.trim()
      : '';

  if (!selectedDate) {
    selectedDate = await findLatestRecordedDate();
  }

  if (!selectedDate) {
    return {
      date: null,
      total: 0,
      data: [],
    };
  }

  if (!isValidDateOnly(selectedDate)) {
    throw new TypeError(
      'Tanggal grafik harus menggunakan format YYYY-MM-DD.',
    );
  }

  const rows = await findByDate(selectedDate, limit);

  return {
    date: selectedDate,
    total: rows.length,
    data: rows,
  };
}

/**
 * Menghitung jumlah record pada satu tanggal.
 */
async function countByDate(date) {
  const normalizedDate =
    typeof date === 'string'
      ? date.trim()
      : '';

  if (!isValidDateOnly(normalizedDate)) {
    throw new TypeError(
      'Tanggal harus valid dan menggunakan format YYYY-MM-DD.',
    );
  }

  const nextDate = addDaysToDateOnly(normalizedDate, 1);

  const [rows] = await db.execute(
    `
      SELECT COUNT(*) AS total
      FROM ${TABLE_NAME}
      WHERE recorded_at >= ?
        AND recorded_at < ?
    `,
    [
      `${normalizedDate} 00:00:00`,
      `${nextDate} 00:00:00`,
    ],
  );

  return Number(rows[0]?.total || 0);
}

/**
 * Menambahkan record baru.
 */
async function create(payload) {
  const data = normalizePayloadData(payload);
  const fields = Object.keys(data);

  if (fields.length === 0) {
    throw new Error(
      'Tidak ada field yang dapat disimpan.',
    );
  }

  if (
    !Object.prototype.hasOwnProperty.call(data, 'recorded_at') ||
    !data.recorded_at
  ) {
    throw new Error(
      'Field recorded_at wajib diisi.',
    );
  }

  const placeholders = fields
    .map(() => '?')
    .join(', ');

  const values = fields.map(
    (field) => data[field],
  );

  const [result] = await db.execute(
    `
      INSERT INTO ${TABLE_NAME}
        (${fields.join(', ')})
      VALUES
        (${placeholders})
    `,
    values,
  );

  return findById(result.insertId);
}

/**
 * Memperbarui record berdasarkan ID.
 */
async function update(id, payload) {
  const safeId = normalizeId(id);
  const data = normalizePayloadData(payload);
  const fields = Object.keys(data);

  if (fields.length === 0) {
    return findById(safeId);
  }

  const setClause = fields
    .map((field) => `${field} = ?`)
    .join(', ');

  const values = fields.map(
    (field) => data[field],
  );

  const [result] = await db.execute(
    `
      UPDATE ${TABLE_NAME}
      SET ${setClause}
      WHERE id = ?
    `,
    [...values, safeId],
  );

  if (result.affectedRows === 0) {
    return null;
  }

  return findById(safeId);
}

/**
 * Menghapus record berdasarkan ID.
 */
async function remove(id) {
  const safeId = normalizeId(id);

  const [result] = await db.execute(
    `
      DELETE FROM ${TABLE_NAME}
      WHERE id = ?
    `,
    [safeId],
  );

  return result.affectedRows > 0;
}

module.exports = {
  TABLE_NAME,
  WRITABLE_FIELDS,

  sanitizePayload,
  normalizePayloadData,
  isValidDateOnly,
  addDaysToDateOnly,

  findAll,
  findById,
  findLatest,
  findLatestRecordedDate,
  findByRecordedAtRange,
  findByDate,
  findDailyChart,
  countByDate,

  create,
  update,
  remove,
};
