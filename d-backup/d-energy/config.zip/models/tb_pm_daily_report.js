const db = require('../config/database');

const TbDailyWh = {
    // Mendapatkan semua data, diurutkan berdasarkan tanggal terbaru
    getAll: async (limit = 500) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_daily_report ORDER BY date DESC LIMIT ?',
            [limit]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan kombinasi unik (primary key komposit)
    getByComposite: async (pm_type, line_table, date) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_daily_report WHERE pm_type = ? AND line_table = ? AND date = ?',
            [pm_type, line_table, date]
        );
        return rows[0];
    },

    // Membuat data baru
    create: async (data) => {
        const {
            pm_type, line_table, line_name,
            start_datetime, end_datetime,
            start_wh, last_wh, total_wh,
            date, year, month, month_name, day, day_name
        } = data;

        const [result] = await db.execute(
            `INSERT INTO tb_pm_daily_report 
            (pm_type, line_table, line_name, start_datetime, end_datetime,
             start_wh, last_wh, total_wh, date, year, month, month_name, day, day_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [pm_type, line_table, line_name, start_datetime, end_datetime,
             start_wh, last_wh, total_wh, date, year, month, month_name, day, day_name]
        );
        // Mengembalikan kombinasi unik (karena tidak ada auto increment)
        return { pm_type, line_table, date };
    },

    // Memperbarui data berdasarkan kombinasi unik
    update: async (pm_type, line_table, date, data) => {
        const {
            line_name, start_datetime, end_datetime,
            start_wh, last_wh, total_wh,
            month_name, day_name
        } = data;

        const [result] = await db.execute(
            `UPDATE tb_pm_daily_report 
            SET line_name = ?, start_datetime = ?, end_datetime = ?,
                start_wh = ?, last_wh = ?, total_wh = ?,
                month_name = ?, day_name = ?, created_at = NOW()
            WHERE pm_type = ? AND line_table = ? AND date = ?`,
            [line_name, start_datetime, end_datetime, start_wh, last_wh, total_wh,
             month_name, day_name, pm_type, line_table, date]
        );
        return result.affectedRows;
    },

    // Menghapus data berdasarkan kombinasi unik
    delete: async (pm_type, line_table, date) => {
        const [result] = await db.execute(
            'DELETE FROM tb_pm_daily_report WHERE pm_type = ? AND line_table = ? AND date = ?',
            [pm_type, line_table, date]
        );
        return result.affectedRows;
    },

    // Mendapatkan data berdasarkan rentang tanggal (kolom date)
    getByDateRange: async (startDate, endDate) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_daily_report WHERE date BETWEEN ? AND ? ORDER BY date DESC',
            [startDate, endDate]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan line_table
    getByLineTable: async (line_table) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_daily_report WHERE line_table = ? ORDER BY date DESC',
            [line_table]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan pm_type
    getByPmType: async (pm_type) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_daily_report WHERE pm_type = ? ORDER BY date DESC',
            [pm_type]
        );
        return rows;
    }
};

module.exports = TbDailyWh;