const db = require('../config/database');
const { DAILY_TABLES } = require('../constants/reportTables');
const validateTable = require('../helpers/validateTable');

const DailyReportModel = {
    getAll: async (tableName, limit = 500) => {
        validateTable(tableName, DAILY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName} ORDER BY shift_date DESC LIMIT ?`,
            [limit]
        );
        return rows;
    },

    getByComposite: async (tableName, pm_type, line_table, shift, shift_date) => {
        validateTable(tableName, DAILY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE pm_type = ? AND line_table = ? AND shift = ? AND shift_date = ?`,
            [pm_type, line_table, shift, shift_date]
        );
        return rows[0];
    },

    create: async (tableName, data) => {
        validateTable(tableName, DAILY_TABLES);

        const {
            pm_type, line_table, line_name, shift, shift_date,
            shift_start_datetime, shift_end_datetime,
            start_kwh, end_kwh, total_kwh,
            year, month, month_name, day, day_name
        } = data;

        await db.execute(
            `INSERT INTO ${tableName}
            (pm_type, line_table, line_name, shift, shift_date,
             shift_start_datetime, shift_end_datetime,
             start_kwh, end_kwh, total_kwh,
             year, month, month_name, day, day_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [
                pm_type, line_table, line_name, shift, shift_date,
                shift_start_datetime, shift_end_datetime,
                start_kwh, end_kwh, total_kwh,
                year, month, month_name, day, day_name
            ]
        );

        return { pm_type, line_table, shift, shift_date };
    },

    update: async (tableName, pm_type, line_table, shift, shift_date, data) => {
        validateTable(tableName, DAILY_TABLES);

        const {
            line_name, shift_start_datetime, shift_end_datetime,
            start_kwh, end_kwh, total_kwh,
            year, month, month_name, day, day_name
        } = data;

        const [result] = await db.execute(
            `UPDATE ${tableName}
             SET line_name = ?, shift_start_datetime = ?, shift_end_datetime = ?,
                 start_kwh = ?, end_kwh = ?, total_kwh = ?,
                 year = ?, month = ?, month_name = ?, day = ?, day_name = ?,
                 updated_at = NOW()
             WHERE pm_type = ? AND line_table = ? AND shift = ? AND shift_date = ?`,
            [
                line_name, shift_start_datetime, shift_end_datetime,
                start_kwh, end_kwh, total_kwh,
                year, month, month_name, day, day_name,
                pm_type, line_table, shift, shift_date
            ]
        );

        return result.affectedRows;
    },

    delete: async (tableName, pm_type, line_table, shift, shift_date) => {
        validateTable(tableName, DAILY_TABLES);
        const [result] = await db.execute(
            `DELETE FROM ${tableName}
             WHERE pm_type = ? AND line_table = ? AND shift = ? AND shift_date = ?`,
            [pm_type, line_table, shift, shift_date]
        );
        return result.affectedRows;
    },

    getByDateRange: async (tableName, startDate, endDate) => {
        validateTable(tableName, DAILY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE shift_date BETWEEN ? AND ?
             ORDER BY shift_date DESC`,
            [startDate, endDate]
        );
        return rows;
    },

    getByLineTable: async (tableName, line_table) => {
        validateTable(tableName, DAILY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE line_table = ?
             ORDER BY shift_date DESC`,
            [line_table]
        );
        return rows;
    },

    getByPmType: async (tableName, pm_type) => {
        validateTable(tableName, DAILY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE pm_type = ?
             ORDER BY shift_date DESC`,
            [pm_type]
        );
        return rows;
    }
};

module.exports = DailyReportModel;