const db = require("../config/database");

const TABLE_NAME = "tb_plts_p1_hourly";

const bulkUpsertHourly = async (rows) => {
  if (!Array.isArray(rows) || rows.length === 0) {
    return {
      affectedRows: 0,
    };
  }

  const values = rows.map((row) => [
    row.energy_date,
    row.date_custom,
    row.production_kwh,
    row.inverter1_kwh,
    row.inverter2_kwh,
  ]);

  const sql = `
    INSERT INTO ${TABLE_NAME}
      (
        energy_date,
        date_custom,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      )
    VALUES ?
    ON DUPLICATE KEY UPDATE
      date_custom = VALUES(date_custom),
      production_kwh = VALUES(production_kwh),
      inverter1_kwh = VALUES(inverter1_kwh),
      inverter2_kwh = VALUES(inverter2_kwh)
  `;

  const [result] = await db.query(sql, [values]);
  return result;
};

const findHourlyByDate = async (dateCustom) => {
  const sql = `
    SELECT
      DATE_FORMAT(energy_date, '%Y-%m-%d %H:%i:%s') AS energy_date,
      DATE_FORMAT(date_custom, '%Y-%m-%d') AS date_custom,
      TIME_FORMAT(TIME(energy_date), '%H:%i') AS time_value,
      production_kwh,
      inverter1_kwh,
      inverter2_kwh
    FROM ${TABLE_NAME}
    WHERE date_custom = ?
    ORDER BY energy_date ASC
  `;

  const [rows] = await db.query(sql, [dateCustom]);
  return rows;
};

module.exports = {
  bulkUpsertHourly,
  findHourlyByDate,
};