const XLSX = require('xlsx');

function normalizeCellValue(value) {
  if (value === undefined || value === '') return null;
  if (value instanceof Date) return value.toISOString();
  return value;
}

function normalizeRow(row) {
  const normalized = {};

  Object.entries(row).forEach(([key, value]) => {
    const cleanKey = String(key).trim();
    normalized[cleanKey] = normalizeCellValue(value);
  });

  return normalized;
}

function isEmptyRow(row) {
  return Object.values(row).every((value) => value === null || value === undefined || value === '');
}

function parseSpreadsheet(buffer) {
  const workbook = XLSX.read(buffer, {
    type: 'buffer',
    cellDates: true,
    raw: false
  });

  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) {
    return [];
  }

  const sheet = workbook.Sheets[firstSheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, {
    defval: null,
    blankrows: false
  });

  return rows.map(normalizeRow).filter((row) => !isEmptyRow(row));
}

module.exports = {
  parseSpreadsheet
};
