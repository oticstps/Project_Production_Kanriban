const HttpError = require('./httpError');

function isValidDateParts(year, month, day) {
  const date = new Date(Date.UTC(year, month - 1, day));
  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
}

function normalizeDate(value, fieldName = 'date') {
  if (value === undefined || value === null || value === '') {
    return null;
  }

  const text = String(value).trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);

  if (!match) {
    throw new HttpError(400, `${fieldName} harus berformat YYYY-MM-DD.`);
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);

  if (!isValidDateParts(year, month, day)) {
    throw new HttpError(400, `${fieldName} bukan tanggal yang valid.`);
  }

  return `${match[1]}-${match[2]}-${match[3]}`;
}

function normalizeDateTime(value, fieldName = 'date_time') {
  if (value === undefined || value === null || value === '') {
    return null;
  }

  const text = String(value).trim();
  const match = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})(?:\.\d{1,6})?$/.exec(text);

  if (!match) {
    throw new HttpError(
      400,
      `${fieldName} harus berformat YYYY-MM-DD HH:mm:ss atau YYYY-MM-DDTHH:mm:ss tanpa timezone.`,
    );
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const hour = Number(match[4]);
  const minute = Number(match[5]);
  const second = Number(match[6]);

  if (!isValidDateParts(year, month, day)) {
    throw new HttpError(400, `${fieldName} memiliki tanggal yang tidak valid.`);
  }

  if (hour > 23 || minute > 59 || second > 59) {
    throw new HttpError(400, `${fieldName} memiliki jam yang tidak valid.`);
  }

  return `${match[1]}-${match[2]}-${match[3]} ${match[4]}:${match[5]}:${match[6]}`;
}

function addOneDay(dateText) {
  const [year, month, day] = dateText.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  date.setUTCDate(date.getUTCDate() + 1);

  const nextYear = String(date.getUTCFullYear()).padStart(4, '0');
  const nextMonth = String(date.getUTCMonth() + 1).padStart(2, '0');
  const nextDay = String(date.getUTCDate()).padStart(2, '0');

  return `${nextYear}-${nextMonth}-${nextDay}`;
}

function parseInteger(value, fallback, { min, max, fieldName }) {
  if (value === undefined || value === null || value === '') {
    return fallback;
  }

  const parsed = Number(value);

  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new HttpError(400, `${fieldName} harus berupa bilangan bulat antara ${min} dan ${max}.`);
  }

  return parsed;
}

module.exports = {
  normalizeDate,
  normalizeDateTime,
  addOneDay,
  parseInteger,
};
