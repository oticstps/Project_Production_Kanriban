const WeeklyReportModel = require('../models/WeeklyReportModel');

const WeeklyReportService = {
    getAll: (tableName, limit) => WeeklyReportModel.getAll(tableName, limit),
    getByComposite: (tableName, pm_type, line_table, year, week) =>
        WeeklyReportModel.getByComposite(tableName, pm_type, line_table, year, week),
    create: (tableName, data) => WeeklyReportModel.create(tableName, data),
    update: (tableName, pm_type, line_table, year, week, data) =>
        WeeklyReportModel.update(tableName, pm_type, line_table, year, week, data),
    delete: (tableName, pm_type, line_table, year, week) =>
        WeeklyReportModel.delete(tableName, pm_type, line_table, year, week),
    getByYear: (tableName, year) => WeeklyReportModel.getByYear(tableName, year),
};

module.exports = WeeklyReportService;