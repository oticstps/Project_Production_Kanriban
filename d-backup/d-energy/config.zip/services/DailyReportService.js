const DailyReportModel = require('../models/DailyReportModel');

const DailyReportService = {
    getAll: (tableName, limit) => DailyReportModel.getAll(tableName, limit),
    getByComposite: (tableName, pm_type, line_table, shift, shift_date) =>
        DailyReportModel.getByComposite(tableName, pm_type, line_table, shift, shift_date),
    create: (tableName, data) => DailyReportModel.create(tableName, data),
    update: (tableName, pm_type, line_table, shift, shift_date, data) =>
        DailyReportModel.update(tableName, pm_type, line_table, shift, shift_date, data),
    delete: (tableName, pm_type, line_table, shift, shift_date) =>
        DailyReportModel.delete(tableName, pm_type, line_table, shift, shift_date),
    getByDateRange: (tableName, startDate, endDate) =>
        DailyReportModel.getByDateRange(tableName, startDate, endDate),
    getByLineTable: (tableName, line_table) =>
        DailyReportModel.getByLineTable(tableName, line_table),
    getByPmType: (tableName, pm_type) =>
        DailyReportModel.getByPmType(tableName, pm_type),
};

module.exports = DailyReportService;