const ShiftlyReportModel = require('../models/ShiftlyReportModel');

const ShiftlyReportService = {
    getAll: (tableName, limit) => ShiftlyReportModel.getAll(tableName, limit),
    getByComposite: (tableName, pm_type, line_table, shift, shift_date) =>
        ShiftlyReportModel.getByComposite(tableName, pm_type, line_table, shift, shift_date),
    create: (tableName, data) => ShiftlyReportModel.create(tableName, data),
    update: (tableName, pm_type, line_table, shift, shift_date, data) =>
        ShiftlyReportModel.update(tableName, pm_type, line_table, shift, shift_date, data),
    delete: (tableName, pm_type, line_table, shift, shift_date) =>
        ShiftlyReportModel.delete(tableName, pm_type, line_table, shift, shift_date),
    getByDateRange: (tableName, startDate, endDate) =>
        ShiftlyReportModel.getByDateRange(tableName, startDate, endDate),
};

module.exports = ShiftlyReportService;