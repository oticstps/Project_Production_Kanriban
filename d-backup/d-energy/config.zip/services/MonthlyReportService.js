const MonthlyReportModel = require('../models/MonthlyReportModel');

const MonthlyReportService = {
    getAll: (tableName, limit) => MonthlyReportModel.getAll(tableName, limit),
    getByComposite: (tableName, pm_type, line_table, year, month) =>
        MonthlyReportModel.getByComposite(tableName, pm_type, line_table, year, month),
    create: (tableName, data) => MonthlyReportModel.create(tableName, data),
    update: (tableName, pm_type, line_table, year, month, data) =>
        MonthlyReportModel.update(tableName, pm_type, line_table, year, month, data),
    delete: (tableName, pm_type, line_table, year, month) =>
        MonthlyReportModel.delete(tableName, pm_type, line_table, year, month),
    getByYear: (tableName, year) => MonthlyReportModel.getByYear(tableName, year),
};

module.exports = MonthlyReportService;