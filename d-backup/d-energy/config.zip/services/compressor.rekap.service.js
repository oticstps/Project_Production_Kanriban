const moment = require('moment-timezone');
const CompressorModel = require('../models/compressor.model');

moment.tz.setDefault('Asia/Jakarta');

function toNumber(value) {
  if (value === null || value === undefined) return NaN;
  return parseFloat(String(value).replace(/,/g, '').trim());
}

async function getRangeData(connection, tableName, startTime, endTime) {
  const startRow = await CompressorModel.getFirstRowInRange(
    connection,
    tableName,
    startTime.format('YYYY-MM-DD HH:mm:ss'),
    endTime.format('YYYY-MM-DD HH:mm:ss')
  );

  const endRow = await CompressorModel.getLastRowInRange(
    connection,
    tableName,
    startTime.format('YYYY-MM-DD HH:mm:ss'),
    endTime.format('YYYY-MM-DD HH:mm:ss')
  );

  if (!startRow || !endRow) {
    return null;
  }

  const startValue = toNumber(startRow.wh_value);
  const endValue = toNumber(endRow.wh_value);

  if (Number.isNaN(startValue) || Number.isNaN(endValue)) {
    return null;
  }

  const totalValue = endValue - startValue;
  if (totalValue <= 0) {
    return null;
  }

  return {
    startDatetime: moment(startRow.date_time).format('YYYY-MM-DD HH:mm:ss'),
    endDatetime: moment(endRow.date_time).format('YYYY-MM-DD HH:mm:ss'),
    startValue,
    endValue,
    totalValue,
  };
}

function buildWeeklyPeriods(dateRows) {
  const map = new Map();

  for (const row of dateRows) {
    const m = moment(row.period_date);
    const isoYear = m.isoWeekYear();
    const isoWeek = m.isoWeek();
    const key = `${isoYear}-${isoWeek}`;

    if (!map.has(key)) {
      const weekStart = m.clone().startOf('isoWeek');
      const weekEnd = weekStart.clone().add(6, 'days');
      const nextWeek = weekStart.clone().add(1, 'week');

      map.set(key, {
        year: isoYear,
        week: isoWeek,
        month: weekStart.month() + 1,
        month_name: weekStart.format('MMMM'),
        week_start_date: weekStart.format('YYYY-MM-DD'),
        week_end_date: weekEnd.format('YYYY-MM-DD'),
        range_start: weekStart.clone().startOf('day'),
        range_end: nextWeek.clone().startOf('day'),
      });
    }
  }

  return Array.from(map.values()).sort(
    (a, b) => a.range_start.valueOf() - b.range_start.valueOf()
  );
}

function buildMonthlyPeriods(dateRows) {
  const map = new Map();

  for (const row of dateRows) {
    const m = moment(row.period_date);
    const key = m.format('YYYY-MM');

    if (!map.has(key)) {
      const monthStart = m.clone().startOf('month');
      const nextMonthStart = monthStart.clone().add(1, 'month');
      const monthEnd = nextMonthStart.clone().subtract(1, 'day');

      map.set(key, {
        year: monthStart.year(),
        month: monthStart.month() + 1,
        month_name: monthStart.format('MMMM'),
        month_start_date: monthStart.format('YYYY-MM-DD'),
        month_end_date: monthEnd.format('YYYY-MM-DD'),
        range_start: monthStart.clone().startOf('day'),
        range_end: nextMonthStart.clone().startOf('day'),
      });
    }
  }

  return Array.from(map.values()).sort(
    (a, b) => a.range_start.valueOf() - b.range_start.valueOf()
  );
}

const CompressorRekapService = {
  async processShiftly() {
    const connection = await CompressorModel.getConnection();
    const results = [];

    try {
      const panels = CompressorModel.getPanelTables();

      for (const panel of panels) {
        const dates = await CompressorModel.getDistinctDates(connection, panel.source_table);

        for (const row of dates) {
          const dateStr = moment(row.period_date).format('YYYY-MM-DD');
          const dateObj = moment(dateStr);

          const shift1Start = dateObj.clone().set({ hour: 7, minute: 10, second: 0, millisecond: 0 });
          const shift1End = dateObj.clone().set({ hour: 19, minute: 50, second: 0, millisecond: 0 });

          const shift2Start = dateObj.clone().set({ hour: 19, minute: 50, second: 0, millisecond: 0 });
          const shift2End = dateObj.clone().add(1, 'day').set({ hour: 7, minute: 10, second: 0, millisecond: 0 });

          const basePayload = {
            pm_type: panel.pm_type,
            line_table: panel.source_table,
            line_name: panel.line_name,
            year: dateObj.year(),
            month: dateObj.month() + 1,
            month_name: dateObj.format('MMMM'),
            day: dateObj.date(),
            day_name: dateObj.format('dddd'),
            shift_date: dateStr,
          };

          const shift1Data = await getRangeData(connection, panel.source_table, shift1Start, shift1End);
          if (shift1Data) {
            await CompressorModel.upsertShiftly(connection, panel.shiftly_table, {
              ...basePayload,
              shift: 'shift_1',
              shift_start_datetime: shift1Data.startDatetime,
              shift_end_datetime: shift1Data.endDatetime,
              start_kwh: shift1Data.startValue,
              end_kwh: shift1Data.endValue,
              total_kwh: shift1Data.totalValue,
            });

            results.push({
              table: panel.shiftly_table,
              shift: 'shift_1',
              shift_date: dateStr,
              total_kwh: shift1Data.totalValue,
            });
          }

          const shift2Data = await getRangeData(connection, panel.source_table, shift2Start, shift2End);
          if (shift2Data) {
            await CompressorModel.upsertShiftly(connection, panel.shiftly_table, {
              ...basePayload,
              shift: 'shift_2',
              shift_start_datetime: shift2Data.startDatetime,
              shift_end_datetime: shift2Data.endDatetime,
              start_kwh: shift2Data.startValue,
              end_kwh: shift2Data.endValue,
              total_kwh: shift2Data.totalValue,
            });

            results.push({
              table: panel.shiftly_table,
              shift: 'shift_2',
              shift_date: dateStr,
              total_kwh: shift2Data.totalValue,
            });
          }
        }
      }

      return results;
    } finally {
      connection.release();
    }
  },

  async processDaily() {
    const connection = await CompressorModel.getConnection();
    const results = [];

    try {
      const panels = CompressorModel.getPanelTables();

      for (const panel of panels) {
        const dates = await CompressorModel.getDistinctDates(connection, panel.source_table);

        for (const row of dates) {
          const dateStr = moment(row.period_date).format('YYYY-MM-DD');
          const dateObj = moment(dateStr);

          const dayStart = dateObj.clone().startOf('day');
          const dayEnd = dateObj.clone().add(1, 'day').startOf('day');

          const dailyData = await getRangeData(connection, panel.source_table, dayStart, dayEnd);
          if (!dailyData) continue;

          await CompressorModel.upsertDaily(connection, panel.daily_table, {
            pm_type: panel.pm_type,
            line_table: panel.source_table,
            line_name: panel.line_name,
            shift: 'daily',
            shift_date: dateStr,
            shift_start_datetime: dailyData.startDatetime,
            shift_end_datetime: dailyData.endDatetime,
            start_kwh: dailyData.startValue,
            end_kwh: dailyData.endValue,
            total_kwh: dailyData.totalValue,
            year: dateObj.year(),
            month: dateObj.month() + 1,
            month_name: dateObj.format('MMMM'),
            day: dateObj.date(),
            day_name: dateObj.format('dddd'),
          });

          results.push({
            table: panel.daily_table,
            shift_date: dateStr,
            total_kwh: dailyData.totalValue,
          });
        }
      }

      return results;
    } finally {
      connection.release();
    }
  },

  async processWeekly() {
    const connection = await CompressorModel.getConnection();
    const results = [];

    try {
      const panels = CompressorModel.getPanelTables();

      for (const panel of panels) {
        const dates = await CompressorModel.getDistinctDates(connection, panel.source_table);
        const weeklyPeriods = buildWeeklyPeriods(dates);

        for (const period of weeklyPeriods) {
          const weeklyData = await getRangeData(
            connection,
            panel.source_table,
            period.range_start,
            period.range_end
          );

          if (!weeklyData) continue;

          await CompressorModel.upsertWeekly(connection, panel.weekly_table, {
            pm_type: panel.pm_type,
            line_table: panel.source_table,
            line_name: panel.line_name,
            week: period.week,
            week_start_date: period.week_start_date,
            week_end_date: period.week_end_date,
            week_start_datetime: weeklyData.startDatetime,
            week_end_datetime: weeklyData.endDatetime,
            start_kwh: weeklyData.startValue,
            end_kwh: weeklyData.endValue,
            total_kwh: weeklyData.totalValue,
            year: period.year,
            month: period.month,
            month_name: period.month_name,
          });

          results.push({
            table: panel.weekly_table,
            year: period.year,
            week: period.week,
            total_kwh: weeklyData.totalValue,
          });
        }
      }

      return results;
    } finally {
      connection.release();
    }
  },

  async processMonthly() {
    const connection = await CompressorModel.getConnection();
    const results = [];

    try {
      const panels = CompressorModel.getPanelTables();

      for (const panel of panels) {
        const dates = await CompressorModel.getDistinctDates(connection, panel.source_table);
        const monthlyPeriods = buildMonthlyPeriods(dates);

        for (const period of monthlyPeriods) {
          const monthlyData = await getRangeData(
            connection,
            panel.source_table,
            period.range_start,
            period.range_end
          );

          if (!monthlyData) continue;

          await CompressorModel.upsertMonthly(connection, panel.monthly_table, {
            pm_type: panel.pm_type,
            line_table: panel.source_table,
            line_name: panel.line_name,
            start_kwh: monthlyData.startValue,
            end_kwh: monthlyData.endValue,
            total_kwh: monthlyData.totalValue,
            year: period.year,
            month: period.month,
            month_name: period.month_name,
            month_start_date: period.month_start_date,
            month_end_date: period.month_end_date,
            month_start_datetime: monthlyData.startDatetime,
            month_end_datetime: monthlyData.endDatetime,
          });

          results.push({
            table: panel.monthly_table,
            year: period.year,
            month: period.month,
            total_kwh: monthlyData.totalValue,
          });
        }
      }

      return results;
    } finally {
      connection.release();
    }
  },
};

module.exports = CompressorRekapService;