# Backend API Shiftly Panel 63 dan Panel 64

Paket ini berisi backend dengan struktur yang sama untuk tabel:

- `tb_kub2_panel63_shiftly`
- `tb_kub2_panel64_shiftly`

## Struktur file

```text
app.js
models/
  tb_kub2Panel63ModelShiftly.js
  tb_kub2Panel64ModelShiftly.js
controllers/
  tb_kub2Panel63ControllerShiftly.js
  tb_kub2Panel64ControllerShiftly.js
routes/
  tb_kub2Panel63RoutesShiftly.js
  tb_kub2Panel64RoutesShiftly.js
```

## Route pada app.js

```js
const tbKub2Panel63ShiftlyRoutes = require(
  './routes/tb_kub2Panel63RoutesShiftly'
);

const tbKub2Panel64ShiftlyRoutes = require(
  './routes/tb_kub2Panel64RoutesShiftly'
);

app.use(
  '/api/kub2-panel63-shiftly',
  tbKub2Panel63ShiftlyRoutes
);

app.use(
  '/api/kub2-panel64-shiftly',
  tbKub2Panel64ShiftlyRoutes
);
```

## Endpoint Panel 64 Shiftly

| Method | Endpoint | Keterangan |
|---|---|---|
| GET | `/api/kub2-panel64-shiftly` | Daftar, filter, urutan, dan pagination |
| GET | `/api/kub2-panel64-shiftly/summary` | Ringkasan total kWh per shift |
| GET | `/api/kub2-panel64-shiftly/:id` | Detail data berdasarkan ID |
| POST | `/api/kub2-panel64-shiftly` | Menambahkan data |
| POST | `/api/kub2-panel64-shiftly/upsert` | Insert/update berdasarkan unique key |
| PUT | `/api/kub2-panel64-shiftly/:id` | Memperbarui seluruh/sebagian field |
| PATCH | `/api/kub2-panel64-shiftly/:id` | Memperbarui sebagian field |
| DELETE | `/api/kub2-panel64-shiftly/:id` | Menghapus data |

## Filter GET

Parameter yang didukung:

- `pm_type`
- `line_table`
- `line_name`
- `shift`
- `shift_date`
- `start_date`
- `end_date`
- `year`
- `month`
- `day`
- `q`
- `page`
- `limit`
- `sort_by`
- `sort_order=ASC|DESC`

Contoh:

```http
GET /api/kub2-panel64-shiftly?line_table=tb_kub2_panel64&shift=shift_1&start_date=2026-08-01&end_date=2026-08-31&page=1&limit=20
```

## Contoh body Panel 64

```json
{
  "pm_type": "DA_01",
  "line_table": "tb_kub2_panel64",
  "line_name": "Panel_64",
  "shift": "shift_1",
  "shift_date": "2026-08-06",
  "shift_start_datetime": "2026-08-06 07:11:10",
  "shift_end_datetime": "2026-08-06 19:49:44",
  "start_kwh": "1713437579.000",
  "end_kwh": "1713593355.000",
  "total_kwh": "155776.000"
}
```

Field `year`, `month`, `month_name`, `day`, dan `day_name` dibuat otomatis dari `shift_date`.

## Unique key

Endpoint upsert mengikuti unique index:

```text
(line_table, shift_date, shift)
```

Struktur tabel Panel 64 diasumsikan sama dengan Panel 63, hanya nama tabelnya yang berbeda.
