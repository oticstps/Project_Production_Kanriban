function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    message: `Endpoint ${req.method} ${req.originalUrl} tidak ditemukan.`,
  });
}

function errorHandler(error, req, res, next) {
  // Parameter next tetap diperlukan agar Express mengenali middleware ini sebagai error handler.
  void next;

  const statusCode = Number(error.statusCode) || 500;

  if (statusCode >= 500) {
    console.error(error);
  }

  res.status(statusCode).json({
    success: false,
    message: statusCode >= 500 ? 'Terjadi kesalahan pada server.' : error.message,
    ...(error.details ? { details: error.details } : {}),
    ...(process.env.NODE_ENV === 'development' && statusCode >= 500
      ? { error: error.message, stack: error.stack }
      : {}),
  });
}

module.exports = {
  notFoundHandler,
  errorHandler,
};
