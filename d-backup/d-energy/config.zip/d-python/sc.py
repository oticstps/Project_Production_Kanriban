import json
import subprocess
import threading
import queue
import time
import os
import sys
from datetime import datetime, timedelta
import logging
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import schedule

# Coba import croniter untuk dukungan ekspresi cron
try:
    from croniter import croniter
    CRON_AVAILABLE = True
except ImportError:
    CRON_AVAILABLE = False

# Konfigurasi logging untuk file (opsional)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("scheduler_gui.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("SchedulerGUI")

class JobDialog(tk.Toplevel):
    """Dialog untuk menambah/mengedit job."""
    def __init__(self, parent, job=None):
        super().__init__(parent)
        self.parent = parent
        self.job = job  # None untuk tambah baru, dict untuk edit
        self.result = None

        self.title("Tambah Job" if job is None else "Edit Job")
        self.geometry("500x450")
        self.resizable(False, False)

        # Buat frame utama
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Nama Job
        ttk.Label(main_frame, text="Nama Job:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.name_var = tk.StringVar(value=job.get("name", "") if job else "")
        ttk.Entry(main_frame, textvariable=self.name_var, width=40).grid(row=0, column=1, sticky=tk.W, pady=2)

        # Path Script Node.js
        ttk.Label(main_frame, text="Path Script:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.script_var = tk.StringVar(value=job.get("script", "") if job else "")
        script_frame = ttk.Frame(main_frame)
        script_frame.grid(row=1, column=1, sticky=tk.EW, pady=2)
        ttk.Entry(script_frame, textvariable=self.script_var, width=30).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(script_frame, text="Browse", command=self.browse_script).pack(side=tk.RIGHT, padx=(5,0))

        # Working Directory
        ttk.Label(main_frame, text="Working Dir (opsional):").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.cwd_var = tk.StringVar(value=job.get("working_dir", "") if job else "")
        cwd_frame = ttk.Frame(main_frame)
        cwd_frame.grid(row=2, column=1, sticky=tk.EW, pady=2)
        ttk.Entry(cwd_frame, textvariable=self.cwd_var, width=30).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(cwd_frame, text="Browse", command=self.browse_cwd).pack(side=tk.RIGHT, padx=(5,0))

        # Tipe Jadwal
        ttk.Label(main_frame, text="Tipe Jadwal:").grid(row=3, column=0, sticky=tk.W, pady=2)
        self.sched_type_var = tk.StringVar()
        sched_types = ["daily", "interval", "weekly"]
        if CRON_AVAILABLE:
            sched_types.append("cron")
        self.sched_combo = ttk.Combobox(main_frame, textvariable=self.sched_type_var, 
                                        values=sched_types, state="readonly", width=15)
        self.sched_combo.grid(row=3, column=1, sticky=tk.W, pady=2)
        self.sched_combo.bind('<<ComboboxSelected>>', self.on_type_change)

        # Frame untuk parameter jadwal (akan berubah sesuai tipe)
        self.param_frame = ttk.LabelFrame(main_frame, text="Parameter Jadwal", padding="5")
        self.param_frame.grid(row=4, column=0, columnspan=2, sticky=tk.EW, pady=10)
        self.param_frame.columnconfigure(0, weight=1)

        # Inisialisasi nilai default
        if job:
            sched = job.get("schedule", {})
            s_type = sched.get("type", "daily")
            self.sched_type_var.set(s_type)
            self.update_param_frame(s_type)
            self.set_param_values(sched)
        else:
            self.sched_type_var.set("daily")
            self.update_param_frame("daily")

        # Tombol
        btn_frame = ttk.Frame(main_frame)
        btn_frame.grid(row=5, column=0, columnspan=2, pady=20)
        ttk.Button(btn_frame, text="Simpan", command=self.save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Batal", command=self.destroy).pack(side=tk.LEFT, padx=5)

        self.grab_set()
        self.wait_window()

    def browse_script(self):
        from tkinter import filedialog
        filename = filedialog.askopenfilename(
            title="Pilih file JavaScript",
            filetypes=[("JavaScript files", "*.js"), ("All files", "*.*")]
        )
        if filename:
            self.script_var.set(filename)

    def browse_cwd(self):
        from tkinter import filedialog
        dirname = filedialog.askdirectory(title="Pilih Working Directory")
        if dirname:
            self.cwd_var.set(dirname)

    def on_type_change(self, event=None):
        s_type = self.sched_type_var.get()
        self.update_param_frame(s_type)

    def update_param_frame(self, s_type):
        # Hapus semua widget di param_frame
        for widget in self.param_frame.winfo_children():
            widget.destroy()

        if s_type == "daily":
            ttk.Label(self.param_frame, text="Waktu (HH:MM):").grid(row=0, column=0, sticky=tk.W)
            self.daily_time_var = tk.StringVar(value="09:00")
            ttk.Entry(self.param_frame, textvariable=self.daily_time_var, width=10).grid(row=0, column=1, sticky=tk.W)
        elif s_type == "interval":
            ttk.Label(self.param_frame, text="Setiap (menit):").grid(row=0, column=0, sticky=tk.W)
            self.interval_min_var = tk.IntVar(value=60)
            ttk.Spinbox(self.param_frame, from_=1, to=1440, textvariable=self.interval_min_var, width=10).grid(row=0, column=1, sticky=tk.W)
        elif s_type == "weekly":
            ttk.Label(self.param_frame, text="Hari:").grid(row=0, column=0, sticky=tk.W)
            self.weekly_day_var = tk.StringVar(value="monday")
            days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
            ttk.Combobox(self.param_frame, textvariable=self.weekly_day_var, values=days, state="readonly", width=10).grid(row=0, column=1, sticky=tk.W)
            ttk.Label(self.param_frame, text="Waktu (HH:MM):").grid(row=1, column=0, sticky=tk.W, pady=(5,0))
            self.weekly_time_var = tk.StringVar(value="09:00")
            ttk.Entry(self.param_frame, textvariable=self.weekly_time_var, width=10).grid(row=1, column=1, sticky=tk.W, pady=(5,0))
        elif s_type == "cron":
            ttk.Label(self.param_frame, text="Ekspresi Cron:").grid(row=0, column=0, sticky=tk.W)
            self.cron_expr_var = tk.StringVar(value="0 * * * *")
            ttk.Entry(self.param_frame, textvariable=self.cron_expr_var, width=20).grid(row=0, column=1, sticky=tk.W)
            ttk.Label(self.param_frame, text="Contoh: '0 9 * * 1' (Senin 09:00)", font=("TkDefaultFont", 8)).grid(row=1, column=0, columnspan=2, sticky=tk.W)

    def set_param_values(self, sched):
        s_type = sched.get("type", "daily")
        if s_type == "daily":
            self.daily_time_var.set(sched.get("time", "09:00"))
        elif s_type == "interval":
            self.interval_min_var.set(sched.get("minutes", 60))
        elif s_type == "weekly":
            self.weekly_day_var.set(sched.get("day", "monday"))
            self.weekly_time_var.set(sched.get("time", "09:00"))
        elif s_type == "cron":
            self.cron_expr_var.set(sched.get("cron_expr", "0 * * * *"))

    def save(self):
        # Validasi input
        name = self.name_var.get().strip()
        script = self.script_var.get().strip()
        if not name:
            messagebox.showerror("Error", "Nama job harus diisi")
            return
        if not script:
            messagebox.showerror("Error", "Path script harus diisi")
            return

        s_type = self.sched_type_var.get()
        schedule_dict = {"type": s_type}

        if s_type == "daily":
            time_str = self.daily_time_var.get().strip()
            if not time_str:
                messagebox.showerror("Error", "Waktu harus diisi")
                return
            schedule_dict["time"] = time_str
        elif s_type == "interval":
            schedule_dict["minutes"] = self.interval_min_var.get()
        elif s_type == "weekly":
            day = self.weekly_day_var.get()
            time_str = self.weekly_time_var.get().strip()
            if not time_str:
                messagebox.showerror("Error", "Waktu harus diisi")
                return
            schedule_dict["day"] = day
            schedule_dict["time"] = time_str
        elif s_type == "cron":
            expr = self.cron_expr_var.get().strip()
            if not expr:
                messagebox.showerror("Error", "Ekspresi cron harus diisi")
                return
            schedule_dict["cron_expr"] = expr

        job_data = {
            "name": name,
            "script": script,
            "schedule": schedule_dict
        }
        cwd = self.cwd_var.get().strip()
        if cwd:
            job_data["working_dir"] = cwd

        self.result = job_data
        self.destroy()

class SchedulerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Node.js Scheduler Manager")
        self.root.geometry("1000x700")

        # Variabel state
        self.jobs = []  # List of job dicts
        self.scheduler_running = False
        self.scheduler_thread = None
        self.stop_scheduler_flag = threading.Event()
        self.log_queue = queue.Queue()
        self.next_run_times = {}  # job_name -> datetime string

        # Load konfigurasi
        self.config_file = "jobs.json"
        self.load_jobs()

        # Setup UI
        self.create_widgets()
        self.refresh_job_list()

        # Start polling log queue
        self.poll_log_queue()

    def create_widgets(self):
        # Menu
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Simpan Konfigurasi", command=self.save_jobs)
        file_menu.add_separator()
        file_menu.add_command(label="Keluar", command=self.on_closing)

        # Toolbar
        toolbar = ttk.Frame(self.root)
        toolbar.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)

        self.start_btn = ttk.Button(toolbar, text="▶ Start Scheduler", command=self.start_scheduler)
        self.start_btn.pack(side=tk.LEFT, padx=2)
        self.stop_btn = ttk.Button(toolbar, text="⏹ Stop Scheduler", command=self.stop_scheduler, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)

        ttk.Button(toolbar, text="➕ Tambah Job", command=self.add_job).pack(side=tk.LEFT, padx=2)
        self.edit_btn = ttk.Button(toolbar, text="✏️ Edit Job", command=self.edit_job, state=tk.DISABLED)
        self.edit_btn.pack(side=tk.LEFT, padx=2)
        self.delete_btn = ttk.Button(toolbar, text="❌ Hapus Job", command=self.delete_job, state=tk.DISABLED)
        self.delete_btn.pack(side=tk.LEFT, padx=2)
        self.run_btn = ttk.Button(toolbar, text="▶ Jalankan Sekarang", command=self.run_job_now, state=tk.DISABLED)
        self.run_btn.pack(side=tk.LEFT, padx=2)

        # Main content: paned window
        paned = ttk.PanedWindow(self.root, orient=tk.VERTICAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Frame untuk treeview
        tree_frame = ttk.Frame(paned)
        paned.add(tree_frame, weight=3)

        # Treeview untuk daftar job
        columns = ("name", "script", "schedule", "next_run", "last_status")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("name", text="Nama Job")
        self.tree.heading("script", text="Script")
        self.tree.heading("schedule", text="Jadwal")
        self.tree.heading("next_run", text="Eksekusi Berikutnya")
        self.tree.heading("last_status", text="Status Terakhir")

        self.tree.column("name", width=150)
        self.tree.column("script", width=250)
        self.tree.column("schedule", width=150)
        self.tree.column("next_run", width=180)
        self.tree.column("last_status", width=150)

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.grid(row=0, column=0, sticky=tk.NSEW)
        scrollbar.grid(row=0, column=1, sticky=tk.NS)

        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)

        # Bind selection event
        self.tree.bind('<<TreeviewSelect>>', self.on_tree_select)
        self.tree.bind('<Double-1>', lambda e: self.edit_job())
        self.tree.bind('<Button-3>', self.show_context_menu)

        # Context menu
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="Jalankan Sekarang", command=self.run_job_now)
        self.context_menu.add_command(label="Edit", command=self.edit_job)
        self.context_menu.add_command(label="Hapus", command=self.delete_job)

        # Frame untuk log
        log_frame = ttk.LabelFrame(paned, text="Log Eksekusi", padding="5")
        paned.add(log_frame, weight=1)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=8, state=tk.DISABLED)
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # Status bar
        self.status_var = tk.StringVar(value="Scheduler: Berhenti")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def show_context_menu(self, event):
        """Tampilkan menu konteks pada klik kanan."""
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)

    def on_tree_select(self, event):
        """Aktifkan tombol edit/delete/run saat ada item yang dipilih."""
        selected = self.tree.selection()
        if selected:
            self.edit_btn.config(state=tk.NORMAL)
            self.delete_btn.config(state=tk.NORMAL)
            self.run_btn.config(state=tk.NORMAL)
        else:
            self.edit_btn.config(state=tk.DISABLED)
            self.delete_btn.config(state=tk.DISABLED)
            self.run_btn.config(state=tk.DISABLED)

    def add_job(self):
        dialog = JobDialog(self.root)
        if dialog.result:
            self.jobs.append(dialog.result)
            self.save_jobs()
            self.refresh_job_list()
            self.log(f"Job '{dialog.result['name']}' ditambahkan.")

    def edit_job(self):
        selected = self.tree.selection()
        if not selected:
            return
        item = selected[0]
        job_name = self.tree.item(item, "values")[0]
        job = next((j for j in self.jobs if j["name"] == job_name), None)
        if job:
            dialog = JobDialog(self.root, job)
            if dialog.result:
                # Update job
                index = self.jobs.index(job)
                self.jobs[index] = dialog.result
                self.save_jobs()
                self.refresh_job_list()
                self.log(f"Job '{dialog.result['name']}' diperbarui.")
                # Jika scheduler berjalan, perlu reload jadwal? 
                # Untuk sederhana, kita restart scheduler
                if self.scheduler_running:
                    self.restart_scheduler()

    def delete_job(self):
        selected = self.tree.selection()
        if not selected:
            return
        item = selected[0]
        job_name = self.tree.item(item, "values")[0]
        if messagebox.askyesno("Konfirmasi", f"Hapus job '{job_name}'?"):
            self.jobs = [j for j in self.jobs if j["name"] != job_name]
            self.save_jobs()
            self.refresh_job_list()
            self.log(f"Job '{job_name}' dihapus.")
            if self.scheduler_running:
                self.restart_scheduler()

    def run_job_now(self):
        selected = self.tree.selection()
        if not selected:
            return
        item = selected[0]
        job_name = self.tree.item(item, "values")[0]
        job = next((j for j in self.jobs if j["name"] == job_name), None)
        if job:
            self.log(f"Menjalankan job '{job_name}' secara manual...")
            # Jalankan di thread terpisah agar GUI tidak freeze
            threading.Thread(target=self._execute_job, args=(job,), daemon=True).start()

    def _execute_job(self, job):
        """Eksekusi script Node.js (dipanggil dari thread)."""
        name = job.get("name", "unknown")
        script = job["script"]
        cwd = job.get("working_dir") or os.path.dirname(script)
        try:
            result = subprocess.run(
                ["node", script],
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=3600
            )
            if result.returncode == 0:
                self.log_queue.put(f"✅ {name}: Selesai (exit 0)")
                if result.stdout:
                    for line in result.stdout.splitlines():
                        self.log_queue.put(f"   [OUT] {line}")
                self._update_last_status(name, "Sukses")
            else:
                self.log_queue.put(f"❌ {name}: Error (exit {result.returncode})")
                if result.stderr:
                    for line in result.stderr.splitlines():
                        self.log_queue.put(f"   [ERR] {line}")
                self._update_last_status(name, f"Error (code {result.returncode})")
        except subprocess.TimeoutExpired:
            self.log_queue.put(f"⏰ {name}: Timeout setelah 1 jam")
            self._update_last_status(name, "Timeout")
        except Exception as e:
            self.log_queue.put(f"🔥 {name}: Exception - {e}")
            self._update_last_status(name, f"Exception: {str(e)[:30]}")

    def _update_last_status(self, job_name, status):
        """Update status terakhir di treeview (dari thread)."""
        # Cari item di treeview dengan nama job_name
        for item in self.tree.get_children():
            if self.tree.item(item, "values")[0] == job_name:
                values = list(self.tree.item(item, "values"))
                values[4] = status
                self.root.after(0, lambda: self.tree.item(item, values=values))
                break

    def refresh_job_list(self):
        """Refresh tampilan treeview dengan data jobs."""
        # Hapus semua item
        for item in self.tree.get_children():
            self.tree.delete(item)
        # Tambahkan job
        for job in self.jobs:
            name = job["name"]
            script = job["script"]
            sched = job["schedule"]
            s_type = sched["type"]
            if s_type == "daily":
                sched_str = f"Setiap hari {sched.get('time', '')}"
            elif s_type == "interval":
                sched_str = f"Setiap {sched.get('minutes', '')} menit"
            elif s_type == "weekly":
                sched_str = f"{sched.get('day', '').capitalize()} {sched.get('time', '')}"
            elif s_type == "cron":
                sched_str = f"Cron: {sched.get('cron_expr', '')}"
            else:
                sched_str = "Unknown"
            next_run = self.next_run_times.get(name, "-")
            last_status = "-"
            self.tree.insert("", tk.END, values=(name, script, sched_str, next_run, last_status))

        # Update tombol jika tidak ada job terpilih
        self.on_tree_select(None)

    def load_jobs(self):
        """Muat jobs dari file JSON."""
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                self.jobs = json.load(f)
        except FileNotFoundError:
            self.jobs = []
        except json.JSONDecodeError:
            messagebox.showerror("Error", f"File {self.config_file} rusak.")
            self.jobs = []

    def save_jobs(self):
        """Simpan jobs ke file JSON."""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.jobs, f, indent=2, ensure_ascii=False)
            self.log("Konfigurasi disimpan.", level="INFO")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal menyimpan konfigurasi: {e}")

    def log(self, message, level="INFO"):
        """Tambahkan pesan ke log widget dan queue."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted = f"[{timestamp}] {message}"
        self.log_queue.put(formatted)

    def poll_log_queue(self):
        """Ambil pesan dari queue dan tampilkan di widget log."""
        try:
            while True:
                msg = self.log_queue.get_nowait()
                self.log_text.config(state=tk.NORMAL)
                self.log_text.insert(tk.END, msg + "\n")
                self.log_text.see(tk.END)
                self.log_text.config(state=tk.DISABLED)
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self.poll_log_queue)

    def start_scheduler(self):
        """Mulai thread scheduler."""
        if self.scheduler_running:
            return
        self.stop_scheduler_flag.clear()
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self.scheduler_thread.start()
        self.scheduler_running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.status_var.set("Scheduler: Berjalan")
        self.log("Scheduler dimulai.")

    def stop_scheduler(self):
        """Hentikan thread scheduler."""
        if not self.scheduler_running:
            return
        self.stop_scheduler_flag.set()
        self.scheduler_running = False
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.status_var.set("Scheduler: Berhenti")
        self.log("Scheduler dihentikan.")

    def restart_scheduler(self):
        """Restart scheduler (misal setelah edit job)."""
        if self.scheduler_running:
            self.stop_scheduler()
            # Tunggu sebentar agar thread selesai
            self.root.after(500, self.start_scheduler)

    def _scheduler_loop(self):
        """Loop utama scheduler (berjalan di thread terpisah)."""
        # Bersihkan semua job yang sudah terjadwal
        schedule.clear()
        # Daftarkan job dari konfigurasi
        for job in self.jobs:
            self._schedule_job(job)

        # Update next run times setiap menit
        last_update = 0

        while not self.stop_scheduler_flag.is_set():
            schedule.run_pending()
            # Update next run times setiap 60 detik
            now = time.time()
            if now - last_update > 60:
                self._update_next_run_times()
                last_update = now
            time.sleep(1)

    def _schedule_job(self, job):
        """Daftarkan job ke library schedule."""
        name = job.get("name", "unnamed")
        script = job["script"]
        working_dir = job.get("working_dir")
        sched = job["schedule"]
        s_type = sched["type"]

        def job_func():
            self._execute_job(job)

        if s_type == "daily":
            schedule.every().day.at(sched["time"]).do(job_func)
        elif s_type == "interval":
            schedule.every(sched["minutes"]).minutes.do(job_func)
        elif s_type == "weekly":
            day = sched["day"]
            time_str = sched["time"]
            getattr(schedule.every(), day).at(time_str).do(job_func)
        elif s_type == "cron":
            if CRON_AVAILABLE:
                # Untuk cron, kita buat job yang dicek setiap menit
                cron_expr = sched["cron_expr"]
                def cron_check():
                    now = datetime.now()
                    if croniter.match(cron_expr, now):
                        job_func()
                schedule.every().minute.do(cron_check)
            else:
                self.log_queue.put(f"⚠️ {name}: Cron tidak didukung (croniter tidak terinstall)")

    def _update_next_run_times(self):
        """Hitung waktu eksekusi berikutnya untuk setiap job dan update UI."""
        new_times = {}
        now = datetime.now()
        for job in self.jobs:
            name = job["name"]
            sched = job["schedule"]
            s_type = sched["type"]
            next_time_str = "-"
            try:
                if s_type == "daily":
                    t = datetime.strptime(sched["time"], "%H:%M").time()
                    next_dt = datetime.combine(now.date(), t)
                    if next_dt <= now:
                        next_dt += timedelta(days=1)
                    next_time_str = next_dt.strftime("%Y-%m-%d %H:%M")
                elif s_type == "interval":
                    # Perkiraan kasar: tambah interval ke waktu sekarang
                    mins = sched["minutes"]
                    next_dt = now + timedelta(minutes=mins)
                    next_time_str = next_dt.strftime("%Y-%m-%d %H:%M")
                elif s_type == "weekly":
                    days_map = {"monday":0, "tuesday":1, "wednesday":2, "thursday":3, "friday":4, "saturday":5, "sunday":6}
                    target_day = days_map[sched["day"]]
                    t = datetime.strptime(sched["time"], "%H:%M").time()
                    days_ahead = target_day - now.weekday()
                    if days_ahead < 0 or (days_ahead == 0 and now.time() >= t):
                        days_ahead += 7
                    next_dt = datetime.combine(now.date() + timedelta(days=days_ahead), t)
                    next_time_str = next_dt.strftime("%Y-%m-%d %H:%M")
                elif s_type == "cron" and CRON_AVAILABLE:
                    cron_expr = sched["cron_expr"]
                    cron = croniter(cron_expr, now)
                    next_dt = cron.get_next(datetime)
                    next_time_str = next_dt.strftime("%Y-%m-%d %H:%M")
            except Exception as e:
                next_time_str = "Error"
            new_times[name] = next_time_str

        self.next_run_times = new_times
        # Update treeview di main thread
        self.root.after(0, self.refresh_job_list)

    def on_closing(self):
        """Tangani penutupan aplikasi."""
        if self.scheduler_running:
            self.stop_scheduler()
        self.save_jobs()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = SchedulerApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()