const multer = require('multer');

const allowedExtensions = ['csv', 'xls', 'xlsx'];

const storage = multer.memoryStorage();

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024
  },
  fileFilter: (req, file, cb) => {
    const extension = file.originalname.split('.').pop().toLowerCase();

    if (!allowedExtensions.includes(extension)) {
      return cb(new Error('File harus berformat CSV, XLS, atau XLSX'));
    }

    cb(null, true);
  }
});

module.exports = upload;
