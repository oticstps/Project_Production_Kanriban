const FullTextModel = require('../models/fullTextModel_p1');

class FullTextController_p1 {
  static async getAll(req, res) {
    try {
      const data = await FullTextModel.getAll();

      return res.status(200).json({
        success: true,
        message: 'Data berhasil diambil',
        data
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Gagal mengambil data',
        error: error.message
      });
    }
  }

  static async getLatest(req, res) {
    try {
      const data = await FullTextModel.getLatest();

      if (!data) {
        return res.status(404).json({
          success: false,
          message: 'Data terbaru tidak ditemukan'
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Data terbaru berhasil diambil',
        data
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Gagal mengambil data terbaru',
        error: error.message
      });
    }
  }

  static async getById(req, res) {
    try {
      const { id } = req.params;
      const data = await FullTextModel.getById(id);

      if (!data) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Detail data berhasil diambil',
        data
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Gagal mengambil detail data',
        error: error.message
      });
    }
  }

  static async create(req, res) {
    try {
      const insertId = await FullTextModel.create(req.body);
      const newData = await FullTextModel.getById(insertId);

      return res.status(201).json({
        success: true,
        message: 'Data berhasil ditambahkan',
        data: newData
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Gagal menambahkan data',
        error: error.message
      });
    }
  }

  static async update(req, res) {
    try {
      const { id } = req.params;

      const existing = await FullTextModel.getById(id);
      if (!existing) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      await FullTextModel.update(id, req.body);
      const updatedData = await FullTextModel.getById(id);

      return res.status(200).json({
        success: true,
        message: 'Data berhasil diperbarui',
        data: updatedData
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Gagal memperbarui data',
        error: error.message
      });
    }
  }

  static async delete(req, res) {
    try {
      const { id } = req.params;

      const existing = await FullTextModel.getById(id);
      if (!existing) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      await FullTextModel.delete(id);

      return res.status(200).json({
        success: true,
        message: 'Data berhasil dihapus'
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: 'Gagal menghapus data',
        error: error.message
      });
    }
  }
}

module.exports = FullTextController_p1;