const {
  bulkUpsertHourly,
  findHourlyByDate,
} = require("../models/pltsP1HourlyModel");

const normalizeObjectKey = (key) => {
  return String(key || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^\w]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
};

const getValueByPossibleKeys = (row, possibleKeys) => {
  const normalizedRow = {};

  Object.keys(row || {}).forEach((key) => {
    normalizedRow[normalizeObjectKey(key)] = row[key];
  });

  for (const key of possibleKeys) {
    const normalizedKey = normalizeObjectKey(key);

    if (
      normalizedRow[normalizedKey] !== undefined &&
      normalizedRow[normalizedKey] !== null &&
      normalizedRow[normalizedKey] !== ""
    ) {
      return normalizedRow[normalizedKey];
    }
  }

  return "";
};

const isValidDate = (value) => {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""));
};

const normalizeTime = (value) => {
  if (value === undefined || value === null || value === "") return "";

  if (typeof value === "number") {
    const fraction = value >= 1 ? value % 1 : value;
    const totalMinutes = Math.round(fraction * 24 * 60);
    const hour = Math.floor(totalMinutes / 60) % 24;
    const minute = totalMinutes % 60;

    return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
  }

  const text = String(value).trim();

  if (!text) return "";

  const decimalNumber = Number(text);

  if (!Number.isNaN(decimalNumber) && text.includes(".")) {
    const fraction = decimalNumber >= 1 ? decimalNumber % 1 : decimalNumber;
    const totalMinutes = Math.round(fraction * 24 * 60);
    const hour = Math.floor(totalMinutes / 60) % 24;
    const minute = totalMinutes % 60;

    return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
  }

  const match = text.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);

  if (!match) return "";

  const hour = Number(match[1]);
  const minute = Number(match[2]);

  if (hour < 0 || hour > 23) return "";
  if (minute < 0 || minute > 59) return "";

  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
};

const parseDecimal = (value) => {
  if (value === undefined || value === null || value === "") return null;

  const normalized = String(value).replace(",", ".").trim();
  const numberValue = Number(normalized);

  if (Number.isNaN(numberValue)) return null;

  return numberValue;
};

const formatDisplayTime = (hour, minute) => {
  return `${hour}:${String(minute).padStart(2, "0")}`;
};

const formatDatabaseTime = (hour, minute) => {
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
};

const toNumberOrZero = (value) => {
  if (value === undefined || value === null || value === "") return 0;

  const numberValue = Number(value);

  if (Number.isNaN(numberValue)) return 0;

  return numberValue;
};

const generateFiveMinuteSlots = (dateCustom, dbRows = []) => {
  const rowMap = new Map();

  dbRows.forEach((row) => {
    const normalizedTime = normalizeTime(row.time_value);

    if (normalizedTime) {
      rowMap.set(normalizedTime, row);
    }
  });

  const result = [];

  for (let totalMinute = 0; totalMinute < 24 * 60; totalMinute += 5) {
    const hour = Math.floor(totalMinute / 60);
    const minute = totalMinute % 60;

    const displayTime = formatDisplayTime(hour, minute);
    const databaseTime = formatDatabaseTime(hour, minute);
    const energyDate = `${dateCustom} ${databaseTime}:00`;

    const foundRow = rowMap.get(databaseTime);

    result.push({
      x: displayTime,
      energy_date: energyDate,
      date_custom: dateCustom,
      production_kwh: foundRow ? toNumberOrZero(foundRow.production_kwh) : 0,
      inverter1_kwh: foundRow ? toNumberOrZero(foundRow.inverter1_kwh) : 0,
      inverter2_kwh: foundRow ? toNumberOrZero(foundRow.inverter2_kwh) : 0,
    });
  }

  return result;
};

const bulkImportHourly = async (req, res) => {
  try {
    const dateCustom = req.body.date_custom || req.body.dateCustom;
    const data = Array.isArray(req.body.data) ? req.body.data : [];

    if (!isValidDate(dateCustom)) {
      return res.status(400).json({
        message: "date_custom wajib diisi dengan format YYYY-MM-DD.",
      });
    }

    if (data.length === 0) {
      return res.status(400).json({
        message: "Data kosong. Tidak ada data yang bisa disimpan.",
      });
    }

    const validRows = [];
    const failedRows = [];

    data.forEach((row, index) => {
      const rawTime = getValueByPossibleKeys(row, [
        "x",
        "time",
        "jam",
        "energy_time",
        "column_1",
      ]);

      const normalizedTime = normalizeTime(rawTime);

      if (!normalizedTime) {
        failedRows.push({
          index,
          reason: "Format waktu pada kolom x tidak valid.",
          row,
        });
        return;
      }

      const productionKwh = parseDecimal(
        getValueByPossibleKeys(row, [
          "pv_power",
          "pv power",
          "production",
          "production_kwh",
          "production kwh",
          "produksi",
          "column_2",
        ])
      );

      const inverter1Kwh = parseDecimal(
        getValueByPossibleKeys(row, [
          "inverter1",
          "inverter_1",
          "inverter 1",
          "inverter1_kwh",
          "inverter 1 kwh",
          "column_3",
        ])
      );

      const inverter2Kwh = parseDecimal(
        getValueByPossibleKeys(row, [
          "inverter2",
          "inverter_2",
          "inverter 2",
          "inverter2_kwh",
          "inverter 2 kwh",
          "column_4",
        ])
      );

      validRows.push({
        energy_date: `${dateCustom} ${normalizedTime}:00`,
        date_custom: dateCustom,
        production_kwh: productionKwh,
        inverter1_kwh: inverter1Kwh,
        inverter2_kwh: inverter2Kwh,
      });
    });

    if (validRows.length === 0) {
      return res.status(400).json({
        message: "Tidak ada baris valid untuk disimpan.",
        result: {
          successCount: 0,
          failedCount: failedRows.length,
          failedRows,
        },
      });
    }

    const dbResult = await bulkUpsertHourly(validRows);

    return res.status(200).json({
      message: "Import data PLTS P1 hourly berhasil.",
      result: {
        successCount: validRows.length,
        failedCount: failedRows.length,
        affectedRows: dbResult.affectedRows || 0,
        failedRows,
      },
    });
  } catch (error) {
    console.error("bulkImportHourly error:", error);

    return res.status(500).json({
      message: "Terjadi kesalahan saat menyimpan data PLTS P1 hourly.",
      error: error.message,
    });
  }
};

const getHourlyByDate = async (req, res) => {
  try {
    const dateCustom = req.query.date || req.query.date_custom || req.params.date;

    if (!isValidDate(dateCustom)) {
      return res.status(400).json({
        message: "Parameter date wajib diisi dengan format YYYY-MM-DD.",
      });
    }

    const dbRows = await findHourlyByDate(dateCustom);
    const monitoringRows = generateFiveMinuteSlots(dateCustom, dbRows);

    return res.status(200).json({
      message: "Data monitoring PLTS P1 hourly berhasil diambil.",
      date_custom: dateCustom,
      total: monitoringRows.length,
      data: monitoringRows,
    });
  } catch (error) {
    console.error("getHourlyByDate error:", error);

    return res.status(500).json({
      message: "Terjadi kesalahan saat mengambil data monitoring PLTS P1 hourly.",
      error: error.message,
    });
  }
};

module.exports = {
  bulkImportHourly,
  getHourlyByDate,
};