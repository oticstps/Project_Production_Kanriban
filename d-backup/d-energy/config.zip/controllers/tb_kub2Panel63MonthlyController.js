const tbKub2Panel63MonthlyModel = require(
    '../models/tb_kub2Panel63ModelMonthly'
);

const requiredCreateFields = [
    'pm_type',
    'line_table',
    'year',
    'month',
];

const numericFields = [
    'start_kwh',
    'end_kwh',
    'total_kwh',
];

const validateCompositeKey = (pmType, lineTable, year, month) => {
    if (!pmType || !lineTable) {
        return 'pm_type dan line_table wajib diisi.';
    }

    const parsedYear = Number(year);
    const parsedMonth = Number(month);

    if (!Number.isInteger(parsedYear) || parsedYear < 1900) {
        return 'year harus berupa tahun yang valid.';
    }

    if (
        !Number.isInteger(parsedMonth) ||
        parsedMonth < 1 ||
        parsedMonth > 12
    ) {
        return 'month harus berupa angka 1 sampai 12.';
    }

    return null;
};

const validatePayload = (body, isCreate = false) => {
    const errors = [];

    if (isCreate) {
        for (const field of requiredCreateFields) {
            if (
                body[field] === undefined ||
                body[field] === null ||
                body[field] === ''
            ) {
                errors.push(`${field} wajib diisi.`);
            }
        }
    }

    if (
        body.year !== undefined &&
        (!Number.isInteger(Number(body.year)) ||
            Number(body.year) < 1900)
    ) {
        errors.push('year harus berupa tahun yang valid.');
    }

    if (
        body.month !== undefined &&
        (!Number.isInteger(Number(body.month)) ||
            Number(body.month) < 1 ||
            Number(body.month) > 12)
    ) {
        errors.push('month harus berupa angka 1 sampai 12.');
    }

    for (const field of numericFields) {
        if (
            body[field] !== undefined &&
            body[field] !== null &&
            body[field] !== '' &&
            Number.isNaN(Number(body[field]))
        ) {
            errors.push(`${field} harus berupa angka.`);
        }
    }

    return errors;
};

/**
 * GET /api/kub2-panel63-monthly
 */
const getAll = async (req, res) => {
    try {
        const result = await tbKub2Panel63MonthlyModel.findAll({
            pmType: req.query.pm_type,
            lineTable: req.query.line_table,
            lineName: req.query.line_name,
            year: req.query.year,
            month: req.query.month,
            page: req.query.page,
            limit: req.query.limit,
        });

        return res.status(200).json({
            success: true,
            message: 'Data monthly berhasil diambil.',
            data: result.rows,
            pagination: result.pagination,
        });
    } catch (error) {
        console.error('getAll monthly error:', error);

        return res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil data.',
            error: error.message,
        });
    }
};

/**
 * GET /api/kub2-panel63-monthly/summary/yearly
 */
const getYearlySummary = async (req, res) => {
    try {
        const rows =
            await tbKub2Panel63MonthlyModel.getYearlySummary({
                pmType: req.query.pm_type,
                lineTable: req.query.line_table,
                lineName: req.query.line_name,
                year: req.query.year,
            });

        return res.status(200).json({
            success: true,
            message: 'Ringkasan tahunan berhasil diambil.',
            data: rows,
        });
    } catch (error) {
        console.error('getYearlySummary error:', error);

        return res.status(500).json({
            success: false,
            message:
                'Terjadi kesalahan saat mengambil ringkasan tahunan.',
            error: error.message,
        });
    }
};

/**
 * GET /api/kub2-panel63-monthly/:pmType/:lineTable/:year/:month
 */
const getByKey = async (req, res) => {
    try {
        const { pmType, lineTable, year, month } = req.params;

        const validationError = validateCompositeKey(
            pmType,
            lineTable,
            year,
            month
        );

        if (validationError) {
            return res.status(400).json({
                success: false,
                message: validationError,
            });
        }

        const row = await tbKub2Panel63MonthlyModel.findByKey(
            pmType,
            lineTable,
            year,
            month
        );

        if (!row) {
            return res.status(404).json({
                success: false,
                message: 'Data monthly tidak ditemukan.',
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Data monthly berhasil ditemukan.',
            data: row,
        });
    } catch (error) {
        console.error('getByKey monthly error:', error);

        return res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil data.',
            error: error.message,
        });
    }
};

/**
 * POST /api/kub2-panel63-monthly
 */
const create = async (req, res) => {
    try {
        const validationErrors = validatePayload(req.body, true);

        if (validationErrors.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Validasi data gagal.',
                errors: validationErrors,
            });
        }

        const existingData =
            await tbKub2Panel63MonthlyModel.findByKey(
                req.body.pm_type,
                req.body.line_table,
                req.body.year,
                req.body.month
            );

        if (existingData) {
            return res.status(409).json({
                success: false,
                message:
                    'Data dengan pm_type, line_table, year, dan month tersebut sudah tersedia.',
            });
        }

        const createdData =
            await tbKub2Panel63MonthlyModel.create({
                ...req.body,
                year: Number(req.body.year),
                month: Number(req.body.month),
            });

        return res.status(201).json({
            success: true,
            message: 'Data monthly berhasil ditambahkan.',
            data: createdData,
        });
    } catch (error) {
        console.error('create monthly error:', error);

        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                success: false,
                message:
                    'Data dengan composite key tersebut sudah tersedia.',
            });
        }

        return res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat menambahkan data.',
            error: error.message,
        });
    }
};

/**
 * PUT/PATCH /api/kub2-panel63-monthly/:pmType/:lineTable/:year/:month
 */
const update = async (req, res) => {
    try {
        const { pmType, lineTable, year, month } = req.params;

        const keyValidationError = validateCompositeKey(
            pmType,
            lineTable,
            year,
            month
        );

        if (keyValidationError) {
            return res.status(400).json({
                success: false,
                message: keyValidationError,
            });
        }

        const validationErrors = validatePayload(req.body, false);

        if (validationErrors.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Validasi data gagal.',
                errors: validationErrors,
            });
        }

        const existingData =
            await tbKub2Panel63MonthlyModel.findByKey(
                pmType,
                lineTable,
                year,
                month
            );

        if (!existingData) {
            return res.status(404).json({
                success: false,
                message: 'Data monthly tidak ditemukan.',
            });
        }

        const result = await tbKub2Panel63MonthlyModel.update(
            pmType,
            lineTable,
            year,
            month,
            req.body
        );

        return res.status(200).json({
            success: true,
            message: 'Data monthly berhasil diperbarui.',
            data: result.data,
        });
    } catch (error) {
        console.error('update monthly error:', error);

        return res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat memperbarui data.',
            error: error.message,
        });
    }
};

/**
 * DELETE /api/kub2-panel63-monthly/:pmType/:lineTable/:year/:month
 */
const remove = async (req, res) => {
    try {
        const { pmType, lineTable, year, month } = req.params;

        const validationError = validateCompositeKey(
            pmType,
            lineTable,
            year,
            month
        );

        if (validationError) {
            return res.status(400).json({
                success: false,
                message: validationError,
            });
        }

        const affectedRows =
            await tbKub2Panel63MonthlyModel.remove(
                pmType,
                lineTable,
                year,
                month
            );

        if (affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Data monthly tidak ditemukan.',
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Data monthly berhasil dihapus.',
        });
    } catch (error) {
        console.error('delete monthly error:', error);

        return res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat menghapus data.',
            error: error.message,
        });
    }
};

module.exports = {
    getAll,
    getByKey,
    getYearlySummary,
    create,
    update,
    remove,
};