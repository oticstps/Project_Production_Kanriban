const PltsP1DailyModel = require("../models/pltsP1DailyModel");

const getAllData = async (req, res) => {
  try {
    const { start_date, end_date, limit, offset } = req.query;

    const data = await PltsP1DailyModel.getAll({
      startDate: start_date,
      endDate: end_date,
      limit: limit || 100,
      offset: offset || 0,
    });

    return res.status(200).json({
      success: true,
      message: "Data berhasil diambil.",
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || "Gagal mengambil data.",
    });
  }
};

const getDataByDate = async (req, res) => {
  try {
    const { energy_date } = req.params;

    const data = await PltsP1DailyModel.getByDate(energy_date);

    if (!data) {
      return res.status(404).json({
        success: false,
        message: "Data tidak ditemukan.",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Data berhasil ditemukan.",
      data,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || "Gagal mengambil data.",
    });
  }
};

const createOrUpdateData = async (req, res) => {
  try {
    await PltsP1DailyModel.upsert(req.body);

    return res.status(200).json({
      success: true,
      message: "Data berhasil disimpan.",
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      message: error.message || "Gagal menyimpan data.",
    });
  }
};

const bulkCreateOrUpdateData = async (req, res) => {
  try {
    const rows = Array.isArray(req.body) ? req.body : req.body.data;

    const result = await PltsP1DailyModel.bulkUpsert(rows);

    return res.status(200).json({
      success: true,
      message: "Proses import selesai.",
      result,
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      message: error.message || "Gagal import data.",
    });
  }
};

const updateData = async (req, res) => {
  try {
    const { energy_date } = req.params;

    const result = await PltsP1DailyModel.updateByDate(energy_date, req.body);

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "Data tidak ditemukan.",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Data berhasil diperbarui.",
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      message: error.message || "Gagal memperbarui data.",
    });
  }
};

const deleteData = async (req, res) => {
  try {
    const { energy_date } = req.params;

    const result = await PltsP1DailyModel.deleteByDate(energy_date);

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "Data tidak ditemukan.",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Data berhasil dihapus.",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || "Gagal menghapus data.",
    });
  }
};

module.exports = {
  getAllData,
  getDataByDate,
  createOrUpdateData,
  bulkCreateOrUpdateData,
  updateData,
  deleteData,
};