const PltsP1DailyModelFullStack = require('../models/pltsP1DailyModelFullStack');

const PltsP1DailyControllerFullStack = {
  async getAll(req, res) {
    try {
      const data = await PltsP1DailyModelFullStack.getAll();

      res.status(200).json({
        success: true,
        message: 'Data PLTS P1 daily berhasil diambil',
        data
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil data PLTS P1 daily',
        error: error.message
      });
    }
  },

  async getByDate(req, res) {
    try {
      const { energy_date } = req.params;

      const data = await PltsP1DailyModelFullStack.getByDate(energy_date);

      if (!data) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      res.status(200).json({
        success: true,
        message: 'Data PLTS P1 daily berhasil diambil',
        data
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil data PLTS P1 daily',
        error: error.message
      });
    }
  },

  async create(req, res) {
    try {
      const {
        energy_date,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      } = req.body;

      if (!energy_date) {
        return res.status(400).json({
          success: false,
          message: 'energy_date wajib diisi'
        });
      }

      await PltsP1DailyModelFullStack.create({
        energy_date,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      });

      res.status(201).json({
        success: true,
        message: 'Data PLTS P1 daily berhasil ditambahkan'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menambahkan data PLTS P1 daily',
        error: error.message
      });
    }
  },

  async update(req, res) {
    try {
      const { energy_date } = req.params;

      const {
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      } = req.body;

      const result = await PltsP1DailyModelFullStack.update(energy_date, {
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      });

      if (result.affectedRows === 0) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      res.status(200).json({
        success: true,
        message: 'Data PLTS P1 daily berhasil diperbarui'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal memperbarui data PLTS P1 daily',
        error: error.message
      });
    }
  },

  async delete(req, res) {
    try {
      const { energy_date } = req.params;

      const result = await PltsP1DailyModelFullStack.delete(energy_date);

      if (result.affectedRows === 0) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      res.status(200).json({
        success: true,
        message: 'Data PLTS P1 daily berhasil dihapus'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menghapus data PLTS P1 daily',
        error: error.message
      });
    }
  }
};

module.exports = PltsP1DailyControllerFullStack;