const MonthlyReportService = require('../services/MonthlyReportService');

const MonthlyReportController = {
    getAll: async (req, res) => {
        try {
            const { table } = req.params;
            const limit = Number(req.query.limit || 500);
            const data = await MonthlyReportService.getAll(table, limit);
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    getByComposite: async (req, res) => {
        try {
            const { table, pm_type, line_table, year, month } = req.params;
            const data = await MonthlyReportService.getByComposite(table, pm_type, line_table, Number(year), Number(month));
            if (!data) return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    create: async (req, res) => {
        try {
            const { table } = req.params;
            const data = await MonthlyReportService.create(table, req.body);
            res.status(201).json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    update: async (req, res) => {
        try {
            const { table, pm_type, line_table, year, month } = req.params;
            const affected = await MonthlyReportService.update(table, pm_type, line_table, Number(year), Number(month), req.body);
            res.json({ success: true, affected });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    delete: async (req, res) => {
        try {
            const { table, pm_type, line_table, year, month } = req.params;
            const affected = await MonthlyReportService.delete(table, pm_type, line_table, Number(year), Number(month));
            res.json({ success: true, affected });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    getByYear: async (req, res) => {
        try {
            const { table, year } = req.params;
            const data = await MonthlyReportService.getByYear(table, Number(year));
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },
};

module.exports = MonthlyReportController;