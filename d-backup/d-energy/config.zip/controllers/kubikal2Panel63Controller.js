const RealtimeModel = require('../models/kubikal2Panel63Model');

// GET /api/realtime – ambil data terkini
exports.getCurrent = async (req, res) => {
    try {
        let data = await RealtimeModel.getCurrent();
        if (!data) {
            await RealtimeModel.update({}); // buat baris default id=1
            data = await RealtimeModel.getCurrent();
        }
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// PUT /api/realtime – update umum (partial)
exports.update = async (req, res) => {
    try {
        await RealtimeModel.update(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 1. Update arus
exports.updateCurrent = async (req, res) => {
    try {
        await RealtimeModel.updateCurrent(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 2. Update tegangan LL
exports.updateVoltageLL = async (req, res) => {
    try {
        await RealtimeModel.updateVoltageLL(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 3. Update tegangan LN
exports.updateVoltageLN = async (req, res) => {
    try {
        await RealtimeModel.updateVoltageLN(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 4. Update daya aktif
exports.updateActivePower = async (req, res) => {
    try {
        await RealtimeModel.updateActivePower(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 5. Update daya semu
exports.updateApparentPower = async (req, res) => {
    try {
        await RealtimeModel.updateApparentPower(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 6. Update faktor daya
exports.updatePowerFactor = async (req, res) => {
    try {
        await RealtimeModel.updatePowerFactor(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 7. Update daya reaktif
exports.updateReactivePower = async (req, res) => {
    try {
        await RealtimeModel.updateReactivePower(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 8. Update frekuensi
exports.updateFrequency = async (req, res) => {
    try {
        await RealtimeModel.updateFrequency(req.body);
        const updated = await RealtimeModel.getCurrent();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// DELETE /api/realtime – hapus data (opsional)
exports.delete = async (req, res) => {
    try {
        await RealtimeModel.delete();
        res.json({ message: 'Data berhasil dihapus' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};