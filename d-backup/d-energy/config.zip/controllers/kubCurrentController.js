// controllers/kubCurrentController.js
const kubCurrentModel = require('../models/kubCurrentModel');

class kubCurrentController {
    // GET /api/data
    static async getData(req, res) {
        try {
            const data = await kubCurrentModel.getAll();
            res.status(200).json({
                status: 'success',
                message: 'Data retrieved successfully',
                data: data
            });
        } catch (error) {
            res.status(500).json({
                status: 'error',
                message: error.message
            });
        }
    }

    // POST /api/data
    static async addData(req, res) {
        try {
            const { panel, current_avg, current_a, current_b, current_c, current_n } = req.body;

            // Validasi sederhana
            if (!panel) {
                return res.status(400).json({ message: 'Panel name is required' });
            }

            const result = await kubCurrentModel.create({
                panel,
                current_avg,
                current_a,
                current_b,
                current_c,
                current_n
            });

            res.status(201).json({
                status: 'success',
                message: 'Data added successfully',
                insertId: result.insertId
            });
        } catch (error) {
            res.status(500).json({
                status: 'error',
                message: error.message
            });
        }
    }

    // DELETE /api/data/:dateTime
    static async deleteData(req, res) {
        try {
            const { dateTime } = req.params;
            const result = await kubCurrentModel.deleteByDateTime(dateTime);

            if (result.affectedRows === 0) {
                return res.status(404).json({ message: 'Data not found' });
            }

            res.status(200).json({
                status: 'success',
                message: 'Data deleted successfully'
            });
        } catch (error) {
            res.status(500).json({
                status: 'error',
                message: error.message
            });
        }
    }
    
    // PUT /api/data/:dateTime (Edit)
    static async updateData(req, res) {
        try {
            const { dateTime } = req.params;
            const newData = req.body;
            
            const result = await kubCurrentModel.update(dateTime, newData);

            if (result.affectedRows === 0) {
                return res.status(404).json({ message: 'Data not found' });
            }

            res.status(200).json({
                status: 'success',
                message: 'Data updated successfully'
            });
        } catch (error) {
            res.status(500).json({
                status: 'error',
                message: error.message
            });
        }
    }
}

module.exports = kubCurrentController;