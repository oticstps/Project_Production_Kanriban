const TbKub2Panel63ModelShiftly = require('../models/tb_kub2Panel63ModelShiftly');

const ALLOWED_FIELDS = [
    'pm_type',
    'line_table',
    'line_name',
    'shift',
    'shift_date',
    'shift_start_datetime',
    'shift_end_datetime',
    'start_kwh',
    'end_kwh',
    'total_kwh',
    'year',
    'month',
    'month_name',
    'day',
    'day_name'
];

const NUMERIC_FIELDS = [
    'start_kwh',
    'end_kwh',
    'total_kwh',
    'year',
    'month',
    'day'
];

const isValidDate = (value) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value))) {
        return false;
    }

    const [year, month, day] = String(value).split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));

    return (
        date.getUTCFullYear() === year &&
        date.getUTCMonth() === month - 1 &&
        date.getUTCDate() === day
    );
};

const getDateMetadata = (shiftDate) => {
    if (!isValidDate(shiftDate)) {
        throw new Error('shift_date harus menggunakan format YYYY-MM-DD.');
    }

    const [year, month, day] = shiftDate.split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));

    return {
        year,
        month,
        month_name: new Intl.DateTimeFormat('en-US', {
            month: 'long',
            timeZone: 'UTC'
        }).format(date),
        day,
        day_name: new Intl.DateTimeFormat('en-US', {
            weekday: 'long',
            timeZone: 'UTC'
        }).format(date)
    };
};

const sanitizePayload = (body, options = {}) => {
    const payload = {};

    for (const field of ALLOWED_FIELDS) {
        if (body[field] !== undefined) {
            payload[field] = body[field] === '' ? null : body[field];
        }
    }

    for (const field of NUMERIC_FIELDS) {
        if (
            payload[field] !== undefined &&
            payload[field] !== null &&
            Number.isNaN(Number(payload[field]))
        ) {
            throw new Error(`${field} harus berupa angka.`);
        }
    }

    if (payload.shift_date) {
        Object.assign(payload, getDateMetadata(payload.shift_date));
    }

    if (options.requireUniqueFields) {
        const requiredFields = ['line_table', 'shift_date', 'shift'];
        const missingFields = requiredFields.filter(
            (field) =>
                payload[field] === undefined ||
                payload[field] === null ||
                String(payload[field]).trim() === ''
        );

        if (missingFields.length > 0) {
            throw new Error(
                `Field wajib belum lengkap: ${missingFields.join(', ')}.`
            );
        }
    }

    if (
        payload.shift_start_datetime &&
        payload.shift_end_datetime &&
        new Date(payload.shift_end_datetime) < new Date(payload.shift_start_datetime)
    ) {
        throw new Error(
            'shift_end_datetime tidak boleh lebih kecil dari shift_start_datetime.'
        );
    }

    return payload;
};

const parseId = (value) => {
    const id = Number.parseInt(value, 10);

    if (!Number.isInteger(id) || id <= 0) {
        return null;
    }

    return id;
};

const handleDatabaseError = (res, error) => {
    console.error(error);

    if (error.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({
            success: false,
            message:
                'Data dengan kombinasi line_table, shift_date, dan shift tersebut sudah tersedia.'
        });
    }

    if (error.code === 'ER_BAD_NULL_ERROR') {
        return res.status(400).json({
            success: false,
            message: 'Terdapat field wajib yang bernilai null.'
        });
    }

    return res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan pada server.',
        error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
};

class TbKub2Panel63ControllerShiftly {
    static async getAll(req, res) {
        try {
            const filters = {
                pm_type: req.query.pm_type,
                line_table: req.query.line_table,
                line_name: req.query.line_name,
                shift: req.query.shift,
                shift_date: req.query.shift_date,
                start_date: req.query.start_date,
                end_date: req.query.end_date,
                year: req.query.year,
                month: req.query.month,
                day: req.query.day,
                q: req.query.q,
                sort_by: req.query.sort_by,
                sort_order: req.query.sort_order,
                page: req.query.page,
                limit: req.query.limit
            };

            const result = await TbKub2Panel63ModelShiftly.findAll(filters);

            return res.status(200).json({
                success: true,
                message: 'Data shift Panel 63 berhasil diambil.',
                data: result.rows,
                pagination: result.pagination
            });
        } catch (error) {
            return handleDatabaseError(res, error);
        }
    }

    static async getById(req, res) {
        const id = parseId(req.params.id);

        if (!id) {
            return res.status(400).json({
                success: false,
                message: 'ID tidak valid.'
            });
        }

        try {
            const data = await TbKub2Panel63ModelShiftly.findById(id);

            if (!data) {
                return res.status(404).json({
                    success: false,
                    message: 'Data shift Panel 63 tidak ditemukan.'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Data shift Panel 63 berhasil diambil.',
                data
            });
        } catch (error) {
            return handleDatabaseError(res, error);
        }
    }

    static async create(req, res) {
        try {
            const payload = sanitizePayload(req.body, {
                requireUniqueFields: true
            });

            const data = await TbKub2Panel63ModelShiftly.create(payload);

            return res.status(201).json({
                success: true,
                message: 'Data shift Panel 63 berhasil ditambahkan.',
                data
            });
        } catch (error) {
            if (!error.code) {
                return res.status(400).json({
                    success: false,
                    message: error.message
                });
            }

            return handleDatabaseError(res, error);
        }
    }

    static async update(req, res) {
        const id = parseId(req.params.id);

        if (!id) {
            return res.status(400).json({
                success: false,
                message: 'ID tidak valid.'
            });
        }

        try {
            const existingData =
                await TbKub2Panel63ModelShiftly.findById(id);

            if (!existingData) {
                return res.status(404).json({
                    success: false,
                    message: 'Data shift Panel 63 tidak ditemukan.'
                });
            }

            const payload = sanitizePayload(req.body);

            const lineTable =
                payload.line_table !== undefined
                    ? payload.line_table
                    : existingData.line_table;
            const shiftDate =
                payload.shift_date !== undefined
                    ? payload.shift_date
                    : existingData.shift_date;
            const shift =
                payload.shift !== undefined ? payload.shift : existingData.shift;

            if (!lineTable || !shiftDate || !shift) {
                return res.status(400).json({
                    success: false,
                    message:
                        'line_table, shift_date, dan shift tidak boleh kosong.'
                });
            }

            const startDateTime =
                payload.shift_start_datetime !== undefined
                    ? payload.shift_start_datetime
                    : existingData.shift_start_datetime;
            const endDateTime =
                payload.shift_end_datetime !== undefined
                    ? payload.shift_end_datetime
                    : existingData.shift_end_datetime;

            if (
                startDateTime &&
                endDateTime &&
                new Date(endDateTime) < new Date(startDateTime)
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        'shift_end_datetime tidak boleh lebih kecil dari shift_start_datetime.'
                });
            }

            const data = await TbKub2Panel63ModelShiftly.update(id, payload);

            return res.status(200).json({
                success: true,
                message: 'Data shift Panel 63 berhasil diperbarui.',
                data
            });
        } catch (error) {
            if (!error.code) {
                return res.status(400).json({
                    success: false,
                    message: error.message
                });
            }

            return handleDatabaseError(res, error);
        }
    }

    static async upsert(req, res) {
        try {
            const payload = sanitizePayload(req.body, {
                requireUniqueFields: true
            });

            const data = await TbKub2Panel63ModelShiftly.upsert(payload);

            return res.status(200).json({
                success: true,
                message:
                    'Data shift Panel 63 berhasil ditambahkan atau diperbarui.',
                data
            });
        } catch (error) {
            if (!error.code) {
                return res.status(400).json({
                    success: false,
                    message: error.message
                });
            }

            return handleDatabaseError(res, error);
        }
    }

    static async delete(req, res) {
        const id = parseId(req.params.id);

        if (!id) {
            return res.status(400).json({
                success: false,
                message: 'ID tidak valid.'
            });
        }

        try {
            const deleted = await TbKub2Panel63ModelShiftly.delete(id);

            if (!deleted) {
                return res.status(404).json({
                    success: false,
                    message: 'Data shift Panel 63 tidak ditemukan.'
                });
            }

            return res.status(200).json({
                success: true,
                message: 'Data shift Panel 63 berhasil dihapus.'
            });
        } catch (error) {
            return handleDatabaseError(res, error);
        }
    }

    static async getSummary(req, res) {
        try {
            const filters = {
                pm_type: req.query.pm_type,
                line_table: req.query.line_table,
                line_name: req.query.line_name,
                shift: req.query.shift,
                shift_date: req.query.shift_date,
                start_date: req.query.start_date,
                end_date: req.query.end_date,
                year: req.query.year,
                month: req.query.month
            };

            const data =
                await TbKub2Panel63ModelShiftly.getSummary(filters);

            return res.status(200).json({
                success: true,
                message: 'Ringkasan data shift Panel 63 berhasil diambil.',
                data
            });
        } catch (error) {
            return handleDatabaseError(res, error);
        }
    }
}

module.exports = TbKub2Panel63ControllerShiftly;
