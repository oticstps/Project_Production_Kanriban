const powerMeterModel = require('../models/powerMeterModel');
const HttpError = require('../utils/httpError');
const {
  normalizeDate,
  normalizeDateTime,
  addOneDay,
  parseInteger,
} = require('../utils/dateTime');

function buildDateFilters(query) {
  const exactDateTime = normalizeDateTime(query.date_time, 'date_time');
  const date = normalizeDate(query.date, 'date');
  const startDateTime = normalizeDateTime(query.start, 'start');
  const endDateTime = normalizeDateTime(query.end, 'end');

  const modes = [
    Boolean(exactDateTime),
    Boolean(date),
    Boolean(startDateTime || endDateTime),
  ].filter(Boolean).length;

  if (modes > 1) {
    throw new HttpError(
      400,
      'Gunakan salah satu mode filter: date_time, date, atau pasangan start/end.',
    );
  }

  if (startDateTime && endDateTime && startDateTime > endDateTime) {
    throw new HttpError(400, 'Nilai start tidak boleh lebih besar daripada end.');
  }

  return {
    exactDateTime,
    dayStart: date,
    dayEndExclusive: date ? addOneDay(date) : null,
    startDateTime,
    endDateTime,
  };
}

async function getTables(req, res, next) {
  try {
    const tables = powerMeterModel.getAllowedTables();

    res.status(200).json({
      success: true,
      total: tables.length,
      data: tables,
    });
  } catch (error) {
    next(error);
  }
}

async function getDataByDateTime(req, res, next) {
  try {
    const { table } = req.params;
    const filters = buildDateFilters(req.query);

    if (
      !filters.exactDateTime &&
      !filters.dayStart &&
      !filters.startDateTime &&
      !filters.endDateTime
    ) {
      throw new HttpError(
        400,
        'Endpoint data memerlukan filter date_time, date, start, atau end. Gunakan endpoint /latest untuk data terbaru.',
      );
    }

    const page = parseInteger(req.query.page, 1, {
      min: 1,
      max: 1000000,
      fieldName: 'page',
    });
    const limit = parseInteger(req.query.limit, 100, {
      min: 1,
      max: 1000,
      fieldName: 'limit',
    });
    const order = String(req.query.order || 'desc').toLowerCase();

    if (!['asc', 'desc'].includes(order)) {
      throw new HttpError(400, 'order hanya boleh bernilai asc atau desc.');
    }

    const offset = (page - 1) * limit;
    const result = await powerMeterModel.findRows({
      tableName: table,
      filters,
      order: order.toUpperCase(),
      limit,
      offset,
    });

    res.status(200).json({
      success: true,
      table,
      filters: {
        date_time: filters.exactDateTime,
        date: filters.dayStart,
        start: filters.startDateTime,
        end: filters.endDateTime,
        order,
      },
      pagination: {
        page,
        limit,
        total: result.total,
        total_pages: Math.ceil(result.total / limit),
        returned: result.rows.length,
      },
      data: result.rows,
    });
  } catch (error) {
    next(error);
  }
}

async function getLatest(req, res, next) {
  try {
    const { table } = req.params;
    const limit = parseInteger(req.query.limit, 1, {
      min: 1,
      max: 100,
      fieldName: 'limit',
    });

    const rows = await powerMeterModel.findLatest({
      tableName: table,
      limit,
    });

    res.status(200).json({
      success: true,
      table,
      returned: rows.length,
      data: rows,
    });
  } catch (error) {
    next(error);
  }
}

async function getDateBounds(req, res, next) {
  try {
    const { table } = req.params;
    const result = await powerMeterModel.getDateBounds(table);

    res.status(200).json({
      success: true,
      table,
      data: result,
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getTables,
  getDataByDateTime,
  getLatest,
  getDateBounds,
};
