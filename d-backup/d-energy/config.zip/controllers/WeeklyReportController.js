const WeeklyReportService = require('../services/WeeklyReportService');

const WeeklyReportController = {
    getAll: async (req, res) => {
        try {
            const { table } = req.params;
            const limit = Number(req.query.limit || 500);
            const data = await WeeklyReportService.getAll(table, limit);
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    getByComposite: async (req, res) => {
        try {
            const { table, pm_type, line_table, year, week } = req.params;
            const data = await WeeklyReportService.getByComposite(table, pm_type, line_table, Number(year), Number(week));
            if (!data) return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    create: async (req, res) => {
        try {
            const { table } = req.params;
            const data = await WeeklyReportService.create(table, req.body);
            res.status(201).json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    update: async (req, res) => {
        try {
            const { table, pm_type, line_table, year, week } = req.params;
            const affected = await WeeklyReportService.update(table, pm_type, line_table, Number(year), Number(week), req.body);
            res.json({ success: true, affected });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    delete: async (req, res) => {
        try {
            const { table, pm_type, line_table, year, week } = req.params;
            const affected = await WeeklyReportService.delete(table, pm_type, line_table, Number(year), Number(week));
            res.json({ success: true, affected });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    getByYear: async (req, res) => {
        try {
            const { table, year } = req.params;
            const data = await WeeklyReportService.getByYear(table, Number(year));
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },
};

module.exports = WeeklyReportController;