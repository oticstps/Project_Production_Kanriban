const pool = require('../config/db');
const { parseSpreadsheet } = require('../utils/fileParser');
const { createImportBatch, getImportBatches } = require('../models/importBatch.model');
const { bulkInsertImportRecords, getRecordsByBatchId } = require('../models/importRecord.model');

function isValidDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value || '') && !Number.isNaN(Date.parse(value));
}

async function importFile(req, res, next) {
  let connection;

  try {
    const { importDate } = req.body;

    if (!isValidDate(importDate)) {
      return res.status(400).json({
        message: 'Tanggal import wajib diisi dengan format YYYY-MM-DD sebelum data diinsert.'
      });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'File CSV/XLS/XLSX wajib diupload.' });
    }

    const rows = parseSpreadsheet(req.file.buffer);

    if (!rows.length) {
      return res.status(400).json({ message: 'File tidak memiliki data yang dapat diimport.' });
    }

    connection = await pool.getConnection();
    await connection.beginTransaction();

    const batchId = await createImportBatch(connection, {
      importDate,
      originalFilename: req.file.originalname,
      totalRows: rows.length
    });

    const insertedRows = await bulkInsertImportRecords(connection, {
      batchId,
      importDate,
      rows
    });

    await connection.commit();

    return res.status(201).json({
      message: 'Import berhasil.',
      batchId,
      importDate,
      originalFilename: req.file.originalname,
      totalRows: rows.length,
      insertedRows,
      sample: rows.slice(0, 3)
    });
  } catch (error) {
    if (connection) await connection.rollback();
    return next(error);
  } finally {
    if (connection) connection.release();
  }
}

async function listBatches(req, res, next) {
  let connection;

  try {
    connection = await pool.getConnection();
    const batches = await getImportBatches(connection, req.query.limit || 20);
    return res.json({ data: batches });
  } catch (error) {
    return next(error);
  } finally {
    if (connection) connection.release();
  }
}

async function listBatchRecords(req, res, next) {
  let connection;

  try {
    connection = await pool.getConnection();
    const records = await getRecordsByBatchId(connection, req.params.id, req.query.limit || 100);
    return res.json({ data: records });
  } catch (error) {
    return next(error);
  } finally {
    if (connection) connection.release();
  }
}

module.exports = {
  importFile,
  listBatches,
  listBatchRecords
};
