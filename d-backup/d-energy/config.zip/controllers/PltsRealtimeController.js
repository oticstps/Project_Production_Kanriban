const PltsRealtimeModel = require("../models/PltsRealtimeModel");

class PltsRealtimeController {
  static async getAllData(req, res) {
    try {
      const { plant } = req.params;
      const { limit } = req.query;

      const data = await PltsRealtimeModel.getAllData(plant, limit || 100);

      return res.status(200).json({
        success: true,
        message: "Data realtime berhasil diambil",
        plant,
        total: data.length,
        data,
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
  }

  static async getLatestData(req, res) {
    try {
      const { plant } = req.params;

      const data = await PltsRealtimeModel.getLatestData(plant);

      return res.status(200).json({
        success: true,
        message: "Data realtime terbaru berhasil diambil",
        plant,
        data,
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
  }

  static async getDataByDateRange(req, res) {
    try {
      const { plant } = req.params;
      const { start_date, end_date } = req.query;

      if (!start_date || !end_date) {
        return res.status(400).json({
          success: false,
          message: "Parameter start_date dan end_date wajib diisi",
        });
      }

      const data = await PltsRealtimeModel.getDataByDateRange(
        plant,
        start_date,
        end_date
      );

      return res.status(200).json({
        success: true,
        message: "Data berdasarkan range tanggal berhasil diambil",
        plant,
        total: data.length,
        filter: {
          start_date,
          end_date,
        },
        data,
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
  }

  static async insertData(req, res) {
    try {
      const { plant } = req.params;
      const { date_time, power, kwh } = req.body;

      if (!date_time || power === undefined || kwh === undefined) {
        return res.status(400).json({
          success: false,
          message: "date_time, power, dan kwh wajib diisi",
        });
      }

      const insertedData = await PltsRealtimeModel.insertData(plant, {
        date_time,
        power,
        kwh,
      });

      return res.status(201).json({
        success: true,
        message: "Data realtime berhasil ditambahkan",
        plant,
        data: insertedData,
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
  }

  static async deleteData(req, res) {
    try {
      const { plant, id } = req.params;

      const affectedRows = await PltsRealtimeModel.deleteData(plant, id);

      if (affectedRows === 0) {
        return res.status(404).json({
          success: false,
          message: "Data tidak ditemukan",
        });
      }

      return res.status(200).json({
        success: true,
        message: "Data berhasil dihapus",
        plant,
        idPrimary: id,
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }
  }
}

module.exports = PltsRealtimeController;