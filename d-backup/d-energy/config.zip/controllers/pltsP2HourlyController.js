const {
  bulkUpsertP2Hourly,
  findP2HourlyByDate,
} = require("../models/pltsP2HourlyModel");

const normalizeObjectKey = (key) => {
  return String(key || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^\w]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
};

const getValueByPossibleKeys = (row, possibleKeys) => {
  const normalizedRow = {};

  Object.keys(row || {}).forEach((key) => {
    normalizedRow[normalizeObjectKey(key)] = row[key];
  });

  for (const key of possibleKeys) {
    const normalizedKey = normalizeObjectKey(key);

    if (
      normalizedRow[normalizedKey] !== undefined &&
      normalizedRow[normalizedKey] !== null &&
      normalizedRow[normalizedKey] !== ""
    ) {
      return normalizedRow[normalizedKey];
    }
  }

  return "";
};

const pad2 = (value) => String(value).padStart(2, "0");

const excelSerialDateTimeToMysql = (serialValue) => {
  const serial = Number(serialValue);

  if (Number.isNaN(serial)) return "";

  const days = Math.floor(serial);
  const fraction = serial - days;
  const totalSeconds = Math.round(fraction * 24 * 60 * 60);

  const excelEpoch = new Date(Date.UTC(1899, 11, 30));
  const date = new Date(excelEpoch.getTime() + days * 24 * 60 * 60 * 1000);

  const hour = Math.floor(totalSeconds / 3600) % 24;
  const minute = Math.floor((totalSeconds % 3600) / 60);
  const second = totalSeconds % 60;

  const year = date.getUTCFullYear();
  const month = pad2(date.getUTCMonth() + 1);
  const day = pad2(date.getUTCDate());

  return `${year}-${month}-${day} ${pad2(hour)}:${pad2(minute)}:${pad2(second)}`;
};

const normalizeDateTime = (value) => {
  if (value === undefined || value === null || value === "") return "";

  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    const year = value.getFullYear();
    const month = pad2(value.getMonth() + 1);
    const day = pad2(value.getDate());
    const hour = pad2(value.getHours());
    const minute = pad2(value.getMinutes());
    const second = pad2(value.getSeconds());

    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  }

  if (typeof value === "number") {
    return excelSerialDateTimeToMysql(value);
  }

  const text = String(value).trim();

  if (!text) return "";

  if (/^\d+(\.\d+)?$/.test(text)) {
    return excelSerialDateTimeToMysql(text);
  }

  const isoMatch = text.match(
    /^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?$/
  );

  if (isoMatch) {
    const year = isoMatch[1];
    const month = isoMatch[2];
    const day = isoMatch[3];
    const hour = pad2(isoMatch[4]);
    const minute = isoMatch[5];
    const second = isoMatch[6] ? pad2(isoMatch[6]) : "00";

    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  }

  const slashMatch = text.match(
    /^(\d{1,2})[/-](\d{1,2})[/-](\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?$/
  );

  if (slashMatch) {
    const day = pad2(slashMatch[1]);
    const month = pad2(slashMatch[2]);
    const year = slashMatch[3];
    const hour = pad2(slashMatch[4]);
    const minute = slashMatch[5];
    const second = slashMatch[6] ? pad2(slashMatch[6]) : "00";

    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  }

  return "";
};

const isValidDateTime = (value) => {
  return /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(String(value || ""));
};

const isValidDate = (value) => {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""));
};

const parseDecimal = (value) => {
  if (value === undefined || value === null || value === "") return null;

  const normalized = String(value).replace(",", ".").trim();
  const numberValue = Number(normalized);

  if (Number.isNaN(numberValue)) return null;

  return numberValue;
};

const toNumberOrZero = (value) => {
  if (value === undefined || value === null || value === "") return 0;

  const numberValue = Number(value);

  if (Number.isNaN(numberValue)) return 0;

  return numberValue;
};

const generateFiveMinuteSlots = (dateCustom, dbRows = []) => {
  const rowMap = new Map();

  dbRows.forEach((row) => {
    if (row.time_value) {
      rowMap.set(row.time_value, row);
    }
  });

  const result = [];

  for (let totalMinute = 0; totalMinute < 24 * 60; totalMinute += 5) {
    const hour = Math.floor(totalMinute / 60);
    const minute = totalMinute % 60;

    const displayTime = `${hour}:${pad2(minute)}`;
    const dbTime = `${pad2(hour)}:${pad2(minute)}`;
    const energyDate = `${dateCustom} ${dbTime}:00`;

    const foundRow = rowMap.get(dbTime);

    result.push({
      x: displayTime,
      energy_date: energyDate,
      purchased_from_grid_kwh: foundRow
        ? toNumberOrZero(foundRow.purchased_from_grid_kwh)
        : 0,
      generated_by_pv_kwh: foundRow
        ? toNumberOrZero(foundRow.generated_by_pv_kwh)
        : 0,
      fed_to_grid_kwh: foundRow
        ? toNumberOrZero(foundRow.fed_to_grid_kwh)
        : 0,
      consumed_by_appliances_kwh: foundRow
        ? toNumberOrZero(foundRow.consumed_by_appliances_kwh)
        : 0,
    });
  }

  return result;
};

const bulkImportP2Hourly = async (req, res) => {
  try {
    const data = Array.isArray(req.body.data) ? req.body.data : [];

    if (data.length === 0) {
      return res.status(400).json({
        message: "Data kosong. Tidak ada data yang bisa disimpan.",
      });
    }

    const validRows = [];
    const failedRows = [];

    data.forEach((row, index) => {
      const rawDateTime = getValueByPossibleKeys(row, [
        "date",
        "datetime",
        "energy_date",
        "tanggal",
        "waktu",
        "column_1",
      ]);

      const energyDate = normalizeDateTime(rawDateTime);

      if (!isValidDateTime(energyDate)) {
        failedRows.push({
          index,
          reason: "Format Date tidak valid. Gunakan format YYYY-MM-DD HH:mm.",
          row,
        });
        return;
      }

      const generatedByPv = parseDecimal(
        getValueByPossibleKeys(row, [
          "pv_output_kw",
          "pv_output",
          "pv output",
          "pv output kw",
          "generated_by_pv_kwh",
          "generated by pv",
          "generated by pv kwh",
          "column_2",
        ])
      );

      const purchasedFromGrid = parseDecimal(
        getValueByPossibleKeys(row, [
          "mains_power_kw",
          "mains_power",
          "mains power",
          "mains power kw",
          "purchased_from_grid_kwh",
          "purchased from grid",
          "purchased from grid kwh",
          "column_3",
        ])
      );

      const fedToGrid = parseDecimal(
        getValueByPossibleKeys(row, [
          "feed_in_power_kw",
          "feed_in_power",
          "feed in power",
          "feed-in power",
          "feed-in power kw",
          "fed_to_grid_kwh",
          "fed to grid",
          "fed to grid kwh",
          "column_4",
        ])
      );

      const consumedByAppliances = parseDecimal(
        getValueByPossibleKeys(row, [
          "consumed_by_appliances_kw",
          "consumed_by_appliances_kwh",
          "consumed_by_appliances",
          "consumed by appliances",
          "consumed by appliances kw",
          "consumed by appliances kwh",
          "appliances",
          "column_5",
        ])
      );

      validRows.push({
        energy_date: energyDate,
        purchased_from_grid_kwh: purchasedFromGrid,
        generated_by_pv_kwh: generatedByPv,
        fed_to_grid_kwh: fedToGrid,
        consumed_by_appliances_kwh: consumedByAppliances,
      });
    });

    if (validRows.length === 0) {
      return res.status(400).json({
        message: "Tidak ada baris valid untuk disimpan.",
        result: {
          successCount: 0,
          failedCount: failedRows.length,
          failedRows,
        },
      });
    }

    const dbResult = await bulkUpsertP2Hourly(validRows);

    return res.status(200).json({
      message: "Import data PLTS P2 hourly berhasil.",
      result: {
        successCount: validRows.length,
        failedCount: failedRows.length,
        affectedRows: dbResult.affectedRows || 0,
        failedRows,
      },
    });
  } catch (error) {
    console.error("bulkImportP2Hourly error:", error);

    return res.status(500).json({
      message: "Terjadi kesalahan saat menyimpan data PLTS P2 hourly.",
      error: error.message,
    });
  }
};

const getP2HourlyByDate = async (req, res) => {
  try {
    const dateCustom = req.query.date || req.query.date_custom || req.params.date;

    if (!isValidDate(dateCustom)) {
      return res.status(400).json({
        message: "Parameter date wajib diisi dengan format YYYY-MM-DD.",
      });
    }

    const dbRows = await findP2HourlyByDate(dateCustom);
    const monitoringRows = generateFiveMinuteSlots(dateCustom, dbRows);

    return res.status(200).json({
      message: "Data monitoring PLTS P2 hourly berhasil diambil.",
      date_custom: dateCustom,
      total: monitoringRows.length,
      data: monitoringRows,
    });
  } catch (error) {
    console.error("getP2HourlyByDate error:", error);

    return res.status(500).json({
      message: "Terjadi kesalahan saat mengambil data monitoring PLTS P2 hourly.",
      error: error.message,
    });
  }
};

module.exports = {
  bulkImportP2Hourly,
  getP2HourlyByDate,
};