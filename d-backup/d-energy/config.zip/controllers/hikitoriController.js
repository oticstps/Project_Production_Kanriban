const Hikitori = require('../models/hikitori');

const getHikitori = async (req, res) => {
  try {
    const filters = {
      name_hikitori: req.query.name,
      status: req.query.status,
      startDate: req.query.startDate,
      endDate: req.query.endDate
    };
    const data = await Hikitori.getAll(filters);
    res.json({ success: true, data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

const getSummary = async (req, res) => {
  try {
    const filters = {
      name_hikitori: req.query.name,
      startDate: req.query.startDate,
      endDate: req.query.endDate
    };
    const summary = await Hikitori.getSummary(filters);
    res.json({ success: true, data: summary });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { getHikitori, getSummary };