const PltsP2DailyModelFullStack = require('../models/pltsP2DailyModelFullStack');

const PltsP2DailyControllerFullStack = {
  async getAll(req, res) {
    try {
      const data = await PltsP2DailyModelFullStack.getAll();

      res.status(200).json({
        success: true,
        message: 'Data PLTS P2 daily berhasil diambil',
        data
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil data PLTS P2 daily',
        error: error.message
      });
    }
  },

  async getByDate(req, res) {
    try {
      const { energy_date } = req.params;

      const data = await PltsP2DailyModelFullStack.getByDate(energy_date);

      if (!data) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      res.status(200).json({
        success: true,
        message: 'Data PLTS P2 daily berhasil diambil',
        data
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil data PLTS P2 daily',
        error: error.message
      });
    }
  },

  async create(req, res) {
    try {
      const {
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      } = req.body;

      if (!energy_date) {
        return res.status(400).json({
          success: false,
          message: 'energy_date wajib diisi'
        });
      }

      await PltsP2DailyModelFullStack.create({
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      });

      res.status(201).json({
        success: true,
        message: 'Data PLTS P2 daily berhasil ditambahkan'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menambahkan data PLTS P2 daily',
        error: error.message
      });
    }
  },

  async update(req, res) {
    try {
      const { energy_date } = req.params;

      const {
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      } = req.body;

      const result = await PltsP2DailyModelFullStack.update(energy_date, {
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      });

      if (result.affectedRows === 0) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      res.status(200).json({
        success: true,
        message: 'Data PLTS P2 daily berhasil diperbarui'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal memperbarui data PLTS P2 daily',
        error: error.message
      });
    }
  },

  async delete(req, res) {
    try {
      const { energy_date } = req.params;

      const result = await PltsP2DailyModelFullStack.delete(energy_date);

      if (result.affectedRows === 0) {
        return res.status(404).json({
          success: false,
          message: 'Data tidak ditemukan'
        });
      }

      res.status(200).json({
        success: true,
        message: 'Data PLTS P2 daily berhasil dihapus'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menghapus data PLTS P2 daily',
        error: error.message
      });
    }
  }
};

module.exports = PltsP2DailyControllerFullStack;