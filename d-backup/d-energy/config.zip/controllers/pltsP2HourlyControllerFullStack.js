const PltsP2HourlyModelFullStack = require('../models/pltsP2HourlyModelFullStack');

function responseSuccess(res, message, data = null, extra = {}) {
  return res.status(200).json({ success: true, message, data, ...extra });
}

function responseCreated(res, message, data = null) {
  return res.status(201).json({ success: true, message, data });
}

function responseError(res, statusCode, message, error = null) {
  return res.status(statusCode).json({
    success: false,
    message,
    error: error?.message || error || null,
  });
}

function getFilters(req) {
  return {
    date: req.query.date,
    startDate: req.query.start_date,
    endDate: req.query.end_date,
    limit: req.query.limit,
    offset: req.query.offset,
    order: req.query.order || 'ASC',
  };
}

exports.index = async (req, res) => {
  try {
    const filters = getFilters(req);

    const [rows, total] = await Promise.all([
      PltsP2HourlyModelFullStack.getAll(filters),
      PltsP2HourlyModelFullStack.count(filters),
    ]);

    return responseSuccess(res, 'Data hourly PLTS Plant 2 berhasil diambil', rows, {
      meta: {
        total,
        limit: Math.min(Math.max(Number(filters.limit) || 5000, 1), 20000),
        offset: Math.max(Number(filters.offset) || 0, 0),
        order: String(filters.order).toUpperCase() === 'DESC' ? 'DESC' : 'ASC',
      },
    });
  } catch (error) {
    return responseError(res, 500, 'Gagal mengambil data hourly PLTS Plant 2', error);
  }
};

exports.show = async (req, res) => {
  try {
    const energyDate = decodeURIComponent(req.params.energy_date);
    const data = await PltsP2HourlyModelFullStack.findByEnergyDate(energyDate);

    if (!data) return responseError(res, 404, 'Data hourly Plant 2 tidak ditemukan');

    return responseSuccess(res, 'Detail hourly Plant 2 berhasil diambil', data);
  } catch (error) {
    return responseError(res, 500, 'Gagal mengambil detail hourly Plant 2', error);
  }
};

exports.latest = async (req, res) => {
  try {
    const data = await PltsP2HourlyModelFullStack.getLatest();

    if (!data) return responseError(res, 404, 'Data terbaru hourly Plant 2 tidak ditemukan');

    return responseSuccess(res, 'Data terbaru hourly Plant 2 berhasil diambil', data);
  } catch (error) {
    return responseError(res, 500, 'Gagal mengambil data terbaru hourly Plant 2', error);
  }
};

exports.dailySummary = async (req, res) => {
  try {
    const { date } = req.query;

    if (!date) {
      return responseError(res, 400, 'Parameter date wajib diisi. Contoh: ?date=2026-05-04');
    }

    const data = await PltsP2HourlyModelFullStack.dailySummary(date);

    if (!data) return responseError(res, 404, 'Ringkasan hourly Plant 2 tidak ditemukan');

    return responseSuccess(res, 'Ringkasan hourly Plant 2 berhasil diambil', data);
  } catch (error) {
    return responseError(res, 500, 'Gagal mengambil ringkasan hourly Plant 2', error);
  }
};

exports.store = async (req, res) => {
  try {
    if (!req.body.energy_date) {
      return responseError(res, 400, 'energy_date wajib diisi');
    }

    const existing = await PltsP2HourlyModelFullStack.findByEnergyDate(req.body.energy_date);

    if (existing) {
      return responseError(res, 409, 'Data hourly Plant 2 dengan energy_date tersebut sudah ada');
    }

    const created = await PltsP2HourlyModelFullStack.create(req.body);
    return responseCreated(res, 'Data hourly Plant 2 berhasil ditambahkan', created);
  } catch (error) {
    return responseError(res, 500, 'Gagal menambahkan data hourly Plant 2', error);
  }
};

exports.upsert = async (req, res) => {
  try {
    if (!req.body.energy_date) {
      return responseError(res, 400, 'energy_date wajib diisi');
    }

    const saved = await PltsP2HourlyModelFullStack.upsert(req.body);
    return responseSuccess(res, 'Data hourly Plant 2 berhasil disimpan atau diperbarui', saved);
  } catch (error) {
    return responseError(res, 500, 'Gagal menyimpan data hourly Plant 2', error);
  }
};

exports.update = async (req, res) => {
  try {
    const energyDate = decodeURIComponent(req.params.energy_date);
    const existing = await PltsP2HourlyModelFullStack.findByEnergyDate(energyDate);

    if (!existing) return responseError(res, 404, 'Data hourly Plant 2 tidak ditemukan');

    const updated = await PltsP2HourlyModelFullStack.update(energyDate, req.body);
    return responseSuccess(res, 'Data hourly Plant 2 berhasil diperbarui', updated);
  } catch (error) {
    return responseError(res, 500, 'Gagal memperbarui data hourly Plant 2', error);
  }
};

exports.destroy = async (req, res) => {
  try {
    const energyDate = decodeURIComponent(req.params.energy_date);
    const deleted = await PltsP2HourlyModelFullStack.delete(energyDate);

    if (!deleted) return responseError(res, 404, 'Data hourly Plant 2 tidak ditemukan');

    return responseSuccess(res, 'Data hourly Plant 2 berhasil dihapus', deleted);
  } catch (error) {
    return responseError(res, 500, 'Gagal menghapus data hourly Plant 2', error);
  }
};
