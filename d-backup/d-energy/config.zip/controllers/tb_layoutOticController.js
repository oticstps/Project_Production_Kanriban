const layoutOticModel = require('../models/tb_layoutOticModel');

async function getAllData(req, res) {
    try {
        const data = await layoutOticModel.getAll();
        res.json({ success: true, data });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

async function getDataById(req, res) {
    const { id } = req.params;
    try {
        const data = await layoutOticModel.getById(id);
        if (!data) return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
        res.json({ success: true, data });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

async function createData(req, res) {
    try {
        const insertId = await layoutOticModel.create(req.body);
        const newData = await layoutOticModel.getById(insertId);
        res.status(201).json({ success: true, data: newData });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

async function updateData(req, res) {
    const { id } = req.params;
    try {
        const updated = await layoutOticModel.update(id, req.body);
        if (!updated) return res.status(404).json({ success: false, message: 'Data tidak ditemukan atau tidak ada perubahan' });
        const updatedData = await layoutOticModel.getById(id);
        res.json({ success: true, data: updatedData });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

async function deleteData(req, res) {
    const { id } = req.params;
    try {
        const deleted = await layoutOticModel.deleteById(id);
        if (!deleted) return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
        res.json({ success: true, message: 'Data berhasil dihapus' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

module.exports = {
    getAllData,
    getDataById,
    createData,
    updateData,
    deleteData
};