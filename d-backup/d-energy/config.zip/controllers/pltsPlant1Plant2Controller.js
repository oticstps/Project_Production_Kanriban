'use strict';

const PltsPlantModel = require('../models/pltsPlant1Plant2Model');

const DECIMAL_FIELDS = Object.freeze([
  'huawei_yield_today',
  'huawei_supply_from_grid_today',
  'huawei_total_yield',
  'huawei_inverter_rated_power',
  'huawei_standard_coal_saved',
  'huawei_co2_avoided',
  'huawei_equivalent_trees_planted',
  'huawei_pv_output_kw',
  'huawei_mains_power_kw',
  'huawei_irradiance_wm2',
  'huawei_consumed_by_appliances_kw',
]);

function normalizeDateTime(value) {
  if (typeof value !== 'string') return value;

  // Mengubah format ISO sederhana menjadi format MySQL DATETIME.
  return value.trim().replace('T', ' ').replace(/Z$/, '').slice(0, 19);
}

function normalizePayload(body = {}) {
  const payload = { ...body };

  if (Object.prototype.hasOwnProperty.call(payload, 'recorded_at')) {
    payload.recorded_at = normalizeDateTime(payload.recorded_at);
  }

  if (
    Object.prototype.hasOwnProperty.call(payload, 'raw_payload_json') &&
    typeof payload.raw_payload_json !== 'string'
  ) {
    payload.raw_payload_json = JSON.stringify(payload.raw_payload_json);
  }

  for (const field of DECIMAL_FIELDS) {
    if (
      Object.prototype.hasOwnProperty.call(payload, field) &&
      payload[field] !== null &&
      payload[field] !== ''
    ) {
      const value = Number(payload[field]);
      payload[field] = Number.isFinite(value) ? value : payload[field];
    }
  }

  return PltsPlantModel.sanitizePayload(payload);
}

function validatePayload(payload, { partial = false } = {}) {
  const errors = [];

  if (!partial && !payload.recorded_at) {
    errors.push('recorded_at wajib diisi.');
  }

  if (!partial && !Object.prototype.hasOwnProperty.call(payload, 'raw_payload_json')) {
    errors.push('raw_payload_json wajib diisi.');
  }

  if (payload.recorded_at && Number.isNaN(Date.parse(payload.recorded_at.replace(' ', 'T')))) {
    errors.push('recorded_at harus berupa tanggal dan waktu yang valid.');
  }

  for (const field of DECIMAL_FIELDS) {
    if (
      Object.prototype.hasOwnProperty.call(payload, field) &&
      payload[field] !== null &&
      payload[field] !== '' &&
      !Number.isFinite(Number(payload[field]))
    ) {
      errors.push(`${field} harus berupa angka atau null.`);
    }
  }

  if (
    Object.prototype.hasOwnProperty.call(payload, 'raw_payload_json') &&
    (payload.raw_payload_json === null || payload.raw_payload_json === '')
  ) {
    errors.push('raw_payload_json tidak boleh kosong.');
  }

  return errors;
}

function sendDatabaseError(res, error) {
  console.error('[PLTS Plant 1 & Plant 2]', error);

  if (error?.code === 'ER_BAD_NULL_ERROR') {
    return res.status(400).json({
      success: false,
      message: 'Terdapat kolom wajib yang belum diisi.',
      error: error.sqlMessage,
    });
  }

  if (error?.code === 'ER_TRUNCATED_WRONG_VALUE_FOR_FIELD') {
    return res.status(400).json({
      success: false,
      message: 'Format atau tipe salah satu nilai tidak sesuai struktur tabel.',
      error: error.sqlMessage,
    });
  }

  return res.status(500).json({
    success: false,
    message: 'Terjadi kesalahan pada server.',
  });
}

async function getAll(req, res) {
  try {
    const result = await PltsPlantModel.findAll({
      page: req.query.page,
      limit: req.query.limit,
      startDate: req.query.start_date
        ? normalizeDateTime(req.query.start_date)
        : undefined,
      endDate: req.query.end_date
        ? normalizeDateTime(req.query.end_date)
        : undefined,
      status: req.query.status,
    });

    return res.status(200).json({
      success: true,
      message: 'Data PLTS berhasil diambil.',
      ...result,
    });
  } catch (error) {
    return sendDatabaseError(res, error);
  }
}

async function getById(req, res) {
  try {
    const data = await PltsPlantModel.findById(req.params.id);

    if (!data) {
      return res.status(404).json({
        success: false,
        message: 'Data PLTS tidak ditemukan.',
      });
    }

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return sendDatabaseError(res, error);
  }
}

async function getLatest(req, res) {
  try {
    const data = await PltsPlantModel.findLatest();

    if (!data) {
      return res.status(404).json({
        success: false,
        message: 'Belum ada data PLTS.',
      });
    }

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    return sendDatabaseError(res, error);
  }
}

async function getByRange(req, res) {
  try {
    const { start, end, limit } = req.query;

    if (!start || !end) {
      return res.status(400).json({
        success: false,
        message: 'Query start dan end wajib diisi.',
      });
    }

    const startDate = normalizeDateTime(start);
    const endDate = normalizeDateTime(end);

    if (
      Number.isNaN(Date.parse(startDate.replace(' ', 'T'))) ||
      Number.isNaN(Date.parse(endDate.replace(' ', 'T')))
    ) {
      return res.status(400).json({
        success: false,
        message: 'Format start atau end tidak valid.',
      });
    }

    if (new Date(startDate) > new Date(endDate)) {
      return res.status(400).json({
        success: false,
        message: 'Nilai start tidak boleh lebih besar dari end.',
      });
    }

    const data = await PltsPlantModel.findByRecordedAtRange(
      startDate,
      endDate,
      limit,
    );

    return res.status(200).json({
      success: true,
      count: data.length,
      data,
    });
  } catch (error) {
    return sendDatabaseError(res, error);
  }
}

async function create(req, res) {
  try {
    const payload = normalizePayload(req.body);
    const errors = validatePayload(payload);

    if (errors.length) {
      return res.status(400).json({
        success: false,
        message: 'Validasi data gagal.',
        errors,
      });
    }

    const data = await PltsPlantModel.create(payload);

    return res.status(201).json({
      success: true,
      message: 'Data PLTS berhasil ditambahkan.',
      data,
    });
  } catch (error) {
    return sendDatabaseError(res, error);
  }
}

async function update(req, res) {
  try {
    const existing = await PltsPlantModel.findById(req.params.id);

    if (!existing) {
      return res.status(404).json({
        success: false,
        message: 'Data PLTS tidak ditemukan.',
      });
    }

    const payload = normalizePayload(req.body);

    if (!Object.keys(payload).length) {
      return res.status(400).json({
        success: false,
        message: 'Tidak ada field valid yang dikirim untuk diperbarui.',
      });
    }

    const errors = validatePayload(payload, { partial: true });

    if (errors.length) {
      return res.status(400).json({
        success: false,
        message: 'Validasi data gagal.',
        errors,
      });
    }

    const data = await PltsPlantModel.update(req.params.id, payload);

    return res.status(200).json({
      success: true,
      message: 'Data PLTS berhasil diperbarui.',
      data,
    });
  } catch (error) {
    return sendDatabaseError(res, error);
  }
}

async function remove(req, res) {
  try {
    const deleted = await PltsPlantModel.remove(req.params.id);

    if (!deleted) {
      return res.status(404).json({
        success: false,
        message: 'Data PLTS tidak ditemukan.',
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Data PLTS berhasil dihapus.',
    });
  } catch (error) {
    return sendDatabaseError(res, error);
  }
}

module.exports = {
  getAll,
  getById,
  getLatest,
  getByRange,
  create,
  update,
  remove,
};
