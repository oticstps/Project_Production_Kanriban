const FullTextModel = require("../models/fullTextModel");

function mapPayload(body = {}) {
  return {
    area1_value: body.area1_value ?? body.area1?.value ?? null,
    area1_label: body.area1_label ?? body.area1?.label ?? null,
    area1_unit: body.area1_unit ?? body.area1?.unit ?? null,

    area2_value: body.area2_value ?? body.area2?.value ?? null,
    area2_label: body.area2_label ?? body.area2?.label ?? null,
    area2_unit: body.area2_unit ?? body.area2?.unit ?? null,

    area3_value: body.area3_value ?? body.area3?.value ?? null,
    area3_label: body.area3_label ?? body.area3?.label ?? null,
    area3_unit: body.area3_unit ?? body.area3?.unit ?? null,

    area4_value: body.area4_value ?? body.area4?.value ?? null,
    area4_label: body.area4_label ?? body.area4?.label ?? null,
    area4_unit: body.area4_unit ?? body.area4?.unit ?? null,

    area5_value: body.area5_value ?? body.area5?.value ?? null,
    area5_label: body.area5_label ?? body.area5?.label ?? null,
    area5_unit: body.area5_unit ?? body.area5?.unit ?? null,

    area6_value: body.area6_value ?? body.area6?.value ?? null,
    area6_label: body.area6_label ?? body.area6?.label ?? null,
    area6_unit: body.area6_unit ?? body.area6?.unit ?? null,

    area7_value: body.area7_value ?? body.area7?.value ?? null,
    area7_label: body.area7_label ?? body.area7?.label ?? null,
    area7_unit: body.area7_unit ?? body.area7?.unit ?? null
  };
}

exports.getAll = async (req, res) => {
  try {
    const data = await FullTextModel.getAll();

    res.status(200).json({
      success: true,
      message: "Data berhasil diambil",
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal mengambil data",
      error: error.message
    });
  }
};

exports.getLatest = async (req, res) => {
  try {
    const data = await FullTextModel.getLatest();

    if (!data) {
      return res.status(404).json({
        success: false,
        message: "Data terbaru tidak ditemukan"
      });
    }

    res.status(200).json({
      success: true,
      message: "Data terbaru berhasil diambil",
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal mengambil data terbaru",
      error: error.message
    });
  }
};

exports.getById = async (req, res) => {
  try {
    const { id } = req.params;
    const data = await FullTextModel.getById(id);

    if (!data) {
      return res.status(404).json({
        success: false,
        message: "Data tidak ditemukan"
      });
    }

    res.status(200).json({
      success: true,
      message: "Detail data berhasil diambil",
      data
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal mengambil detail data",
      error: error.message
    });
  }
};

exports.create = async (req, res) => {
  try {
    const payload = mapPayload(req.body);
    const created = await FullTextModel.create(payload);

    res.status(201).json({
      success: true,
      message: "Data berhasil ditambahkan",
      data: created
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal menambahkan data",
      error: error.message
    });
  }
};

exports.update = async (req, res) => {
  try {
    const { id } = req.params;
    const payload = mapPayload(req.body);
    const updated = await FullTextModel.update(id, payload);

    if (!updated) {
      return res.status(404).json({
        success: false,
        message: "Data tidak ditemukan"
      });
    }

    res.status(200).json({
      success: true,
      message: "Data berhasil diupdate",
      data: updated
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal update data",
      error: error.message
    });
  }
};

exports.remove = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await FullTextModel.delete(id);

    if (!deleted) {
      return res.status(404).json({
        success: false,
        message: "Data tidak ditemukan"
      });
    }

    res.status(200).json({
      success: true,
      message: "Data berhasil dihapus"
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal menghapus data",
      error: error.message
    });
  }
};