const kubModel = require('../models/kubModel');
const kubAggregatorService = require('../services/kubAggregatorService');

function isEmpty(value) {
  return value === undefined || value === null || String(value).trim() === '';
}

exports.getPowerMeters = async (req, res) => {
  try {
    const data = await kubModel.getPowerMeters();
    return res.status(200).json({
      success: true,
      message: 'Daftar power meter berhasil diambil',
      total: data.length,
      data,
    });
  } catch (error) {
    console.error('Error getPowerMeters:', error);
    return res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat mengambil daftar power meter',
      error: error.message,
    });
  }
};

exports.getShiftly = async (req, res) => {
  try {
    const { power_meter } = req.params;
    if (isEmpty(power_meter)) {
      return res.status(400).json({ success: false, message: 'Parameter power_meter wajib diisi' });
    }

    const data = await kubModel.getShiftlyByMeter(power_meter);
    return res.status(200).json({
      success: true,
      message: 'Data shiftly berhasil diambil',
      total: data.length,
      data,
    });
  } catch (error) {
    console.error('Error getShiftly:', error);
    return res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat mengambil data shiftly',
      error: error.message,
    });
  }
};

exports.getDaily = async (req, res) => {
  try {
    const { power_meter } = req.params;
    const { year, month } = req.query;

    if (isEmpty(power_meter)) {
      return res.status(400).json({ success: false, message: 'Parameter power_meter wajib diisi' });
    }
    if (isEmpty(year) || isEmpty(month)) {
      return res.status(400).json({ success: false, message: 'Query year dan month wajib diisi' });
    }

    const data = await kubModel.getDailyByMeter(power_meter, year, month);
    return res.status(200).json({
      success: true,
      message: 'Data daily berhasil diambil',
      total: data.length,
      data,
    });
  } catch (error) {
    console.error('Error getDaily:', error);
    return res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat mengambil data daily',
      error: error.message,
    });
  }
};

exports.getWeekly = async (req, res) => {
  try {
    const { power_meter } = req.params;
    const { year, week } = req.query;

    if (isEmpty(power_meter)) {
      return res.status(400).json({ success: false, message: 'Parameter power_meter wajib diisi' });
    }
    if (isEmpty(year) || isEmpty(week)) {
      return res.status(400).json({ success: false, message: 'Query year dan week wajib diisi' });
    }

    const data = await kubModel.getWeeklyByMeter(power_meter, year, week);
    return res.status(200).json({
      success: true,
      message: 'Data weekly berhasil diambil',
      total: data.length,
      data,
    });
  } catch (error) {
    console.error('Error getWeekly:', error);
    return res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat mengambil data weekly',
      error: error.message,
    });
  }
};

exports.getMonthly = async (req, res) => {
  try {
    const { power_meter } = req.params;
    const { year, month } = req.query;

    if (isEmpty(power_meter)) {
      return res.status(400).json({ success: false, message: 'Parameter power_meter wajib diisi' });
    }
    if (isEmpty(year)) {
      return res.status(400).json({ success: false, message: 'Query year wajib diisi' });
    }

    const data = await kubModel.getMonthlyByMeter(power_meter, year, month);
    return res.status(200).json({
      success: true,
      message: 'Data monthly berhasil diambil',
      total: data.length,
      data,
    });
  } catch (error) {
    console.error('Error getMonthly:', error);
    return res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat mengambil data monthly',
      error: error.message,
    });
  }
};

exports.rekapShiftly = async (req, res) => {
  try {
    const meterFilter = req.body?.power_meter || null;
    const result = await kubAggregatorService.rekapShiftly(meterFilter);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error rekapShiftly:', error);
    return res.status(500).json({ success: false, message: 'Gagal menjalankan rekap shiftly', error: error.message });
  }
};

exports.rekapDaily = async (req, res) => {
  try {
    const meterFilter = req.body?.power_meter || null;
    const result = await kubAggregatorService.rekapDaily(meterFilter);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error rekapDaily:', error);
    return res.status(500).json({ success: false, message: 'Gagal menjalankan rekap daily', error: error.message });
  }
};

exports.rekapWeekly = async (req, res) => {
  try {
    const meterFilter = req.body?.power_meter || null;
    const result = await kubAggregatorService.rekapWeekly(meterFilter);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error rekapWeekly:', error);
    return res.status(500).json({ success: false, message: 'Gagal menjalankan rekap weekly', error: error.message });
  }
};

exports.rekapMonthly = async (req, res) => {
  try {
    const meterFilter = req.body?.power_meter || null;
    const result = await kubAggregatorService.rekapMonthly(meterFilter);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error rekapMonthly:', error);
    return res.status(500).json({ success: false, message: 'Gagal menjalankan rekap monthly', error: error.message });
  }
};
