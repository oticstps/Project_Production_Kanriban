const comp19Model = require('../models/tb_comp19ModelShiftly');

// GET semua data
exports.getAll = async (req, res) => {
  try {
    const data = await comp19Model.getAll();
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET data by ID
exports.getById = async (req, res) => {
  try {
    const { id } = req.params;
    const data = await comp19Model.getById(id);
    if (!data) {
      return res.status(404).json({ message: 'Data tidak ditemukan' });
    }
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// POST data baru
exports.create = async (req, res) => {
  try {
    // Validasi sederhana (sesuaikan dengan kebutuhan)
    // Di sini semua field opsional karena banyak kolom nullable
    const newData = await comp19Model.create(req.body);
    res.status(201).json(newData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// PUT update data
exports.update = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = await comp19Model.getById(id);
    if (!existing) {
      return res.status(404).json({ message: 'Data tidak ditemukan' });
    }

    const updated = await comp19Model.update(id, req.body);
    if (updated) {
      const updatedData = await comp19Model.getById(id);
      res.json(updatedData);
    } else {
      res.status(500).json({ message: 'Gagal update data' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE data
exports.delete = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = await comp19Model.getById(id);
    if (!existing) {
      return res.status(404).json({ message: 'Data tidak ditemukan' });
    }

    const deleted = await comp19Model.deleteById(id);
    if (deleted) {
      res.json({ message: 'Data berhasil dihapus' });
    } else {
      res.status(500).json({ message: 'Gagal hapus data' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};