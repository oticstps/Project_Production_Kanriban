const ShiftlyReportService = require('../services/ShiftlyReportService');

const ShiftlyReportController = {
    getAll: async (req, res) => {
        try {
            const { table } = req.params;
            const limit = Number(req.query.limit || 500);
            const data = await ShiftlyReportService.getAll(table, limit);
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    getByComposite: async (req, res) => {
        try {
            const { table, pm_type, line_table, shift, shift_date } = req.params;
            const data = await ShiftlyReportService.getByComposite(table, pm_type, line_table, shift, shift_date);
            if (!data) return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    create: async (req, res) => {
        try {
            const { table } = req.params;
            const data = await ShiftlyReportService.create(table, req.body);
            res.status(201).json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    update: async (req, res) => {
        try {
            const { table, pm_type, line_table, shift, shift_date } = req.params;
            const affected = await ShiftlyReportService.update(table, pm_type, line_table, shift, shift_date, req.body);
            res.json({ success: true, affected });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    delete: async (req, res) => {
        try {
            const { table, pm_type, line_table, shift, shift_date } = req.params;
            const affected = await ShiftlyReportService.delete(table, pm_type, line_table, shift, shift_date);
            res.json({ success: true, affected });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },

    getByDateRange: async (req, res) => {
        try {
            const { table } = req.params;
            const { startDate, endDate } = req.query;
            const data = await ShiftlyReportService.getByDateRange(table, startDate, endDate);
            res.json({ success: true, data });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    },
};

module.exports = ShiftlyReportController;