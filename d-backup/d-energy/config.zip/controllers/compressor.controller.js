const CompressorRekapService = require('../services/compressor.rekap.service');
const CompressorModel = require('../models/compressor.model');

const tableMap = {
  shiftly: {
    panel24: 'tb_panel_24_energy_vah_wh_shiftly',
    panel21: 'tb_panel_21_energy_vah_wh_shiftly',
    panel19: 'tb_panel_19_energy_vah_wh_shiftly',
    panel20: 'tb_kub_panel_20_wh_shiftly',
  },
  daily: {
    panel24: 'tb_panel_24_energy_vah_wh_daily',
    panel21: 'tb_panel_21_energy_vah_wh_daily',
    panel19: 'tb_panel_19_energy_vah_wh_daily',
    panel20: 'tb_kub_panel_20_wh_daily',
  },
  weekly: {
    panel24: 'tb_panel_24_energy_vah_wh_weekly',
    panel21: 'tb_panel_21_energy_vah_wh_weekly',
    panel19: 'tb_panel_19_energy_vah_wh_weekly',
    panel20: 'tb_kub_panel_20_wh_weekly',
  },
  monthly: {
    panel24: 'tb_panel_24_energy_vah_wh_monthly',
    panel21: 'tb_panel_21_energy_vah_wh_monthly',
    panel19: 'tb_panel_19_energy_vah_wh_monthly',
    panel20: 'tb_kub_panel_20_wh_monthly',
  },
};

const CompressorController = {
  async runShiftly(req, res) {
    try {
      const data = await CompressorRekapService.processShiftly();
      res.status(200).json({
        success: true,
        message: 'Rekap shiftly berhasil dijalankan',
        total: data.length,
        data,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menjalankan rekap shiftly',
        error: error.message,
      });
    }
  },

  async runDaily(req, res) {
    try {
      const data = await CompressorRekapService.processDaily();
      res.status(200).json({
        success: true,
        message: 'Rekap daily berhasil dijalankan',
        total: data.length,
        data,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menjalankan rekap daily',
        error: error.message,
      });
    }
  },

  async runWeekly(req, res) {
    try {
      const data = await CompressorRekapService.processWeekly();
      res.status(200).json({
        success: true,
        message: 'Rekap weekly berhasil dijalankan',
        total: data.length,
        data,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menjalankan rekap weekly',
        error: error.message,
      });
    }
  },

  async runMonthly(req, res) {
    try {
      const data = await CompressorRekapService.processMonthly();
      res.status(200).json({
        success: true,
        message: 'Rekap monthly berhasil dijalankan',
        total: data.length,
        data,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal menjalankan rekap monthly',
        error: error.message,
      });
    }
  },

  async getData(req, res) {
    try {
      const { period, panel } = req.params;
      const { year, month, shift_date, week } = req.query;

      const targetTable = tableMap?.[period]?.[panel];
      if (!targetTable) {
        return res.status(400).json({
          success: false,
          message: 'Period atau panel tidak valid',
        });
      }

      const rows = await CompressorModel.getData(targetTable, {
        year,
        month,
        shift_date,
        week,
      });

      res.status(200).json({
        success: true,
        message: 'Data berhasil diambil',
        total: rows.length,
        data: rows,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Gagal mengambil data',
        error: error.message,
      });
    }
  },
};

module.exports = CompressorController;