const TbKub1TotalKwhShiftly = require('../models/tb_kub1_total_kwh_shiftly');

const REQUIRED_CREATE_FIELDS = [
  'pm_type',
  'line_table',
  'line_name',
  'shift',
  'shift_date'
];

const isPositiveInteger = (value) => {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0;
};

const isValidDateOnly = (value) => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }

  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));

  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
};

const sendServerError = (res, error) => {
  console.error(error);

  return res.status(500).json({
    success: false,
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? error.message : undefined
  });
};

const TbKub1TotalKwhShiftlyController = {
  getAll: async (req, res) => {
    try {
      const data = await TbKub1TotalKwhShiftly.getAll(req.query.limit);

      return res.status(200).json({
        success: true,
        data,
        count: data.length,
        message: 'Data retrieved successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  },

  getById: async (req, res) => {
    try {
      const { id } = req.params;

      if (!isPositiveInteger(id)) {
        return res.status(400).json({
          success: false,
          message: 'ID must be a positive integer'
        });
      }

      const data = await TbKub1TotalKwhShiftly.getById(Number(id));

      if (!data) {
        return res.status(404).json({
          success: false,
          message: 'Data not found'
        });
      }

      return res.status(200).json({
        success: true,
        data,
        message: 'Data retrieved successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  },

  create: async (req, res) => {
    try {
      const payload = req.body || {};
      const missingFields = REQUIRED_CREATE_FIELDS.filter(
        (field) => payload[field] === undefined || payload[field] === null || payload[field] === ''
      );

      if (missingFields.length > 0) {
        return res.status(400).json({
          success: false,
          message: `Required fields are missing: ${missingFields.join(', ')}`
        });
      }

      if (!isValidDateOnly(payload.shift_date)) {
        return res.status(400).json({
          success: false,
          message: 'shift_date must use a valid YYYY-MM-DD format'
        });
      }

      const id = await TbKub1TotalKwhShiftly.create(payload);
      const data = await TbKub1TotalKwhShiftly.getById(id);

      return res.status(201).json({
        success: true,
        data,
        message: 'Data created successfully'
      });
    } catch (error) {
      if (error.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({
          success: false,
          message: 'The same shift record already exists'
        });
      }

      return sendServerError(res, error);
    }
  },

  update: async (req, res) => {
    try {
      const { id } = req.params;
      const payload = req.body || {};

      if (!isPositiveInteger(id)) {
        return res.status(400).json({
          success: false,
          message: 'ID must be a positive integer'
        });
      }

      if (
        Object.prototype.hasOwnProperty.call(payload, 'shift_date') &&
        payload.shift_date !== null &&
        !isValidDateOnly(payload.shift_date)
      ) {
        return res.status(400).json({
          success: false,
          message: 'shift_date must use a valid YYYY-MM-DD format'
        });
      }

      const existingData = await TbKub1TotalKwhShiftly.getById(Number(id));

      if (!existingData) {
        return res.status(404).json({
          success: false,
          message: 'Data not found'
        });
      }

      const result = await TbKub1TotalKwhShiftly.updateById(Number(id), payload);

      if (result.noFields) {
        return res.status(400).json({
          success: false,
          message: 'No valid fields were provided for update'
        });
      }

      const data = await TbKub1TotalKwhShiftly.getById(Number(id));

      return res.status(200).json({
        success: true,
        data,
        message: result.changedRows > 0
          ? 'Data updated successfully'
          : 'No data changes were detected'
      });
    } catch (error) {
      if (error.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({
          success: false,
          message: 'The same shift record already exists'
        });
      }

      return sendServerError(res, error);
    }
  },

  remove: async (req, res) => {
    try {
      const { id } = req.params;

      if (!isPositiveInteger(id)) {
        return res.status(400).json({
          success: false,
          message: 'ID must be a positive integer'
        });
      }

      const affectedRows = await TbKub1TotalKwhShiftly.deleteById(Number(id));

      if (affectedRows === 0) {
        return res.status(404).json({
          success: false,
          message: 'Data not found'
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Data deleted successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  },

  getByDateRange: async (req, res) => {
    try {
      const startDate = req.query.startDate || req.query.start_date;
      const endDate = req.query.endDate || req.query.end_date;

      if (!isValidDateOnly(startDate) || !isValidDateOnly(endDate)) {
        return res.status(400).json({
          success: false,
          message: 'startDate and endDate must use a valid YYYY-MM-DD format'
        });
      }

      if (startDate > endDate) {
        return res.status(400).json({
          success: false,
          message: 'startDate cannot be later than endDate'
        });
      }

      const data = await TbKub1TotalKwhShiftly.getByDateRange(startDate, endDate);

      return res.status(200).json({
        success: true,
        data,
        count: data.length,
        message: 'Data retrieved successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  },

  getByShift: async (req, res) => {
    try {
      const data = await TbKub1TotalKwhShiftly.getByShift(req.params.shift);

      return res.status(200).json({
        success: true,
        data,
        count: data.length,
        message: 'Data retrieved successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  },

  getByLineTable: async (req, res) => {
    try {
      const data = await TbKub1TotalKwhShiftly.getByLineTable(req.params.line_table);

      return res.status(200).json({
        success: true,
        data,
        count: data.length,
        message: 'Data retrieved successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  },

  getByPmType: async (req, res) => {
    try {
      const data = await TbKub1TotalKwhShiftly.getByPmType(req.params.pm_type);

      return res.status(200).json({
        success: true,
        data,
        count: data.length,
        message: 'Data retrieved successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  },

  // Alias sementara untuk frontend lama yang masih memakai /power-meter/:power_meter.
  getByPowerMeter: async (req, res) => {
    try {
      const data = await TbKub1TotalKwhShiftly.getByPmType(req.params.power_meter);

      return res.status(200).json({
        success: true,
        data,
        count: data.length,
        message: 'Data retrieved successfully'
      });
    } catch (error) {
      return sendServerError(res, error);
    }
  }
};

module.exports = TbKub1TotalKwhShiftlyController;
