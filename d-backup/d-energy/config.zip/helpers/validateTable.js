function validateTable(tableName, allowedTables) {
    if (!allowedTables.includes(tableName)) {
        throw new Error(`Table tidak diizinkan: ${tableName}`);
    }
}

module.exports = validateTable;