const DAILY_TABLES = [
    'tb_pm200_bs1_daily', 'tb_pm200_bs2_daily', 'tb_pm200_cc1_daily', 'tb_pm200_cc234_daily',
    'tb_pm200_chab_daily', 'tb_pm200_chcd_daily', 'tb_pm200_chef_daily', 'tb_pm200_chsaa_daily',
    'tb_pm200_chsac_daily', 'tb_pm200_conn_daily', 'tb_pm200_cr1_daily', 'tb_pm200_cr2_daily',
    'tb_pm200_cr3_daily', 'tb_pm200_cr4_daily', 'tb_pm200_cr5_daily', 'tb_pm200_cr6_daily',
    'tb_pm200_cr7_daily', 'tb_pm200_cr8_daily', 'tb_pm200_cr9_daily', 'tb_pm200_cr10_daily',
    'tb_pm200_cr11_daily', 'tb_pm200_cr12_daily', 'tb_pm200_ct_daily', 'tb_pm200_hla_daily',
    'tb_pm200_ra_daily', 'tb_pm200_ret_daily', 'tb_pm200_chsab_daily',

    'tb_pm220_bs1_daily', 'tb_pm220_bs2_daily', 'tb_pm220_cc1_daily', 'tb_pm220_cc234_daily',
    'tb_pm220_chab_daily', 'tb_pm220_chcd_daily', 'tb_pm220_chef_daily', 'tb_pm220_chsaa_daily',
    'tb_pm220_chsac_daily', 'tb_pm220_conn_daily', 'tb_pm220_cr1_daily', 'tb_pm220_cr2_daily',
    'tb_pm220_cr3_daily', 'tb_pm220_cr4_daily', 'tb_pm220_cr5_daily', 'tb_pm220_cr6_daily',
    'tb_pm220_cr7_daily', 'tb_pm220_cr8_daily', 'tb_pm220_cr9_daily', 'tb_pm220_cr10_daily',
    'tb_pm220_cr11_daily', 'tb_pm220_cr12_daily', 'tb_pm220_ct_daily', 'tb_pm220_hla_daily',
    'tb_pm220_ra_daily', 'tb_pm220_ret_daily', 'tb_pm220_chsab_daily'
];

const SHIFTLY_TABLES = [
    'tb_pm200_bs1_shiftly', 'tb_pm200_bs2_shiftly', 'tb_pm200_cc1_shiftly', 'tb_pm200_cc234_shiftly',
    'tb_pm200_chab_shiftly', 'tb_pm200_chcd_shiftly', 'tb_pm200_chef_shiftly', 'tb_pm200_chsaa_shiftly',
    'tb_pm200_chsac_shiftly', 'tb_pm200_conn_shiftly', 'tb_pm200_cr1_shiftly', 'tb_pm200_cr2_shiftly',
    'tb_pm200_cr3_shiftly', 'tb_pm200_cr4_shiftly', 'tb_pm200_cr5_shiftly', 'tb_pm200_cr6_shiftly',
    'tb_pm200_cr7_shiftly', 'tb_pm200_cr8_shiftly', 'tb_pm200_cr9_shiftly', 'tb_pm200_cr10_shiftly',
    'tb_pm200_cr11_shiftly', 'tb_pm200_cr12_shiftly', 'tb_pm200_ct_shiftly', 'tb_pm200_hla_shiftly',
    'tb_pm200_ra_shiftly', 'tb_pm200_ret_shiftly', 'tb_pm200_chsab_shiftly',

    'tb_pm220_bs1_shiftly', 'tb_pm220_bs2_shiftly', 'tb_pm220_cc1_shiftly', 'tb_pm220_cc234_shiftly',
    'tb_pm220_chab_shiftly', 'tb_pm220_chcd_shiftly', 'tb_pm220_chef_shiftly', 'tb_pm220_chsaa_shiftly',
    'tb_pm220_chsac_shiftly', 'tb_pm220_conn_shiftly', 'tb_pm220_cr1_shiftly', 'tb_pm220_cr2_shiftly',
    'tb_pm220_cr3_shiftly', 'tb_pm220_cr4_shiftly', 'tb_pm220_cr5_shiftly', 'tb_pm220_cr6_shiftly',
    'tb_pm220_cr7_shiftly', 'tb_pm220_cr8_shiftly', 'tb_pm220_cr9_shiftly', 'tb_pm220_cr10_shiftly',
    'tb_pm220_cr11_shiftly', 'tb_pm220_cr12_shiftly', 'tb_pm220_ct_shiftly', 'tb_pm220_hla_shiftly',
    'tb_pm220_ra_shiftly', 'tb_pm220_ret_shiftly', 'tb_pm220_chsab_shiftly'
];

const WEEKLY_TABLES = [
    'tb_pm200_bs1_weekly', 'tb_pm200_bs2_weekly', 'tb_pm200_cc1_weekly', 'tb_pm200_cc234_weekly',
    'tb_pm200_chab_weekly', 'tb_pm200_chcd_weekly', 'tb_pm200_chef_weekly', 'tb_pm200_chsaa_weekly',
    'tb_pm200_chsac_weekly', 'tb_pm200_conn_weekly', 'tb_pm200_cr1_weekly', 'tb_pm200_cr2_weekly',
    'tb_pm200_cr3_weekly', 'tb_pm200_cr4_weekly', 'tb_pm200_cr5_weekly', 'tb_pm200_cr6_weekly',
    'tb_pm200_cr7_weekly', 'tb_pm200_cr8_weekly', 'tb_pm200_cr9_weekly', 'tb_pm200_cr10_weekly',
    'tb_pm200_cr11_weekly', 'tb_pm200_cr12_weekly', 'tb_pm200_ct_weekly', 'tb_pm200_hla_weekly',
    'tb_pm200_ra_weekly', 'tb_pm200_ret_weekly', 'tb_pm200_chsab_weekly',

    'tb_pm220_bs1_weekly', 'tb_pm220_bs2_weekly', 'tb_pm220_cc1_weekly', 'tb_pm220_cc234_weekly',
    'tb_pm220_chab_weekly', 'tb_pm220_chcd_weekly', 'tb_pm220_chef_weekly', 'tb_pm220_chsaa_weekly',
    'tb_pm220_chsac_weekly', 'tb_pm220_conn_weekly', 'tb_pm220_cr1_weekly', 'tb_pm220_cr2_weekly',
    'tb_pm220_cr3_weekly', 'tb_pm220_cr4_weekly', 'tb_pm220_cr5_weekly', 'tb_pm220_cr6_weekly',
    'tb_pm220_cr7_weekly', 'tb_pm220_cr8_weekly', 'tb_pm220_cr9_weekly', 'tb_pm220_cr10_weekly',
    'tb_pm220_cr11_weekly', 'tb_pm220_cr12_weekly', 'tb_pm220_ct_weekly', 'tb_pm220_hla_weekly',
    'tb_pm220_ra_weekly', 'tb_pm220_ret_weekly', 'tb_pm220_chsab_weekly'
];

const MONTHLY_TABLES = [
    'tb_pm200_bs1_monthly', 'tb_pm200_bs2_monthly', 'tb_pm200_cc1_monthly', 'tb_pm200_cc234_monthly',
    'tb_pm200_chab_monthly', 'tb_pm200_chcd_monthly', 'tb_pm200_chef_monthly', 'tb_pm200_chsaa_monthly',
    'tb_pm200_chsac_monthly', 'tb_pm200_conn_monthly', 'tb_pm200_cr1_monthly', 'tb_pm200_cr2_monthly',
    'tb_pm200_cr3_monthly', 'tb_pm200_cr4_monthly', 'tb_pm200_cr5_monthly', 'tb_pm200_cr6_monthly',
    'tb_pm200_cr7_monthly', 'tb_pm200_cr8_monthly', 'tb_pm200_cr9_monthly', 'tb_pm200_cr10_monthly',
    'tb_pm200_cr11_monthly', 'tb_pm200_cr12_monthly', 'tb_pm200_ct_monthly', 'tb_pm200_hla_monthly',
    'tb_pm200_ra_monthly', 'tb_pm200_ret_monthly', 'tb_pm200_chsab_monthly',

    'tb_pm220_bs1_monthly', 'tb_pm220_bs2_monthly', 'tb_pm220_cc1_monthly', 'tb_pm220_cc234_monthly',
    'tb_pm220_chab_monthly', 'tb_pm220_chcd_monthly', 'tb_pm220_chef_monthly', 'tb_pm220_chsaa_monthly',
    'tb_pm220_chsac_monthly', 'tb_pm220_conn_monthly', 'tb_pm220_cr1_monthly', 'tb_pm220_cr2_monthly',
    'tb_pm220_cr3_monthly', 'tb_pm220_cr4_monthly', 'tb_pm220_cr5_monthly', 'tb_pm220_cr6_monthly',
    'tb_pm220_cr7_monthly', 'tb_pm220_cr8_monthly', 'tb_pm220_cr9_monthly', 'tb_pm220_cr10_monthly',
    'tb_pm220_cr11_monthly', 'tb_pm220_cr12_monthly', 'tb_pm220_ct_monthly', 'tb_pm220_hla_monthly',
    'tb_pm220_ra_monthly', 'tb_pm220_ret_monthly', 'tb_pm220_chsab_monthly'
];

module.exports = {
    DAILY_TABLES,
    SHIFTLY_TABLES,
    WEEKLY_TABLES,
    MONTHLY_TABLES
};