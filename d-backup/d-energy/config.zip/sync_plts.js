require("dotenv").config();

const mysql = require("mysql2/promise");

const TABLE_NAME =
  process.env.TABLE_NAME || "plts_plant_1_plant_2";

const BATCH_SIZE = Number(process.env.BATCH_SIZE || 1000);
const SYNC_INTERVAL_MS = Number(
  process.env.SYNC_INTERVAL_MS || 60000
);
const RECHECK_ROWS = Number(process.env.RECHECK_ROWS || 1000);

const sourcePool = mysql.createPool({
  host: process.env.SOURCE_HOST,
  port: Number(process.env.SOURCE_PORT || 3306),
  user: process.env.SOURCE_USER,
  password: process.env.SOURCE_PASSWORD,
  database: process.env.SOURCE_DATABASE,
  waitForConnections: true,
  connectionLimit: 5,
  queueLimit: 0,
  connectTimeout: 10000,
  charset: "utf8mb4",
});

const targetPool = mysql.createPool({
  host: process.env.TARGET_HOST,
  port: Number(process.env.TARGET_PORT || 3306),
  user: process.env.TARGET_USER,
  password: process.env.TARGET_PASSWORD,
  database: process.env.TARGET_DATABASE,
  waitForConnections: true,
  connectionLimit: 5,
  queueLimit: 0,
  connectTimeout: 10000,
  charset: "utf8mb4",
});


function escapeIdentifier(identifier) {
  return `\`${String(identifier).replace(/`/g, "``")}\``;
}



async function checkTableExists(pool, databaseName, tableName) {
  const [rows] = await pool.execute(
    `
      SELECT COUNT(*) AS total
      FROM information_schema.tables
      WHERE table_schema = ?
        AND table_name = ?
    `,
    [databaseName, tableName]
  );

  return Number(rows[0]?.total || 0) > 0;
}


async function getTableColumns(pool, databaseName, tableName) {
  const [rows] = await pool.execute(
    `
      SELECT
        COLUMN_NAME,
        COLUMN_KEY,
        EXTRA,
        ORDINAL_POSITION
      FROM information_schema.columns
      WHERE table_schema = ?
        AND table_name = ?
      ORDER BY ORDINAL_POSITION
    `,
    [databaseName, tableName]
  );

  return rows;
}


async function getCompatibleTableStructure() {
  const sourceColumns = await getTableColumns(
    sourcePool,
    process.env.SOURCE_DATABASE,
    TABLE_NAME
  );

  const targetColumns = await getTableColumns(
    targetPool,
    process.env.TARGET_DATABASE,
    TABLE_NAME
  );

  if (!sourceColumns.length) {
    throw new Error(
      `Struktur tabel sumber ${TABLE_NAME} tidak ditemukan.`
    );
  }

  if (!targetColumns.length) {
    throw new Error(
      `Struktur tabel tujuan ${TABLE_NAME} tidak ditemukan.`
    );
  }

  const targetColumnNames = new Set(
    targetColumns.map((column) => column.COLUMN_NAME)
  );

  const compatibleColumns = sourceColumns
    .map((column) => column.COLUMN_NAME)
    .filter((columnName) => targetColumnNames.has(columnName));

  if (!compatibleColumns.length) {
    throw new Error(
      "Tidak ditemukan kolom yang sama antara tabel sumber dan tujuan."
    );
  }

  const sourcePrimaryKeys = sourceColumns
    .filter((column) => column.COLUMN_KEY === "PRI")
    .map((column) => column.COLUMN_NAME);

  const targetPrimaryKeys = targetColumns
    .filter((column) => column.COLUMN_KEY === "PRI")
    .map((column) => column.COLUMN_NAME);

  if (!sourcePrimaryKeys.length || !targetPrimaryKeys.length) {
    throw new Error(
      "Tabel sumber dan tujuan harus memiliki primary key."
    );
  }

  if (sourcePrimaryKeys.length !== 1) {
    throw new Error(
      "Program ini menggunakan satu primary key. Composite primary key belum didukung."
    );
  }

  const primaryKey = sourcePrimaryKeys[0];

  if (!targetPrimaryKeys.includes(primaryKey)) {
    throw new Error(
      `Primary key '${primaryKey}' pada sumber tidak sesuai dengan tabel tujuan.`
    );
  }

  if (!compatibleColumns.includes(primaryKey)) {
    throw new Error(
      `Kolom primary key '${primaryKey}' tidak tersedia pada kedua tabel.`
    );
  }

  return {
    columns: compatibleColumns,
    primaryKey,
  };
}


async function getTargetMaximumPrimaryKey(primaryKey) {
  const table = escapeIdentifier(TABLE_NAME);
  const key = escapeIdentifier(primaryKey);

  const [rows] = await targetPool.query(
    `SELECT MAX(${key}) AS maximum_id FROM ${table}`
  );

  return Number(rows[0]?.maximum_id || 0);
}


async function upsertRows(rows, columns, primaryKey) {
  if (!rows.length) {
    return 0;
  }

  const table = escapeIdentifier(TABLE_NAME);

  const escapedColumns = columns.map(escapeIdentifier);

  const updateColumns = columns.filter(
    (column) => column !== primaryKey
  );

  const rowPlaceholder = `(${columns.map(() => "?").join(", ")})`;

  const allPlaceholders = rows
    .map(() => rowPlaceholder)
    .join(", ");

  const values = [];

  for (const row of rows) {
    for (const column of columns) {
      values.push(row[column]);
    }
  }

  let upsertClause;

  if (updateColumns.length > 0) {
    upsertClause = updateColumns
      .map((column) => {
        const escapedColumn = escapeIdentifier(column);

        return `${escapedColumn} = VALUES(${escapedColumn})`;
      })
      .join(", ");
  } else {
    const escapedPrimaryKey = escapeIdentifier(primaryKey);

    upsertClause =
      `${escapedPrimaryKey} = VALUES(${escapedPrimaryKey})`;
  }

  const sql = `
    INSERT INTO ${table}
      (${escapedColumns.join(", ")})
    VALUES
      ${allPlaceholders}
    ON DUPLICATE KEY UPDATE
      ${upsertClause}
  `;

  const connection = await targetPool.getConnection();

  try {
    await connection.beginTransaction();

    const [result] = await connection.query(sql, values);

    await connection.commit();

    return Number(result.affectedRows || 0);
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}



async function syncNewRows(columns, primaryKey) {
  const table = escapeIdentifier(TABLE_NAME);
  const key = escapeIdentifier(primaryKey);

  const columnList = columns
    .map(escapeIdentifier)
    .join(", ");

  let lastPrimaryKey =
    await getTargetMaximumPrimaryKey(primaryKey);

  let totalRead = 0;
  let totalAffected = 0;

  while (true) {
    const sql = `
      SELECT ${columnList}
      FROM ${table}
      WHERE ${key} > ?
      ORDER BY ${key} ASC
      LIMIT ?
    `;

    const [rows] = await sourcePool.query(sql, [
      lastPrimaryKey,
      BATCH_SIZE,
    ]);

    if (!rows.length) {
      break;
    }

    const affectedRows = await upsertRows(
      rows,
      columns,
      primaryKey
    );

    totalRead += rows.length;
    totalAffected += affectedRows;

    lastPrimaryKey = rows[rows.length - 1][primaryKey];

    console.log(
      `[${new Date().toISOString()}] Data baru diproses: ` +
      `${rows.length}, primary key terakhir: ${lastPrimaryKey}`
    );

    if (rows.length < BATCH_SIZE) {
      break;
    }
  }

  return {
    read: totalRead,
    affected: totalAffected,
  };
}






async function recheckRecentRows(columns, primaryKey) {
  if (RECHECK_ROWS <= 0) {
    return {
      read: 0,
      affected: 0,
    };
  }

  const table = escapeIdentifier(TABLE_NAME);
  const key = escapeIdentifier(primaryKey);

  const columnList = columns
    .map(escapeIdentifier)
    .join(", ");

  const [rows] = await sourcePool.query(
    `
      SELECT ${columnList}
      FROM ${table}
      ORDER BY ${key} DESC
      LIMIT ?
    `,
    [RECHECK_ROWS]
  );

  if (!rows.length) {
    return {
      read: 0,
      affected: 0,
    };
  }

  rows.reverse();

  const affectedRows = await upsertRows(
    rows,
    columns,
    primaryKey
  );

  return {
    read: rows.length,
    affected: affectedRows,
  };
}





async function runSynchronization() {
  const startedAt = Date.now();

  console.log("\n========================================");
  console.log(
    `[${new Date().toISOString()}] Sinkronisasi dimulai`
  );

  const sourceExists = await checkTableExists(
    sourcePool,
    process.env.SOURCE_DATABASE,
    TABLE_NAME
  );

  const targetExists = await checkTableExists(
    targetPool,
    process.env.TARGET_DATABASE,
    TABLE_NAME
  );

  if (!sourceExists) {
    throw new Error(
      `Tabel sumber '${TABLE_NAME}' tidak ditemukan.`
    );
  }

  if (!targetExists) {
    throw new Error(
      `Tabel tujuan '${TABLE_NAME}' tidak ditemukan.`
    );
  }

  const { columns, primaryKey } =
    await getCompatibleTableStructure();

  console.log(`Tabel       : ${TABLE_NAME}`);
  console.log(`Primary key : ${primaryKey}`);
  console.log(`Jumlah kolom: ${columns.length}`);

  const newRowsResult = await syncNewRows(
    columns,
    primaryKey
  );

  const recentRowsResult = await recheckRecentRows(
    columns,
    primaryKey
  );

  const durationSeconds = (
    (Date.now() - startedAt) /
    1000
  ).toFixed(2);

  console.log("----------------------------------------");
  console.log(
    `Data baru dibaca       : ${newRowsResult.read}`
  );
  console.log(
    `Data terakhir diperiksa: ${recentRowsResult.read}`
  );
  console.log(
    `Affected rows          : ${
      newRowsResult.affected + recentRowsResult.affected
    }`
  );
  console.log(`Durasi                 : ${durationSeconds} detik`);
  console.log(
    `[${new Date().toISOString()}] Sinkronisasi selesai`
  );
  console.log("========================================");
}





let synchronizationRunning = false;
let synchronizationTimer = null;

async function synchronizationLoop() {
  if (synchronizationRunning) {
    console.log(
      "Sinkronisasi sebelumnya masih berjalan. Siklus dilewati."
    );
    return;
  }

  synchronizationRunning = true;

  try {
    await runSynchronization();
  } catch (error) {
    console.error(
      `[${new Date().toISOString()}] Sinkronisasi gagal:`,
      error.message
    );

    if (error.code) {
      console.error(`Kode error MySQL: ${error.code}`);
    }
  } finally {
    synchronizationRunning = false;

    synchronizationTimer = setTimeout(
      synchronizationLoop,
      SYNC_INTERVAL_MS
    );
  }
}






async function shutdown(signal) {
  console.log(`\nMenerima sinyal ${signal}. Program dihentikan.`);

  if (synchronizationTimer) {
    clearTimeout(synchronizationTimer);
  }

  try {
    await sourcePool.end();
    await targetPool.end();
  } catch (error) {
    console.error(
      "Terjadi kesalahan saat menutup koneksi:",
      error.message
    );
  }

  process.exit(0);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

synchronizationLoop();