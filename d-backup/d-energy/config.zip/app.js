const dotenv = require('dotenv');

// Muat environment variable sebelum mengimpor konfigurasi database.
dotenv.config();

const express = require('express');
const cors = require('cors');

const pool = require('./config/database');
const app = express();

// =============================
// Middleware dasar
// =============================
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(
  express.urlencoded({
    extended: true,
    limit: '20mb',
  })
);

// Logger request sederhana.
app.use((req, res, next) => {
  console.log(
    `[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`
  );
  next();
});

// =============================
// Import routes
// =============================
const authRoutes = require('./routes/auth');
const tableRoute = require('./routes/table.route');
const manhourRoutes = require('./routes/manhourRoutes');
const productionRoutes = require('./routes/productionRoutes');
const energyElectricalRoutesMonthly = require(
  './routes/energyElectricalRoutesMonthly'
);

const tb_kub1_active_power = require(
  './routes/tb_kub1_active_power'
);
const tb_kub1_total_kwh = require(
  './routes/tb_kub1_total_kwh'
);
const tb_pm_hourly_kwh = require(
  './routes/tb_pm_hourly_report'
);
const tb_pm_shiftly_kwh = require(
  './routes/tb_pm_shiftly_report'
);
const tb_pm_daily_kwh = require(
  './routes/tb_pm_daily_report'
);
const tb_pm_weekly_kwh = require(
  './routes/tb_pm_weekly_report'
);
const tb_pm_monthly_kwh = require(
  './routes/tb_pm_monthly_report'
);
const tb_pm_monthly_kub_kwh = require(
  './routes/tb_pm_monthly_kub_report'
);
const tb_pm_shiftly_kub_kwh = require(
  './routes/tb_pm_shiftly_kub_report'
);

const energyRoutesPlant2 = require(
  './routes/energyRoutesPlant2'
);
const manhourBreakdown = require(
  './routes/manhourBreakdown'
);
const trialCommonRail9 = require(
  './routes/trialCommonRail9Route'
);

// =============================
// Kubikal
// =============================
const kubCurrent = require('./routes/kubCurrentRoute');
const realtimeKubikal1 = require(
  './routes/kubikal1Route'
);
const realtimeKubikal2panel63 = require(
  './routes/kubikal2Panel63Route'
);
const realtimeKubikal2panel64 = require(
  './routes/kubikal2Panel64Route'
);
const realtimeKubikal1panel24 = require(
  './routes/kubikal1Panel24Route'
);
const realtimeKubikal1panel21 = require(
  './routes/kubikal1Panel21Route'
);
const realtimeKubikal1panel19 = require(
  './routes/kubikal1Panel19Route'
);
const layoutOticRoutes = require(
  './routes/tb_layoutOticRoutes'
);

const comp19RoutesShiftly = require(
  './routes/tb_comp19RoutesShiftly'
);
const comp21RoutesShiftly = require(
  './routes/tb_comp21RoutesShiftly'
);
const comp24RoutesShiftly = require(
  './routes/tb_comp24RoutesShiftly'
);
const comp20RoutesShiftly = require(
  './routes/tb_comp20RoutesShiftly'
);

const comp19RoutesMonthly = require(
  './routes/tb_comp19RoutesMonthly'
);
const comp21RoutesMonthly = require(
  './routes/tb_comp21RoutesMonthly'
);
const comp24RoutesMonthly = require(
  './routes/tb_comp24RoutesMonthly'
);
const comp20RoutesMonthly = require(
  './routes/tb_comp20RoutesMonthly'
);

// Route monthly Panel 63 yang baru.
const tbKub2Panel63MonthlyRoutes = require(
  './routes/tb_kub2Panel63MonthlyRoutes'
);

// Route monthly Panel 64 yang baru.
const tbKub2Panel64MonthlyRoutes = require(
  './routes/tb_kub2Panel64MonthlyRoutes'
);

// Route shiftly Panel 63.
const tbKub2Panel63ShiftlyRoutes = require(
  './routes/tb_kub2Panel63RoutesShiftly'
);

// Route shiftly Panel 64.
const tbKub2Panel64ShiftlyRoutes = require(
  './routes/tb_kub2Panel64RoutesShiftly'
);

// =============================
// Hikitori
// =============================
const hikitoriRoutes = require(
  './routes/hikitoriRoutes'
);

// =============================
// Line breakdown base time
// =============================
const dailyReportRoutes = require(
  './routes/dailyReportRoutes'
);
const shiftlyReportRoutes = require(
  './routes/shiftlyReportRoutes'
);
const weeklyReportRoutes = require(
  './routes/weeklyReportRoutes'
);
const monthlyReportRoutes = require(
  './routes/monthlyReportRoutes'
);

// =============================
// Compressor
// =============================
const compressorRoutes = require(
  './routes/compressor.routes'
);

// =============================
// Kubikal base time
// =============================
const kubRoutes = require('./routes/kubRoutes');

// =============================
// PLTS
// =============================
const fullTextRoutes = require(
  './routes/fullTextRoutes'
);
const fullTextRoutes_p1 = require(
  './routes/fullTextRoutes_p1'
);

const pltsP1DailyRoutes = require(
  './routes/pltsP1DailyRoutes'
);
const pltsP2DailyRoutes = require(
  './routes/pltsP2DailyRoutes'
);
const pltsP1DailyRoutesFullStack = require(
  './routes/pltsP1DailyRoutesFullStack'
);
const pltsP2DailyRoutesFullStack = require(
  './routes/pltsP2DailyRoutesFullStack'
);
const pltsP1HourlyRoutes = require(
  './routes/pltsP1HourlyRoutes'
);
const pltsP2HourlyRoutes = require(
  './routes/pltsP2HourlyRoutes'
);
const pltsP1HourlyRoutesFullStack = require(
  './routes/pltsP1HourlyRoutesFullStack'
);
const pltsP2HourlyRoutesFullStack = require(
  './routes/pltsP2HourlyRoutesFullStack'
);
const pltsRealtimeRoutes = require(
  './routes/pltsRealtimeRoutes'
);
const pltsPlant1Plant2Routes = require(
  './routes/pltsPlant1Plant2Routes'
);

// =============================
// Routes baru
// =============================
const powerMeterRoutes = require(
  './routes/powerMeterRoutes'
);

// =============================
// Error handlers
// =============================
const {
  notFoundHandler,
  errorHandler,
} = require('./middlewares/errorHandler');

// =============================
// Basic endpoints
// =============================
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'API is running...',
    timestamp: new Date().toISOString(),
    endpoints: {
      test: '/api/test',
      energy: '/api/energy/pm-monthly-report',
      kub2Panel63Monthly: '/api/kub2-panel63-monthly',
      kub2Panel64Monthly: '/api/kub2-panel64-monthly',
      kub2Panel63Shiftly: '/api/kub2-panel63-shiftly',
      kub2Panel63ShiftlySummary:
        '/api/kub2-panel63-shiftly/summary',
      kub2Panel64Shiftly: '/api/kub2-panel64-shiftly',
      kub2Panel64ShiftlySummary:
        '/api/kub2-panel64-shiftly/summary',
    },
  });
});

app.get('/api/test', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Test route works!',
    timestamp: new Date(),
    environment: process.env.NODE_ENV,
  });
});

// =============================
// Register routes
// Semua route harus diletakkan sebelum notFoundHandler.
// =============================
app.use('/api/auth', authRoutes);

app.use('/all', tableRoute);
app.use('/api/manhour', manhourRoutes);
app.use('/api/productions', productionRoutes);
app.use('/api/energy', energyElectricalRoutesMonthly);

app.use(
  '/api/kub1-active-power',
  tb_kub1_active_power
);
app.use(
  '/api/kub1-total-kwh',
  tb_kub1_total_kwh
);

app.use('/api/pm-hourly-kwh', tb_pm_hourly_kwh);
app.use('/api/pm-shiftly-kwh', tb_pm_shiftly_kwh);
app.use('/api/pm-daily-kwh', tb_pm_daily_kwh);
app.use('/api/pm-weekly-kwh', tb_pm_weekly_kwh);
app.use('/api/pm-monthly-kwh', tb_pm_monthly_kwh);
app.use(
  '/api/pm-monthly-kub-kwh',
  tb_pm_monthly_kub_kwh
);
app.use(
  '/api/pm-shiftly-kub-kwh',
  tb_pm_shiftly_kub_kwh
);

app.use('/api', energyRoutesPlant2);
app.use('/api/common-rail', manhourBreakdown);
app.use('/api/trial', trialCommonRail9);

// =============================
// Kubikal routes
// =============================
app.use('/api/kub', kubCurrent);
app.use(
  '/api/kubikal1realtime',
  realtimeKubikal1
);
app.use(
  '/api/kubikal2panel63realtime',
  realtimeKubikal2panel63
);
app.use(
  '/api/kubikal2panel64realtime',
  realtimeKubikal2panel64
);
app.use(
  '/api/kubikal1panel24realtime',
  realtimeKubikal1panel24
);
app.use(
  '/api/kubikal1panel21realtime',
  realtimeKubikal1panel21
);
app.use(
  '/api/kubikal1panel19realtime',
  realtimeKubikal1panel19
);

app.use('/api/layout-otics', layoutOticRoutes);

app.use(
  '/api/comp19Shiftly',
  comp19RoutesShiftly
);
app.use(
  '/api/comp21Shiftly',
  comp21RoutesShiftly
);
app.use(
  '/api/comp24Shiftly',
  comp24RoutesShiftly
);
app.use(
  '/api/comp20Shiftly',
  comp20RoutesShiftly
);

app.use(
  '/api/comp19Monthly',
  comp19RoutesMonthly
);
app.use(
  '/api/comp21Monthly',
  comp21RoutesMonthly
);
app.use(
  '/api/comp24Monthly',
  comp24RoutesMonthly
);
app.use(
  '/api/comp20Monthly',
  comp20RoutesMonthly
);

// Monthly Panel 63.
// Route ini wajib berada sebelum notFoundHandler.
app.use(
  '/api/kub2-panel63-monthly',
  tbKub2Panel63MonthlyRoutes
);

app.use(
  '/api/kub2-panel64-monthly',
  tbKub2Panel64MonthlyRoutes
);

// Shiftly Panel 63.
app.use(
  '/api/kub2-panel63-shiftly',
  tbKub2Panel63ShiftlyRoutes
);

// Shiftly Panel 64.
app.use(
  '/api/kub2-panel64-shiftly',
  tbKub2Panel64ShiftlyRoutes
);

// =============================
// Hikitori
// =============================
app.use('/api/hikitori', hikitoriRoutes);

// =============================
// Line breakdown base time
// =============================
app.use(
  '/api/reports/daily',
  dailyReportRoutes
);
app.use(
  '/api/reports/shiftly',
  shiftlyReportRoutes
);
app.use(
  '/api/reports/weekly',
  weeklyReportRoutes
);
app.use(
  '/api/reports/monthly',
  monthlyReportRoutes
);

// =============================
// Compressor base time
// =============================
app.use('/api/compressor', compressorRoutes);

// =============================
// Kubikal base time
// =============================
app.use('/api/kub', kubRoutes);

// =============================
// PLTS
// =============================
app.use('/api/full-texts', fullTextRoutes);
app.use('/api/full-texts-p1', fullTextRoutes_p1);

app.use(
  '/api/plts-p1-daily',
  pltsP1DailyRoutes
);
app.use(
  '/api/plts-p2-daily',
  pltsP2DailyRoutes
);
app.use(
  '/api/plts-p1-daily-full-stack',
  pltsP1DailyRoutesFullStack
);
app.use(
  '/api/plts-p2-daily-full-stack',
  pltsP2DailyRoutesFullStack
);
app.use(
  '/api/plts-p1-hourly',
  pltsP1HourlyRoutes
);
app.use(
  '/api/plts-p2-hourly',
  pltsP2HourlyRoutes
);
app.use(
  '/api/plts-p1-hourly-full-stack',
  pltsP1HourlyRoutesFullStack
);
app.use(
  '/api/plts-p2-hourly-full-stack',
  pltsP2HourlyRoutesFullStack
);
app.use('/api/plts', pltsRealtimeRoutes);
app.use(
  '/api/plts-plant-1-plant-2',
  pltsPlant1Plant2Routes
);

// =============================
// Routes baru
// =============================
app.use('/api/power-meters', powerMeterRoutes);

// =============================
// 404 dan error handler
// HARUS berada paling bawah setelah semua routes.
// =============================
app.use(notFoundHandler);
app.use(errorHandler);

// =============================
// Start server
// =============================
const PORT = Number(process.env.PORT) || 4001;

let server = null;
let isShuttingDown = false;

const testDatabaseConnection = async () => {
  const connection = await pool.getConnection();

  try {
    await connection.query('SELECT 1');
  } finally {
    connection.release();
  }
};

const printMainEndpoints = () => {
  console.log('📚 Main API Endpoints:');
  console.log('   GET    /');
  console.log('   GET    /api/test');

  console.log('');
  console.log('   Panel 63 Monthly');
  console.log('   GET    /api/kub2-panel63-monthly');
  console.log(
    '   GET    /api/kub2-panel63-monthly/:pmType/:lineTable/:year/:month'
  );
  console.log('   POST   /api/kub2-panel63-monthly');
  console.log(
    '   PUT    /api/kub2-panel63-monthly/:pmType/:lineTable/:year/:month'
  );
  console.log(
    '   PATCH  /api/kub2-panel63-monthly/:pmType/:lineTable/:year/:month'
  );
  console.log(
    '   DELETE /api/kub2-panel63-monthly/:pmType/:lineTable/:year/:month'
  );

  console.log('');
  console.log('   Panel 64 Monthly');
  console.log('   GET    /api/kub2-panel64-monthly');
  console.log(
    '   GET    /api/kub2-panel64-monthly/:pmType/:lineTable/:year/:month'
  );
  console.log('   POST   /api/kub2-panel64-monthly');
  console.log(
    '   PUT    /api/kub2-panel64-monthly/:pmType/:lineTable/:year/:month'
  );
  console.log(
    '   PATCH  /api/kub2-panel64-monthly/:pmType/:lineTable/:year/:month'
  );
  console.log(
    '   DELETE /api/kub2-panel64-monthly/:pmType/:lineTable/:year/:month'
  );

  console.log('');
  console.log('   Panel 63 Shiftly');
  console.log('   GET    /api/kub2-panel63-shiftly');
  console.log('   GET    /api/kub2-panel63-shiftly/summary');
  console.log('   GET    /api/kub2-panel63-shiftly/:id');
  console.log('   POST   /api/kub2-panel63-shiftly');
  console.log('   POST   /api/kub2-panel63-shiftly/upsert');
  console.log('   PUT    /api/kub2-panel63-shiftly/:id');
  console.log('   PATCH  /api/kub2-panel63-shiftly/:id');
  console.log('   DELETE /api/kub2-panel63-shiftly/:id');

  console.log('');
  console.log('   Panel 64 Shiftly');
  console.log('   GET    /api/kub2-panel64-shiftly');
  console.log('   GET    /api/kub2-panel64-shiftly/summary');
  console.log('   GET    /api/kub2-panel64-shiftly/:id');
  console.log('   POST   /api/kub2-panel64-shiftly');
  console.log('   POST   /api/kub2-panel64-shiftly/upsert');
  console.log('   PUT    /api/kub2-panel64-shiftly/:id');
  console.log('   PATCH  /api/kub2-panel64-shiftly/:id');
  console.log('   DELETE /api/kub2-panel64-shiftly/:id');
};

const startServer = async () => {
  try {
    await testDatabaseConnection();

    console.log(
      '✅ MySQL Production database connected successfully'
    );

    server = app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(
        '🌐 Environment:',
        process.env.NODE_ENV || 'development'
      );

      printMainEndpoints();
    });

    server.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        console.error(
          `❌ Port ${PORT} sedang digunakan oleh proses lain.`
        );
      } else {
        console.error('❌ HTTP server error:', error);
      }

      process.exit(1);
    });
  } catch (error) {
    console.error(
      '❌ Database connection failed:',
      error.message
    );

    process.exit(1);
  }
};

const shutdown = async (signal) => {
  if (isShuttingDown) {
    return;
  }

  isShuttingDown = true;
  console.log(`\n🛑 ${signal} received. Shutting down...`);

  const forceShutdownTimer = setTimeout(() => {
    console.error('❌ Forced shutdown after timeout.');
    process.exit(1);
  }, 10000);

  forceShutdownTimer.unref();

  try {
    if (server) {
      await new Promise((resolve, reject) => {
        server.close((error) => {
          if (error) {
            reject(error);
            return;
          }

          resolve();
        });
      });
    }

    if (pool && typeof pool.end === 'function') {
      await pool.end();
    }

    console.log('✅ Server and database pool closed.');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error during shutdown:', error);
    process.exit(1);
  }
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

process.on('unhandledRejection', (reason) => {
  console.error('❌ Unhandled promise rejection:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught exception:', error);
  shutdown('UNCAUGHT_EXCEPTION');
});

// Jalankan server hanya jika file ini dieksekusi langsung.
if (require.main === module) {
  startServer();
}

module.exports = app;
