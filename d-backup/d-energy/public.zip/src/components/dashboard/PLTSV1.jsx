import { Import } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';

import Layout from '../layout/Layout';


const API_URL =
  import.meta.env.VITE_PLTS_API_URL ||
  'http://172.27.6.191:4000/api/plts-plant-1-plant-2';

const REFRESH_INTERVAL = 30_000;

const EMPTY_PAGINATION = {
  page: 1,
  limit: 20,
  total: 0,
  totalPages: 1,
};

const FIELD_GROUPS = [
  {
    title: 'Informasi Umum',
    fields: [
      ['id', 'ID'],
      ['recorded_at', 'Waktu Rekam'],
      ['created_at', 'Waktu Tersimpan'],
    ],
  },
  {
    title: 'OTICS · Plant 1',
    fields: [
      ['otics_power', 'Power'],
      ['otics_phase_1_inv1', 'Phase 1 Inverter 1'],
      ['otics_phase_1_inv2', 'Phase 1 Inverter 2'],
      ['otics_pv_energy_today', 'PV Energy Today'],
      ['otics_pv_energy_monthly', 'PV Energy Monthly'],
      ['otics_pv_energy_total', 'PV Energy Total'],
      ['otics_irradiation', 'Irradiation'],
      ['otics_pr', 'Performance Ratio'],
      ['otics_weather_temp', 'Weather Temperature'],
      ['otics_weather_date', 'Weather Date'],
      ['otics_co2_reduced', 'CO₂ Reduced'],
      ['otics_status', 'Status'],
      ['otics_comm_monitoring_last', 'Last Communication'],
    ],
  },
  {
    title: 'Huawei · Plant 2',
    fields: [
      ['huawei_temperature', 'Temperature'],
      ['huawei_yield_today', 'Yield Today'],
      ['huawei_supply_from_grid_today', 'Supply from Grid Today'],
      ['huawei_total_yield', 'Total Yield'],
      ['huawei_inverter_rated_power', 'Inverter Rated Power'],
      ['huawei_installed_pv_capacity', 'Installed PV Capacity'],
      ['huawei_standard_coal_saved', 'Standard Coal Saved'],
      ['huawei_co2_avoided', 'CO₂ Avoided'],
      ['huawei_equivalent_trees_planted', 'Equivalent Trees Planted'],
      ['huawei_pv_output_kw', 'PV Output'],
      ['huawei_mains_power_kw', 'Mains Power'],
      ['huawei_irradiance_wm2', 'Irradiance'],
      ['huawei_consumed_by_appliances_kw', 'Consumed by Appliances'],
    ],
  },
];

function classNames(...values) {
  return values.filter(Boolean).join(' ');
}

function safeNumber(value) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function formatNumber(value, options = {}) {
  const number = safeNumber(value);
  if (number === null) return '-';

  return new Intl.NumberFormat('id-ID', {
    maximumFractionDigits: options.maximumFractionDigits ?? 3,
    minimumFractionDigits: options.minimumFractionDigits ?? 0,
  }).format(number);
}

function formatMetric(value, unit = '', maximumFractionDigits = 2) {
  const formatted = formatNumber(value, { maximumFractionDigits });
  return formatted === '-' ? '-' : `${formatted}${unit ? ` ${unit}` : ''}`;
}

function parseDate(value) {
  if (!value) return null;
  const normalized = String(value).replace(' ', 'T');
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatDateTime(value, includeSeconds = true) {
  const date = parseDate(value);
  if (!date) return value || '-';

  return new Intl.DateTimeFormat('id-ID', {
    dateStyle: 'medium',
    timeStyle: includeSeconds ? 'medium' : 'short',
  }).format(date);
}

function formatShortTime(value) {
  const date = parseDate(value);
  if (!date) return '-';

  return new Intl.DateTimeFormat('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

function getLocalDateKey(value) {
  const date = parseDate(value);
  if (!date) return '';

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  return `${year}-${month}-${day}`;
}

function formatDateOnly(value) {
  const date = parseDate(value);
  if (!date) return '-';

  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  }).format(date);
}

function toApiDate(value, endOfDay = false) {
  if (!value) return '';
  return `${value} ${endOfDay ? '23:59:59' : '00:00:00'}`;
}

function getErrorMessage(error) {
  if (error instanceof Error) return error.message;
  return 'Terjadi kesalahan yang tidak diketahui.';
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(options.headers || {}),
    },
  });

  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok) {
    const validationMessage = Array.isArray(payload?.errors)
      ? payload.errors.join(' ')
      : '';

    throw new Error(
      validationMessage ||
        payload?.message ||
        `Permintaan gagal dengan status ${response.status}.`,
    );
  }

  return payload;
}

function Icon({ name, className = 'h-5 w-5' }) {
  const common = {
    className,
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.8,
    viewBox: '0 0 24 24',
    'aria-hidden': true,
  };

  const icons = {
    sun: (
      <svg {...common}>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41" />
      </svg>
    ),
    bolt: (
      <svg {...common}>
        <path d="m13 2-8 12h7l-1 8 8-12h-7l1-8Z" />
      </svg>
    ),
    activity: (
      <svg {...common}>
        <path d="M3 12h4l2-7 4 14 2-7h6" />
      </svg>
    ),
    cloud: (
      <svg {...common}>
        <path d="M17.5 19H7a5 5 0 1 1 1.4-9.8A6 6 0 0 1 20 11a4 4 0 0 1-2.5 8Z" />
      </svg>
    ),
    temperature: (
      <svg {...common}>
        <path d="M14 14.76V5a4 4 0 0 0-8 0v9.76a6 6 0 1 0 8 0Z" />
        <path d="M10 6v10" />
      </svg>
    ),
    refresh: (
      <svg {...common}>
        <path d="M20 11a8.1 8.1 0 0 0-15.5-2M4 4v5h5M4 13a8.1 8.1 0 0 0 15.5 2M20 20v-5h-5" />
      </svg>
    ),
    download: (
      <svg {...common}>
        <path d="M12 3v12M7 10l5 5 5-5M5 21h14" />
      </svg>
    ),
    eye: (
      <svg {...common}>
        <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z" />
        <circle cx="12" cy="12" r="2.5" />
      </svg>
    ),
    close: (
      <svg {...common}>
        <path d="m6 6 12 12M18 6 6 18" />
      </svg>
    ),
    chevronLeft: (
      <svg {...common}>
        <path d="m15 18-6-6 6-6" />
      </svg>
    ),
    chevronRight: (
      <svg {...common}>
        <path d="m9 18 6-6-6-6" />
      </svg>
    ),
    database: (
      <svg {...common}>
        <ellipse cx="12" cy="5" rx="8" ry="3" />
        <path d="M4 5v7c0 1.66 3.58 3 8 3s8-1.34 8-3V5" />
        <path d="M4 12v7c0 1.66 3.58 3 8 3s8-1.34 8-3v-7" />
      </svg>
    ),
    wifi: (
      <svg {...common}>
        <path d="M5 12.55a11 11 0 0 1 14.08 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01" />
      </svg>
    ),
  };

  return icons[name] || icons.activity;
}

function StatusBadge({ status }) {
  const normalized = String(status || '').toLowerCase();
  const healthy = ['healthy', 'normal', 'online', 'active'].some((item) =>
    normalized.includes(item),
  );
  const warning = ['warning', 'warn', 'attention'].some((item) =>
    normalized.includes(item),
  );

  return (
    <span
      className={classNames(
        'inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ring-1 ring-inset',
        healthy && 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
        warning && 'bg-amber-50 text-amber-700 ring-amber-600/20',
        !healthy &&
          !warning &&
          'bg-rose-50 text-rose-700 ring-rose-600/20',
      )}
    >
      <span
        className={classNames(
          'h-2 w-2 rounded-full',
          healthy && 'bg-emerald-500',
          warning && 'bg-amber-500',
          !healthy && !warning && 'bg-rose-500',
        )}
      />
      {status || 'Unknown'}
    </span>
  );
}

function SummaryCard({ title, value, subtitle, icon, accent = 'emerald' }) {
  const accents = {
    emerald: 'bg-emerald-50 text-emerald-700 ring-emerald-100',
    cyan: 'bg-cyan-50 text-cyan-700 ring-cyan-100',
    blue: 'bg-blue-50 text-blue-700 ring-blue-100',
    amber: 'bg-amber-50 text-amber-700 ring-amber-100',
    violet: 'bg-violet-50 text-violet-700 ring-violet-100',
  };

  return (
    <article className="rounded-2xl border border-slate-200 bg-slate-50 p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[clamp(0.65rem,0.7vw,0.9rem)] font-bold uppercase tracking-wide text-slate-500">
            {title}
          </p>
          <p className="mt-1 truncate text-[clamp(1.05rem,1.3vw,2rem)] font-black leading-tight text-slate-900">
            {value}
          </p>
          <p className="mt-0.5 truncate text-[clamp(0.62rem,0.66vw,0.85rem)] text-slate-400">
            {subtitle}
          </p>
        </div>
        <div
          className={classNames(
            'grid h-10 w-10 shrink-0 place-items-center rounded-xl ring-1',
            accents[accent] || accents.emerald,
          )}
        >
          <Icon name={icon} className="h-5 w-5" />
        </div>
      </div>
    </article>
  );
}

/**
 * Komponen BarChart sederhana menggunakan SVG.
 * Menampilkan diagram batang vertikal untuk data time‑series.
 */
function BarChart({ data, field, title, unit, valueFormatter, emptyMessage }) {
  const bars = useMemo(() => {
    const cleaned = data
      .map((row) => ({
        time: row.recorded_at,
        value: safeNumber(row[field]),
      }))
      .filter((row) => row.value !== null && parseDate(row.time))
      .sort((a, b) => parseDate(a.time).getTime() - parseDate(b.time).getTime());

    if (cleaned.length === 0) return [];

    // Grafik hanya menampilkan record dalam satu tanggal terbaru yang tersedia.
    const activeDateKey = getLocalDateKey(cleaned.at(-1)?.time);
    const oneDayData = cleaned.filter((row) => getLocalDateKey(row.time) === activeDateKey);
    const values = oneDayData.map((row) => row.value);
    const max = Math.max(...values);
    const min = Math.min(...values);
    const range = max - min || 1;

    const width = 640;
    const height = 220;
    const paddingX = 18;
    const paddingY = 18;
    const barWidth =
      oneDayData.length === 1 ? 60 : Math.min(40, (width - paddingX * 2) / oneDayData.length - 4);

    return oneDayData.map((row, index) => {
      const barHeight = ((row.value - min) / range) * (height - paddingY * 2);
      const x =
        oneDayData.length === 1
          ? width / 2 - barWidth / 2
          : paddingX + (index / (oneDayData.length - 1)) * (width - paddingX * 2) - barWidth / 2;

      return {
        ...row,
        x,
        y: paddingY + (height - paddingY * 2) - barHeight,
        height: barHeight,
        width: barWidth,
        max,
        min,
      };
    });
  }, [data, field]);

  const latest = bars.at(-1);

  return (
    <article className="rounded-2xl border border-slate-200 bg-slate-50 p-4 shadow-sm sm:p-5">
      <div className="mb-4 flex items-start justify-between gap-4">
        <div>
          <h3 className="text-[clamp(0.85rem,0.9vw,1.15rem)] font-black text-slate-900">
            {title}
          </h3>
          <p className="mt-1 text-xs text-slate-400">
            {bars.length > 0
              ? `Data satu hari · ${formatDateOnly(bars[0]?.time)} · ${bars.length} record`
              : 'Data satu hari'}
          </p>
        </div>
        <div className="text-right">
          <p className="text-[clamp(1rem,1.2vw,1.6rem)] font-black text-slate-900">
            {latest
              ? valueFormatter
                ? valueFormatter(latest.value)
                : formatMetric(latest.value, unit)
              : '-'}
          </p>
          <p className="text-xs text-slate-400">nilai terakhir</p>
        </div>
      </div>

      {bars.length > 0 ? (
        <>
          <div className="relative overflow-hidden rounded-xl bg-white">
            <svg
              className="h-56 w-full"
              viewBox="0 0 640 220"
              preserveAspectRatio="none"
              role="img"
              aria-label={`Grafik ${title}`}
            >
              {/* Garis bantu horizontal */}
              {[44, 88, 132, 176].map((y) => (
                <line
                  key={y}
                  x1="0"
                  x2="640"
                  y1={y}
                  y2={y}
                  stroke="currentColor"
                  className="text-slate-200"
                  strokeDasharray="4 6"
                />
              ))}
              {/* Batang */}
              {bars.map((bar, index) => (
                <rect
                  key={`${bar.time}-${index}`}
                  x={bar.x}
                  y={bar.y}
                  width={bar.width}
                  height={bar.height}
                  fill="rgb(16 185 129)"
                  rx="2"
                  ry="2"
                />
              ))}
            </svg>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
            <span>{formatShortTime(bars[0]?.time)}</span>
            <span>
              Rentang {formatNumber(bars[0]?.min)}–{formatNumber(bars[0]?.max)} {unit}
            </span>
            <span>{formatShortTime(latest?.time)}</span>
          </div>
        </>
      ) : (
        <div className="grid h-56 place-items-center rounded-xl bg-white text-sm text-slate-400">
          {emptyMessage || 'Data grafik belum tersedia.'}
        </div>
      )}
    </article>
  );
}

function DetailModal({ row, onClose }) {
  if (!row) return null;

  let rawPayload = row.raw_payload_json;
  try {
    rawPayload = JSON.stringify(JSON.parse(row.raw_payload_json), null, 2);
  } catch {
    rawPayload = row.raw_payload_json || '-';
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/60 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="plts-detail-title"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="max-h-[92vh] w-full max-w-5xl overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 sm:px-7">
          <div>
            <h2
              id="plts-detail-title"
              className="text-lg font-black text-slate-900"
            >
              Detail Data PLTS #{row.id}
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              {formatDateTime(row.recorded_at)}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="grid h-10 w-10 place-items-center rounded-xl text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
            aria-label="Tutup detail"
          >
            <Icon name="close" />
          </button>
        </div>

        <div className="max-h-[calc(92vh-76px)] overflow-y-auto p-5 sm:p-7">
          <div className="space-y-6">
            {FIELD_GROUPS.map((group) => (
              <section key={group.title}>
                <h3 className="mb-3 text-sm font-black uppercase tracking-wider text-slate-500">
                  {group.title}
                </h3>
                <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {group.fields.map(([field, label]) => (
                    <div
                      key={field}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
                    >
                      <dt className="text-xs font-bold text-slate-500">{label}</dt>
                      <dd className="mt-1 break-words text-sm font-semibold text-slate-900">
                        {field.endsWith('_at') || field.endsWith('_date')
                          ? formatDateTime(row[field])
                          : row[field] ?? '-'}
                      </dd>
                    </div>
                  ))}
                </dl>
              </section>
            ))}

            <section>
              <h3 className="mb-3 text-sm font-black uppercase tracking-wider text-slate-500">
                Raw Payload JSON
              </h3>
              <pre className="max-h-80 overflow-auto rounded-2xl bg-slate-950 p-4 text-xs leading-6 text-slate-200">
                {rawPayload}
              </pre>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

function LoadingRows() {
  return Array.from({ length: 6 }, (_, index) => (
    <tr key={index} className="animate-pulse border-b border-slate-100">
      {Array.from({ length: 9 }, (_, cell) => (
        <td key={cell} className="px-4 py-4">
          <div className="h-4 rounded bg-slate-100" />
        </td>
      ))}
    </tr>
  ));
}

export default function PLTS() {
  const [rows, setRows] = useState([]);
  const [latest, setLatest] = useState(null);
  const [pagination, setPagination] = useState(EMPTY_PAGINATION);
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    status: '',
    limit: 20,
  });
  const [appliedFilters, setAppliedFilters] = useState(filters);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [selectedRow, setSelectedRow] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);

  const fetchDashboard = useCallback(
    async ({ silent = false } = {}) => {
      if (silent) setRefreshing(true);
      else setLoading(true);

      setError('');

      const query = new URLSearchParams({
        page: String(page),
        limit: String(appliedFilters.limit),
      });

      if (appliedFilters.startDate) {
        query.set('start_date', toApiDate(appliedFilters.startDate));
      }
      if (appliedFilters.endDate) {
        query.set('end_date', toApiDate(appliedFilters.endDate, true));
      }
      if (appliedFilters.status) {
        query.set('status', appliedFilters.status);
      }

      try {
        const [listResult, latestResult] = await Promise.all([
          requestJson(`${API_URL}?${query.toString()}`),
          requestJson(`${API_URL}/latest`).catch((latestError) => {
            if (latestError.message.includes('Belum ada data')) return null;
            throw latestError;
          }),
        ]);

        setRows(Array.isArray(listResult?.data) ? listResult.data : []);
        setPagination({
          ...EMPTY_PAGINATION,
          ...(listResult?.pagination || {}),
        });
        setLatest(latestResult?.data || null);
        setLastUpdated(new Date());
      } catch (fetchError) {
        setError(getErrorMessage(fetchError));
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [page, appliedFilters],
  );

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  useEffect(() => {
    if (!autoRefresh) return undefined;

    const intervalId = window.setInterval(() => {
      fetchDashboard({ silent: true });
    }, REFRESH_INTERVAL);

    return () => window.clearInterval(intervalId);
  }, [autoRefresh, fetchDashboard]);

  useEffect(() => {
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setSelectedRow(null);
    };

    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, []);

  const chartRows = useMemo(
    () =>
      [...rows].sort((a, b) => {
        const aTime = parseDate(a.recorded_at)?.getTime() || 0;
        const bTime = parseDate(b.recorded_at)?.getTime() || 0;
        return aTime - bTime;
      }),
    [rows],
  );

  const summary = useMemo(() => {
    const source = latest || rows[0] || {};
    return {
      source,
      totalPower:
        safeNumber(source.otics_power) !== null
          ? source.otics_power
          : source.huawei_pv_output_kw,
      inverterTotal:
        (safeNumber(source.otics_phase_1_inv1) || 0) +
        (safeNumber(source.otics_phase_1_inv2) || 0),
    };
  }, [latest, rows]);

  function handleApplyFilters(event) {
    event.preventDefault();

    if (
      filters.startDate &&
      filters.endDate &&
      new Date(filters.startDate) > new Date(filters.endDate)
    ) {
      setError('Tanggal mulai tidak boleh lebih besar daripada tanggal akhir.');
      return;
    }

    setError('');
    setPage(1);
    setAppliedFilters(filters);
  }

  function handleResetFilters() {
    const nextFilters = {
      startDate: '',
      endDate: '',
      status: '',
      limit: 20,
    };
    setFilters(nextFilters);
    setAppliedFilters(nextFilters);
    setPage(1);
  }

  function exportCsv() {
    if (!rows.length) return;

    const columns = [
      'id',
      'recorded_at',
      'otics_power',
      'otics_phase_1_inv1',
      'otics_phase_1_inv2',
      'otics_pv_energy_today',
      'otics_pv_energy_monthly',
      'otics_pv_energy_total',
      'otics_irradiation',
      'otics_pr',
      'otics_weather_temp',
      'otics_weather_date',
      'otics_co2_reduced',
      'otics_status',
      'otics_comm_monitoring_last',
      'huawei_temperature',
      'huawei_yield_today',
      'huawei_supply_from_grid_today',
      'huawei_total_yield',
      'huawei_inverter_rated_power',
      'huawei_installed_pv_capacity',
      'huawei_standard_coal_saved',
      'huawei_co2_avoided',
      'huawei_equivalent_trees_planted',
      'huawei_pv_output_kw',
      'huawei_mains_power_kw',
      'huawei_irradiance_wm2',
      'huawei_consumed_by_appliances_kw',
      'created_at',
    ];

    const escapeCsv = (value) => {
      const text = value === null || value === undefined ? '' : String(value);
      return `"${text.replaceAll('"', '""')}"`;
    };

    const csv = [
      columns.join(','),
      ...rows.map((row) =>
        columns.map((column) => escapeCsv(row[column])).join(','),
      ),
    ].join('\n');

    const blob = new Blob([`\uFEFF${csv}`], {
      type: 'text/csv;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `plts-data-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  const currentPage = Number(pagination.page) || page;
  const totalPages = Math.max(Number(pagination.totalPages) || 1, 1);

  return (
    <Layout>
      <div className="base">
        <div className="min-h-screen bg-slate-50 text-slate-900">
          <main className="mx-auto max-w-[1600px] space-y-4 px-3 py-4 sm:px-5 sm:py-5 lg:px-6 lg:py-6">
            {/* Header Card */}
            <section className="mb-3 flex flex-col justify-between gap-3 rounded-3xl border border-slate-200 bg-white p-3 shadow-sm sm:p-4 md:flex-row md:items-center lg:mb-5 lg:gap-5 lg:p-6">
              <div className="min-w-0">
                <p className="text-[clamp(0.75rem,0.82vw,1.15rem)] font-black uppercase tracking-[0.18em] text-emerald-600">
                  PLTS Monitoring Dashboard
                </p>
                <h1 className="mt-1 text-[clamp(1.1rem,1.5vw,2.25rem)] font-black leading-tight text-slate-950">
                  Plant 1 OTICS & Plant 2 Huawei
                </h1>
                <p className="mt-1 text-[clamp(0.72rem,0.75vw,1.05rem)] font-semibold text-slate-500">
                  Pembaruan real-time · Total {formatNumber(pagination.total)}{' '}
                  record pada database
                </p>
                {summary.source.otics_status && (
                  <span className="mt-2 inline-block">
                    <StatusBadge status={summary.source.otics_status} />
                  </span>
                )}
              </div>

              <div className="flex w-full flex-col gap-2 sm:flex-row md:w-auto">
                <label className="flex cursor-pointer items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2 text-[clamp(0.72rem,0.75vw,1rem)] font-bold text-slate-600 transition hover:bg-white">
                  <input
                    type="checkbox"
                    checked={autoRefresh}
                    onChange={(event) => setAutoRefresh(event.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  Auto-refresh 30s
                </label>
                <button
                  type="button"
                  onClick={() => fetchDashboard({ silent: true })}
                  disabled={refreshing}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-2 text-[clamp(0.8rem,0.8vw,1.12rem)] font-black text-slate-700 shadow-sm transition hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <span className={refreshing ? 'animate-spin' : ''}>
                    <Icon name="refresh" className="h-4 w-4" />
                  </span>
                  {refreshing ? 'Memuat...' : 'Refresh'}
                </button>
              </div>
            </section>

            {/* Error Message */}
            {error && (
              <div className="mb-3 flex items-start justify-between gap-4 rounded-3xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 shadow-sm sm:p-5">
                <div>
                  <p className="font-black">Data gagal dimuat</p>
                  <p className="mt-1">{error}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setError('')}
                  className="rounded-xl p-1.5 hover:bg-rose-100 transition"
                  aria-label="Tutup pesan error"
                >
                  <Icon name="close" className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* Summary Cards */}
            <section className="grid gap-3 sm:gap-4 sm:grid-cols-2 xl:grid-cols-5">
              <SummaryCard
                title="OTICS Power"
                value={formatMetric(summary.source.otics_power, 'kW')}
                subtitle="Output daya Plant 1"
                icon="bolt"
                accent="emerald"
              />
              <SummaryCard
                title="Huawei PV Output"
                value={formatMetric(summary.source.huawei_pv_output_kw, 'kW')}
                subtitle="Output daya Plant 2"
                icon="activity"
                accent="blue"
              />
              <SummaryCard
                title="Total Inverter OTICS"
                value={formatMetric(summary.inverterTotal, 'kW')}
                subtitle={`Inv-1 ${formatNumber(summary.source.otics_phase_1_inv1)} · Inv-2 ${formatNumber(summary.source.otics_phase_1_inv2)}`}
                icon="database"
                accent="violet"
              />
              <SummaryCard
                title="Irradiance Huawei"
                value={formatMetric(summary.source.huawei_irradiance_wm2, 'W/m²')}
                subtitle={`OTICS ${formatMetric(summary.source.otics_irradiation, 'W/m²')}`}
                icon="sun"
                accent="amber"
              />
              <SummaryCard
                title="CO₂ Avoided"
                value={formatMetric(summary.source.huawei_co2_avoided, '')}
                subtitle={`OTICS reduced ${formatNumber(summary.source.otics_co2_reduced)}`}
                icon="cloud"
                accent="emerald"
              />
            </section>

            {/* Charts — Card Kondisi Terbaru telah dihapus, chart sekarang full width */}
            <div className="grid gap-4 sm:gap-5 lg:grid-cols-2">
              <BarChart
                data={chartRows}
                field="otics_power"
                title="Tren Daya OTICS"
                unit="kW"
              />
              <BarChart
                data={chartRows}
                field="huawei_pv_output_kw"
                title="Tren PV Output Huawei"
                unit="kW"
              />
            </div>

            {/* Tabel Riwayat */}
            <section className="rounded-3xl border border-slate-200 bg-white shadow-md shadow-slate-200/70">
              <div className="border-b border-slate-200 p-5">
                <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
                  <div>
                    <p className="text-[clamp(0.75rem,0.82vw,1.15rem)] font-black uppercase tracking-[0.18em] text-emerald-600">
                      Riwayat Monitoring
                    </p>
                    <h2 className="mt-1 text-[clamp(1.1rem,1.5vw,2.25rem)] font-black leading-tight text-slate-950">
                      Data Historis PLTS
                    </h2>
                    <p className="mt-1 text-sm text-slate-500">
                      Total {formatNumber(pagination.total)} record pada database.
                    </p>
                  </div>

                  <form
                    onSubmit={handleApplyFilters}
                    className="grid w-full gap-3 sm:grid-cols-2 xl:w-auto xl:grid-cols-[150px_150px_140px_100px_auto]"
                  >
                    <label className="block">
                      <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">
                        Tanggal mulai
                      </span>
                      <input
                        type="date"
                        value={filters.startDate}
                        onChange={(event) =>
                          setFilters((current) => ({
                            ...current,
                            startDate: event.target.value,
                          }))
                        }
                        className="h-10 w-full rounded-2xl border border-slate-300 bg-white px-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                      />
                    </label>

                    <label className="block">
                      <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">
                        Tanggal akhir
                      </span>
                      <input
                        type="date"
                        value={filters.endDate}
                        onChange={(event) =>
                          setFilters((current) => ({
                            ...current,
                            endDate: event.target.value,
                          }))
                        }
                        className="h-10 w-full rounded-2xl border border-slate-300 bg-white px-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                      />
                    </label>

                    <label className="block">
                      <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">
                        Status OTICS
                      </span>
                      <select
                        value={filters.status}
                        onChange={(event) =>
                          setFilters((current) => ({
                            ...current,
                            status: event.target.value,
                          }))
                        }
                        className="h-10 w-full rounded-2xl border border-slate-300 bg-white px-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                      >
                        <option value="">Semua status</option>
                        <option value="Healthy">Healthy</option>
                        <option value="Warning">Warning</option>
                        <option value="Error">Error</option>
                        <option value="Offline">Offline</option>
                      </select>
                    </label>

                    <label className="block">
                      <span className="mb-1 block text-xs font-bold uppercase tracking-wide text-slate-500">
                        Baris
                      </span>
                      <select
                        value={filters.limit}
                        onChange={(event) =>
                          setFilters((current) => ({
                            ...current,
                            limit: Number(event.target.value),
                          }))
                        }
                        className="h-10 w-full rounded-2xl border border-slate-300 bg-white px-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                      >
                        {[10, 20, 50, 100].map((size) => (
                          <option key={size} value={size}>
                            {size}
                          </option>
                        ))}
                      </select>
                    </label>

                    <div className="flex items-end gap-2 sm:col-span-2 xl:col-span-1">
                      <button
                        type="submit"
                        className="h-10 flex-1 rounded-2xl bg-slate-950 px-4 text-sm font-black text-white transition hover:bg-slate-800"
                      >
                        Terapkan
                      </button>
                      <button
                        type="button"
                        onClick={handleResetFilters}
                        className="h-10 rounded-2xl border border-slate-300 px-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50"
                      >
                        Reset
                      </button>
                    </div>
                  </form>
                </div>

                <div className="mt-4 flex justify-end">
                  <button
                    type="button"
                    onClick={exportCsv}
                    disabled={!rows.length}
                    className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <Icon name="download" className="h-4 w-4" />
                    Ekspor halaman ke CSV
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-[1180px] w-full text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
                    <tr>
                      <th className="px-4 py-3 font-black">Waktu</th>
                      <th className="px-4 py-3 font-black">Status</th>
                      <th className="px-4 py-3 text-right font-black">
                        OTICS Power
                      </th>
                      <th className="px-4 py-3 text-right font-black">Inv 1</th>
                      <th className="px-4 py-3 text-right font-black">Inv 2</th>
                      <th className="px-4 py-3 text-right font-black">
                        Huawei PV
                      </th>
                      <th className="px-4 py-3 text-right font-black">Grid</th>
                      <th className="px-4 py-3 text-right font-black">
                        Irradiance
                      </th>
                      <th className="px-4 py-3 text-center font-black">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <LoadingRows />
                    ) : rows.length > 0 ? (
                      rows.map((row) => (
                        <tr
                          key={row.id}
                          className="border-b border-slate-100 transition hover:bg-emerald-50/30"
                        >
                          <td className="whitespace-nowrap px-4 py-3">
                            <p className="font-bold text-slate-800">
                              {formatDateTime(row.recorded_at)}
                            </p>
                            <p className="mt-0.5 text-xs text-slate-400">
                              ID #{row.id}
                            </p>
                          </td>
                          <td className="whitespace-nowrap px-4 py-3">
                            <StatusBadge status={row.otics_status} />
                          </td>
                          <td className="whitespace-nowrap px-4 py-3 text-right font-bold text-slate-800">
                            {formatMetric(row.otics_power, 'kW')}
                          </td>
                          <td className="whitespace-nowrap px-4 py-3 text-right text-slate-600">
                            {formatMetric(row.otics_phase_1_inv1, 'kW')}
                          </td>
                          <td className="whitespace-nowrap px-4 py-3 text-right text-slate-600">
                            {formatMetric(row.otics_phase_1_inv2, 'kW')}
                          </td>
                          <td className="whitespace-nowrap px-4 py-3 text-right font-bold text-emerald-700">
                            {formatMetric(row.huawei_pv_output_kw, 'kW')}
                          </td>
                          <td className="whitespace-nowrap px-4 py-3 text-right text-slate-600">
                            {formatMetric(row.huawei_mains_power_kw, 'kW')}
                          </td>
                          <td className="whitespace-nowrap px-4 py-3 text-right text-slate-600">
                            {formatMetric(row.huawei_irradiance_wm2, 'W/m²')}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button
                              type="button"
                              onClick={() => setSelectedRow(row)}
                              className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-emerald-700 transition hover:bg-emerald-100"
                            >
                              <Icon name="eye" className="h-4 w-4" />
                              Detail
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={9} className="px-4 py-16 text-center">
                          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400">
                            <Icon name="database" className="h-7 w-7" />
                          </div>
                          <p className="mt-4 font-black text-slate-700">
                            Data tidak ditemukan
                          </p>
                          <p className="mt-1 text-sm text-slate-400">
                            Ubah filter atau periksa koneksi ke backend.
                          </p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-col gap-3 border-t border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-sm font-semibold text-slate-500">
                  Halaman{' '}
                  <strong className="text-slate-800">{currentPage}</strong> dari{' '}
                  <strong className="text-slate-800">{totalPages}</strong>
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setPage((current) => Math.max(current - 1, 1))}
                    disabled={currentPage <= 1 || loading}
                    className="inline-flex h-10 items-center gap-1 rounded-2xl border border-slate-300 px-3 text-sm font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <Icon name="chevronLeft" className="h-4 w-4" />
                    Sebelumnya
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setPage((current) => Math.min(current + 1, totalPages))
                    }
                    disabled={currentPage >= totalPages || loading}
                    className="inline-flex h-10 items-center gap-1 rounded-2xl border border-slate-300 px-3 text-sm font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Berikutnya
                    <Icon name="chevronRight" className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </section>
          </main>

          <DetailModal row={selectedRow} onClose={() => setSelectedRow(null)} />
        </div>
      </div>
    </Layout>
  );
}