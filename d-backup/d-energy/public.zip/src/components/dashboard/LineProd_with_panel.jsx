import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import * as XLSX from "xlsx";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import Layout from "../layout/Layout";

const API_BASE_URL = import.meta.env.VITE_API_URL || "";
const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92;
const PAGE_SIZE = 10;

const PG_COLOR_MAP = {
  "PG1.1": "#0ea5e9",
  "PG2.1": "#14b8a6",
  "PG2.2": "#f59e0b",
  "PG2.3": "#f97316",
  Facility: "#8b5cf6",
  Unknown: "#94a3b8",
};

const SERIES_COLORS = [
  "#0ea5e9",
  "#14b8a6",
  "#6366f1",
  "#22c55e",
  "#f59e0b",
  "#ef4444",
  "#8b5cf6",
  "#06b6d4",
  "#84cc16",
  "#f97316",
  "#ec4899",
  "#64748b",
  "#0891b2",
  "#16a34a",
  "#7c3aed",
  "#ea580c",
  "#475569",
  "#dc2626",
];

const PERIOD_OPTIONS = [
  { value: "daily", label: "Daily" },
  { value: "shiftly", label: "Shiftly" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
];

const PM_OPTIONS = [
  { value: "ALL", label: "Semua Tipe PM" },
  { value: "PM 200", label: "PM 200" },
  { value: "PM 220", label: "PM 220" },
  { value: "PANEL COMPRESSOR", label: "Panel Compressor" },
];

const DATE_MODE_OPTIONS = [
  { value: "range", label: "Mode Range" },
  { value: "month", label: "Mode Bulan" },
];

const MONTH_OPTIONS = [
  { value: 1, label: "Januari" },
  { value: 2, label: "Februari" },
  { value: 3, label: "Maret" },
  { value: 4, label: "April" },
  { value: 5, label: "Mei" },
  { value: 6, label: "Juni" },
  { value: 7, label: "Juli" },
  { value: 8, label: "Agustus" },
  { value: 9, label: "September" },
  { value: 10, label: "Oktober" },
  { value: 11, label: "November" },
  { value: 12, label: "Desember" },
];

const WEEK_OPTIONS = Array.from({ length: 53 }, (_, index) => ({
  value: index + 1,
  label: `Week ${index + 1}`,
}));

const LINE_OPTIONS = {
  PM200: [
    { label: "BS1", source: "tb_pm200_bs1" },
    { label: "BS2", source: "tb_pm200_bs2" },
    { label: "CC1", source: "tb_pm200_cc1" },
    { label: "CC234", source: "tb_pm200_cc234" },
    { label: "CHAB", source: "tb_pm200_chab" },
    { label: "CHCD", source: "tb_pm200_chcd" },
    { label: "CHEF", source: "tb_pm200_chef" },
    { label: "CHSAA", source: "tb_pm200_chsaa" },
    { label: "CHSAC", source: "tb_pm200_chsac" },
    { label: "CHSAB", source: "tb_pm200_chsab" },
    { label: "CONN", source: "tb_pm200_conn" },
    { label: "CR1", source: "tb_pm200_cr1" },
    { label: "CR2", source: "tb_pm200_cr2" },
    { label: "CR3", source: "tb_pm200_cr3" },
    { label: "CR4", source: "tb_pm200_cr4" },
    { label: "CR5", source: "tb_pm200_cr5" },
    { label: "CR6", source: "tb_pm200_cr6" },
    { label: "CR7", source: "tb_pm200_cr7" },
    { label: "CR8", source: "tb_pm200_cr8" },
    { label: "CR9", source: "tb_pm200_cr9" },
    { label: "CR10", source: "tb_pm200_cr10" },
    { label: "CR11", source: "tb_pm200_cr11" },
    { label: "CR12", source: "tb_pm200_cr12" },
    { label: "CT", source: "tb_pm200_ct" },
    { label: "HLA", source: "tb_pm200_hla" },
    { label: "RA", source: "tb_pm200_ra" },
    { label: "RET", source: "tb_pm200_ret" },
  ],
  PM220: [
    { label: "BS1", source: "tb_pm220_bs1" },
    { label: "BS2", source: "tb_pm220_bs2" },
    { label: "CC1", source: "tb_pm220_cc1" },
    { label: "CC234", source: "tb_pm220_cc234" },
    { label: "CHAB", source: "tb_pm220_chab" },
    { label: "CHCD", source: "tb_pm220_chcd" },
    { label: "CHEF", source: "tb_pm220_chef" },
    { label: "CHSAA", source: "tb_pm220_chsaa" },
    { label: "CHSAC", source: "tb_pm220_chsac" },
    { label: "CHSAB", source: "tb_pm220_chsab" },
    { label: "CONN", source: "tb_pm220_conn" },
    { label: "CR1", source: "tb_pm220_cr1" },
    { label: "CR2", source: "tb_pm220_cr2" },
    { label: "CR3", source: "tb_pm220_cr3" },
    { label: "CR4", source: "tb_pm220_cr4" },
    { label: "CR5", source: "tb_pm220_cr5" },
    { label: "CR6", source: "tb_pm220_cr6" },
    { label: "CR7", source: "tb_pm220_cr7" },
    { label: "CR8", source: "tb_pm220_cr8" },
    { label: "CR9", source: "tb_pm220_cr9" },
    { label: "CR10", source: "tb_pm220_cr10" },
    { label: "CR11", source: "tb_pm220_cr11" },
    { label: "CR12", source: "tb_pm220_cr12" },
    { label: "CT", source: "tb_pm220_ct" },
    { label: "HLA", source: "tb_pm220_hla" },
    { label: "RA", source: "tb_pm220_ra" },
    { label: "RET", source: "tb_pm220_ret" },
  ],
};

const PANEL_OPTIONS = [
  { label: "PANEL 19", source: "panel19", lineTable: "tb_panel_19_energy_vah_wh", pg: "Facility", pmType: "PANEL COMPRESSOR" },
  { label: "PANEL 20", source: "panel20", lineTable: "tb_panel_20_energy_vah_wh", pg: "Facility", pmType: "PANEL COMPRESSOR" },
  { label: "PANEL 21", source: "panel21", lineTable: "tb_panel_21_energy_vah_wh", pg: "Facility", pmType: "PANEL COMPRESSOR" },
  { label: "PANEL 24", source: "panel24", lineTable: "tb_panel_24_energy_vah_wh", pg: "Facility", pmType: "PANEL COMPRESSOR" },
];

const PANEL_PERIOD_MAP = {
  shiftly: ["panel24"],
  daily: ["panel21"],
  weekly: ["panel19"],
  monthly: ["panel20"],
};

const tableNameMapping = {
  tb_pm200_bs1: ["BALANCE SHAFT 1", "PG1.1"],
  tb_pm200_bs2: ["BALANCE SHAFT 2", "PG1.1"],
  tb_pm200_ret: ["RETAINER", "PG1.1"],
  tb_pm200_conn: ["CONNECTOR", "PG1.1"],
  tb_pm200_ra: ["ROLLER ARM", "PG1.1"],
  tb_pm200_hla: ["HLA", "PG1.1"],

  tb_pm200_cr4: ["COMMON RAIL 4", "PG2.1"],
  tb_pm200_cr6: ["COMMON RAIL 6", "PG2.1"],
  tb_pm200_cr9: ["COMMON RAIL 9", "PG2.1"],
  tb_pm200_cr10: ["COMMON RAIL 10", "PG2.1"],
  tb_pm200_cr11: ["COMMON RAIL 11", "PG2.1"],
  tb_pm200_cr12: ["COMMON RAIL 12", "PG2.1"],

  tb_pm200_cr1: ["COMMON RAIL 1", "PG2.2"],
  tb_pm200_cr2: ["COMMON RAIL 2", "PG2.2"],
  tb_pm200_cr3: ["COMMON RAIL 3", "PG2.2"],
  tb_pm200_cr5: ["COMMON RAIL 5", "PG2.2"],
  tb_pm200_cr7: ["COMMON RAIL 7", "PG2.2"],
  tb_pm200_cr8: ["COMMON RAIL 8", "PG2.2"],

  tb_pm200_cc1: ["CAM CAP 1", "PG2.3"],
  tb_pm200_cc234: ["CAM CAP 234", "PG2.3"],
  tb_pm200_chab: ["CAM HOUSING AB", "PG2.3"],
  tb_pm200_chcd: ["CAM HOUSING CD", "PG2.3"],
  tb_pm200_chef: ["CAM HOUSING EF", "PG2.3"],
  tb_pm200_chsaa: ["CAM HOUSING ASSY A", "PG2.3"],
  tb_pm200_chsab: ["CAM HOUSING ASSY B", "PG2.3"],
  tb_pm200_chsac: ["CAM HOUSING ASSY C", "PG2.3"],
  tb_pm200_ct: ["CT", "PG2.3"],

  tb_pm220_bs1: ["BALANCE SHAFT 1", "PG1.1"],
  tb_pm220_bs2: ["BALANCE SHAFT 2", "PG1.1"],
  tb_pm220_ret: ["RETAINER", "PG1.1"],
  tb_pm220_conn: ["CONNECTOR", "PG1.1"],
  tb_pm220_ra: ["ROLLER ARM", "PG1.1"],
  tb_pm220_hla: ["HLA", "PG1.1"],

  tb_pm220_cr4: ["COMMON RAIL 4", "PG2.1"],
  tb_pm220_cr6: ["COMMON RAIL 6", "PG2.1"],
  tb_pm220_cr9: ["COMMON RAIL 9", "PG2.1"],
  tb_pm220_cr10: ["COMMON RAIL 10", "PG2.1"],
  tb_pm220_cr11: ["COMMON RAIL 11", "PG2.1"],
  tb_pm220_cr12: ["COMMON RAIL 12", "PG2.1"],

  tb_pm220_cr1: ["COMMON RAIL 1", "PG2.2"],
  tb_pm220_cr2: ["COMMON RAIL 2", "PG2.2"],
  tb_pm220_cr3: ["COMMON RAIL 3", "PG2.2"],
  tb_pm220_cr5: ["COMMON RAIL 5", "PG2.2"],
  tb_pm220_cr7: ["COMMON RAIL 7", "PG2.2"],
  tb_pm220_cr8: ["COMMON RAIL 8", "PG2.2"],

  tb_pm220_cc1: ["CAM CAP 1", "PG2.3"],
  tb_pm220_cc234: ["CAM CAP 234", "PG2.3"],
  tb_pm220_chab: ["CAM HOUSING AB", "PG2.3"],
  tb_pm220_chcd: ["CAM HOUSING CD", "PG2.3"],
  tb_pm220_chef: ["CAM HOUSING EF", "PG2.3"],
  tb_pm220_chsaa: ["CAM HOUSING ASSY A", "PG2.3"],
  tb_pm220_chsab: ["CAM HOUSING ASSY B", "PG2.3"],
  tb_pm220_chsac: ["CAM HOUSING ASSY C", "PG2.3"],
};

tableNameMapping.tb_panel_19_energy_vah_wh = ["PANEL 19", "Facility"];
tableNameMapping.tb_panel_20_energy_vah_wh = ["PANEL 20", "Facility"];
tableNameMapping.tb_panel_21_energy_vah_wh = ["PANEL 21", "Facility"];
tableNameMapping.tb_panel_24_energy_vah_wh = ["PANEL 24", "Facility"];

function getISOWeek(date = new Date()) {
  const tempDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = tempDate.getUTCDay() || 7;
  tempDate.setUTCDate(tempDate.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(tempDate.getUTCFullYear(), 0, 1));
  return Math.ceil((((tempDate - yearStart) / 86400000) + 1) / 7);
}

function normalizePmType(pmType) {
  const value = String(pmType || "").trim().toUpperCase();
  if (value === "PM200" || value === "PM 200") return "PM 200";
  if (value === "PM220" || value === "PM 220") return "PM 220";
  if (value.includes("PANEL")) return "PANEL COMPRESSOR";
  return pmType || "Unknown";
}

function normalizeLineTable(lineTable) {
  if (!lineTable) return "";
  return String(lineTable).replace(/_(daily|shiftly|weekly|monthly)$/i, "");
}

function extractPanelNumber(value) {
  const raw = normalizeLineTable(value);
  if (!raw) return null;

  const panelTableMatch = raw.match(/tb_panel_(\d+)_energy_vah_wh/i);
  if (panelTableMatch) return panelTableMatch[1];

  const panelKeyMatch = raw.match(/panel\s*_?(\d+)/i);
  if (panelKeyMatch) return panelKeyMatch[1];

  return null;
}

function getPGByLineTable(lineTable) {
  const normalized = normalizeLineTable(lineTable);
  const panelNumber = extractPanelNumber(normalized);
  if (panelNumber) return "Facility";
  return tableNameMapping[normalized]?.[1] || "Unknown";
}

function getLineDisplayName(lineTable, fallback = "-") {
  const normalized = normalizeLineTable(lineTable);
  const panelNumber = extractPanelNumber(normalized);
  if (panelNumber) return `PANEL ${panelNumber}`;
  return tableNameMapping[normalized]?.[0] || fallback;
}

function whToKwh(value) {
  return Number(value || 0) / 1000;
}

function formatNumber(value, digits = 2) {
  return Number(value || 0).toLocaleString("id-ID", {
    minimumFractionDigits: 0,
    maximumFractionDigits: digits,
  });
}

function formatCurrency(value) {
  return `Rp ${Math.round(Number(value || 0)).toLocaleString("id-ID")}`;
}

function formatDate(value) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString("id-ID");
}

function formatDateTime(value) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString("id-ID");
}

function getMonthName(monthNumber) {
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  return months[Number(monthNumber) - 1] || "";
}

function safeDateLabel(dateString) {
  if (!dateString) return "-";
  const d = new Date(dateString);
  if (Number.isNaN(d.getTime())) return String(dateString);
  return d.toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
  });
}

function getRangeFromMonth(year, month) {
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 0);
  return {
    start: start.toISOString().slice(0, 10),
    end: end.toISOString().slice(0, 10),
  };
}

function isPanelAssetAvailableForPeriod(source, period) {
  return (PANEL_PERIOD_MAP[period] || []).includes(source);
}

function isAssetAvailableForPeriod(asset, period) {
  if (!asset) return false;
  if (asset.kind !== "panel") return true;
  return isPanelAssetAvailableForPeriod(asset.source, period);
}

function getMonthPairsBetween(startDate, endDate) {
  if (!startDate || !endDate) return [];
  const start = new Date(startDate);
  const end = new Date(endDate);
  const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
  const limit = new Date(end.getFullYear(), end.getMonth(), 1);
  const pairs = [];

  while (cursor <= limit) {
    pairs.push({ year: cursor.getFullYear(), month: cursor.getMonth() + 1 });
    cursor.setMonth(cursor.getMonth() + 1);
  }

  return pairs;
}

function getRowDateValue(row) {
  return (
    row.shift_date ||
    row.date ||
    row.daily_date ||
    row.week_start_date ||
    row.month_start_date ||
    row.created_at ||
    null
  );
}

function isDateWithinRange(dateValue, startDate, endDate) {
  if (!dateValue) return false;
  const value = new Date(dateValue);
  const start = new Date(startDate);
  const end = new Date(endDate);
  if ([value, start, end].some((item) => Number.isNaN(item.getTime()))) return false;

  value.setHours(0, 0, 0, 0);
  start.setHours(0, 0, 0, 0);
  end.setHours(0, 0, 0, 0);

  return value >= start && value <= end;
}

function buildAllAssets() {
  const lineAssets = Object.entries(LINE_OPTIONS).flatMap(([pmKey, items]) =>
    items.map((item) => {
      const normalizedPmType = pmKey === "PM200" ? "PM 200" : "PM 220";
      return {
        kind: "line",
        source: item.source,
        label: item.label,
        detailKey: item.label,
        detailLabel: item.label,
        pmType: normalizedPmType,
        pg: getPGByLineTable(item.source),
        lineTable: item.source,
      };
    })
  );

  const panelAssets = PANEL_OPTIONS.map((item) => ({
    ...item,
    kind: "panel",
    detailKey: item.source,
    detailLabel: item.label,
  }));

  return [...lineAssets, ...panelAssets];
}

function getSeriesKey(item, singleDetail) {
  const baseName = item.line_name || getLineDisplayName(item.normalized_line_table || item.line_table);
  if (singleDetail) return baseName;
  return item.kind === "panel" ? baseName : `${baseName} (${normalizePmType(item.pm_type)})`;
}

function ContextualPieChart({ title, slices, referenceLabel, referenceTotalKwh, usingReferenceTotal }) {
  const denominator = Number(referenceTotalKwh || 0);

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const item = payload[0].payload;
      return (
        <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-lg">
          <p className="font-semibold text-slate-800">{item.name || "Unknown"}</p>
          <p className="text-sm text-slate-600">Konsumsi: {formatNumber(item.value)} kWh</p>
          <p className="text-sm text-slate-600">
            Persentase: {formatNumber(item.percentage || 0, 2)}%
            {usingReferenceTotal ? ` dari ${referenceLabel || "Unknown"}` : ""}
          </p>
        </div>
      );
    }
    return null;
  };

  if (!slices.length) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <h3 className="mb-1 text-sm font-semibold text-slate-800">{title}</h3>
        <p className="mb-3 text-xs text-slate-500">
          {usingReferenceTotal
            ? `Acuan persentase: ${referenceLabel || "Unknown"}${denominator > 0 ? ` • ${formatNumber(denominator)} kWh` : ""}`
            : "Acuan persentase menggunakan total data aktif"}
        </p>
        <div className="flex h-[320px] items-center justify-center text-sm text-slate-500">
          Tidak ada data untuk ditampilkan
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-1 text-sm font-semibold text-slate-800">{title}</h3>
      <p className="mb-3 text-xs text-slate-500">
        {usingReferenceTotal
          ? `Acuan persentase: ${referenceLabel || "Unknown"}${denominator > 0 ? ` • ${formatNumber(denominator)} kWh` : ""}`
          : "Acuan persentase menggunakan total data aktif"}
      </p>
      <div className="h-[320px] min-w-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={slices}
              cx="50%"
              cy="47%"
              outerRadius={82}
              dataKey="value"
              nameKey="name"
              label={({ payload }) => `${payload.name}: ${formatNumber(payload.percentage || 0, 1)}%`}
              labelLine={false}
            >
              {slices.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} stroke="#fff" strokeWidth={2} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend
              verticalAlign="bottom"
              content={() => (
                <div className="mt-2 flex flex-wrap justify-center gap-2 text-xs">
                  {slices.map((entry, idx) => (
                    <div key={idx} className="flex items-center">
                      <div className="mr-1 h-3 w-3 rounded-full" style={{ backgroundColor: entry.color }} />
                      <span className="text-slate-600">{entry.name || "Unknown"} ({formatNumber(entry.percentage || 0, 1)}%)</span>
                    </div>
                  ))}
                </div>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default function LineProd() {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  const currentWeek = getISOWeek(now);
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
  const today = new Date().toISOString().slice(0, 10);

  const allAssets = useMemo(() => buildAllAssets(), []);

  const [period, setPeriod] = useState("daily");
  const [pmGroup, setPmGroup] = useState("ALL");
  const [selectedPg, setSelectedPg] = useState("ALL");
  const [selectedDetail, setSelectedDetail] = useState("ALL");

  const [dateMode, setDateMode] = useState("range");
  const [startDate, setStartDate] = useState(firstDay);
  const [endDate, setEndDate] = useState(today);
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedWeek, setSelectedWeek] = useState(currentWeek);

  const [rawRows, setRawRows] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [referenceRows, setReferenceRows] = useState([]);
  const [powerMeterOptions, setPowerMeterOptions] = useState([]);
  const [selectedPowerMeter, setSelectedPowerMeter] = useState("");
  const [warnings, setWarnings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFetching, setIsFetching] = useState(false);
  const [error, setError] = useState(null);

  const [tableSearch, setTableSearch] = useState("");
  const [tablePgFilter, setTablePgFilter] = useState("ALL");
  const [tablePmFilter, setTablePmFilter] = useState("ALL");
  const [sortBy, setSortBy] = useState("total_kwh");
  const [sortOrder, setSortOrder] = useState("desc");
  const [currentPage, setCurrentPage] = useState(1);

  const years = useMemo(() => {
    const arr = [];
    for (let y = 2024; y <= currentYear + 2; y += 1) arr.push(y);
    return arr;
  }, [currentYear]);

  const uniquePgOptions = useMemo(
    () => Array.from(new Set(allAssets.filter((item) => isAssetAvailableForPeriod(item, period)).map((item) => item.pg))).sort(),
    [allAssets, period]
  );

  const availableDetails = useMemo(() => {
    const filtered = allAssets.filter((item) => {
      const matchPeriod = isAssetAvailableForPeriod(item, period);
      const matchPg = selectedPg === "ALL" || item.pg === selectedPg;
      const matchPm = pmGroup === "ALL" || item.pmType === pmGroup;
      return matchPeriod && matchPg && matchPm;
    });

    const map = new Map();
    filtered.forEach((item) => {
      if (!map.has(item.detailKey)) {
        map.set(item.detailKey, { value: item.detailKey, label: item.detailLabel });
      }
    });

    return Array.from(map.values()).sort((a, b) => a.label.localeCompare(b.label));
  }, [allAssets, period, selectedPg, pmGroup]);

  useEffect(() => {
    const fetchPowerMeterOptions = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/kub/power-meters`);
        const options = response?.data?.data || [];
        setPowerMeterOptions(options);
        setSelectedPowerMeter((prev) => prev || options?.[0]?.power_meter || "");
      } catch (err) {
        console.error(err);
        setPowerMeterOptions([]);
        setSelectedPowerMeter((prev) => prev || "");
      }
    };

    fetchPowerMeterOptions();
  }, []);

  useEffect(() => {
    if (selectedDetail !== "ALL" && !availableDetails.some((item) => item.value === selectedDetail)) {
      setSelectedDetail("ALL");
    }
  }, [availableDetails, selectedDetail]);

  useEffect(() => {
    setCurrentPage(1);
  }, [tableSearch, tablePgFilter, tablePmFilter, sortBy, sortOrder, rawRows]);

  const getEffectiveRange = () => {
    if (dateMode === "month") {
      const range = getRangeFromMonth(selectedYear, selectedMonth);
      return { effectiveStartDate: range.start, effectiveEndDate: range.end };
    }

    return {
      effectiveStartDate: startDate,
      effectiveEndDate: endDate,
    };
  };

  const getTargetAssets = () =>
    allAssets.filter((item) => {
      const matchPeriod = isAssetAvailableForPeriod(item, period);
      const matchPg = selectedPg === "ALL" || item.pg === selectedPg;
      const matchPm = pmGroup === "ALL" || item.pmType === pmGroup;
      const matchDetail = selectedDetail === "ALL" || item.detailKey === selectedDetail;
      return matchPeriod && matchPg && matchPm && matchDetail;
    });

  const filterRowsByPeriod = (rows) => {
    const { effectiveStartDate, effectiveEndDate } = getEffectiveRange();

    return rows.filter((row) => {
      if (period === "daily" || period === "shiftly") {
        if (dateMode === "month") {
          return Number(row.year) === Number(selectedYear) && Number(row.month) === Number(selectedMonth);
        }
        return isDateWithinRange(getRowDateValue(row), effectiveStartDate, effectiveEndDate);
      }

      if (period === "weekly") {
        return Number(row.year) === Number(selectedYear) && Number(row.week) === Number(selectedWeek);
      }

      if (period === "monthly") {
        return Number(row.year) === Number(selectedYear) && Number(row.month) === Number(selectedMonth);
      }

      return true;
    });
  };

  const transformRow = (row, asset) => {
    const normalizedLineTable = normalizeLineTable(row.line_table || asset.lineTable || asset.source);
    const resolvedPmType = normalizePmType(row.pm_type || asset.pmType);
    const resolvedLineName = row.line_name || getLineDisplayName(normalizedLineTable, asset.label);

    return {
      ...row,
      kind: asset.kind,
      pm_type: resolvedPmType,
      line_name: resolvedLineName,
      line_table: row.line_table || asset.lineTable || asset.source,
      normalized_line_table: normalizedLineTable,
      asset_source: asset.source,
      asset_label: asset.label,
      detail_key: asset.detailKey,
      detail_label: asset.detailLabel,
      start_kwh: whToKwh(row.start_kwh),
      end_kwh: whToKwh(row.end_kwh),
      total_kwh: whToKwh(row.total_kwh),
      year: Number(row.year || selectedYear),
      month: Number(row.month || selectedMonth || 0),
      week: row.week != null ? Number(row.week) : undefined,
      month_name: row.month_name || getMonthName(row.month || selectedMonth),
    };
  };

  const fetchLineAsset = async (asset) => {
    const { effectiveStartDate, effectiveEndDate } = getEffectiveRange();
    const tableName = `${asset.source}_${period}`;
    const url =
      period === "daily" || period === "shiftly"
        ? `${API_BASE_URL}/api/reports/${period}/${tableName}/range?startDate=${effectiveStartDate}&endDate=${effectiveEndDate}`
        : `${API_BASE_URL}/api/reports/${period}/${tableName}/year/${selectedYear}`;

    const response = await axios.get(url);
    const rows = response?.data?.data || [];
    return filterRowsByPeriod(rows.map((row) => transformRow(row, asset)));
  };

  const fetchPanelAsset = async (asset) => {
    const baseUrl = `${API_BASE_URL}/api/compressor/${period}/${asset.source}`;
    let rows = [];

    if (period === "shiftly") {
      const response = await axios.get(baseUrl);
      rows = response?.data?.data || [];
    }

    if (period === "daily") {
      const monthPairs =
        dateMode === "month"
          ? [{ year: selectedYear, month: selectedMonth }]
          : getMonthPairsBetween(startDate, endDate);

      const settled = await Promise.allSettled(
        monthPairs.map((item) => axios.get(baseUrl, { params: { year: item.year, month: item.month } }))
      );

      rows = settled.flatMap((item) => (item.status === "fulfilled" ? item.value?.data?.data || [] : []));
    }

    if (period === "weekly") {
      const response = await axios.get(baseUrl, { params: { year: selectedYear, week: selectedWeek } });
      rows = response?.data?.data || [];
    }

    if (period === "monthly") {
      const response = await axios.get(baseUrl, { params: { year: selectedYear, month: selectedMonth } });
      rows = response?.data?.data || [];
    }

    return filterRowsByPeriod(rows.map((row) => transformRow(row, asset)));
  };

  const fetchReferencePowerMeter = async () => {
    if (!selectedPowerMeter) return [];

    const baseUrl = `${API_BASE_URL}/api/kub/${period}/${encodeURIComponent(selectedPowerMeter)}`;
    let rows = [];

    if (period === "shiftly") {
      const response = await axios.get(baseUrl);
      rows = response?.data?.data || [];
    }

    if (period === "daily") {
      const monthPairs =
        dateMode === "month"
          ? [{ year: selectedYear, month: selectedMonth }]
          : getMonthPairsBetween(startDate, endDate);

      const settled = await Promise.allSettled(
        monthPairs.map((item) => axios.get(baseUrl, { params: { year: item.year, month: item.month } }))
      );

      rows = settled.flatMap((item) => (item.status === "fulfilled" ? item.value?.data?.data || [] : []));
    }

    if (period === "weekly") {
      const response = await axios.get(baseUrl, { params: { year: selectedYear, week: selectedWeek } });
      rows = response?.data?.data || [];
    }

    if (period === "monthly") {
      const response = await axios.get(baseUrl, { params: { year: selectedYear, month: selectedMonth } });
      rows = response?.data?.data || [];
    }

    const transformed = rows.map((row) => ({
      ...row,
      kind: "reference",
      pm_type: row.pm_type || "POWER METER PUSAT",
      line_name: row.line_name || selectedPowerMeter || "Unknown",
      line_table: row.line_table || "tb_kub_total_kwh",
      normalized_line_table: normalizeLineTable(row.line_table || "tb_kub_total_kwh"),
      asset_source: selectedPowerMeter,
      asset_label: selectedPowerMeter,
      detail_key: selectedPowerMeter,
      detail_label: selectedPowerMeter,
      start_kwh: whToKwh(row.start_kwh),
      end_kwh: whToKwh(row.end_kwh),
      total_kwh: whToKwh(row.total_kwh),
      year: Number(row.year || selectedYear),
      month: Number(row.month || selectedMonth || 0),
      week: row.week != null ? Number(row.week) : undefined,
      month_name: row.month_name || getMonthName(row.month || selectedMonth),
    }));

    return filterRowsByPeriod(transformed);
  };

  const fetchAllData = async () => {
    const targets = getTargetAssets();
    if (!targets.length) return { rows: [], warnings: [] };

    const settled = await Promise.allSettled(
      targets.map(async (asset) => {
        const rows = asset.kind === "panel" ? await fetchPanelAsset(asset) : await fetchLineAsset(asset);
        return { asset, rows };
      })
    );

    const nextWarnings = [];
    const nextRows = [];

    settled.forEach((result, index) => {
      if (result.status === "fulfilled") {
        nextRows.push(...result.value.rows);
      } else {
        nextWarnings.push(`${targets[index]?.label || "Asset"}: ${result.reason?.message || "Unknown error"}`);
      }
    });

    return { rows: nextRows, warnings: nextWarnings };
  };

  const buildChartData = (rows) => {
    const singleDetail = selectedDetail !== "ALL";

    if (singleDetail) {
      if (period === "shiftly") {
        const grouped = {};
        rows.forEach((item) => {
          const key = item.shift_date;
          if (!grouped[key]) {
            grouped[key] = { date: safeDateLabel(item.shift_date), sortKey: item.shift_date, shift1: 0, shift2: 0 };
          }
          const value = Number(item.total_kwh || 0);
          if (item.shift === "shift_1") grouped[key].shift1 += value;
          if (item.shift === "shift_2") grouped[key].shift2 += value;
        });
        return Object.values(grouped).sort((a, b) => new Date(a.sortKey) - new Date(b.sortKey));
      }

      if (period === "daily") {
        return rows
          .map((item) => ({
            date: safeDateLabel(item.shift_date || getRowDateValue(item)),
            sortKey: item.shift_date || getRowDateValue(item),
            total: Number(item.total_kwh || 0),
          }))
          .sort((a, b) => new Date(a.sortKey) - new Date(b.sortKey));
      }

      if (period === "weekly") {
        return rows
          .map((item) => ({
            date: `W${item.week} ${item.year}`,
            sortKey: `${item.year}-${String(item.week).padStart(2, "0")}`,
            total: Number(item.total_kwh || 0),
          }))
          .sort((a, b) => a.sortKey.localeCompare(b.sortKey));
      }

      return rows
        .map((item) => ({
          date: `${item.month_name || getMonthName(item.month)} ${item.year}`,
          sortKey: `${item.year}-${String(item.month).padStart(2, "0")}`,
          total: Number(item.total_kwh || 0),
        }))
        .sort((a, b) => a.sortKey.localeCompare(b.sortKey));
    }

    const grouped = {};

    rows.forEach((item) => {
      let key = "";
      let label = "";

      if (period === "daily" || period === "shiftly") {
        key = item.shift_date || getRowDateValue(item);
        label = safeDateLabel(key);
      } else if (period === "weekly") {
        key = `${item.year}-${String(item.week).padStart(2, "0")}`;
        label = `W${item.week} ${item.year}`;
      } else {
        key = `${item.year}-${String(item.month).padStart(2, "0")}`;
        label = `${item.month_name || getMonthName(item.month)} ${item.year}`;
      }

      if (!grouped[key]) grouped[key] = { date: label, sortKey: key };
      grouped[key][getSeriesKey(item, false)] = Number(item.total_kwh || 0);
    });

    return Object.values(grouped).sort((a, b) => {
      if (period === "daily" || period === "shiftly") return new Date(a.sortKey) - new Date(b.sortKey);
      return a.sortKey.localeCompare(b.sortKey);
    });
  };

  const fetchData = async () => {
    try {
      setError(null);
      setIsFetching(true);
      const result = await fetchAllData();
      const nextWarnings = [...result.warnings];
      let nextReferenceRows = [];

      if (selectedPowerMeter) {
        try {
          nextReferenceRows = await fetchReferencePowerMeter();
        } catch (referenceError) {
          console.error(referenceError);
          nextWarnings.push(`Power Meter Pusat ${selectedPowerMeter || "Unknown"}: ${referenceError?.message || "Unknown error"}`);
        }
      }

      setWarnings(nextWarnings);
      setReferenceRows(nextReferenceRows);
      setRawRows(result.rows);
      setChartData(buildChartData(result.rows));
    } catch (err) {
      console.error(err);
      setError("Gagal memuat data dari server.");
      setWarnings([]);
      setReferenceRows([]);
      setRawRows([]);
      setChartData([]);
    } finally {
      setLoading(false);
      setIsFetching(false);
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period, pmGroup, selectedPg, selectedDetail, startDate, endDate, selectedYear, selectedMonth, selectedWeek, dateMode, selectedPowerMeter]);

  const tableRows = useMemo(() => {
    const filtered = rawRows.filter((item) => {
      const pg = getPGByLineTable(item.normalized_line_table || item.line_table);
      const pmType = normalizePmType(item.pm_type);
      const search = tableSearch.trim().toLowerCase();

      const matchesSearch =
        !search ||
        String(pmType || "").toLowerCase().includes(search) ||
        String(item.line_name || "").toLowerCase().includes(search) ||
        String(item.line_table || "").toLowerCase().includes(search) ||
        String(item.normalized_line_table || "").toLowerCase().includes(search) ||
        String(pg || "").toLowerCase().includes(search) ||
        String(item.month_name || "").toLowerCase().includes(search) ||
        String(item.year || "").toLowerCase().includes(search) ||
        String(item.shift || "").toLowerCase().includes(search);

      const matchesPg = tablePgFilter === "ALL" || pg === tablePgFilter;
      const matchesPm = tablePmFilter === "ALL" || pmType === tablePmFilter;

      return matchesSearch && matchesPg && matchesPm;
    });

    const sorted = [...filtered].sort((a, b) => {
      let aVal = a[sortBy];
      let bVal = b[sortBy];

      if (sortBy === "pg") {
        aVal = getPGByLineTable(a.normalized_line_table || a.line_table);
        bVal = getPGByLineTable(b.normalized_line_table || b.line_table);
      }

      if (["total_kwh", "start_kwh", "end_kwh", "year", "month", "week"].includes(sortBy)) {
        aVal = Number(aVal || 0);
        bVal = Number(bVal || 0);
        return sortOrder === "asc" ? aVal - bVal : bVal - aVal;
      }

      aVal = String(aVal || "").toLowerCase();
      bVal = String(bVal || "").toLowerCase();

      if (aVal < bVal) return sortOrder === "asc" ? -1 : 1;
      if (aVal > bVal) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });

    return sorted;
  }, [rawRows, tableSearch, tablePgFilter, tablePmFilter, sortBy, sortOrder]);

  const totalPages = Math.max(1, Math.ceil(tableRows.length / PAGE_SIZE));

  const paginatedRows = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return tableRows.slice(start, start + PAGE_SIZE);
  }, [tableRows, currentPage]);

  const exportToExcel = () => {
    if (!tableRows.length) return;

    const exportData = tableRows.map((item) => ({
      "PM Type": normalizePmType(item.pm_type),
      "Line Table": item.normalized_line_table || normalizeLineTable(item.line_table),
      "Line Name": item.line_name,
      "Production Group": getPGByLineTable(item.normalized_line_table || item.line_table),
      ...(period === "daily" || period === "shiftly"
        ? {
            Shift: item.shift,
            Date: item.shift_date,
            Start: item.shift_start_datetime,
            End: item.shift_end_datetime,
          }
        : {}),
      ...(period === "weekly"
        ? {
            Week: item.week,
            "Week Start Date": item.week_start_date,
            "Week End Date": item.week_end_date,
            "Week Start Datetime": item.week_start_datetime,
            "Week End Datetime": item.week_end_datetime,
          }
        : {}),
      ...(period === "monthly"
        ? {
            "Month Start Date": item.month_start_date,
            "Month End Date": item.month_end_date,
            "Month Start Datetime": item.month_start_datetime,
            "Month End Datetime": item.month_end_datetime,
          }
        : {}),
      Year: item.year,
      Month: item.month,
      "Month Name": item.month_name,
      "Start KWH": Number(item.start_kwh || 0),
      "End KWH": Number(item.end_kwh || 0),
      "Total KWH": Number(item.total_kwh || 0),
      "Persentase Pusat (%)": referenceTotalKwh > 0 ? Number((((Number(item.total_kwh || 0) / referenceTotalKwh) * 100)).toFixed(2)) : null,
      "Cost (IDR)": Math.round(Number(item.total_kwh || 0) * COST_PER_KWH),
      "CO2 (kg)": Math.round(Number(item.total_kwh || 0) * CO2_EMISSION_FACTOR),
    }));

    const totalKwh = tableRows.reduce((sum, item) => sum + Number(item.total_kwh || 0), 0);

    exportData.push(
      {},
      {
        "PM Type": "TOTAL",
        "Total KWH": Math.round(totalKwh * 100) / 100,
        "Persentase Pusat (%)": referenceTotalKwh > 0 ? Number((((totalKwh / referenceTotalKwh) * 100)).toFixed(2)) : null,
        "Cost (IDR)": Math.round(totalKwh * COST_PER_KWH),
        "CO2 (kg)": Math.round(totalKwh * CO2_EMISSION_FACTOR),
      }
    );

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Line Prod");
    XLSX.writeFile(wb, `line_prod_${period}_${selectedPg}_${selectedDetail}_${selectedYear}.xlsx`);
  };

  const totalKwh = useMemo(() => rawRows.reduce((sum, item) => sum + Number(item.total_kwh || 0), 0), [rawRows]);
  const totalShift1 = useMemo(() => rawRows.filter((item) => item.shift === "shift_1").reduce((sum, item) => sum + Number(item.total_kwh || 0), 0), [rawRows]);
  const totalShift2 = useMemo(() => rawRows.filter((item) => item.shift === "shift_2").reduce((sum, item) => sum + Number(item.total_kwh || 0), 0), [rawRows]);

  const periodCount = useMemo(() => {
    if (period === "daily" || period === "shiftly") {
      return new Set(rawRows.map((item) => item.shift_date)).size;
    }
    if (period === "weekly") {
      return new Set(rawRows.map((item) => `${item.year}-${item.week}`)).size;
    }
    return new Set(rawRows.map((item) => `${item.year}-${item.month}`)).size;
  }, [rawRows, period]);

  const avgKwh = periodCount ? totalKwh / periodCount : 0;
  const totalCost = Math.round(totalKwh * COST_PER_KWH);
  const totalCo2 = totalKwh * CO2_EMISSION_FACTOR;

  const peakValue = useMemo(() => {
    if (!chartData.length) return 0;
    if (selectedDetail !== "ALL") {
      if (period === "shiftly") return Math.max(...chartData.map((d) => Math.max(d.shift1 || 0, d.shift2 || 0)), 0);
      return Math.max(...chartData.map((d) => Number(d.total || 0)), 0);
    }
    return Math.max(
      ...chartData.map((row) =>
        Object.keys(row)
          .filter((k) => !["date", "sortKey"].includes(k))
          .reduce((sum, key) => sum + Number(row[key] || 0), 0)
      ),
      0
    );
  }, [chartData, selectedDetail, period]);

  const selectedDetailTitle =
    selectedDetail === "ALL"
      ? "Semua Line / Panel"
      : availableDetails.find((item) => item.value === selectedDetail)?.label || selectedDetail;

  const renderTooltipFormatter = (value, name) => {
    if (name === "shift1") return [`${formatNumber(value)} kWh`, "Shift 1"];
    if (name === "shift2") return [`${formatNumber(value)} kWh`, "Shift 2"];
    if (name === "total") return [`${formatNumber(value)} kWh`, "Total"];
    return [`${formatNumber(value)} kWh`, name];
  };

  const dynamicBarKeys = useMemo(() => {
    if (selectedDetail !== "ALL") return [];
    const keys = new Set();
    chartData.forEach((row) => {
      Object.keys(row).forEach((key) => {
        if (!["date", "sortKey"].includes(key)) keys.add(key);
      });
    });
    return Array.from(keys);
  }, [chartData, selectedDetail]);

  const uniquePmTypes = useMemo(
    () => Array.from(new Set(rawRows.map((x) => normalizePmType(x.pm_type)).filter(Boolean))).sort(),
    [rawRows]
  );
  const uniquePgs = useMemo(
    () => Array.from(new Set(rawRows.map((x) => getPGByLineTable(x.normalized_line_table || x.line_table)))).sort(),
    [rawRows]
  );

  const referenceTotalKwh = useMemo(
    () => referenceRows.reduce((sum, item) => sum + Number(item.total_kwh || 0), 0),
    [referenceRows]
  );

  const utilizationPercent = useMemo(() => {
    if (!(referenceTotalKwh > 0)) return null;
    return (totalKwh / referenceTotalKwh) * 100;
  }, [totalKwh, referenceTotalKwh]);

  const seriesColorMap = useMemo(() => {
    const map = {};
    dynamicBarKeys.forEach((key, idx) => {
      map[key] = SERIES_COLORS[idx % SERIES_COLORS.length];
    });
    return map;
  }, [dynamicBarKeys]);

  const pieChartConfig = useMemo(() => {
    const clampAndFinalize = (items, title) => {
      const normalizedItems = items
        .map((item, idx) => ({
          name: item.name || "Unknown",
          value: Number(item.value || 0),
          color: item.color || SERIES_COLORS[idx % SERIES_COLORS.length],
          locked: Boolean(item.locked),
        }))
        .filter((item) => item.value > 0);

      const knownTotal = normalizedItems.reduce((sum, item) => sum + item.value, 0);
      const denominator = referenceTotalKwh > 0 ? referenceTotalKwh : knownTotal;

      let finalItems = [...normalizedItems];
      if (referenceTotalKwh > knownTotal) {
        finalItems.push({
          name: "Unknown",
          value: referenceTotalKwh - knownTotal,
          color: PG_COLOR_MAP.Unknown,
          locked: true,
        });
      }

      if (finalItems.length > 8) {
        const locked = finalItems.filter((item) => item.locked);
        const unlocked = finalItems.filter((item) => !item.locked).sort((a, b) => b.value - a.value);
        const keepCount = Math.max(0, 7 - locked.length);
        const kept = unlocked.slice(0, keepCount);
        const remainder = unlocked.slice(keepCount).reduce((sum, item) => sum + item.value, 0);
        finalItems = [...kept, ...locked];
        if (remainder > 0) {
          const unknownIndex = finalItems.findIndex((item) => item.name === "Unknown");
          if (unknownIndex >= 0) {
            finalItems[unknownIndex] = {
              ...finalItems[unknownIndex],
              value: finalItems[unknownIndex].value + remainder,
            };
          } else {
            finalItems.push({ name: "Unknown", value: remainder, color: PG_COLOR_MAP.Unknown, locked: true });
          }
        }
      }

      finalItems = finalItems.map((item) => ({
        ...item,
        percentage: denominator > 0 ? (item.value / denominator) * 100 : 0,
      }));

      return {
        title,
        slices: finalItems,
        usingReferenceTotal: referenceTotalKwh > 0,
      };
    };

    if (selectedDetail !== "ALL") {
      if (period === "shiftly") {
        return clampAndFinalize(
          [
            { name: "Shift 1", value: totalShift1, color: "#06b6d4" },
            { name: "Shift 2", value: totalShift2, color: "#4f46e5" },
          ],
          `Distribusi ${selectedDetailTitle} vs Power Meter Pusat`
        );
      }

      return clampAndFinalize(
        chartData.map((item, idx) => ({
          name: item.date || "Unknown",
          value: Number(item.total || 0),
          color: SERIES_COLORS[idx % SERIES_COLORS.length],
        })),
        `Distribusi ${selectedDetailTitle} per Periode`
      );
    }

    if (selectedPg === "ALL" && pmGroup === "ALL") {
      const pgMap = {};
      rawRows.forEach((item) => {
        const pg = getPGByLineTable(item.normalized_line_table || item.line_table) || "Unknown";
        pgMap[pg] = (pgMap[pg] || 0) + Number(item.total_kwh || 0);
      });

      return clampAndFinalize(
        Object.entries(pgMap).map(([name, value]) => ({
          name,
          value,
          color: PG_COLOR_MAP[name] || PG_COLOR_MAP.Unknown,
        })),
        "Distribusi kWh per PG vs Power Meter Pusat"
      );
    }

    const detailMap = {};
    rawRows.forEach((item) => {
      const name = getSeriesKey(item, false) || "Unknown";
      detailMap[name] = (detailMap[name] || 0) + Number(item.total_kwh || 0);
    });

    return clampAndFinalize(
      Object.entries(detailMap).map(([name, value], idx) => ({
        name,
        value,
        color: seriesColorMap[name] || SERIES_COLORS[idx % SERIES_COLORS.length],
      })),
      "Distribusi kWh per Line / Panel vs Power Meter Pusat"
    );
  }, [
    chartData,
    period,
    pmGroup,
    rawRows,
    referenceTotalKwh,
    selectedDetail,
    selectedDetailTitle,
    selectedPg,
    seriesColorMap,
    totalShift1,
    totalShift2,
  ]);

  if (loading) {
    return (
      <Layout>
        <div className="p-4 text-sm text-slate-700">Memuat data...</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="w-full">
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex items-center gap-3">
                  <p>Filter</p>
                  {isFetching && (
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-slate-300 border-t-sky-500" />
                      <span>Memperbarui...</span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 md:grid-cols-3 xl:grid-cols-8">
                  <select value={period} onChange={(e) => setPeriod(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                    {PERIOD_OPTIONS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
                  </select>

                  <select value={selectedPg} onChange={(e) => setSelectedPg(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                    <option value="ALL">PT Otics (Total All)</option>
                    {uniquePgOptions.map((pg) => <option key={pg} value={pg}>{pg}</option>)}
                  </select>

                  <select value={selectedPowerMeter} onChange={(e) => setSelectedPowerMeter(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                    <option value="">Power Meter Pusat: Unknown</option>
                    {powerMeterOptions.map((item) => (
                      <option key={item.power_meter} value={item.power_meter}>{item.power_meter}</option>
                    ))}
                  </select>

                  <select value={selectedDetail} onChange={(e) => setSelectedDetail(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                    <option value="ALL">Semua Line / Panel</option>
                    {availableDetails.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
                  </select>

                  <select value={pmGroup} onChange={(e) => setPmGroup(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                    {PM_OPTIONS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
                  </select>

                  {(period === "daily" || period === "shiftly") && (
                    <select value={dateMode} onChange={(e) => setDateMode(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                      {DATE_MODE_OPTIONS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
                    </select>
                  )}

                  {(period === "daily" || period === "shiftly") && dateMode === "range" && (
                    <>
                      <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm" />
                      <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm" />
                    </>
                  )}

                  {(period === "daily" || period === "shiftly") && dateMode === "month" && (
                    <>
                      <select value={selectedMonth} onChange={(e) => setSelectedMonth(Number(e.target.value))} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                        {MONTH_OPTIONS.map((month) => <option key={month.value} value={month.value}>{month.label}</option>)}
                      </select>
                      <select value={selectedYear} onChange={(e) => setSelectedYear(Number(e.target.value))} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                        {years.map((year) => <option key={year} value={year}>{year}</option>)}
                      </select>
                    </>
                  )}

                  {period === "weekly" && (
                    <>
                      <select value={selectedYear} onChange={(e) => setSelectedYear(Number(e.target.value))} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                        {years.map((year) => <option key={year} value={year}>{year}</option>)}
                      </select>
                      <select value={selectedWeek} onChange={(e) => setSelectedWeek(Number(e.target.value))} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                        {WEEK_OPTIONS.map((week) => <option key={week.value} value={week.value}>{week.label}</option>)}
                      </select>
                    </>
                  )}

                  {period === "monthly" && (
                    <>
                      <select value={selectedYear} onChange={(e) => setSelectedYear(Number(e.target.value))} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                        {years.map((year) => <option key={year} value={year}>{year}</option>)}
                      </select>
                      <select value={selectedMonth} onChange={(e) => setSelectedMonth(Number(e.target.value))} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                        {MONTH_OPTIONS.map((month) => <option key={month.value} value={month.value}>{month.label}</option>)}
                      </select>
                    </>
                  )}

                  <button onClick={exportToExcel} className="rounded-xl bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-700">
                    Export Excel
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-sm text-slate-600">
                <span>Menampilkan:</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">PT Otics</span>
                <span className="rounded-full bg-sky-100 px-3 py-1 font-semibold text-sky-700">{selectedPg === "ALL" ? "Total All" : selectedPg}</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">Acuan: {selectedPowerMeter || "Unknown"}</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">{selectedDetailTitle}</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">{period}</span>
                <span className="rounded-full bg-slate-100 px-3 py-1">{pmGroup === "ALL" ? "Semua Tipe PM" : pmGroup}</span>
                {(period === "daily" || period === "shiftly") && dateMode === "month" && (
                  <span className="rounded-full bg-slate-100 px-3 py-1">{MONTH_OPTIONS.find((m) => m.value === selectedMonth)?.label} {selectedYear}</span>
                )}
                {period === "weekly" && (
                  <span className="rounded-full bg-slate-100 px-3 py-1">Week {selectedWeek} {selectedYear}</span>
                )}
                {period === "monthly" && (
                  <span className="rounded-full bg-slate-100 px-3 py-1">{MONTH_OPTIONS.find((m) => m.value === selectedMonth)?.label} {selectedYear}</span>
                )}
              </div>
            </div>
          </div>

          {error && <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

          {warnings.length > 0 && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
              Sebagian endpoint tidak berhasil dimuat. Total warning: {warnings.length}.
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            <div className="xl:col-span-1">
              <ContextualPieChart title={pieChartConfig.title} slices={pieChartConfig.slices} referenceLabel={selectedPowerMeter || "Unknown"} referenceTotalKwh={referenceTotalKwh} usingReferenceTotal={pieChartConfig.usingReferenceTotal} />
            </div>

            <div className="xl:col-span-2 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-800">Grafik Konsumsi Energi (kWh)</h3>
                <span className="text-xs text-slate-500">API dalam Wh, dashboard ditampilkan dalam kWh</span>
              </div>

              <div className="h-[320px] min-w-0">
                <ResponsiveContainer>
                  <BarChart data={chartData} margin={{ top: 15, right: 15, left: 0, bottom: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis tickFormatter={(v) => formatNumber(v, 1)} />
                    <Tooltip formatter={renderTooltipFormatter} labelFormatter={(label) => `Periode: ${label}`} />
                    <Legend verticalAlign="top" wrapperStyle={{ fontSize: "12px" }} />

                    {selectedDetail !== "ALL" ? (
                      period === "shiftly" ? (
                        <>
                          <Bar dataKey="shift1" fill="#06b6d4" radius={[6, 6, 0, 0]} />
                          <Bar dataKey="shift2" fill="#4f46e5" radius={[6, 6, 0, 0]} />
                        </>
                      ) : (
                        <Bar dataKey="total" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                      )
                    ) : (
                      dynamicBarKeys.map((key, idx) => (
                        <Bar key={key} dataKey={key} stackId="a" fill={SERIES_COLORS[idx % SERIES_COLORS.length]} radius={[4, 4, 0, 0]} />
                      ))
                    )}
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 lg:grid-cols-6">
            {[
              { label: "Total Energy", value: `${formatNumber(totalKwh)} kWh`, icon: "⚡" },
              { label: "Acuan Pusat", value: referenceTotalKwh > 0 ? `${formatNumber(referenceTotalKwh)} kWh` : "Unknown", icon: "🏭" },
              { label: "Share vs Pusat", value: utilizationPercent != null ? `${formatNumber(utilizationPercent, 2)}%` : "Unknown", icon: "🧭" },
              { label: "Cost", value: formatCurrency(totalCost), icon: "💰" },
              { label: "Average", value: `${formatNumber(avgKwh)} kWh`, icon: "📈" },
              ...(period === "shiftly" && selectedDetail !== "ALL"
                ? [
                    { label: "Shift 1", value: `${formatNumber(totalShift1)} kWh`, icon: "🕒" },
                    { label: "Shift 2", value: `${formatNumber(totalShift2)} kWh`, icon: "🌙" },
                  ]
                : []),
              { label: "Peak", value: `${formatNumber(peakValue)} kWh`, icon: "⬆️" },
            ].map((stat, idx) => (
              <div key={idx} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                <div className="text-xs font-medium text-slate-500">{stat.label}</div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-lg">{stat.icon}</span>
                  <span className="text-lg font-bold text-slate-800">{stat.value}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <h3 className="text-sm font-semibold text-red-600">🔥 CO2 Emissions</h3>
              <div className="mt-3 grid grid-cols-1 gap-2 text-sm text-slate-700 md:grid-cols-3">
                <div>
                  <div className="text-xs text-slate-500">Total</div>
                  <div className="font-semibold">{formatNumber(totalCo2)} kg</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Average</div>
                  <div className="font-semibold">{formatNumber(totalCo2 / (periodCount || 1))} kg</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Estimasi Tahunan</div>
                  <div className="font-semibold">{formatNumber(totalCo2 * 12)} kg</div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <h3 className="text-sm font-semibold text-amber-600">💰 Cost Analysis</h3>
              <div className="mt-3 grid grid-cols-1 gap-2 text-sm text-slate-700 md:grid-cols-3">
                <div>
                  <div className="text-xs text-slate-500">Total</div>
                  <div className="font-semibold">{formatCurrency(totalCost)}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Average</div>
                  <div className="font-semibold">{periodCount ? formatCurrency(Math.round(totalCost / periodCount)) : "Rp 0"}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Tarif</div>
                  <div className="font-semibold">Rp {formatNumber(COST_PER_KWH, 2)}/kWh</div>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <h3 className="text-sm font-semibold text-slate-800">Tabel Data Energi</h3>
                <p className="text-xs text-slate-500">Gunakan filter, sort, dan pagination untuk mempermudah analisa.</p>
              </div>

              <div className="grid grid-cols-1 gap-2 md:grid-cols-5 lg:min-w-[1000px]">
                <input type="text" value={tableSearch} onChange={(e) => setTableSearch(e.target.value)} placeholder="Cari PM, line, table, PG, month, year..." className="rounded-xl border border-slate-300 px-3 py-2 text-sm" />

                <select value={tablePgFilter} onChange={(e) => setTablePgFilter(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                  <option value="ALL">Semua PG</option>
                  {uniquePgs.map((pg) => <option key={pg} value={pg}>{pg}</option>)}
                </select>

                <select value={tablePmFilter} onChange={(e) => setTablePmFilter(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                  <option value="ALL">Semua PM Type</option>
                  {uniquePmTypes.map((pm) => <option key={pm} value={pm}>{pm}</option>)}
                </select>

                <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                  <option value="total_kwh">Sort: Total kWh</option>
                  <option value="start_kwh">Sort: Start kWh</option>
                  <option value="end_kwh">Sort: End kWh</option>
                  <option value="line_name">Sort: Line</option>
                  <option value="pm_type">Sort: PM Type</option>
                  <option value="pg">Sort: PG</option>
                  <option value="year">Sort: Year</option>
                  <option value="month">Sort: Month</option>
                  <option value="week">Sort: Week</option>
                </select>

                <select value={sortOrder} onChange={(e) => setSortOrder(e.target.value)} className="rounded-xl border border-slate-300 px-3 py-2 text-sm">
                  <option value="desc">Order: Desc</option>
                  <option value="asc">Order: Asc</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="min-w-full text-sm">
                <thead className="sticky top-0 bg-slate-100">
                  <tr className="text-left text-slate-700">
                    <th className="px-3 py-3">No</th>
                    <th className="px-3 py-3">PM Type</th>
                    <th className="px-3 py-3">Line / Panel</th>
                    <th className="px-3 py-3">PG</th>
                    <th className="px-3 py-3">Line Table</th>

                    {(period === "daily" || period === "shiftly") && (
                      <>
                        <th className="px-3 py-3">Shift</th>
                        <th className="px-3 py-3">Date</th>
                        <th className="px-3 py-3">Start</th>
                        <th className="px-3 py-3">End</th>
                      </>
                    )}

                    {period === "weekly" && (
                      <>
                        <th className="px-3 py-3">Week</th>
                        <th className="px-3 py-3">Week Start</th>
                        <th className="px-3 py-3">Week End</th>
                      </>
                    )}

                    {period === "monthly" && (
                      <>
                        <th className="px-3 py-3">Month</th>
                        <th className="px-3 py-3">Month Start</th>
                        <th className="px-3 py-3">Month End</th>
                      </>
                    )}

                    <th className="px-3 py-3">Start kWh</th>
                    <th className="px-3 py-3">End kWh</th>
                    <th className="px-3 py-3">Total kWh</th>
                    <th className="px-3 py-3">% Pusat</th>
                    <th className="px-3 py-3">Cost</th>
                    <th className="px-3 py-3">CO2</th>
                  </tr>
                </thead>

                <tbody>
                  {paginatedRows.length === 0 ? (
                    <tr>
                      <td colSpan={20} className="px-4 py-8 text-center text-slate-500">Tidak ada data.</td>
                    </tr>
                  ) : (
                    paginatedRows.map((item, idx) => (
                      <tr key={`${item.line_name}-${idx}-${item.pm_type}-${item.shift_date || item.week || item.month}`} className="border-t border-slate-100 hover:bg-slate-50">
                        <td className="px-3 py-2.5">{(currentPage - 1) * PAGE_SIZE + idx + 1}</td>
                        <td className="px-3 py-2.5">
                          <span
                            className={`rounded-full px-2 py-1 text-xs font-medium ${
                              normalizePmType(item.pm_type) === "PM 200"
                                ? "bg-cyan-100 text-cyan-700"
                                : normalizePmType(item.pm_type) === "PM 220"
                                  ? "bg-indigo-100 text-indigo-700"
                                  : "bg-violet-100 text-violet-700"
                            }`}
                          >
                            {normalizePmType(item.pm_type)}
                          </span>
                        </td>
                        <td className="px-3 py-2.5">{item.line_name || getLineDisplayName(item.normalized_line_table)}</td>
                        <td className="px-3 py-2.5">
                          <span className="rounded-full px-2 py-1 text-xs font-medium text-white" style={{ backgroundColor: PG_COLOR_MAP[getPGByLineTable(item.normalized_line_table || item.line_table)] || "#999" }}>
                            {getPGByLineTable(item.normalized_line_table || item.line_table)}
                          </span>
                        </td>
                        <td className="px-3 py-2.5">{item.normalized_line_table || normalizeLineTable(item.line_table)}</td>

                        {(period === "daily" || period === "shiftly") && (
                          <>
                            <td className="px-3 py-2.5">{item.shift}</td>
                            <td className="px-3 py-2.5">{formatDate(item.shift_date || getRowDateValue(item))}</td>
                            <td className="px-3 py-2.5">{formatDateTime(item.shift_start_datetime)}</td>
                            <td className="px-3 py-2.5">{formatDateTime(item.shift_end_datetime)}</td>
                          </>
                        )}

                        {period === "weekly" && (
                          <>
                            <td className="px-3 py-2.5">{item.week}</td>
                            <td className="px-3 py-2.5">{formatDate(item.week_start_date)}</td>
                            <td className="px-3 py-2.5">{formatDate(item.week_end_date)}</td>
                          </>
                        )}

                        {period === "monthly" && (
                          <>
                            <td className="px-3 py-2.5">{`${item.month_name || getMonthName(item.month)} ${item.year}`}</td>
                            <td className="px-3 py-2.5">{formatDate(item.month_start_date)}</td>
                            <td className="px-3 py-2.5">{formatDate(item.month_end_date)}</td>
                          </>
                        )}

                        <td className="px-3 py-2.5">{formatNumber(item.start_kwh)}</td>
                        <td className="px-3 py-2.5">{formatNumber(item.end_kwh)}</td>
                        <td className="px-3 py-2.5 font-semibold text-sky-700">{formatNumber(item.total_kwh)}</td>
                        <td className="px-3 py-2.5">{referenceTotalKwh > 0 ? `${formatNumber((Number(item.total_kwh || 0) / referenceTotalKwh) * 100, 2)}%` : "Unknown"}</td>
                        <td className="px-3 py-2.5">{formatCurrency(item.total_kwh * COST_PER_KWH)}</td>
                        <td className="px-3 py-2.5">{formatNumber(item.total_kwh * CO2_EMISSION_FACTOR)} kg</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div className="text-sm text-slate-500">Menampilkan <span className="font-semibold">{paginatedRows.length}</span> dari <span className="font-semibold">{tableRows.length}</span> data</div>

              <div className="flex items-center gap-2">
                <button onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm disabled:cursor-not-allowed disabled:opacity-50">Prev</button>
                <span className="text-sm text-slate-600">Page {currentPage} / {totalPages}</span>
                <button onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm disabled:cursor-not-allowed disabled:opacity-50">Next</button>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm font-medium text-yellow-800">
            ⚠️ Line lama tetap dipertahankan. Persentase pie chart, tabel, dan ringkasan sekarang mengacu ke Power Meter Pusat; jika acuan tidak tersedia maka ditampilkan sebagai Unknown.
          </div>
        </div>
      </div>
    </Layout>
  );
}
