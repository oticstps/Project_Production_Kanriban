import React, { useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import Layout from "../layout/Layout";

const API_BASE_URL = "http://172.27.6.191:4000/api/plts-p2-hourly";

const ACCEPTED_EXTENSIONS = [
  ".xlsx",
  ".xls",
  ".csv",
  ".txt",
  ".tsv",
  ".xlsb",
  ".ods",
];

function ConverterExelP2Hourly() {
  const fileInputRef = useRef(null);

  const [selectedFile, setSelectedFile] = useState(null);
  const [workbookData, setWorkbookData] = useState(null);
  const [sheetNames, setSheetNames] = useState([]);
  const [selectedSheet, setSelectedSheet] = useState("");

  const [rawRows, setRawRows] = useState([]);
  const [jsonData, setJsonData] = useState([]);
  const [rawJsonText, setRawJsonText] = useState("");
  const [fileInfo, setFileInfo] = useState(null);

  const [parseMode, setParseMode] = useState("auto");
  const [parseInfo, setParseInfo] = useState(null);

  const [monitoringDate, setMonitoringDate] = useState("");
  const [monitoringRows, setMonitoringRows] = useState([]);

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isFetchingMonitoring, setIsFetchingMonitoring] = useState(false);

  const [error, setError] = useState("");
  const [importResult, setImportResult] = useState(null);

  const prettyJson = useMemo(() => {
    try {
      return JSON.stringify(jsonData, null, 2);
    } catch {
      return "[]";
    }
  }, [jsonData]);

  const pad2 = (value) => String(value).padStart(2, "0");

  const resetAll = () => {
    setSelectedFile(null);
    setWorkbookData(null);
    setSheetNames([]);
    setSelectedSheet("");
    setRawRows([]);
    setJsonData([]);
    setRawJsonText("");
    setFileInfo(null);
    setParseMode("auto");
    setParseInfo(null);
    setMonitoringRows([]);
    setMonitoringDate("");
    setError("");
    setImportResult(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const getExtension = (fileName = "") => {
    const lastDot = fileName.lastIndexOf(".");
    if (lastDot === -1) return "";
    return fileName.slice(lastDot).toLowerCase();
  };

  const isAcceptedFile = (file) => {
    const ext = getExtension(file?.name || "");
    return ACCEPTED_EXTENSIONS.includes(ext);
  };

  const normalizeObjectKey = (key) => {
    return String(key || "")
      .replace(/\uFEFF/g, "")
      .replace(/\u00A0/g, " ")
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "_")
      .replace(/[^\w]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
  };

  const normalizeHeaderKey = (key, index) => {
    const normalized = normalizeObjectKey(key);

    if (!normalized) {
      return `column_${index + 1}`;
    }

    return normalized;
  };

  const isRowEmpty = (row) => {
    if (!Array.isArray(row)) return true;

    return row.every((cell) => {
      return cell === undefined || cell === null || String(cell).trim() === "";
    });
  };

  const isHeaderCandidate = (row) => {
    if (!Array.isArray(row)) return false;

    const keys = row.map((cell) => normalizeObjectKey(cell));

    const hasDate = keys.some((key) =>
      ["date", "datetime", "energy_date", "tanggal", "waktu"].includes(key)
    );

    const hasPv = keys.some((key) => {
      return (
        key.includes("pv_output") ||
        key.includes("generated_by_pv") ||
        key === "pv"
      );
    });

    const hasMains = keys.some((key) => {
      return (
        key.includes("mains_power") ||
        key.includes("purchased_from_grid") ||
        key.includes("grid")
      );
    });

    const hasFeedIn = keys.some((key) => {
      return key.includes("feed_in_power") || key.includes("fed_to_grid");
    });

    const hasConsumed = keys.some((key) => {
      return key.includes("consumed_by_appliances") || key.includes("appliances");
    });

    return hasDate && (hasPv || hasMains || hasFeedIn || hasConsumed);
  };

  const findHeaderRowIndex = (rows) => {
    if (!Array.isArray(rows)) return -1;

    for (let i = 0; i < rows.length; i += 1) {
      if (isHeaderCandidate(rows[i])) {
        return i;
      }
    }

    return -1;
  };

  const convertRawRowsToObjects = (rows, mode = "auto") => {
    const cleanRows = Array.isArray(rows)
      ? rows.filter((row) => !isRowEmpty(row))
      : [];

    if (cleanRows.length === 0) {
      return {
        rows: [],
        info: {
          headerRowIndex: -1,
          totalRawRows: 0,
          totalDataRows: 0,
          headers: [],
          mode,
        },
      };
    }

    let headerRowIndex = -1;

    if (mode === "first-row") {
      headerRowIndex = 0;
    } else if (mode === "no-header") {
      headerRowIndex = -1;
    } else {
      headerRowIndex = findHeaderRowIndex(cleanRows);
    }

    let headers = [];
    let dataRows = [];

    if (headerRowIndex >= 0) {
      headers = cleanRows[headerRowIndex].map((cell, index) =>
        normalizeHeaderKey(cell, index)
      );

      dataRows = cleanRows.slice(headerRowIndex + 1);
    } else {
      headers = [
        "date",
        "pv_output_kw",
        "mains_power_kw",
        "feed_in_power_kw",
        "consumed_by_appliances_kw",
      ];

      dataRows = cleanRows;
    }

    const objectRows = dataRows
      .filter((row) => !isRowEmpty(row))
      .map((row) => {
        const obj = {};

        headers.forEach((header, index) => {
          obj[header] = row[index] ?? "";
        });

        return obj;
      });

    return {
      rows: objectRows,
      info: {
        headerRowIndex,
        totalRawRows: cleanRows.length,
        totalDataRows: objectRows.length,
        headers,
        mode,
      },
    };
  };

  const getValueByPossibleKeys = (row, possibleKeys) => {
    const normalizedRow = {};

    Object.keys(row || {}).forEach((key) => {
      normalizedRow[normalizeObjectKey(key)] = row[key];
    });

    for (const key of possibleKeys) {
      const normalizedKey = normalizeObjectKey(key);

      if (
        normalizedRow[normalizedKey] !== undefined &&
        normalizedRow[normalizedKey] !== null &&
        normalizedRow[normalizedKey] !== ""
      ) {
        return normalizedRow[normalizedKey];
      }
    }

    return "";
  };

  const formatDateObject = (date) => {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) return "";

    const year = date.getFullYear();
    const month = pad2(date.getMonth() + 1);
    const day = pad2(date.getDate());
    const hour = pad2(date.getHours());
    const minute = pad2(date.getMinutes());
    const second = pad2(date.getSeconds());

    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  };

  const excelSerialDateTimeToMysql = (serialValue) => {
    const serial = Number(serialValue);

    if (Number.isNaN(serial)) return "";

    const days = Math.floor(serial);
    const fraction = serial - days;
    const totalSeconds = Math.round(fraction * 24 * 60 * 60);

    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const date = new Date(excelEpoch.getTime() + days * 24 * 60 * 60 * 1000);

    const year = date.getUTCFullYear();
    const month = pad2(date.getUTCMonth() + 1);
    const day = pad2(date.getUTCDate());

    const hour = Math.floor(totalSeconds / 3600) % 24;
    const minute = Math.floor((totalSeconds % 3600) / 60);
    const second = totalSeconds % 60;

    return `${year}-${month}-${day} ${pad2(hour)}:${pad2(minute)}:${pad2(
      second
    )}`;
  };

  const normalizeDateTimeForBackend = (value) => {
    if (value === undefined || value === null || value === "") return "";

    if (value instanceof Date) {
      return formatDateObject(value);
    }

    if (typeof value === "number") {
      return excelSerialDateTimeToMysql(value);
    }

    let text = String(value)
      .replace(/\uFEFF/g, "")
      .replace(/\u00A0/g, " ")
      .replace(/\s+/g, " ")
      .replace(/"/g, "")
      .trim();

    if (!text) return "";

    if (/^\d+(\.\d+)?$/.test(text)) {
      return excelSerialDateTimeToMysql(text);
    }

    text = text.replace("T", " ");

    const ymdMatch = text.match(
      /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/
    );

    if (ymdMatch) {
      const year = ymdMatch[1];
      const month = pad2(ymdMatch[2]);
      const day = pad2(ymdMatch[3]);
      const hour = pad2(ymdMatch[4] || "0");
      const minute = pad2(ymdMatch[5] || "0");
      const second = pad2(ymdMatch[6] || "0");

      return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
    }

    const dmyOrMdyMatch = text.match(
      /^(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/
    );

    if (dmyOrMdyMatch) {
      let first = Number(dmyOrMdyMatch[1]);
      let second = Number(dmyOrMdyMatch[2]);
      let year = dmyOrMdyMatch[3];

      if (year.length === 2) {
        year = `20${year}`;
      }

      let day = first;
      let month = second;

      if (first <= 12 && second > 12) {
        month = first;
        day = second;
      }

      const hour = pad2(dmyOrMdyMatch[4] || "0");
      const minute = pad2(dmyOrMdyMatch[5] || "0");
      const secondValue = pad2(dmyOrMdyMatch[6] || "0");

      return `${year}-${pad2(month)}-${pad2(day)} ${hour}:${minute}:${secondValue}`;
    }

    const parsedDate = new Date(text);

    if (!Number.isNaN(parsedDate.getTime())) {
      return formatDateObject(parsedDate);
    }

    return "";
  };

  const isValidDateTimeValue = (value) => {
    return /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(
      String(value || "")
    );
  };

  const parseDecimalForPayload = (value) => {
    if (value === undefined || value === null || value === "") return null;

    const normalized = String(value)
      .replace(/\u00A0/g, " ")
      .replace(",", ".")
      .trim();

    if (!normalized || normalized === "-" || normalized === "–") return null;

    const numberValue = Number(normalized);

    if (Number.isNaN(numberValue)) return null;

    return numberValue;
  };

  const normalizeRowForBackend = (row) => {
    const rawDateTime = getValueByPossibleKeys(row, [
      "date",
      "datetime",
      "energy_date",
      "tanggal",
      "waktu",
      "time",
      "column_1",
    ]);

    const generatedByPv = getValueByPossibleKeys(row, [
      "pv_output_kw",
      "pv_output",
      "pv output",
      "pv output kw",
      "pv_output_kwh",
      "generated_by_pv_kwh",
      "generated by pv",
      "generated by pv kwh",
      "generated by pv kw",
      "column_2",
    ]);

    const purchasedFromGrid = getValueByPossibleKeys(row, [
      "mains_power_kw",
      "mains_power",
      "mains power",
      "mains power kw",
      "mains_power_kwh",
      "purchased_from_grid_kwh",
      "purchased from grid",
      "purchased from grid kwh",
      "purchased from grid kw",
      "column_3",
    ]);

    const fedToGrid = getValueByPossibleKeys(row, [
      "feed_in_power_kw",
      "feed_in_power",
      "feed in power",
      "feed-in power",
      "feed-in power kw",
      "feed_in_power_kwh",
      "fed_to_grid_kwh",
      "fed to grid",
      "fed to grid kwh",
      "fed to grid kw",
      "column_4",
    ]);

    const consumedByAppliances = getValueByPossibleKeys(row, [
      "consumed_by_appliances_kw",
      "consumed_by_appliances_kwh",
      "consumed_by_appliances",
      "consumed by appliances",
      "consumed by appliances kw",
      "consumed by appliances kwh",
      "appliances",
      "column_5",
    ]);

    return {
      energy_date: normalizeDateTimeForBackend(rawDateTime),
      purchased_from_grid_kwh: parseDecimalForPayload(purchasedFromGrid),
      generated_by_pv_kwh: parseDecimalForPayload(generatedByPv),
      fed_to_grid_kwh: parseDecimalForPayload(fedToGrid),
      consumed_by_appliances_kwh: parseDecimalForPayload(consumedByAppliances),
    };
  };

  const prepareDataForBackend = (debug = false) => {
    if (!Array.isArray(jsonData)) return [];

    const invalidRows = [];

    const payloadData = jsonData
      .filter((row) => row && typeof row === "object" && !Array.isArray(row))
      .map((row, index) => {
        const normalizedRow = normalizeRowForBackend(row);

        if (!isValidDateTimeValue(normalizedRow.energy_date)) {
          invalidRows.push({
            index,
            rawRow: row,
            parsedEnergyDate: normalizedRow.energy_date,
          });
        }

        return normalizedRow;
      })
      .filter((row) => isValidDateTimeValue(row.energy_date));

    if (debug) {
      console.log("RAW ROWS SAMPLE:", rawRows.slice(0, 5));
      console.log("JSON DATA SAMPLE:", jsonData.slice(0, 5));
      console.log("PARSE INFO:", parseInfo);
      console.log("PAYLOAD VALID SAMPLE:", payloadData.slice(0, 5));
      console.log("INVALID ROWS SAMPLE:", invalidRows.slice(0, 10));
    }

    return payloadData;
  };

  const readWorkbookSafely = async (file) => {
    const buffer = await file.arrayBuffer();

    const originalWarn = console.warn;
    const originalError = console.error;

    try {
      console.warn = (...args) => {
        const message = args.join(" ");
        if (message.includes("Bad uncompressed size")) return;
        originalWarn(...args);
      };

      console.error = (...args) => {
        const message = args.join(" ");
        if (message.includes("Bad uncompressed size")) return;
        originalError(...args);
      };

      return XLSX.read(buffer, {
        type: "array",
        raw: true,
        cellDates: true,
        cellText: true,
        codepage: 65001,
        WTF: false,
      });
    } finally {
      console.warn = originalWarn;
      console.error = originalError;
    }
  };

  const convertSheetToJson = (workbook, sheetName, mode = parseMode) => {
    const worksheet = workbook.Sheets[sheetName];

    if (!worksheet) {
      throw new Error(`Sheet "${sheetName}" tidak ditemukan.`);
    }

    const rows = XLSX.utils.sheet_to_json(worksheet, {
      header: 1,
      defval: "",
      raw: true,
      blankrows: false,
    });

    const converted = convertRawRowsToObjects(rows, mode);

    setRawRows(rows);
    setJsonData(converted.rows);
    setRawJsonText(JSON.stringify(converted.rows, null, 2));
    setParseInfo(converted.info);
    setImportResult(null);
    setError("");
  };

  const parseFile = async (file) => {
    if (!file) return;

    setIsLoading(true);
    setError("");
    setImportResult(null);

    try {
      if (!isAcceptedFile(file)) {
        throw new Error(
          "Format file tidak didukung. Gunakan file .xlsx, .xls, .csv, .txt, .tsv, .xlsb, atau .ods."
        );
      }

      const ext = getExtension(file.name);
      const workbook = await readWorkbookSafely(file);
      const names = workbook.SheetNames || [];

      if (names.length === 0) {
        throw new Error("File tidak memiliki sheet atau data yang bisa dibaca.");
      }

      setSelectedFile(file);
      setWorkbookData(workbook);
      setSheetNames(names);
      setSelectedSheet(names[0]);

      setFileInfo({
        name: file.name,
        size: file.size,
        type: file.type || ext || "unknown",
        lastModified: file.lastModified
          ? new Date(file.lastModified).toLocaleString("id-ID")
          : "-",
      });

      convertSheetToJson(workbook, names[0], parseMode);
    } catch (err) {
      console.error("Gagal membaca file:", err);
      setError(err.message || "Terjadi kesalahan saat membaca file.");
      setWorkbookData(null);
      setSheetNames([]);
      setSelectedSheet("");
      setRawRows([]);
      setJsonData([]);
      setRawJsonText("");
      setFileInfo(null);
      setParseInfo(null);
      setImportResult(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = async (event) => {
    const file = event.target.files?.[0];
    await parseFile(file);
  };

  const handleDrop = async (event) => {
    event.preventDefault();
    event.stopPropagation();

    const file = event.dataTransfer.files?.[0];
    await parseFile(file);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleSheetChange = (event) => {
    const newSheet = event.target.value;
    setSelectedSheet(newSheet);

    if (workbookData && newSheet) {
      try {
        convertSheetToJson(workbookData, newSheet, parseMode);
      } catch (err) {
        setError(err.message || "Gagal mengubah sheet.");
      }
    }
  };

  const handleParseModeChange = (event) => {
    const newMode = event.target.value;
    setParseMode(newMode);

    if (workbookData && selectedSheet) {
      try {
        convertSheetToJson(workbookData, selectedSheet, newMode);
      } catch (err) {
        setError(err.message || "Gagal mengubah mode baca header.");
      }
    }
  };

  const handleCopyJson = async () => {
    try {
      await navigator.clipboard.writeText(prettyJson);
      alert("JSON berhasil disalin ke clipboard.");
    } catch (err) {
      console.error("Copy gagal:", err);
      alert("Gagal menyalin JSON.");
    }
  };

  const handleDownloadJson = () => {
    try {
      const blob = new Blob([prettyJson], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");

      const baseName = selectedFile?.name
        ? selectedFile.name.replace(/\.[^/.]+$/, "")
        : "converted_data";

      a.href = url;
      a.download = `${baseName}_${selectedSheet || "sheet"}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Download gagal:", err);
      alert("Gagal download file JSON.");
    }
  };

  const handleSaveToDatabase = async () => {
    try {
      setIsSaving(true);
      setError("");
      setImportResult(null);

      if (!Array.isArray(jsonData) || jsonData.length === 0) {
        throw new Error("Tidak ada data JSON untuk disimpan.");
      }

      const payloadData = prepareDataForBackend(true);

      if (payloadData.length === 0) {
        throw new Error(
          "Tidak ada data valid. Sistem belum bisa membaca kolom Date. Coba ubah Mode Baca Header menjadi 'Tanpa Header / Kolom Tetap', lalu simpan ulang."
        );
      }

      const response = await fetch(`${API_BASE_URL}/bulk`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          data: payloadData,
        }),
      });

      const responseText = await response.text();

      let result = {};
      try {
        result = responseText ? JSON.parse(responseText) : {};
      } catch {
        throw new Error(responseText || "Response backend bukan JSON valid.");
      }

      if (!response.ok) {
        throw new Error(result.message || "Gagal menyimpan data ke database.");
      }

      setImportResult(result.result);

      const firstDate = payloadData[0]?.energy_date?.slice(0, 10);

      if (firstDate) {
        setMonitoringDate(firstDate);
        await fetchMonitoringByDate(firstDate);
      }

      alert(
        `Import selesai. Berhasil: ${result.result.successCount}, Gagal: ${result.result.failedCount}`
      );
    } catch (err) {
      console.error("Gagal simpan ke database:", err);
      setError(err.message || "Gagal simpan ke database.");
    } finally {
      setIsSaving(false);
    }
  };

  const fetchMonitoringByDate = async (targetDate = monitoringDate) => {
    try {
      setIsFetchingMonitoring(true);
      setError("");

      if (!targetDate) {
        throw new Error("Pilih tanggal monitoring terlebih dahulu.");
      }

      const response = await fetch(`${API_BASE_URL}?date=${targetDate}`);
      const responseText = await response.text();

      let result = {};
      try {
        result = responseText ? JSON.parse(responseText) : {};
      } catch {
        throw new Error(responseText || "Response backend bukan JSON valid.");
      }

      if (!response.ok) {
        throw new Error(result.message || "Gagal mengambil data monitoring.");
      }

      setMonitoringRows(Array.isArray(result.data) ? result.data : []);
    } catch (err) {
      console.error("Gagal mengambil monitoring:", err);
      setError(err.message || "Gagal mengambil data monitoring.");
      setMonitoringRows([]);
    } finally {
      setIsFetchingMonitoring(false);
    }
  };

  const renderRawPreview = () => {
    if (!Array.isArray(rawRows) || rawRows.length === 0) {
      return <div style={styles.emptyBox}>Belum ada raw sheet.</div>;
    }

    return (
      <div style={styles.tableWrapper}>
        <table style={styles.table}>
          <tbody>
            {rawRows.slice(0, 15).map((row, rowIndex) => (
              <tr key={rowIndex}>
                {row.map((cell, cellIndex) => (
                  <td key={cellIndex} style={styles.td}>
                    {cell instanceof Date
                      ? formatDateObject(cell)
                      : String(cell ?? "")}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderTablePreview = () => {
    if (!Array.isArray(jsonData) || jsonData.length === 0) {
      return <div style={styles.emptyBox}>Tidak ada data untuk ditampilkan.</div>;
    }

    const firstRow = jsonData[0] || {};
    const columns = Object.keys(firstRow);

    return (
      <div style={styles.tableWrapper}>
        <table style={styles.table}>
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col} style={styles.th}>
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {jsonData.slice(0, 15).map((row, rowIndex) => (
              <tr key={rowIndex}>
                {columns.map((col) => (
                  <td key={`${rowIndex}-${col}`} style={styles.td}>
                    {row[col] instanceof Date
                      ? formatDateObject(row[col])
                      : String(row[col] ?? "")}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderPayloadPreview = () => {
    const payloadData = prepareDataForBackend(false);

    if (!payloadData.length) {
      return (
        <div style={styles.emptyBox}>
          Payload belum tersedia. Cek Preview Raw Sheet dan ubah Mode Baca Header
          jika kolom Date belum terbaca.
        </div>
      );
    }

    return (
      <div style={styles.tableWrapper}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>energy_date</th>
              <th style={styles.th}>purchased_from_grid_kwh</th>
              <th style={styles.th}>generated_by_pv_kwh</th>
              <th style={styles.th}>fed_to_grid_kwh</th>
              <th style={styles.th}>consumed_by_appliances_kwh</th>
            </tr>
          </thead>
          <tbody>
            {payloadData.slice(0, 15).map((row, index) => (
              <tr key={`${row.energy_date}-${index}`}>
                <td style={styles.td}>{row.energy_date}</td>
                <td style={styles.td}>{row.purchased_from_grid_kwh ?? ""}</td>
                <td style={styles.td}>{row.generated_by_pv_kwh ?? ""}</td>
                <td style={styles.td}>{row.fed_to_grid_kwh ?? ""}</td>
                <td style={styles.td}>
                  {row.consumed_by_appliances_kwh ?? ""}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderMonitoringTable = () => {
    if (!Array.isArray(monitoringRows) || monitoringRows.length === 0) {
      return (
        <div style={styles.emptyBox}>
          Belum ada data monitoring. Pilih tanggal lalu klik Tampilkan Monitoring.
        </div>
      );
    }

    return (
      <div style={styles.tableWrapper}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>x</th>
              <th style={styles.th}>Purchased from Grid (kWh)</th>
              <th style={styles.th}>Generated by PV (kWh)</th>
              <th style={styles.th}>Fed to Grid (kWh)</th>
              <th style={styles.th}>Consumed by Appliances (kWh)</th>
            </tr>
          </thead>
          <tbody>
            {monitoringRows.map((row) => (
              <tr key={row.energy_date}>
                <td style={styles.td}>{row.x}</td>
                <td style={styles.td}>{row.purchased_from_grid_kwh}</td>
                <td style={styles.td}>{row.generated_by_pv_kwh}</td>
                <td style={styles.td}>{row.fed_to_grid_kwh}</td>
                <td style={styles.td}>{row.consumed_by_appliances_kwh}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <Layout>
      <div style={styles.page}>
        <div style={styles.container}>
          <div style={styles.header}>
            <h1 style={styles.title}>Import PLTS P2 Hourly</h1>
            <p style={styles.subtitle}>
              Upload file Excel dengan kolom Date, PV output, Mains power,
              Feed-in power, dan Consumed by appliances. Data disimpan ke
              tb_plts_p2_hourly.
            </p>
          </div>

          <div
            style={styles.dropZone}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
          >
            <p style={styles.dropText}>
              Drag & drop file ke sini atau pilih manual
            </p>

            <button
              type="button"
              style={styles.primaryButton}
              onClick={() => fileInputRef.current?.click()}
            >
              Pilih File
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_EXTENSIONS.join(",")}
              onChange={handleFileChange}
              style={{ display: "none" }}
            />

            <p style={styles.supportText}>
              Format didukung: {ACCEPTED_EXTENSIONS.join(", ")}
            </p>
          </div>

          {isLoading && <div style={styles.infoBox}>Sedang membaca file...</div>}

          {isSaving && (
            <div style={styles.infoBox}>Sedang menyimpan data ke database...</div>
          )}

          {isFetchingMonitoring && (
            <div style={styles.infoBox}>Sedang mengambil data monitoring...</div>
          )}

          {error && <div style={styles.errorBox}>{error}</div>}

          {importResult && (
            <div style={styles.successBox}>
              Import selesai. Berhasil:{" "}
              <strong>{importResult.successCount}</strong>, Gagal:{" "}
              <strong>{importResult.failedCount}</strong>
            </div>
          )}

          {fileInfo && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Informasi File</h3>
              <div style={styles.infoGrid}>
                <div>
                  <strong>Nama:</strong> {fileInfo.name}
                </div>
                <div>
                  <strong>Ukuran:</strong> {(fileInfo.size / 1024).toFixed(2)} KB
                </div>
                <div>
                  <strong>Tipe:</strong> {fileInfo.type}
                </div>
                <div>
                  <strong>Last Modified:</strong> {fileInfo.lastModified}
                </div>
              </div>
            </div>
          )}

          {sheetNames.length > 0 && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Pengaturan Konversi</h3>

              <div style={styles.controlRow}>
                <div style={styles.controlGroup}>
                  <label style={styles.label}>Pilih Sheet</label>
                  <select
                    value={selectedSheet}
                    onChange={handleSheetChange}
                    style={styles.select}
                  >
                    {sheetNames.map((sheet) => (
                      <option key={sheet} value={sheet}>
                        {sheet}
                      </option>
                    ))}
                  </select>
                </div>

                <div style={styles.controlGroup}>
                  <label style={styles.label}>Mode Baca Header</label>
                  <select
                    value={parseMode}
                    onChange={handleParseModeChange}
                    style={styles.select}
                  >
                    <option value="auto">Deteksi Otomatis</option>
                    <option value="first-row">Baris Pertama Jadi Header</option>
                    <option value="no-header">
                      Tanpa Header / Kolom Tetap
                    </option>
                  </select>
                </div>
              </div>

              {parseInfo && (
                <div style={styles.infoBox}>
                  Header Row:{" "}
                  <strong>
                    {parseInfo.headerRowIndex >= 0
                      ? parseInfo.headerRowIndex + 1
                      : "Tidak pakai header"}
                  </strong>
                  {" | "}Total Data: <strong>{parseInfo.totalDataRows}</strong>
                  {" | "}Header:{" "}
                  <strong>{parseInfo.headers.join(", ")}</strong>
                </div>
              )}

              <div style={styles.buttonRow}>
                <button
                  type="button"
                  style={styles.secondaryButton}
                  onClick={handleCopyJson}
                >
                  Copy JSON
                </button>

                <button
                  type="button"
                  style={styles.secondaryButton}
                  onClick={handleDownloadJson}
                >
                  Download JSON
                </button>

                <button
                  type="button"
                  style={{
                    ...styles.saveButton,
                    opacity: isSaving ? 0.7 : 1,
                    cursor: isSaving ? "not-allowed" : "pointer",
                  }}
                  onClick={handleSaveToDatabase}
                  disabled={isSaving}
                >
                  {isSaving ? "Menyimpan..." : "Simpan ke Database"}
                </button>

                <button
                  type="button"
                  style={styles.dangerButton}
                  onClick={resetAll}
                >
                  Reset
                </button>
              </div>
            </div>
          )}

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Preview Raw Sheet</h3>
            {renderRawPreview()}
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Preview JSON Terbaca</h3>
            {renderTablePreview()}
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Preview Payload ke Database</h3>
            {renderPayloadPreview()}
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Monitoring PLTS P2 Per 5 Menit</h3>

            <div style={styles.controlRow}>
              <div style={styles.controlGroup}>
                <label style={styles.label}>Pilih Tanggal Monitoring</label>
                <input
                  type="date"
                  value={monitoringDate}
                  onChange={(event) => setMonitoringDate(event.target.value)}
                  style={styles.input}
                />
              </div>
            </div>

            <div style={styles.buttonRow}>
              <button
                type="button"
                style={{
                  ...styles.primaryButton,
                  opacity: isFetchingMonitoring ? 0.7 : 1,
                  cursor: isFetchingMonitoring ? "not-allowed" : "pointer",
                }}
                onClick={() => fetchMonitoringByDate()}
                disabled={isFetchingMonitoring}
              >
                {isFetchingMonitoring
                  ? "Mengambil Data..."
                  : "Tampilkan Monitoring"}
              </button>
            </div>

            <div style={{ marginTop: "16px" }}>{renderMonitoringTable()}</div>
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>JSON Output</h3>
            <textarea
              value={rawJsonText}
              readOnly
              style={styles.textarea}
              placeholder="Hasil JSON akan tampil di sini..."
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f5f7fb",
    padding: "24px",
    boxSizing: "border-box",
    fontFamily: "Arial, sans-serif",
  },
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
  },
  header: {
    marginBottom: "24px",
  },
  title: {
    margin: 0,
    fontSize: "28px",
    color: "#1f2937",
  },
  subtitle: {
    marginTop: "8px",
    color: "#6b7280",
    fontSize: "14px",
    lineHeight: 1.6,
  },
  dropZone: {
    backgroundColor: "#ffffff",
    border: "2px dashed #cbd5e1",
    borderRadius: "12px",
    padding: "32px",
    textAlign: "center",
    marginBottom: "20px",
  },
  dropText: {
    marginBottom: "12px",
    color: "#334155",
    fontSize: "16px",
  },
  supportText: {
    marginTop: "12px",
    fontSize: "12px",
    color: "#64748b",
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: "12px",
    padding: "20px",
    marginBottom: "20px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
  },
  cardTitle: {
    marginTop: 0,
    marginBottom: "16px",
    fontSize: "18px",
    color: "#111827",
  },
  infoGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: "12px",
    color: "#374151",
    fontSize: "14px",
  },
  controlRow: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
    gap: "16px",
    marginBottom: "16px",
  },
  controlGroup: {
    display: "flex",
    flexDirection: "column",
  },
  label: {
    marginBottom: "8px",
    fontSize: "14px",
    fontWeight: "bold",
    color: "#374151",
  },
  input: {
    padding: "10px 12px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    fontSize: "14px",
    outline: "none",
  },
  select: {
    padding: "10px 12px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    fontSize: "14px",
    outline: "none",
  },
  buttonRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: "10px",
  },
  primaryButton: {
    backgroundColor: "#2563eb",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 18px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
  },
  secondaryButton: {
    backgroundColor: "#0f766e",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
  },
  saveButton: {
    backgroundColor: "#2563eb",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
  },
  dangerButton: {
    backgroundColor: "#dc2626",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
  },
  infoBox: {
    backgroundColor: "#e0f2fe",
    color: "#075985",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
    fontSize: "13px",
    lineHeight: 1.6,
  },
  successBox: {
    backgroundColor: "#dcfce7",
    color: "#166534",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  errorBox: {
    backgroundColor: "#fee2e2",
    color: "#991b1b",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  emptyBox: {
    padding: "20px",
    border: "1px dashed #cbd5e1",
    borderRadius: "8px",
    color: "#6b7280",
    textAlign: "center",
  },
  tableWrapper: {
    overflowX: "auto",
    border: "1px solid #e5e7eb",
    borderRadius: "8px",
    maxHeight: "520px",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: "13px",
  },
  th: {
    backgroundColor: "#f8fafc",
    borderBottom: "1px solid #e5e7eb",
    padding: "10px",
    textAlign: "left",
    whiteSpace: "nowrap",
    position: "sticky",
    top: 0,
    zIndex: 1,
  },
  td: {
    borderBottom: "1px solid #f1f5f9",
    padding: "10px",
    verticalAlign: "top",
    whiteSpace: "nowrap",
  },
  textarea: {
    width: "100%",
    minHeight: "360px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    padding: "12px",
    boxSizing: "border-box",
    fontFamily: "monospace",
    fontSize: "13px",
    resize: "vertical",
    outline: "none",
  },
};

export default ConverterExelP2Hourly;