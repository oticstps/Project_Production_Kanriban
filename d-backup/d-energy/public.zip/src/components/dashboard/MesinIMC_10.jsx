import React, { useState, useEffect } from 'react';

// ==================== KOMPONEN CIRCULAR GAUGE ====================
const CircularGauge = ({ value, label, color, size = 130 }) => {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const clampedValue = Math.min(100, Math.max(0, value || 0));
  const offset = circumference - (clampedValue / 100) * circumference;

  const getColor = (val) => {
    if (val >= 80) return '#10b981'; // hijau
    if (val >= 60) return '#f59e0b'; // kuning
    return '#ef4444'; // merah
  };

  const gaugeColor = color || getColor(clampedValue);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <svg width={size} height={size} viewBox="0 0 130 130">
        {/* Background circle */}
        <circle
          cx="65"
          cy="65"
          r={radius}
          fill="none"
          stroke="#e5e7eb"
          strokeWidth="10"
        />
        {/* Progress circle */}
        <circle
          cx="65"
          cy="65"
          r={radius}
          fill="none"
          stroke={gaugeColor}
          strokeWidth="10"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          transform="rotate(-90 65 65)"
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
        {/* Center text */}
        <text
          x="65"
          y="60"
          textAnchor="middle"
          dominantBaseline="central"
          style={{ fontSize: '22px', fontWeight: 'bold', fill: '#1f2937' }}
        >
          {clampedValue.toFixed(1)}%
        </text>
        <text
          x="65"
          y="80"
          textAnchor="middle"
          dominantBaseline="central"
          style={{ fontSize: '11px', fill: '#6b7280' }}
        >
          {label}
        </text>
      </svg>
      <span
        style={{
          marginTop: '4px',
          fontSize: '13px',
          fontWeight: 600,
          color: '#374151',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
        }}
      >
        {label}
      </span>
    </div>
  );
};

// ==================== KOMPONEN UTAMA ====================
const MesinIMC_10 = () => {
  // State untuk form input
  const [plannedProductionTime, setPlannedProductionTime] = useState('');
  const [runningTime, setRunningTime] = useState('');
  const [idealCycleTime, setIdealCycleTime] = useState('');
  const [totalCount, setTotalCount] = useState('');
  const [goodCount, setGoodCount] = useState('');

  // State untuk hasil kalkulasi
  const [availability, setAvailability] = useState(0);
  const [performance, setPerformance] = useState(0);
  const [quality, setQuality] = useState(0);
  const [oee, setOee] = useState(0);
  const [downtime, setDowntime] = useState(0);
  const [rejectCount, setRejectCount] = useState(0);

  // State untuk history log
  const [history, setHistory] = useState([]);

  // State untuk notifikasi
  const [notification, setNotification] = useState(null);

  // Load history dari localStorage saat pertama kali
  useEffect(() => {
    const saved = localStorage.getItem('mesinIMC10_oee_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        setHistory([]);
      }
    }
  }, []);

  // Simpan history ke localStorage setiap ada perubahan
  useEffect(() => {
    localStorage.setItem('mesinIMC10_oee_history', JSON.stringify(history));
  }, [history]);

  // Fungsi kalkulasi OEE
  const calculateOEE = () => {
    const planned = parseFloat(plannedProductionTime) || 0;
    const running = parseFloat(runningTime) || 0;
    const cycleTime = parseFloat(idealCycleTime) || 0;
    const total = parseFloat(totalCount) || 0;
    const good = parseFloat(goodCount) || 0;

    // Hitung downtime
    const dt = Math.max(0, planned - running);
    setDowntime(dt);

    // Hitung reject
    const reject = Math.max(0, total - good);
    setRejectCount(reject);

    // Availability = Running Time / Planned Production Time
    let avail = 0;
    if (planned > 0) {
      avail = (running / planned) * 100;
    }
    setAvailability(Math.min(100, avail));

    // Performance = (Ideal Cycle Time × Total Count) / Running Time (dalam detik)
    let perf = 0;
    if (running > 0) {
      perf = (cycleTime * total) / (running * 60) * 100;
    }
    setPerformance(Math.min(100, perf));

    // Quality = Good Count / Total Count
    let qual = 0;
    if (total > 0) {
      qual = (good / total) * 100;
    }
    setQuality(Math.min(100, qual));

    // OEE = Availability × Performance × Quality
    const oeeValue = (avail * perf * qual) / 10000;
    setOee(Math.min(100, Math.max(0, oeeValue)));
  };

  // Kalkulasi otomatis setiap input berubah
  useEffect(() => {
    calculateOEE();
  }, [plannedProductionTime, runningTime, idealCycleTime, totalCount, goodCount]);

  // Tampilkan notifikasi sementara
  const showNotification = (message, type = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 2500);
  };

  // Simpan data ke history
  const saveToHistory = () => {
    const planned = parseFloat(plannedProductionTime) || 0;
    const running = parseFloat(runningTime) || 0;
    const cycleTime = parseFloat(idealCycleTime) || 0;
    const total = parseFloat(totalCount) || 0;
    const good = parseFloat(goodCount) || 0;

    if (planned === 0 && running === 0 && total === 0) {
      showNotification('⚠️ Tidak ada data untuk disimpan!', 'warning');
      return;
    }

    const newEntry = {
      id: Date.now(),
      timestamp: new Date().toLocaleString('id-ID', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }),
      plannedProductionTime: planned,
      runningTime: running,
      downtime: Math.max(0, planned - running),
      idealCycleTime: cycleTime,
      totalCount: total,
      goodCount: good,
      rejectCount: Math.max(0, total - good),
      availability: parseFloat(availability.toFixed(2)),
      performance: parseFloat(performance.toFixed(2)),
      quality: parseFloat(quality.toFixed(2)),
      oee: parseFloat(oee.toFixed(2)),
    };

    setHistory((prev) => [newEntry, ...prev]);
    showNotification('✅ Data berhasil disimpan ke history!');
  };

  // Hapus satu entry history
  const deleteHistoryEntry = (id) => {
    setHistory((prev) => prev.filter((entry) => entry.id !== id));
    showNotification('🗑️ Entry berhasil dihapus!', 'warning');
  };

  // Hapus semua history
  const clearAllHistory = () => {
    if (window.confirm('Hapus seluruh history log? Tindakan ini tidak dapat dibatalkan.')) {
      setHistory([]);
      showNotification('🗑️ Semua history telah dihapus!', 'warning');
    }
  };

  // Reset form
  const resetForm = () => {
    setPlannedProductionTime('');
    setRunningTime('');
    setIdealCycleTime('');
    setTotalCount('');
    setGoodCount('');
    setAvailability(0);
    setPerformance(0);
    setQuality(0);
    setOee(0);
    setDowntime(0);
    setRejectCount(0);
    showNotification('🔄 Form berhasil direset!', 'info');
  };

  // Export CSV
  const exportCSV = () => {
    if (history.length === 0) {
      showNotification('⚠️ Tidak ada data untuk diexport!', 'warning');
      return;
    }

    const headers = [
      'Timestamp',
      'Planned Time (min)',
      'Running Time (min)',
      'Downtime (min)',
      'Cycle Time (s)',
      'Total Count',
      'Good Count',
      'Reject',
      'Availability (%)',
      'Performance (%)',
      'Quality (%)',
      'OEE (%)',
    ];

    const rows = history.map((entry) => [
      entry.timestamp,
      entry.plannedProductionTime,
      entry.runningTime,
      entry.downtime,
      entry.idealCycleTime,
      entry.totalCount,
      entry.goodCount,
      entry.rejectCount,
      entry.availability,
      entry.performance,
      entry.quality,
      entry.oee,
    ]);

    const csvContent = [headers, ...rows].map((row) => row.join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `OEE_MESIN_IMC-10_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    showNotification('📥 CSV berhasil di-download!');
  };

  // Gaya warna OEE
  const getOEEColor = () => {
    if (oee >= 85) return '#10b981';
    if (oee >= 60) return '#f59e0b';
    return '#ef4444';
  };

  // ==================== STYLES ====================
  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f0f4f8 0%, #e2e8f0 100%)',
      fontFamily: "'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      padding: '20px',
    },
    header: {
      background: 'linear-gradient(135deg, #1e3a5f 0%, #0f2440 100%)',
      borderRadius: '16px',
      padding: '24px 32px',
      marginBottom: '24px',
      boxShadow: '0 8px 32px rgba(15, 36, 64, 0.3)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: '16px',
    },
    headerTitle: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
    },
    machineIcon: {
      width: '56px',
      height: '56px',
      background: 'rgba(255,255,255,0.1)',
      borderRadius: '14px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '28px',
    },
    headerText: {
      color: '#ffffff',
    },
    machineName: {
      fontSize: '26px',
      fontWeight: '800',
      margin: 0,
      letterSpacing: '1px',
      color: '#ffffff',
    },
    machineSub: {
      fontSize: '13px',
      color: '#94a3b8',
      margin: '2px 0 0 0',
      letterSpacing: '0.5px',
    },
    liveBadge: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      background: 'rgba(16, 185, 129, 0.15)',
      border: '1px solid rgba(16, 185, 129, 0.4)',
      borderRadius: '20px',
      padding: '8px 16px',
      color: '#10b981',
      fontSize: '13px',
      fontWeight: 600,
    },
    liveDot: {
      width: '10px',
      height: '10px',
      borderRadius: '50%',
      background: '#10b981',
      animation: 'pulse 2s infinite',
    },
    cardGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      marginBottom: '24px',
    },
    gaugeCard: {
      background: '#ffffff',
      borderRadius: '16px',
      padding: '20px',
      boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      transition: 'transform 0.2s, box-shadow 0.2s',
      cursor: 'default',
      border: '1px solid #f1f5f9',
    },
    mainOeeCard: {
      background: '#ffffff',
      borderRadius: '16px',
      padding: '20px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      border: `3px solid ${getOEEColor()}`,
      transition: 'border-color 0.5s ease',
    },
    formCard: {
      background: '#ffffff',
      borderRadius: '16px',
      padding: '28px',
      marginBottom: '24px',
      boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
      border: '1px solid #f1f5f9',
    },
    formTitle: {
      fontSize: '18px',
      fontWeight: '700',
      color: '#1e293b',
      marginBottom: '20px',
      paddingBottom: '12px',
      borderBottom: '2px solid #e2e8f0',
    },
    formGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
      gap: '16px',
    },
    inputGroup: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
    },
    label: {
      fontSize: '13px',
      fontWeight: '600',
      color: '#475569',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
    },
    input: {
      padding: '10px 14px',
      borderRadius: '10px',
      border: '2px solid #e2e8f0',
      fontSize: '15px',
      outline: 'none',
      transition: 'border-color 0.2s',
      width: '100%',
      boxSizing: 'border-box',
      background: '#f8fafc',
    },
    inputFocus: {
      borderColor: '#3b82f6',
      background: '#ffffff',
    },
    buttonRow: {
      display: 'flex',
      gap: '12px',
      marginTop: '24px',
      flexWrap: 'wrap',
    },
    btnPrimary: {
      padding: '12px 24px',
      borderRadius: '10px',
      border: 'none',
      fontWeight: '600',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s',
      background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
      color: '#ffffff',
      boxShadow: '0 4px 12px rgba(37, 99, 235, 0.3)',
    },
    btnSuccess: {
      padding: '12px 24px',
      borderRadius: '10px',
      border: 'none',
      fontWeight: '600',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s',
      background: 'linear-gradient(135deg, #10b981, #059669)',
      color: '#ffffff',
      boxShadow: '0 4px 12px rgba(5, 150, 105, 0.3)',
    },
    btnDanger: {
      padding: '10px 18px',
      borderRadius: '10px',
      border: 'none',
      fontWeight: '600',
      fontSize: '13px',
      cursor: 'pointer',
      transition: 'all 0.2s',
      background: '#ef4444',
      color: '#ffffff',
    },
    btnOutline: {
      padding: '12px 24px',
      borderRadius: '10px',
      border: '2px solid #e2e8f0',
      fontWeight: '600',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s',
      background: '#ffffff',
      color: '#475569',
    },
    btnSmall: {
      padding: '6px 14px',
      borderRadius: '8px',
      border: 'none',
      fontWeight: '600',
      fontSize: '12px',
      cursor: 'pointer',
      transition: 'all 0.2s',
      background: '#fef2f2',
      color: '#ef4444',
    },
    historyCard: {
      background: '#ffffff',
      borderRadius: '16px',
      padding: '28px',
      boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
      border: '1px solid #f1f5f9',
    },
    historyHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      flexWrap: 'wrap',
      gap: '12px',
      marginBottom: '20px',
      paddingBottom: '12px',
      borderBottom: '2px solid #e2e8f0',
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: '13px',
    },
    th: {
      background: '#f8fafc',
      padding: '12px 10px',
      textAlign: 'left',
      fontWeight: '700',
      color: '#475569',
      textTransform: 'uppercase',
      fontSize: '11px',
      letterSpacing: '0.5px',
      borderBottom: '2px solid #e2e8f0',
    },
    td: {
      padding: '10px',
      borderBottom: '1px solid #f1f5f9',
      color: '#334155',
    },
    badgeGood: {
      background: '#d1fae5',
      color: '#065f46',
      padding: '4px 10px',
      borderRadius: '12px',
      fontWeight: '700',
      fontSize: '12px',
    },
    badgeWarn: {
      background: '#fef3c7',
      color: '#92400e',
      padding: '4px 10px',
      borderRadius: '12px',
      fontWeight: '700',
      fontSize: '12px',
    },
    badgeBad: {
      background: '#fee2e2',
      color: '#991b1b',
      padding: '4px 10px',
      borderRadius: '12px',
      fontWeight: '700',
      fontSize: '12px',
    },
    notification: {
      position: 'fixed',
      top: '20px',
      right: '20px',
      padding: '14px 20px',
      borderRadius: '12px',
      fontWeight: '600',
      fontSize: '14px',
      boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
      zIndex: 1000,
      animation: 'slideIn 0.3s ease',
      maxWidth: '400px',
      color: '#ffffff',
    },
    emptyState: {
      textAlign: 'center',
      padding: '40px',
      color: '#94a3b8',
      fontSize: '15px',
    },
    summaryRow: {
      display: 'flex',
      gap: '16px',
      flexWrap: 'wrap',
      marginTop: '16px',
    },
    summaryBadge: {
      padding: '8px 16px',
      borderRadius: '20px',
      fontWeight: '600',
      fontSize: '13px',
      background: '#f1f5f9',
      color: '#475569',
    },
  };

  // ==================== RENDER ====================
  return (
    <div style={styles.container}>
      {/* Animasi global */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes slideIn {
          from { transform: translateX(100px); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `}</style>

      {/* Notifikasi */}
      {notification && (
        <div
          style={{
            ...styles.notification,
            background:
              notification.type === 'success'
                ? '#10b981'
                : notification.type === 'warning'
                ? '#f59e0b'
                : notification.type === 'info'
                ? '#3b82f6'
                : '#ef4444',
          }}
        >
          {notification.message}
        </div>
      )}

      {/* ========== HEADER ========== */}
      <div style={styles.header}>
        <div style={styles.headerTitle}>
          <div style={styles.machineIcon}>⚙️</div>
          <div style={styles.headerText}>
            <h1 style={styles.machineName}>MESIN IMC-10</h1>
            <p style={styles.machineSub}>Sistem Monitoring OEE • Overall Equipment Effectiveness</p>
          </div>
        </div>
        <div style={styles.liveBadge}>
          <span style={styles.liveDot}></span>
          LIVE MONITORING
        </div>
      </div>

      {/* ========== GAUGE CARDS ========== */}
      <div style={styles.cardGrid}>
        {/* OEE Card - Utama */}
        <div style={styles.mainOeeCard}>
          <CircularGauge value={oee} label="OEE" color={getOEEColor()} size={140} />
          <div style={{ marginTop: '8px', textAlign: 'center' }}>
            <span
              style={{
                fontSize: '12px',
                fontWeight: 600,
                color: getOEEColor(),
                background: `${getOEEColor()}15`,
                padding: '4px 12px',
                borderRadius: '10px',
              }}
            >
              {oee >= 85 ? '🏆 World Class' : oee >= 60 ? '📊 Average' : '⚠️ Perlu Perbaikan'}
            </span>
          </div>
        </div>

        {/* Availability Card */}
        <div style={styles.gaugeCard}>
          <CircularGauge value={availability} label="Availability" color="#3b82f6" size={120} />
          <div style={styles.summaryRow}>
            <span style={styles.summaryBadge}>⏱️ Running: {parseFloat(runningTime) || 0} min</span>
            <span style={styles.summaryBadge}>⏸️ Downtime: {downtime.toFixed(1)} min</span>
          </div>
        </div>

        {/* Performance Card */}
        <div style={styles.gaugeCard}>
          <CircularGauge value={performance} label="Performance" color="#8b5cf6" size={120} />
          <div style={styles.summaryRow}>
            <span style={styles.summaryBadge}>⚡ Cycle: {parseFloat(idealCycleTime) || 0} s</span>
            <span style={styles.summaryBadge}>📦 Total: {parseFloat(totalCount) || 0} pcs</span>
          </div>
        </div>

        {/* Quality Card */}
        <div style={styles.gaugeCard}>
          <CircularGauge value={quality} label="Quality" color="#f59e0b" size={120} />
          <div style={styles.summaryRow}>
            <span style={styles.summaryBadge}>✅ Good: {parseFloat(goodCount) || 0} pcs</span>
            <span style={styles.summaryBadge}>❌ Reject: {rejectCount.toFixed(0)} pcs</span>
          </div>
        </div>
      </div>

      {/* ========== FORM INPUT ========== */}
      <div style={styles.formCard}>
        <h2 style={styles.formTitle}>📋 Data Produksi - MESIN IMC-10</h2>
        <div style={styles.formGrid}>
          {/* Planned Production Time */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>⏱️ Waktu Produksi Rencana (menit)</label>
            <input
              type="number"
              style={styles.input}
              placeholder="Contoh: 480 (8 jam)"
              value={plannedProductionTime}
              onChange={(e) => setPlannedProductionTime(e.target.value)}
              min="0"
              step="any"
              onFocus={(e) => (e.target.style.borderColor = '#3b82f6')}
              onBlur={(e) => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>

          {/* Running Time */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>▶️ Waktu Berjalan (menit)</label>
            <input
              type="number"
              style={styles.input}
              placeholder="Contoh: 420"
              value={runningTime}
              onChange={(e) => setRunningTime(e.target.value)}
              min="0"
              step="any"
              onFocus={(e) => (e.target.style.borderColor = '#3b82f6')}
              onBlur={(e) => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>

          {/* Ideal Cycle Time */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>⚡ Waktu Siklus Ideal (detik/unit)</label>
            <input
              type="number"
              style={styles.input}
              placeholder="Contoh: 30"
              value={idealCycleTime}
              onChange={(e) => setIdealCycleTime(e.target.value)}
              min="0"
              step="any"
              onFocus={(e) => (e.target.style.borderColor = '#3b82f6')}
              onBlur={(e) => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>

          {/* Total Count */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>📦 Total Produksi (unit)</label>
            <input
              type="number"
              style={styles.input}
              placeholder="Contoh: 800"
              value={totalCount}
              onChange={(e) => setTotalCount(e.target.value)}
              min="0"
              step="any"
              onFocus={(e) => (e.target.style.borderColor = '#3b82f6')}
              onBlur={(e) => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>

          {/* Good Count */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>✅ Produksi Baik (unit)</label>
            <input
              type="number"
              style={styles.input}
              placeholder="Contoh: 780"
              value={goodCount}
              onChange={(e) => setGoodCount(e.target.value)}
              min="0"
              step="any"
              onFocus={(e) => (e.target.style.borderColor = '#3b82f6')}
              onBlur={(e) => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>
        </div>

        {/* Info Downtime & Reject (read-only) */}
        <div style={{ ...styles.summaryRow, marginTop: '20px' }}>
          <span style={{ ...styles.summaryBadge, background: '#fef2f2', color: '#991b1b' }}>
            ⏸️ Downtime Terhitung: <strong>{downtime.toFixed(1)} menit</strong>
          </span>
          <span style={{ ...styles.summaryBadge, background: '#fff7ed', color: '#c2410c' }}>
            ❌ Reject Terhitung: <strong>{rejectCount.toFixed(0)} unit</strong>
          </span>
        </div>

        {/* Tombol Aksi */}
        <div style={styles.buttonRow}>
          <button style={styles.btnSuccess} onClick={saveToHistory}>
            💾 Simpan ke History
          </button>
          <button style={styles.btnPrimary} onClick={exportCSV}>
            📥 Export CSV
          </button>
          <button style={styles.btnOutline} onClick={resetForm}>
            🔄 Reset Form
          </button>
        </div>
      </div>

      {/* ========== HISTORY LOG ========== */}
      <div style={styles.historyCard}>
        <div style={styles.historyHeader}>
          <h2 style={{ ...styles.formTitle, marginBottom: 0, paddingBottom: 0, borderBottom: 'none' }}>
            📜 History Log - MESIN IMC-10
          </h2>
          <div style={{ display: 'flex', gap: '8px' }}>
            <span style={{ ...styles.summaryBadge, background: '#eff6ff', color: '#1d4ed8' }}>
              Total: {history.length} record
            </span>
            {history.length > 0 && (
              <button style={styles.btnSmall} onClick={clearAllHistory}>
                🗑️ Hapus Semua
              </button>
            )}
          </div>
        </div>

        {history.length === 0 ? (
          <div style={styles.emptyState}>
            <div style={{ fontSize: '48px', marginBottom: '12px' }}>📭</div>
            <p>Belum ada data history. Silakan isi form dan simpan data produksi.</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Tanggal</th>
                  <th style={styles.th}>Planned (min)</th>
                  <th style={styles.th}>Running (min)</th>
                  <th style={styles.th}>Downtime (min)</th>
                  <th style={styles.th}>Cycle (s)</th>
                  <th style={styles.th}>Total</th>
                  <th style={styles.th}>Good</th>
                  <th style={styles.th}>Reject</th>
                  <th style={styles.th}>Avail (%)</th>
                  <th style={styles.th}>Perf (%)</th>
                  <th style={styles.th}>Qual (%)</th>
                  <th style={styles.th}>OEE (%)</th>
                  <th style={styles.th}>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {history.map((entry) => (
                  <tr key={entry.id} style={{ transition: 'background 0.2s' }}>
                    <td style={styles.td}>{entry.timestamp}</td>
                    <td style={styles.td}>{entry.plannedProductionTime}</td>
                    <td style={styles.td}>{entry.runningTime}</td>
                    <td style={styles.td}>{entry.downtime.toFixed(1)}</td>
                    <td style={styles.td}>{entry.idealCycleTime}</td>
                    <td style={styles.td}><strong>{entry.totalCount}</strong></td>
                    <td style={styles.td}>{entry.goodCount}</td>
                    <td style={styles.td}>{entry.rejectCount}</td>
                    <td style={styles.td}>
                      <span
                        style={
                          entry.availability >= 80
                            ? styles.badgeGood
                            : entry.availability >= 60
                            ? styles.badgeWarn
                            : styles.badgeBad
                        }
                      >
                        {entry.availability.toFixed(1)}%
                      </span>
                    </td>
                    <td style={styles.td}>
                      <span
                        style={
                          entry.performance >= 80
                            ? styles.badgeGood
                            : entry.performance >= 60
                            ? styles.badgeWarn
                            : styles.badgeBad
                        }
                      >
                        {entry.performance.toFixed(1)}%
                      </span>
                    </td>
                    <td style={styles.td}>
                      <span
                        style={
                          entry.quality >= 80
                            ? styles.badgeGood
                            : entry.quality >= 60
                            ? styles.badgeWarn
                            : styles.badgeBad
                        }
                      >
                        {entry.quality.toFixed(1)}%
                      </span>
                    </td>
                    <td style={styles.td}>
                      <span
                        style={{
                          ...(entry.oee >= 85
                            ? styles.badgeGood
                            : entry.oee >= 60
                            ? styles.badgeWarn
                            : styles.badgeBad),
                          fontWeight: '800',
                          fontSize: '14px',
                        }}
                      >
                        {entry.oee.toFixed(1)}%
                      </span>
                    </td>
                    <td style={styles.td}>
                      <button
                        style={styles.btnSmall}
                        onClick={() => deleteHistoryEntry(entry.id)}
                        title="Hapus entry ini"
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{ textAlign: 'center', padding: '20px', color: '#94a3b8', fontSize: '12px', marginTop: '16px' }}>
        © {new Date().getFullYear()} MESIN IMC-10 OEE System • Dibuat khusus untuk monitoring efektivitas mesin
      </div>
    </div>
  );
};

export default MesinIMC_10;