import React, { useEffect, useMemo, useState } from "react";
import Layout from "../layout/Layout";
const API_URL = "http://172.27.6.191:4000/api/full-texts-p1";

function PLTSP1() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const fetchData = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError("");

      const response = await fetch(API_URL, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const result = await response.json();

      if (!result.success || !Array.isArray(result.data)) {
        throw new Error("Format data API tidak sesuai");
      }

      setRows(result.data);
    } catch (err) {
      setError(err.message || "Gagal mengambil data");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(() => fetchData(true), 30000);
    return () => clearInterval(interval);
  }, []);

  const latest = useMemo(() => {
    if (!rows.length) return null;
    return rows[0];
  }, [rows]);

  const parseNumber = (value) => {
    if (value === null || value === undefined || value === "") return 0;
    const num = Number(value);
    return Number.isNaN(num) ? 0 : num;
  };

  const formatNumber = (value, digits = 2) => {
    return parseNumber(value).toLocaleString("id-ID", {
      minimumFractionDigits: 0,
      maximumFractionDigits: digits,
    });
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return "-";
    const date = new Date(dateString.replace(" ", "T"));
    if (Number.isNaN(date.getTime())) return dateString;

    return date.toLocaleString("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  const cards = latest
    ? [
        {
          title: "Phase 1",
          value: formatNumber(latest.phase_1),
          unit: latest.phase_1_unit || "kW",
        },
        {
          title: "PV Energy",
          value: formatNumber(latest.pv_energy),
          unit: latest.pv_energy_unit || "kWh",
        },
        {
          title: "PR",
          value: formatNumber(latest.pr),
          unit: latest.pr_unit || "",
        },
        {
          title: "Temperature",
          value: formatNumber(latest.weather_for_cikarang),
          unit: latest.weather_unit || "°C",
        },
        {
          title: "CO₂ Reduced",
          value: formatNumber(latest.co2_reduced),
          unit: latest.co2_reduced_unit || "Tons",
        },
        {
          title: "Status PV",
          value: latest.status_pv || "-",
          unit: "",
          isStatus: true,
        },
      ]
    : [];

  return (


    <>
      <Layout>
      <div className="bg-slate-100 p-3 md:p-4">
      <div className="mx-auto max-w-7xl space-y-4">
        <div className="rounded-xl bg-white px-4 py-3 shadow-sm">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className="text-lg font-bold text-slate-800 md:text-xl">
                Dashboard Monitoring PLTS P1
              </h1>
              <p className="text-xs text-slate-500 md:text-sm">
                Monitoring phase 1, PV energy, PR, temperatur, dan CO₂ reduction
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="rounded-lg bg-slate-100 px-3 py-2 text-xs text-slate-600">
                {latest ? (
                  <>
                    Update:{" "}
                    <span className="font-semibold text-slate-800">
                      {formatDateTime(latest.created_at)}
                    </span>
                  </>
                ) : (
                  "Belum ada data"
                )}
              </div>

              <button
                onClick={() => fetchData(true)}
                className="rounded-lg bg-blue-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-blue-700"
              >
                {refreshing ? "Refreshing..." : "Refresh"}
              </button>
            </div>
          </div>
        </div>

        {loading && (
          <div className="rounded-xl bg-white p-8 text-center shadow-sm">
            <div className="text-sm font-medium text-slate-700">Loading data...</div>
          </div>
        )}

        {!loading && error && (
          <div className="rounded-xl border border-red-200 bg-red-50 p-4 shadow-sm">
            <h2 className="text-sm font-semibold text-red-700">Gagal memuat data</h2>
            <p className="mt-1 text-xs text-red-600">{error}</p>
          </div>
        )}

        {!loading && !error && latest && (
          <>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
              {cards.map((card, index) => (
                <div
                  key={index}
                  className="rounded-xl bg-white px-3 py-3 shadow-sm transition hover:shadow-md"
                >
                  <div className="mb-2 flex items-center justify-between">
                    <span className="truncate text-[11px] font-medium text-slate-500">
                      {card.title}
                    </span>
                    <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-medium text-blue-700">
                      P1
                    </span>
                  </div>

                  {card.isStatus ? (
                    <div className="mt-2">
                      <span className="inline-flex rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-700">
                        {card.value}
                      </span>
                    </div>
                  ) : (
                    <div className="flex items-end gap-1">
                      <span className="text-xl font-bold leading-none text-slate-800">
                        {card.value}
                      </span>
                      {card.unit && (
                        <span className="text-[11px] text-slate-500">{card.unit}</span>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
              <div className="rounded-xl bg-white p-4 shadow-sm xl:col-span-2">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-semibold text-slate-800">
                    Ringkasan Data Terbaru
                  </h2>
                  <span className="text-[11px] text-slate-500">
                    Record #{latest.id}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                  <MiniInfo
                    label="Phase 1"
                    value={`${formatNumber(latest.phase_1)} ${latest.phase_1_unit || "kW"}`}
                  />
                  <MiniInfo
                    label="PV Energy"
                    value={`${formatNumber(latest.pv_energy)} ${latest.pv_energy_unit || "kWh"}`}
                  />
                  <MiniInfo
                    label="PR"
                    value={`${formatNumber(latest.pr)} ${latest.pr_unit || ""}`}
                  />
                  <MiniInfo
                    label="Temperature"
                    value={`${formatNumber(latest.weather_for_cikarang)} ${latest.weather_unit || "°C"}`}
                  />
                  <MiniInfo
                    label="CO₂ Reduced"
                    value={`${formatNumber(latest.co2_reduced)} ${latest.co2_reduced_unit || "Tons"}`}
                  />
                  <MiniInfo label="Status" value={latest.status_pv || "-"} />
                  <MiniInfo label="Last Update" value={latest.last_update || "-"} />
                  <MiniInfo
                    label="Created At"
                    value={formatDateTime(latest.created_at)}
                  />
                </div>
              </div>

              <div className="rounded-xl bg-white p-4 shadow-sm">
                <h2 className="mb-3 text-sm font-semibold text-slate-800">
                  Status Sistem
                </h2>

                <div className="space-y-2">
                  <CompactStatus title="Koneksi API" value="Aktif" color="green" />
                  <CompactStatus title="Auto Refresh" value="30 detik" color="blue" />
                  <CompactStatus
                    title="Jumlah Record"
                    value={`${rows.length} data`}
                    color="amber"
                  />
                  <CompactStatus
                    title="PV Status"
                    value={latest.status_pv || "-"}
                    color="green"
                  />
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-white p-4 shadow-sm">
              <div className="mb-3 flex flex-col gap-1 md:flex-row md:items-center md:justify-between">
                <h2 className="text-sm font-semibold text-slate-800">
                  Riwayat Data Monitoring P1
                </h2>
                <p className="text-[11px] text-slate-500">
                  Histori data endpoint P1
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-left text-slate-500">
                      <th className="px-2 py-2 font-medium">ID</th>
                      <th className="px-2 py-2 font-medium">Waktu</th>
                      <th className="px-2 py-2 font-medium">Phase 1</th>
                      <th className="px-2 py-2 font-medium">PV Energy</th>
                      <th className="px-2 py-2 font-medium">PR</th>
                      <th className="px-2 py-2 font-medium">Temp</th>
                      <th className="px-2 py-2 font-medium">CO₂</th>
                      <th className="px-2 py-2 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((item) => (
                      <tr
                        key={item.id}
                        className="border-b border-slate-100 text-slate-700 hover:bg-slate-50"
                      >
                        <td className="px-2 py-2 font-semibold">{item.id}</td>
                        <td className="px-2 py-2 whitespace-nowrap">
                          {formatDateTime(item.created_at)}
                        </td>
                        <td className="px-2 py-2 whitespace-nowrap">
                          {formatNumber(item.phase_1)} {item.phase_1_unit || "kW"}
                        </td>
                        <td className="px-2 py-2 whitespace-nowrap">
                          {formatNumber(item.pv_energy)} {item.pv_energy_unit || "kWh"}
                        </td>
                        <td className="px-2 py-2 whitespace-nowrap">
                          {formatNumber(item.pr)} {item.pr_unit || ""}
                        </td>
                        <td className="px-2 py-2 whitespace-nowrap">
                          {formatNumber(item.weather_for_cikarang)}{" "}
                          {item.weather_unit || "°C"}
                        </td>
                        <td className="px-2 py-2 whitespace-nowrap">
                          {formatNumber(item.co2_reduced)}{" "}
                          {item.co2_reduced_unit || "Tons"}
                        </td>
                        <td className="px-2 py-2">
                          <span className="rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-semibold text-green-700">
                            {item.status_pv || "-"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {!loading && !error && !latest && (
          <div className="rounded-xl bg-white p-8 text-center shadow-sm">
            <div className="text-sm font-medium text-slate-700">Data kosong</div>
            <p className="mt-1 text-xs text-slate-500">
              API berhasil dipanggil, tetapi belum ada data yang ditampilkan.
            </p>
          </div>
        )}
      </div>
    </div>
      </Layout>
    </>

  );
}

function MiniInfo({ label, value }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">
      <p className="text-[10px] uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-xs font-semibold leading-snug text-slate-800">{value}</p>
    </div>
  );
}

function CompactStatus({ title, value, color = "green" }) {
  const colorMap = {
    green: "bg-green-100 text-green-700",
    blue: "bg-blue-100 text-blue-700",
    amber: "bg-amber-100 text-amber-700",
  };

  return (
    <div className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2">
      <span className="text-xs text-slate-600">{title}</span>
      <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${colorMap[color]}`}>
        {value}
      </span>
    </div>
  );
}

export default PLTSP1;