import React, { useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import Layout from "../layout/Layout";

const API_BASE_URL = "http://172.27.6.191:4000/api/plts-p1-daily";

const ACCEPTED_EXTENSIONS = [
  ".xlsx",
  ".xls",
  ".csv",
  ".txt",
  ".tsv",
  ".xlsb",
  ".ods",
];

function ConverterExelP1() {
  const fileInputRef = useRef(null);

  const [selectedFile, setSelectedFile] = useState(null);
  const [workbookData, setWorkbookData] = useState(null);
  const [sheetNames, setSheetNames] = useState([]);
  const [selectedSheet, setSelectedSheet] = useState("");
  const [jsonData, setJsonData] = useState([]);
  const [rawJsonText, setRawJsonText] = useState("");
  const [rangePreview, setRangePreview] = useState([]);
  const [fileInfo, setFileInfo] = useState(null);
  const [headerMode, setHeaderMode] = useState("auto");
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");
  const [importResult, setImportResult] = useState(null);

  const prettyJson = useMemo(() => {
    try {
      return JSON.stringify(jsonData, null, 2);
    } catch {
      return "[]";
    }
  }, [jsonData]);

  const resetAll = () => {
    setSelectedFile(null);
    setWorkbookData(null);
    setSheetNames([]);
    setSelectedSheet("");
    setJsonData([]);
    setRawJsonText("");
    setRangePreview([]);
    setFileInfo(null);
    setHeaderMode("auto");
    setError("");
    setImportResult(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const getExtension = (fileName = "") => {
    const lastDot = fileName.lastIndexOf(".");
    if (lastDot === -1) return "";
    return fileName.slice(lastDot).toLowerCase();
  };

  const isAcceptedFile = (file) => {
    const ext = getExtension(file?.name || "");
    return ACCEPTED_EXTENSIONS.includes(ext);
  };

  const normalizeKey = (key, index) => {
    if (key === undefined || key === null || String(key).trim() === "") {
      return `column_${index + 1}`;
    }

    return String(key)
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "_")
      .replace(/[^\w]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
  };

  const normalizeObjectKey = (key) => {
    return String(key || "")
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "_")
      .replace(/[^\w]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
  };

  const getValueByPossibleKeys = (row, possibleKeys) => {
    const normalizedRow = {};

    Object.keys(row || {}).forEach((key) => {
      normalizedRow[normalizeObjectKey(key)] = row[key];
    });

    for (const key of possibleKeys) {
      const normalizedKey = normalizeObjectKey(key);

      if (
        normalizedRow[normalizedKey] !== undefined &&
        normalizedRow[normalizedKey] !== null &&
        normalizedRow[normalizedKey] !== ""
      ) {
        return normalizedRow[normalizedKey];
      }
    }

    return "";
  };

  const excelSerialDateToYMD = (serialValue) => {
    const serial = Number(serialValue);

    if (Number.isNaN(serial)) return "";

    const days = Math.floor(serial);
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const date = new Date(excelEpoch.getTime() + days * 24 * 60 * 60 * 1000);

    return date.toISOString().slice(0, 10);
  };

  const normalizeDateForBackend = (value) => {
    if (value === undefined || value === null || value === "") return "";

    if (value instanceof Date && !Number.isNaN(value.getTime())) {
      return value.toISOString().slice(0, 10);
    }

    if (typeof value === "number") {
      return excelSerialDateToYMD(value);
    }

    const text = String(value).trim();

    if (!text) return "";

    const lowerText = text.toLowerCase();

    if (lowerText === "x") return "";
    if (lowerText === "date") return "";
    if (lowerText === "tanggal") return "";
    if (lowerText === "energy_date") return "";
    if (lowerText === "energy date") return "";

    if (/^\d+(\.\d+)?$/.test(text)) {
      return excelSerialDateToYMD(text);
    }

    if (/^\d{4}-\d{2}-\d{2}$/.test(text)) {
      return text;
    }

    const mdy = text.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);

    if (mdy) {
      const month = mdy[1].padStart(2, "0");
      const day = mdy[2].padStart(2, "0");
      const year = mdy[3];

      return `${year}-${month}-${day}`;
    }

    const parsedDate = new Date(text);

    if (!Number.isNaN(parsedDate.getTime())) {
      return parsedDate.toISOString().slice(0, 10);
    }

    return "";
  };

  const isValidDateValue = (value) => {
    return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""));
  };

  const normalizeRowForBackend = (row) => {
    const rawDate = getValueByPossibleKeys(row, [
      "x",
      "date",
      "tanggal",
      "energy_date",
      "energy date",
      "column_1",
    ]);

    return {
      energy_date: normalizeDateForBackend(rawDate),

      production_kwh: getValueByPossibleKeys(row, [
        "production",
        "production_kwh",
        "production kwh",
        "produksi",
        "column_2",
      ]),

      inverter1_kwh: getValueByPossibleKeys(row, [
        "inverter1",
        "inverter_1",
        "inverter 1",
        "inverter1_kwh",
        "inverter 1 kwh",
        "column_3",
      ]),

      inverter2_kwh: getValueByPossibleKeys(row, [
        "inverter2",
        "inverter_2",
        "inverter 2",
        "inverter2_kwh",
        "inverter 2 kwh",
        "column_4",
      ]),
    };
  };

  const prepareDataForBackend = () => {
    if (!Array.isArray(jsonData)) return [];

    return jsonData
      .filter((row) => row && typeof row === "object" && !Array.isArray(row))
      .map((row) => normalizeRowForBackend(row))
      .filter((row) => isValidDateValue(row.energy_date));
  };

  const readWorkbookSafely = async (file) => {
    const buffer = await file.arrayBuffer();

    const originalWarn = console.warn;
    const originalError = console.error;

    try {
      console.warn = (...args) => {
        const message = args.join(" ");
        if (message.includes("Bad uncompressed size")) return;
        originalWarn(...args);
      };

      console.error = (...args) => {
        const message = args.join(" ");
        if (message.includes("Bad uncompressed size")) return;
        originalError(...args);
      };

      return XLSX.read(buffer, {
        type: "array",
        raw: true,
        codepage: 65001,
        cellDates: false,
        cellText: true,
        WTF: false,
      });
    } finally {
      console.warn = originalWarn;
      console.error = originalError;
    }
  };

  const convertSheetToJson = (workbook, sheetName, mode = "auto") => {
    const worksheet = workbook.Sheets[sheetName];

    if (!worksheet) {
      throw new Error(`Sheet "${sheetName}" tidak ditemukan.`);
    }

    const previewRows = XLSX.utils.sheet_to_json(worksheet, {
      header: 1,
      defval: "",
      raw: true,
      blankrows: false,
    });

    setRangePreview(previewRows.slice(0, 10));

    let result = [];

    if (mode === "array") {
      result = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: "",
        raw: true,
        blankrows: false,
      });
    } else if (mode === "custom-header") {
      const rows = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: "",
        raw: true,
        blankrows: false,
      });

      if (rows.length === 0) {
        result = [];
      } else {
        const headers = rows[0].map((item, index) => normalizeKey(item, index));

        result = rows.slice(1).map((row) => {
          const obj = {};

          headers.forEach((header, index) => {
            obj[header] = row[index] ?? "";
          });

          return obj;
        });
      }
    } else {
      result = XLSX.utils.sheet_to_json(worksheet, {
        defval: "",
        raw: true,
        blankrows: false,
      });
    }

    setJsonData(result);
    setRawJsonText(JSON.stringify(result, null, 2));
    setImportResult(null);
  };

  const parseFile = async (file) => {
    if (!file) return;

    setIsLoading(true);
    setError("");
    setImportResult(null);

    try {
      if (!isAcceptedFile(file)) {
        throw new Error(
          "Format file tidak didukung. Gunakan file .xlsx, .xls, .csv, .txt, .tsv, .xlsb, atau .ods"
        );
      }

      const ext = getExtension(file.name);
      const workbook = await readWorkbookSafely(file);
      const names = workbook.SheetNames || [];

      if (names.length === 0) {
        throw new Error("File tidak memiliki sheet atau data yang bisa dibaca.");
      }

      setSelectedFile(file);
      setWorkbookData(workbook);
      setSheetNames(names);
      setSelectedSheet(names[0]);

      setFileInfo({
        name: file.name,
        size: file.size,
        type: file.type || ext || "unknown",
        lastModified: file.lastModified
          ? new Date(file.lastModified).toLocaleString("id-ID")
          : "-",
      });

      convertSheetToJson(workbook, names[0], headerMode);
    } catch (err) {
      console.error("Gagal membaca file:", err);
      setError(err.message || "Terjadi kesalahan saat membaca file.");
      setWorkbookData(null);
      setSheetNames([]);
      setSelectedSheet("");
      setJsonData([]);
      setRawJsonText("");
      setRangePreview([]);
      setFileInfo(null);
      setImportResult(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = async (event) => {
    const file = event.target.files?.[0];
    await parseFile(file);
  };

  const handleDrop = async (event) => {
    event.preventDefault();
    event.stopPropagation();

    const file = event.dataTransfer.files?.[0];
    await parseFile(file);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleSheetChange = (event) => {
    const newSheet = event.target.value;
    setSelectedSheet(newSheet);

    if (workbookData && newSheet) {
      try {
        convertSheetToJson(workbookData, newSheet, headerMode);
      } catch (err) {
        setError(err.message || "Gagal mengubah sheet.");
      }
    }
  };

  const handleHeaderModeChange = (event) => {
    const newMode = event.target.value;
    setHeaderMode(newMode);

    if (workbookData && selectedSheet) {
      try {
        convertSheetToJson(workbookData, selectedSheet, newMode);
      } catch (err) {
        setError(err.message || "Gagal mengubah mode header.");
      }
    }
  };

  const handleCopyJson = async () => {
    try {
      await navigator.clipboard.writeText(prettyJson);
      alert("JSON berhasil disalin ke clipboard.");
    } catch (err) {
      console.error("Copy gagal:", err);
      alert("Gagal menyalin JSON.");
    }
  };

  const handleDownloadJson = () => {
    try {
      const blob = new Blob([prettyJson], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");

      const baseName = selectedFile?.name
        ? selectedFile.name.replace(/\.[^/.]+$/, "")
        : "converted_data";

      a.href = url;
      a.download = `${baseName}_${selectedSheet || "sheet"}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Download gagal:", err);
      alert("Gagal download file JSON.");
    }
  };

  const handleSaveToDatabase = async () => {
    try {
      setIsSaving(true);
      setError("");
      setImportResult(null);

      if (!Array.isArray(jsonData) || jsonData.length === 0) {
        throw new Error("Tidak ada data JSON untuk disimpan.");
      }

      if (headerMode === "array") {
        throw new Error(
          "Mode Array 2D tidak bisa langsung disimpan. Gunakan Auto Object atau Baris Pertama Jadi Header."
        );
      }

      const payloadData = prepareDataForBackend();

      console.log("JSON asli:", jsonData);
      console.log("Payload PLTS Plant 1:", payloadData);

      if (payloadData.length === 0) {
        throw new Error(
          "Tidak ada data valid. Pastikan file memiliki kolom x, Production, Inverter1, dan Inverter2."
        );
      }

      const response = await fetch(`${API_BASE_URL}/bulk`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          data: payloadData,
        }),
      });

      const responseText = await response.text();

      let result = {};
      try {
        result = responseText ? JSON.parse(responseText) : {};
      } catch {
        throw new Error(responseText || "Response backend bukan JSON valid.");
      }

      if (!response.ok) {
        throw new Error(result.message || "Gagal menyimpan data ke database.");
      }

      setImportResult(result.result);

      alert(
        `Import selesai. Berhasil: ${result.result.successCount}, Gagal: ${result.result.failedCount}`
      );
    } catch (err) {
      console.error("Gagal simpan ke database:", err);
      setError(err.message || "Gagal simpan ke database.");
    } finally {
      setIsSaving(false);
    }
  };

  const renderTablePreview = () => {
    if (!Array.isArray(jsonData) || jsonData.length === 0) {
      return <div style={styles.emptyBox}>Tidak ada data untuk ditampilkan.</div>;
    }

    if (headerMode === "array") {
      return (
        <div style={styles.tableWrapper}>
          <table style={styles.table}>
            <tbody>
              {jsonData.slice(0, 10).map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {Array.isArray(row) &&
                    row.map((cell, cellIndex) => (
                      <td key={cellIndex} style={styles.td}>
                        {String(cell)}
                      </td>
                    ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    const firstRow = jsonData[0] || {};
    const columns = Object.keys(firstRow);

    return (
      <div style={styles.tableWrapper}>
        <table style={styles.table}>
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col} style={styles.th}>
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {jsonData.slice(0, 10).map((row, rowIndex) => (
              <tr key={rowIndex}>
                {columns.map((col) => (
                  <td key={`${rowIndex}-${col}`} style={styles.td}>
                    {String(row[col] ?? "")}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <Layout>
      <div style={styles.page}>
        <div style={styles.container}>
          <div style={styles.header}>
            <h1 style={styles.title}>Import PLTS P1 Daily</h1>
            <p style={styles.subtitle}>
              Upload file Excel dengan kolom x, Production, Inverter1, dan
              Inverter2.
            </p>
          </div>

          <div
            style={styles.dropZone}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
          >
            <p style={styles.dropText}>Drag & drop file ke sini atau pilih manual</p>

            <button
              type="button"
              style={styles.primaryButton}
              onClick={() => fileInputRef.current?.click()}
            >
              Pilih File
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_EXTENSIONS.join(",")}
              onChange={handleFileChange}
              style={{ display: "none" }}
            />

            <p style={styles.supportText}>
              Format didukung: {ACCEPTED_EXTENSIONS.join(", ")}
            </p>
          </div>

          {isLoading && <div style={styles.infoBox}>Sedang membaca file...</div>}

          {isSaving && (
            <div style={styles.infoBox}>Sedang menyimpan data ke database...</div>
          )}

          {error && <div style={styles.errorBox}>{error}</div>}

          {importResult && (
            <div style={styles.successBox}>
              Import selesai. Berhasil:{" "}
              <strong>{importResult.successCount}</strong>, Gagal:{" "}
              <strong>{importResult.failedCount}</strong>
            </div>
          )}

          {fileInfo && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Informasi File</h3>
              <div style={styles.infoGrid}>
                <div>
                  <strong>Nama:</strong> {fileInfo.name}
                </div>
                <div>
                  <strong>Ukuran:</strong> {(fileInfo.size / 1024).toFixed(2)} KB
                </div>
                <div>
                  <strong>Tipe:</strong> {fileInfo.type}
                </div>
                <div>
                  <strong>Last Modified:</strong> {fileInfo.lastModified}
                </div>
              </div>
            </div>
          )}

          {sheetNames.length > 0 && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Pengaturan Konversi</h3>

              <div style={styles.controlRow}>
                <div style={styles.controlGroup}>
                  <label style={styles.label}>Pilih Sheet</label>
                  <select
                    value={selectedSheet}
                    onChange={handleSheetChange}
                    style={styles.select}
                  >
                    {sheetNames.map((sheet) => (
                      <option key={sheet} value={sheet}>
                        {sheet}
                      </option>
                    ))}
                  </select>
                </div>

                <div style={styles.controlGroup}>
                  <label style={styles.label}>Mode Header</label>
                  <select
                    value={headerMode}
                    onChange={handleHeaderModeChange}
                    style={styles.select}
                  >
                    <option value="auto">Auto Object</option>
                    <option value="custom-header">Baris Pertama Jadi Header</option>
                    <option value="array">Array 2D</option>
                  </select>
                </div>
              </div>

              <div style={styles.buttonRow}>
                <button
                  type="button"
                  style={styles.secondaryButton}
                  onClick={handleCopyJson}
                >
                  Copy JSON
                </button>

                <button
                  type="button"
                  style={styles.secondaryButton}
                  onClick={handleDownloadJson}
                >
                  Download JSON
                </button>

                <button
                  type="button"
                  style={{
                    ...styles.saveButton,
                    opacity: isSaving ? 0.7 : 1,
                    cursor: isSaving ? "not-allowed" : "pointer",
                  }}
                  onClick={handleSaveToDatabase}
                  disabled={isSaving}
                >
                  {isSaving ? "Menyimpan..." : "Simpan ke Database"}
                </button>

                <button
                  type="button"
                  style={styles.dangerButton}
                  onClick={resetAll}
                >
                  Reset
                </button>
              </div>
            </div>
          )}

          {rangePreview.length > 0 && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Preview Raw Sheet</h3>
              <div style={styles.tableWrapper}>
                <table style={styles.table}>
                  <tbody>
                    {rangePreview.map((row, rowIndex) => (
                      <tr key={rowIndex}>
                        {row.map((cell, cellIndex) => (
                          <td key={cellIndex} style={styles.td}>
                            {String(cell)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Preview Hasil JSON</h3>
            {renderTablePreview()}
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>JSON Output</h3>
            <textarea
              value={rawJsonText}
              readOnly
              style={styles.textarea}
              placeholder="Hasil JSON akan tampil di sini..."
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f5f7fb",
    padding: "24px",
    boxSizing: "border-box",
    fontFamily: "Arial, sans-serif",
  },
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
  },
  header: {
    marginBottom: "24px",
  },
  title: {
    margin: 0,
    fontSize: "28px",
    color: "#1f2937",
  },
  subtitle: {
    marginTop: "8px",
    color: "#6b7280",
    fontSize: "14px",
  },
  dropZone: {
    backgroundColor: "#ffffff",
    border: "2px dashed #cbd5e1",
    borderRadius: "12px",
    padding: "32px",
    textAlign: "center",
    marginBottom: "20px",
  },
  dropText: {
    marginBottom: "12px",
    color: "#334155",
    fontSize: "16px",
  },
  supportText: {
    marginTop: "12px",
    fontSize: "12px",
    color: "#64748b",
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: "12px",
    padding: "20px",
    marginBottom: "20px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
  },
  cardTitle: {
    marginTop: 0,
    marginBottom: "16px",
    fontSize: "18px",
    color: "#111827",
  },
  infoGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: "12px",
    color: "#374151",
    fontSize: "14px",
  },
  controlRow: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
    gap: "16px",
    marginBottom: "16px",
  },
  controlGroup: {
    display: "flex",
    flexDirection: "column",
  },
  label: {
    marginBottom: "8px",
    fontSize: "14px",
    fontWeight: "bold",
    color: "#374151",
  },
  select: {
    padding: "10px 12px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    fontSize: "14px",
    outline: "none",
  },
  buttonRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: "10px",
  },
  primaryButton: {
    backgroundColor: "#2563eb",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 18px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
  },
  secondaryButton: {
    backgroundColor: "#0f766e",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
  },
  saveButton: {
    backgroundColor: "#2563eb",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
  },
  dangerButton: {
    backgroundColor: "#dc2626",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
  },
  infoBox: {
    backgroundColor: "#e0f2fe",
    color: "#075985",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  successBox: {
    backgroundColor: "#dcfce7",
    color: "#166534",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  errorBox: {
    backgroundColor: "#fee2e2",
    color: "#991b1b",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  emptyBox: {
    padding: "20px",
    border: "1px dashed #cbd5e1",
    borderRadius: "8px",
    color: "#6b7280",
    textAlign: "center",
  },
  tableWrapper: {
    overflowX: "auto",
    border: "1px solid #e5e7eb",
    borderRadius: "8px",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: "13px",
  },
  th: {
    backgroundColor: "#f8fafc",
    borderBottom: "1px solid #e5e7eb",
    padding: "10px",
    textAlign: "left",
    whiteSpace: "nowrap",
  },
  td: {
    borderBottom: "1px solid #f1f5f9",
    padding: "10px",
    verticalAlign: "top",
    whiteSpace: "nowrap",
  },
  textarea: {
    width: "100%",
    minHeight: "360px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    padding: "12px",
    boxSizing: "border-box",
    fontFamily: "monospace",
    fontSize: "13px",
    resize: "vertical",
    outline: "none",
  },
};

export default ConverterExelP1;