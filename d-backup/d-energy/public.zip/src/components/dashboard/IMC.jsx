import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

/*
|--------------------------------------------------------------------------
| API CONFIG
|--------------------------------------------------------------------------
|
| .env frontend:
|
| VITE_API_URL=http://localhost:4100/api/imc
|
| Jika .env tidak dibuat, otomatis:
| http://localhost:4100/api/imc
|
*/

const API_BASE =
  import.meta.env.VITE_API_URL ||
  "http://localhost:4100/api/imc";


/*
|--------------------------------------------------------------------------
| MACHINE CONFIG
|--------------------------------------------------------------------------
*/

const MACHINE_LIST = [
  {
    id: "40",
    name: "IMC-40",
  },
  {
    id: "10",
    name: "IMC-10",
  },
  {
    id: "28",
    name: "IMC-28",
  },
  {
    id: "29",
    name: "IMC-29",
  },
];


/*
|--------------------------------------------------------------------------
| HELPER DATE
|--------------------------------------------------------------------------
*/

function pad(value) {
  return String(value).padStart(2, "0");
}


/*
|--------------------------------------------------------------------------
| DATETIME LOCAL VALUE
|--------------------------------------------------------------------------
|
| menghasilkan:
|
| 2026-08-13T07:00
|
*/

function toDateTimeLocal(date) {
  return (
    `${date.getFullYear()}-` +
    `${pad(date.getMonth() + 1)}-` +
    `${pad(date.getDate())}T` +
    `${pad(date.getHours())}:` +
    `${pad(date.getMinutes())}`
  );
}


/*
|--------------------------------------------------------------------------
| DEFAULT FROM
|--------------------------------------------------------------------------
|
| Hari ini jam 07:00
|
*/

function getDefaultFrom() {
  const now = new Date();

  now.setHours(7, 0, 0, 0);

  return toDateTimeLocal(now);
}


/*
|--------------------------------------------------------------------------
| DEFAULT TO
|--------------------------------------------------------------------------
|
| Waktu sekarang.
|
| Jika waktu sekarang masih sebelum 07:00,
| kita tetap pakai sekarang.
|
*/

function getDefaultTo() {
  return toDateTimeLocal(new Date());
}


/*
|--------------------------------------------------------------------------
| CONVERT DATETIME-LOCAL KE MYSQL FORMAT
|--------------------------------------------------------------------------
|
| input:
| 2026-08-13T07:00
|
| output:
| 2026-08-13 07:00:00
|
*/

function toMysqlDateTime(value) {
  if (!value) return "";

  const converted = value.replace("T", " ");

  return converted.length === 16
    ? `${converted}:00`
    : converted;
}


/*
|--------------------------------------------------------------------------
| FORMAT DATABASE DATETIME
|--------------------------------------------------------------------------
*/

function formatDateTime(value) {
  if (!value) {
    return "-";
  }

  const normalized =
    typeof value === "string"
      ? value.replace(" ", "T")
      : value;

  const date = new Date(normalized);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(date);
}


/*
|--------------------------------------------------------------------------
| FORMAT SHORT TIME
|--------------------------------------------------------------------------
*/

function formatTime(value) {
  if (!value) {
    return "-";
  }

  const normalized =
    typeof value === "string"
      ? value.replace(" ", "T")
      : value;

  const date = new Date(normalized);

  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return new Intl.DateTimeFormat("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(date);
}


/*
|--------------------------------------------------------------------------
| FETCH HELPER
|--------------------------------------------------------------------------
*/

async function apiFetch(url) {
  const response = await fetch(url);

  const body = await response.json();

  if (!response.ok) {
    throw new Error(
      body?.message ||
        body?.error ||
        `HTTP Error ${response.status}`
    );
  }

  return body;
}


/*
|--------------------------------------------------------------------------
| STATUS STYLE
|--------------------------------------------------------------------------
*/

function getMachineStatusStyle(status) {
  switch (String(status || "").toUpperCase()) {
    case "RUNNING":
      return {
        dot: "bg-emerald-500",
        badge:
          "bg-emerald-50 text-emerald-700 border-emerald-200",
        card:
          "border-emerald-200",
      };

    case "TROUBLE":
    case "FAULT":
      return {
        dot: "bg-red-500",
        badge:
          "bg-red-50 text-red-700 border-red-200",
        card:
          "border-red-200",
      };

    case "STOPPED":
      return {
        dot: "bg-slate-400",
        badge:
          "bg-slate-100 text-slate-600 border-slate-200",
        card:
          "border-slate-200",
      };

    default:
      return {
        dot: "bg-amber-400",
        badge:
          "bg-amber-50 text-amber-700 border-amber-200",
        card:
          "border-amber-200",
      };
  }
}


/*
|--------------------------------------------------------------------------
| HIGH LOW BADGE
|--------------------------------------------------------------------------
*/

function SignalBadge({
  value,
  highLabel = "HIGH",
  lowLabel = "LOW",
}) {
  const isHigh =
    String(value || "").toUpperCase() === "HIGH";

  return (
    <span
      className={[
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1",
        "text-xs font-semibold",
        isHigh
          ? "border-emerald-200 bg-emerald-50 text-emerald-700"
          : "border-slate-200 bg-slate-100 text-slate-600",
      ].join(" ")}
    >
      <span
        className={[
          "h-2 w-2 rounded-full",
          isHigh
            ? "bg-emerald-500"
            : "bg-slate-400",
        ].join(" ")}
      />

      {isHigh ? highLabel : lowLabel}
    </span>
  );
}


/*
|--------------------------------------------------------------------------
| DURATION DISPLAY
|--------------------------------------------------------------------------
*/

function Duration({
  value,
}) {
  if (!value) {
    return (
      <span className="text-slate-400">
        -
      </span>
    );
  }

  if (typeof value === "string") {
    return value;
  }

  return (
    <div>
      <div className="font-semibold text-slate-900">
        {value.formatted || "00:00:00"}
      </div>

      {value.hoursDecimal !== undefined && (
        <div className="mt-0.5 text-xs text-slate-400">
          {value.hoursDecimal} jam
        </div>
      )}
    </div>
  );
}


/*
|--------------------------------------------------------------------------
| LOADING
|--------------------------------------------------------------------------
*/

function LoadingBlock({
  text = "Memuat data...",
}) {
  return (
    <div className="flex min-h-[180px] items-center justify-center">
      <div className="flex items-center gap-3 text-sm text-slate-500">
        <div className="h-5 w-5 animate-spin rounded-full border-2 border-slate-300 border-t-slate-700" />

        {text}
      </div>
    </div>
  );
}


/*
|--------------------------------------------------------------------------
| ERROR BOX
|--------------------------------------------------------------------------
*/

function ErrorBox({
  message,
}) {
  if (!message) return null;

  return (
    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
      {message}
    </div>
  );
}


/*
|--------------------------------------------------------------------------
| MACHINE CARD
|--------------------------------------------------------------------------
*/

function MachineCard({
  machine,
  summary,
  selected,
  onSelect,
}) {
  const style =
    getMachineStatusStyle(machine.status);

  return (
    <button
      type="button"
      onClick={onSelect}
      className={[
        "w-full rounded-2xl border bg-white p-5 text-left",
        "shadow-sm transition-all duration-200",
        "hover:-translate-y-0.5 hover:shadow-md",
        selected
          ? "ring-2 ring-blue-500 ring-offset-2"
          : "",
        style.card,
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">
            Machine
          </div>

          <h2 className="mt-1 text-xl font-bold text-slate-900">
            {machine.machine}
          </h2>
        </div>

        <span
          className={[
            "inline-flex items-center gap-2 rounded-full border px-3 py-1.5",
            "text-xs font-bold",
            style.badge,
          ].join(" ")}
        >
          <span
            className={[
              "h-2.5 w-2.5 rounded-full",
              style.dot,
              machine.status === "RUNNING"
                ? "animate-pulse"
                : "",
            ].join(" ")}
          />

          {machine.status || "UNKNOWN"}
        </span>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-slate-50 p-3">
          <div className="text-xs text-slate-400">
            RUN
          </div>

          <div className="mt-2">
            <SignalBadge
              value={machine.runStatus}
            />
          </div>
        </div>

        <div className="rounded-xl bg-slate-50 p-3">
          <div className="text-xs text-slate-400">
            TROUBLE
          </div>

          <div className="mt-2">
            <SignalBadge
              value={machine.troubleStatus}
            />
          </div>
        </div>
      </div>

      {summary && (
        <div className="mt-4 grid grid-cols-3 divide-x divide-slate-200 rounded-xl border border-slate-100 bg-white py-3">
          <div className="px-2 text-center">
            <div className="text-[11px] text-slate-400">
              Running
            </div>

            <div className="mt-1 text-sm font-bold text-slate-800">
              {summary.running?.formatted ||
                summary.runningHours ||
                "-"}
            </div>
          </div>

          <div className="px-2 text-center">
            <div className="text-[11px] text-slate-400">
              Trouble
            </div>

            <div className="mt-1 text-sm font-bold text-red-600">
              {summary.trouble?.formatted ||
                summary.troubleHours ||
                "-"}
            </div>
          </div>

          <div className="px-2 text-center">
            <div className="text-[11px] text-slate-400">
              Qty
            </div>

            <div className="mt-1 text-sm font-bold text-blue-600">
              {summary.quantity ?? 0}
            </div>
          </div>
        </div>
      )}

      <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4 text-xs">
        <span className="text-slate-400">
          Last Signal
        </span>

        <span className="font-medium text-slate-600">
          {formatTime(machine.lastSignal)}
        </span>
      </div>
    </button>
  );
}


/*
|--------------------------------------------------------------------------
| MAIN COMPONENT
|--------------------------------------------------------------------------
*/

export default function IMC() {
  /*
  |--------------------------------------------------------------------------
  | DATE FILTER
  |--------------------------------------------------------------------------
  */

  const [from, setFrom] =
    useState(getDefaultFrom);

  const [to, setTo] =
    useState(getDefaultTo);


  /*
  |--------------------------------------------------------------------------
  | STATUS
  |--------------------------------------------------------------------------
  */

  const [machines, setMachines] =
    useState([]);

  const [statusLoading, setStatusLoading] =
    useState(true);

  const [statusError, setStatusError] =
    useState("");


  /*
  |--------------------------------------------------------------------------
  | SUMMARY
  |--------------------------------------------------------------------------
  */

  const [summary, setSummary] =
    useState([]);

  const [summaryLoading, setSummaryLoading] =
    useState(true);

  const [summaryError, setSummaryError] =
    useState("");


  /*
  |--------------------------------------------------------------------------
  | SELECTED MACHINE
  |--------------------------------------------------------------------------
  */

  const [
    selectedMachine,
    setSelectedMachine,
  ] = useState("40");


  /*
  |--------------------------------------------------------------------------
  | HISTORY
  |--------------------------------------------------------------------------
  */

  const [
    historyType,
    setHistoryType,
  ] = useState("run");

  const [
    historyLimit,
    setHistoryLimit,
  ] = useState(100);

  const [history, setHistory] =
    useState([]);

  const [historyLoading, setHistoryLoading] =
    useState(true);

  const [historyError, setHistoryError] =
    useState("");


  /*
  |--------------------------------------------------------------------------
  | LAST REFRESH
  |--------------------------------------------------------------------------
  */

  const [
    lastRefresh,
    setLastRefresh,
  ] = useState(null);


  /*
  |--------------------------------------------------------------------------
  | FETCH STATUS
  |--------------------------------------------------------------------------
  */

  const fetchStatus = useCallback(
    async ({
      silent = false,
    } = {}) => {
      try {
        if (!silent) {
          setStatusLoading(true);
        }

        setStatusError("");

        const result =
          await apiFetch(
            `${API_BASE}/status`
          );

        setMachines(
          Array.isArray(result.data)
            ? result.data
            : []
        );

        setLastRefresh(new Date());
      } catch (error) {
        console.error(
          "FETCH STATUS ERROR:",
          error
        );

        setStatusError(error.message);
      } finally {
        if (!silent) {
          setStatusLoading(false);
        }
      }
    },
    []
  );


  /*
  |--------------------------------------------------------------------------
  | FETCH SUMMARY
  |--------------------------------------------------------------------------
  */

  const fetchSummary =
    useCallback(async () => {
      if (!from || !to) return;

      try {
        setSummaryLoading(true);
        setSummaryError("");

        const params =
          new URLSearchParams({
            from: toMysqlDateTime(from),
            to: toMysqlDateTime(to),
          });

        const result =
          await apiFetch(
            `${API_BASE}/summary?${params.toString()}`
          );

        setSummary(
          Array.isArray(result.data)
            ? result.data
            : []
        );
      } catch (error) {
        console.error(
          "FETCH SUMMARY ERROR:",
          error
        );

        setSummaryError(error.message);
      } finally {
        setSummaryLoading(false);
      }
    }, [from, to]);


  /*
  |--------------------------------------------------------------------------
  | FETCH HISTORY
  |--------------------------------------------------------------------------
  */

  const fetchHistory =
    useCallback(async () => {
      if (!selectedMachine) return;

      try {
        setHistoryLoading(true);
        setHistoryError("");

        const params =
          new URLSearchParams({
            type: historyType,
            limit: String(historyLimit),
          });

        const result =
          await apiFetch(
            `${API_BASE}/${selectedMachine}/history?${params.toString()}`
          );

        setHistory(
          Array.isArray(result.data)
            ? result.data
            : []
        );
      } catch (error) {
        console.error(
          "FETCH HISTORY ERROR:",
          error
        );

        setHistoryError(error.message);
      } finally {
        setHistoryLoading(false);
      }
    }, [
      selectedMachine,
      historyType,
      historyLimit,
    ]);


  /*
  |--------------------------------------------------------------------------
  | INITIAL DATA
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);


  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);


  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);


  /*
  |--------------------------------------------------------------------------
  | AUTO REFRESH STATUS - 5 SECOND
  |--------------------------------------------------------------------------
  */

  useEffect(() => {
    const timer =
      setInterval(() => {
        fetchStatus({
          silent: true,
        });
      }, 5000);

    return () =>
      clearInterval(timer);
  }, [fetchStatus]);


  /*
  |--------------------------------------------------------------------------
  | SUMMARY MAP
  |--------------------------------------------------------------------------
  */

  const summaryMap =
    useMemo(() => {
      const map = {};

      summary.forEach((item) => {
        map[String(item.id)] =
          item;

        if (item.machine) {
          map[item.machine] =
            item;
        }
      });

      return map;
    }, [summary]);


  /*
  |--------------------------------------------------------------------------
  | CURRENT SELECTED STATUS
  |--------------------------------------------------------------------------
  */

  const selectedStatus =
    useMemo(() => {
      return (
        machines.find(
          (item) =>
            String(item.id) ===
              String(selectedMachine) ||
            item.machine ===
              `IMC-${selectedMachine}`
        ) || null
      );
    }, [
      machines,
      selectedMachine,
    ]);


  /*
  |--------------------------------------------------------------------------
  | CURRENT SELECTED SUMMARY
  |--------------------------------------------------------------------------
  */

  const selectedSummary =
    useMemo(() => {
      return (
        summaryMap[
          String(selectedMachine)
        ] ||
        summaryMap[
          `IMC-${selectedMachine}`
        ] ||
        null
      );
    }, [
      summaryMap,
      selectedMachine,
    ]);


  /*
  |--------------------------------------------------------------------------
  | OVERALL STATS
  |--------------------------------------------------------------------------
  */

  const totalRunning =
    useMemo(() => {
      return machines.filter(
        (item) =>
          item.status === "RUNNING"
      ).length;
    }, [machines]);


  const totalTrouble =
    useMemo(() => {
      return machines.filter(
        (item) =>
          item.troubleStatus ===
            "HIGH" ||
          item.status === "TROUBLE"
      ).length;
    }, [machines]);


  const totalQuantity =
    useMemo(() => {
      return summary.reduce(
        (total, item) =>
          total +
          Number(
            item.quantity || 0
          ),
        0
      );
    }, [summary]);


  /*
  |--------------------------------------------------------------------------
  | REFRESH ALL
  |--------------------------------------------------------------------------
  */

  async function refreshAll() {
    await Promise.all([
      fetchStatus(),
      fetchSummary(),
      fetchHistory(),
    ]);
  }


  /*
  |--------------------------------------------------------------------------
  | APPLY PERIOD
  |--------------------------------------------------------------------------
  */

  function applyPeriod() {
    fetchSummary();
  }


  /*
  |--------------------------------------------------------------------------
  | RENDER
  |--------------------------------------------------------------------------
  */

  return (
    <div className="min-h-screen bg-slate-50">
      {/* ============================================================= */}
      {/* HEADER                                                        */}
      {/* ============================================================= */}

      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-4 py-5 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">

            <div>
              <div className="flex items-center gap-3">

                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-600 text-lg font-bold text-white shadow-sm">
                  IMC
                </div>

                <div>
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                    IMC Machine Monitoring
                  </h1>

                  <p className="mt-1 text-sm text-slate-500">
                    Real-time machine running,
                    trouble, running hour dan
                    quantity
                  </p>
                </div>
              </div>
            </div>


            <div className="flex flex-wrap items-end gap-3">

              {/* FROM */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-500">
                  Dari
                </label>

                <input
                  type="datetime-local"
                  value={from}
                  onChange={(e) =>
                    setFrom(
                      e.target.value
                    )
                  }
                  className="rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                />
              </div>


              {/* TO */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-500">
                  Sampai
                </label>

                <input
                  type="datetime-local"
                  value={to}
                  onChange={(e) =>
                    setTo(
                      e.target.value
                    )
                  }
                  className="rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                />
              </div>


              <button
                type="button"
                onClick={applyPeriod}
                className="rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-700"
              >
                Terapkan
              </button>


              <button
                type="button"
                onClick={refreshAll}
                className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
              >
                Refresh
              </button>
            </div>
          </div>


          {/* LAST UPDATE */}
          <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
            <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />

            Auto refresh setiap 5 detik

            <span>•</span>

            Update terakhir:

            <span className="font-medium text-slate-600">
              {lastRefresh
                ? lastRefresh.toLocaleTimeString(
                    "id-ID"
                  )
                : "-"}
            </span>
          </div>
        </div>
      </div>


      {/* ============================================================= */}
      {/* CONTENT                                                       */}
      {/* ============================================================= */}

      <main className="mx-auto max-w-[1600px] space-y-6 px-4 py-6 sm:px-6 lg:px-8">

        <ErrorBox
          message={
            statusError ||
            summaryError
          }
        />


        {/* =========================================================== */}
        {/* KPI                                                         */}
        {/* =========================================================== */}

        <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">

          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="text-sm font-medium text-slate-500">
              Total Machine
            </div>

            <div className="mt-2 text-3xl font-bold text-slate-900">
              {machines.length ||
                MACHINE_LIST.length}
            </div>

            <div className="mt-2 text-xs text-slate-400">
              IMC Monitoring
            </div>
          </div>


          <div className="rounded-2xl border border-emerald-200 bg-white p-5 shadow-sm">
            <div className="text-sm font-medium text-slate-500">
              Running
            </div>

            <div className="mt-2 text-3xl font-bold text-emerald-600">
              {totalRunning}
            </div>

            <div className="mt-2 flex items-center gap-1.5 text-xs text-emerald-600">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
              Machine Running
            </div>
          </div>


          <div className="rounded-2xl border border-red-200 bg-white p-5 shadow-sm">
            <div className="text-sm font-medium text-slate-500">
              Trouble
            </div>

            <div className="mt-2 text-3xl font-bold text-red-600">
              {totalTrouble}
            </div>

            <div className="mt-2 text-xs text-red-500">
              Active Trouble
            </div>
          </div>


          <div className="rounded-2xl border border-blue-200 bg-white p-5 shadow-sm">
            <div className="text-sm font-medium text-slate-500">
              Total Quantity
            </div>

            <div className="mt-2 text-3xl font-bold text-blue-600">
              {totalQuantity.toLocaleString(
                "id-ID"
              )}
            </div>

            <div className="mt-2 text-xs text-slate-400">
              Periode terpilih
            </div>
          </div>
        </section>


        {/* =========================================================== */}
        {/* MACHINE CARDS                                               */}
        {/* =========================================================== */}

        <section>
          <div className="mb-4 flex items-end justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Machine Status
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                Klik machine untuk melihat
                detail history.
              </p>
            </div>
          </div>


          {statusLoading ? (
            <LoadingBlock />
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {machines.map(
                (machine) => {
                  const id =
                    String(
                      machine.id ||
                        machine.machine?.replace(
                          "IMC-",
                          ""
                        )
                    );

                  const machineSummary =
                    summaryMap[id] ||
                    summaryMap[
                      machine.machine
                    ];

                  return (
                    <MachineCard
                      key={
                        machine.machine
                      }
                      machine={
                        machine
                      }
                      summary={
                        machineSummary
                      }
                      selected={
                        selectedMachine ===
                        id
                      }
                      onSelect={() =>
                        setSelectedMachine(
                          id
                        )
                      }
                    />
                  );
                }
              )}
            </div>
          )}
        </section>


        {/* =========================================================== */}
        {/* SUMMARY TABLE                                               */}
        {/* =========================================================== */}

        <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

          <div className="border-b border-slate-200 px-5 py-4">
            <h2 className="font-bold text-slate-900">
              Production Summary
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Running hour, trouble dan
              quantity pada periode yang
              dipilih.
            </p>
          </div>


          {summaryLoading ? (
            <LoadingBlock />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px]">

                <thead className="bg-slate-50">
                  <tr className="border-b border-slate-200 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
                    <th className="px-5 py-3">
                      Machine
                    </th>

                    <th className="px-5 py-3">
                      Run Status
                    </th>

                    <th className="px-5 py-3">
                      Trouble
                    </th>

                    <th className="px-5 py-3">
                      Running Hour
                    </th>

                    <th className="px-5 py-3">
                      Trouble Duration
                    </th>

                    <th className="px-5 py-3 text-right">
                      Quantity
                    </th>
                  </tr>
                </thead>


                <tbody>
                  {summary.map(
                    (item) => (
                      <tr
                        key={
                          item.id ||
                          item.machine
                        }
                        className="border-b border-slate-100 transition last:border-0 hover:bg-slate-50"
                      >
                        <td className="px-5 py-4">
                          <div className="font-bold text-slate-900">
                            {
                              item.machine
                            }
                          </div>
                        </td>

                        <td className="px-5 py-4">
                          <SignalBadge
                            value={
                              item.runStatus
                            }
                          />
                        </td>

                        <td className="px-5 py-4">
                          <SignalBadge
                            value={
                              item.troubleStatus
                            }
                          />
                        </td>

                        <td className="px-5 py-4">
                          <Duration
                            value={
                              item.running
                            }
                          />
                        </td>

                        <td className="px-5 py-4">
                          <Duration
                            value={
                              item.trouble
                            }
                          />
                        </td>

                        <td className="px-5 py-4 text-right text-lg font-bold text-blue-600">
                          {Number(
                            item.quantity ||
                              0
                          ).toLocaleString(
                            "id-ID"
                          )}
                        </td>
                      </tr>
                    )
                  )}


                  {summary.length ===
                    0 && (
                    <tr>
                      <td
                        colSpan={6}
                        className="px-5 py-10 text-center text-sm text-slate-400"
                      >
                        Belum ada data
                        summary.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </section>


        {/* =========================================================== */}
        {/* DETAIL MACHINE                                              */}
        {/* =========================================================== */}

        <section className="grid gap-6 xl:grid-cols-[340px_minmax(0,1fr)]">

          {/* LEFT */}
          <div className="space-y-4">

            {/* SELECT MACHINE */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">

              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Selected Machine
              </div>

              <select
                value={
                  selectedMachine
                }
                onChange={(e) =>
                  setSelectedMachine(
                    e.target.value
                  )
                }
                className="mt-3 w-full rounded-xl border border-slate-300 bg-white px-3 py-3 font-semibold text-slate-800 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              >
                {MACHINE_LIST.map(
                  (item) => (
                    <option
                      key={item.id}
                      value={item.id}
                    >
                      {item.name}
                    </option>
                  )
                )}
              </select>


              {selectedStatus && (
                <div className="mt-5 space-y-4">

                  <div>
                    <div className="text-xs text-slate-400">
                      Machine Status
                    </div>

                    <div className="mt-2">
                      <span
                        className={[
                          "inline-flex items-center gap-2 rounded-full border px-3 py-1.5",
                          "text-sm font-bold",
                          getMachineStatusStyle(
                            selectedStatus.status
                          ).badge,
                        ].join(
                          " "
                        )}
                      >
                        <span
                          className={[
                            "h-2.5 w-2.5 rounded-full",
                            getMachineStatusStyle(
                              selectedStatus.status
                            ).dot,
                          ].join(
                            " "
                          )}
                        />

                        {
                          selectedStatus.status
                        }
                      </span>
                    </div>
                  </div>


                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-xl bg-slate-50 p-3">
                      <div className="text-xs text-slate-400">
                        RUN
                      </div>

                      <div className="mt-2">
                        <SignalBadge
                          value={
                            selectedStatus.runStatus
                          }
                        />
                      </div>
                    </div>

                    <div className="rounded-xl bg-slate-50 p-3">
                      <div className="text-xs text-slate-400">
                        TROUBLE
                      </div>

                      <div className="mt-2">
                        <SignalBadge
                          value={
                            selectedStatus.troubleStatus
                          }
                        />
                      </div>
                    </div>
                  </div>


                  <div className="border-t border-slate-100 pt-4">
                    <div className="text-xs text-slate-400">
                      Last Signal
                    </div>

                    <div className="mt-1 text-sm font-medium text-slate-700">
                      {formatDateTime(
                        selectedStatus.lastSignal
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>


            {/* PERIOD SUMMARY */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">

              <div className="text-sm font-bold text-slate-900">
                Period Summary
              </div>

              {selectedSummary ? (
                <div className="mt-4 space-y-4">

                  <div className="rounded-xl bg-emerald-50 p-4">
                    <div className="text-xs font-medium text-emerald-600">
                      Running Hour
                    </div>

                    <div className="mt-1 text-xl font-bold text-emerald-700">
                      {selectedSummary
                        .running
                        ?.formatted ||
                        "-"}
                    </div>
                  </div>


                  <div className="rounded-xl bg-red-50 p-4">
                    <div className="text-xs font-medium text-red-500">
                      Trouble Duration
                    </div>

                    <div className="mt-1 text-xl font-bold text-red-600">
                      {selectedSummary
                        .trouble
                        ?.formatted ||
                        "-"}
                    </div>
                  </div>


                  <div className="rounded-xl bg-blue-50 p-4">
                    <div className="text-xs font-medium text-blue-500">
                      Quantity
                    </div>

                    <div className="mt-1 text-2xl font-bold text-blue-700">
                      {Number(
                        selectedSummary.quantity ||
                          0
                      ).toLocaleString(
                        "id-ID"
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="mt-4 text-sm text-slate-400">
                  Summary belum
                  tersedia.
                </div>
              )}
            </div>
          </div>


          {/* RIGHT / HISTORY */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

            <div className="flex flex-col gap-4 border-b border-slate-200 p-5 lg:flex-row lg:items-center lg:justify-between">

              <div>
                <h2 className="font-bold text-slate-900">
                  {
                    MACHINE_LIST.find(
                      (item) =>
                        item.id ===
                        selectedMachine
                    )?.name
                  }{" "}
                  History
                </h2>

                <p className="mt-1 text-sm text-slate-500">
                  History perubahan
                  status machine.
                </p>
              </div>


              <div className="flex flex-wrap gap-2">

                {[
                  {
                    id: "main",
                    label: "Main",
                  },
                  {
                    id: "run",
                    label: "Run",
                  },
                  {
                    id: "trouble",
                    label:
                      "Trouble",
                  },
                ].map(
                  (item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() =>
                        setHistoryType(
                          item.id
                        )
                      }
                      className={[
                        "rounded-lg px-3 py-2 text-xs font-semibold transition",
                        historyType ===
                        item.id
                          ? "bg-slate-900 text-white"
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                      ].join(
                        " "
                      )}
                    >
                      {item.label}
                    </button>
                  )
                )}


                <select
                  value={
                    historyLimit
                  }
                  onChange={(e) =>
                    setHistoryLimit(
                      Number(
                        e.target.value
                      )
                    )
                  }
                  className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-600 outline-none"
                >
                  <option value={50}>
                    50 data
                  </option>

                  <option value={100}>
                    100 data
                  </option>

                  <option value={250}>
                    250 data
                  </option>

                  <option value={500}>
                    500 data
                  </option>
                </select>
              </div>
            </div>


            <ErrorBox
              message={
                historyError
              }
            />


            {historyLoading ? (
              <LoadingBlock
                text="Memuat history..."
              />
            ) : (
              <div className="max-h-[650px] overflow-auto">
                <table className="w-full min-w-[680px]">

                  <thead className="sticky top-0 z-10 bg-slate-50">
                    <tr className="border-b border-slate-200 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">

                      <th className="px-5 py-3">
                        ID
                      </th>

                      <th className="px-5 py-3">
                        Date / Time
                      </th>

                      <th className="px-5 py-3">
                        Machine
                      </th>

                      <th className="px-5 py-3">
                        Status
                      </th>
                    </tr>
                  </thead>


                  <tbody>
                    {history.map(
                      (row) => (
                        <tr
                          key={row.id}
                          className="border-b border-slate-100 transition last:border-0 hover:bg-slate-50"
                        >
                          <td className="px-5 py-3 text-sm text-slate-400">
                            #{row.id}
                          </td>

                          <td className="px-5 py-3">
                            <div className="text-sm font-medium text-slate-700">
                              {formatDateTime(
                                row.created_at
                              )}
                            </div>
                          </td>

                          <td className="px-5 py-3 text-sm font-semibold text-slate-700">
                            {
                              row.name_line
                            }
                          </td>

                          <td className="px-5 py-3">
                            {historyType ===
                            "main" ? (
                              <span
                                className={[
                                  "inline-flex rounded-full border px-2.5 py-1 text-xs font-bold",
                                  getMachineStatusStyle(
                                    row.status
                                  ).badge,
                                ].join(
                                  " "
                                )}
                              >
                                {
                                  row.status
                                }
                              </span>
                            ) : (
                              <SignalBadge
                                value={
                                  row.status
                                }
                              />
                            )}
                          </td>
                        </tr>
                      )
                    )}


                    {history.length ===
                      0 && (
                      <tr>
                        <td
                          colSpan={4}
                          className="px-5 py-12 text-center text-sm text-slate-400"
                        >
                          Belum ada
                          data history.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </section>


        {/* =========================================================== */}
        {/* FOOTER                                                      */}
        {/* =========================================================== */}

        <div className="pb-4 pt-2 text-center text-xs text-slate-400">
          IMC Machine Monitoring System
        </div>
      </main>
    </div>
  );
}