import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Container } from 'react-bootstrap';
import axios from 'axios';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  LabelList,
  Legend,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import * as XLSX from 'xlsx';
import Nais_Layout from '../layout/Layout';

const API_ROOT = '/api';

const KUB_SHIFTLY_API_URL = `${API_ROOT}/pm-shiftly-kub-kwh`;
const KUB_MONTHLY_API_URL = `${API_ROOT}/pm-monthly-kub-kwh`;
const KUBIKAL_PRIMARY_LINE = 'tb_kub1_total_kwh';

const COMPRESSORS = [
  {
    key: 'comp19',
    label: 'PANEL 19',
    japaneseLabel: 'パネル19',
    lineTable: 'tb_comp_19',
    shiftly: `${API_ROOT}/comp19Shiftly`,
    monthly: `${API_ROOT}/comp19Monthly`,
  },
  {
    key: 'comp20',
    label: 'PANEL 20',
    japaneseLabel: 'パネル20',
    lineTable: 'tb_comp_20',
    shiftly: `${API_ROOT}/comp20Shiftly`,
    monthly: `${API_ROOT}/comp20Monthly`,
  },
  {
    key: 'comp21',
    label: 'PANEL 21',
    japaneseLabel: 'パネル21',
    lineTable: 'tb_comp_21',
    shiftly: `${API_ROOT}/comp21Shiftly`,
    monthly: `${API_ROOT}/comp21Monthly`,
  },
  {
    key: 'comp24',
    label: 'PANEL 24',
    japaneseLabel: 'パネル24',
    lineTable: 'tb_comp_24',
    shiftly: `${API_ROOT}/comp24Shiftly`,
    monthly: `${API_ROOT}/comp24Monthly`,
  },
];

const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92;
const SHIFTLY_RAW_TO_KWH_DIVISOR = 1000;
const MONTHLY_RAW_TO_KWH_DIVISOR = 1000;
const REFRESH_INTERVAL_MS = 5 * 60 * 1000;

const MONTHS = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

const MONTH_NUMBER_BY_NAME = {
  januari: 1,
  january: 1,
  februari: 2,
  february: 2,
  maret: 3,
  march: 3,
  april: 4,
  mei: 5,
  may: 5,
  juni: 6,
  june: 6,
  juli: 7,
  july: 7,
  agustus: 8,
  august: 8,
  september: 9,
  oktober: 10,
  october: 10,
  november: 11,
  desember: 12,
  december: 12,
};

const PIE_COLORS = ['#0f5fa8', '#14b8a6', '#f59e0b', '#8b5cf6', '#ef4444'];
const DEFAULT_MONTHLY_BAR_COLOR = '#0284c7';
const PARTIAL_MONTH_BAR_COLOR = '#f97316';
const PARETO_BAR_COLOR = '#0ea5e9';
const PARETO_LINE_COLOR = '#dc2626';

const toNumber = (value) => {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
};

const getMonthNumber = (value) => {
  const numericValue = toNumber(value);
  if (numericValue >= 1 && numericValue <= 12) return numericValue;
  return MONTH_NUMBER_BY_NAME[String(value || '').trim().toLowerCase()] || 0;
};

const numberFormatter = new Intl.NumberFormat('id-ID', {
  maximumFractionDigits: 0,
});

const decimalFormatter = new Intl.NumberFormat('id-ID', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

const currencyFormatter = new Intl.NumberFormat('id-ID', {
  style: 'currency',
  currency: 'IDR',
  maximumFractionDigits: 0,
});

const formatNumber = (value) => numberFormatter.format(toNumber(value));
const formatDecimal = (value) => decimalFormatter.format(toNumber(value));
const formatCurrency = (value) => currencyFormatter.format(toNumber(value));
const toShiftlyKwh = (value) =>
  toNumber(value) / SHIFTLY_RAW_TO_KWH_DIVISOR;
const toMonthlyKwh = (value) =>
  toNumber(value) / MONTHLY_RAW_TO_KWH_DIVISOR;

const normalizeShift = (value) => {
  const normalized = String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');

  if (normalized === 'SHIFT 1' || normalized.endsWith(' 1')) return 'shift1';
  if (normalized === 'SHIFT 2' || normalized.endsWith(' 2')) return 'shift2';
  return null;
};

const parseDate = (value) => {
  if (!value) return new Date(0);
  return new Date(`${String(value).slice(0, 10)}T00:00:00`);
};

const formatLineLabel = (lineTable, lineName) =>
  String(lineName || lineTable || '-')
    .replace(/^tb_/, '')
    .replace(/_total_kwh$/i, '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());

const extractApiRecords = (response, endpointLabel) => {
  const payload = response?.data;

  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data)) return payload.data;

  throw new Error(`Format respons ${endpointLabel} tidak valid.`);
};

const normalizeRecords = (records, source) =>
  records.map((item) => ({
    ...item,
    source_key: source.key,
    source_label: source.label,
    line_table: item?.line_table || source.lineTable,
    line_name: item?.line_name || source.label,
  }));

const getLatestShiftRecord = (records) =>
  records
    .slice()
    .sort((a, b) => parseDate(b.shift_date) - parseDate(a.shift_date))[0] || null;

const getLatestMonthlyRecord = (records) =>
  records
    .slice()
    .sort((a, b) => {
      const yearDifference = toNumber(b.year) - toNumber(a.year);
      if (yearDifference !== 0) return yearDifference;
      return (
        getMonthNumber(b.month || b.month_name) -
        getMonthNumber(a.month || a.month_name)
      );
    })[0] || null;

const buildDailyData = (records, monthNumber, year) => {
  const grouped = new Map();

  records
    .filter(
      (item) =>
        getMonthNumber(item.month || item.month_name) === monthNumber &&
        toNumber(item.year) === toNumber(year)
    )
    .forEach((item) => {
      const dateKey = String(item.shift_date || '').slice(0, 10);
      const shiftKey = normalizeShift(item.shift);
      if (!dateKey || !shiftKey) return;

      if (!grouped.has(dateKey)) {
        grouped.set(dateKey, {
          dateKey,
          date: `${item.day_name || ''}, ${item.day || ''} ${String(
            item.month_name || MONTHS[monthNumber - 1] || ''
          ).slice(0, 3)}`,
          shift1: 0,
          shift2: 0,
        });
      }

      grouped.get(dateKey)[shiftKey] += toShiftlyKwh(item.total_kwh);
    });

  return [...grouped.values()]
    .sort((a, b) => parseDate(a.dateKey) - parseDate(b.dateKey))
    .map((item) => ({
      ...item,
      shift1: Number(item.shift1.toFixed(2)),
      shift2: Number(item.shift2.toFixed(2)),
      total: Number((item.shift1 + item.shift2).toFixed(2)),
    }));
};

const buildMonthlyData = (records, year, throughMonthNumber) => {
  const grouped = new Map();

  records
    .filter((item) => {
      const monthNumber = getMonthNumber(item.month || item.month_name);
      return (
        toNumber(item.year) === toNumber(year) &&
        monthNumber >= 1 &&
        monthNumber <= throughMonthNumber
      );
    })
    .forEach((item) => {
      const monthNumber = getMonthNumber(item.month || item.month_name);
      const monthName = MONTHS[monthNumber - 1] || item.month_name || '-';
      const key = `${year}-${String(monthNumber).padStart(2, '0')}`;

      if (!grouped.has(key)) {
        grouped.set(key, {
          key,
          year: toNumber(year),
          month: monthNumber,
          monthName,
          period: monthName.slice(0, 3),
          kwh: 0,
          rawTotalKwh: 0,
        });
      }

      const group = grouped.get(key);
      const rawTotalKwh = toNumber(item.total_kwh);
      group.rawTotalKwh += rawTotalKwh;
      group.kwh += toMonthlyKwh(rawTotalKwh);
    });

  return [...grouped.values()]
    .sort((a, b) => a.month - b.month)
    .map((item) => ({
      ...item,
      kwh: Number(item.kwh.toFixed(2)),
    }));
};

const sumMonthlyPeriod = (records, monthNumber, year) =>
  records
    .filter(
      (item) =>
        getMonthNumber(item.month || item.month_name) === monthNumber &&
        toNumber(item.year) === toNumber(year)
    )
    .reduce((sum, item) => sum + toMonthlyKwh(item.total_kwh), 0);

const SummaryCard = ({
  icon,
  title,
  japaneseTitle,
  subtitle,
  value,
  accent,
}) => (
  <div
    style={{
      backgroundColor: '#fff',
      padding: '12px',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(15, 23, 42, 0.08)',
      border: '1px solid #edf2f7',
      minHeight: '122px',
    }}
  >
    <div
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '7px',
        marginBottom: '5px',
      }}
    >
      <span style={{ fontSize: '20px' }}>{icon}</span>
      <div>
        <div style={{ fontSize: '14px', fontWeight: 700, color: accent }}>
          {title}
        </div>
        <div
          lang="ja"
          style={{
            marginTop: '1px',
            fontSize: '11px',
            lineHeight: 1.25,
            fontWeight: 600,
            color: '#64748b',
          }}
        >
          {japaneseTitle}
        </div>
      </div>
    </div>
    <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>
      {subtitle}
    </div>
    <div
      style={{
        fontSize: '20px',
        lineHeight: 1.25,
        fontWeight: 800,
        color: '#1e293b',
        wordBreak: 'break-word',
      }}
    >
      {value}
    </div>
  </div>
);

const BilingualHeading = ({ title, japaneseTitle, icon, color = '#1e293b' }) => (
  <div>
    <div style={{ fontWeight: 800, color }}>
      {icon ? `${icon} ` : ''}
      {title}
    </div>
    <div
      lang="ja"
      style={{ marginTop: '1px', fontSize: '11px', color: '#64748b' }}
    >
      {japaneseTitle}
    </div>
  </div>
);

const EmptyChart = ({ message = 'Tidak ada data untuk filter yang dipilih.' }) => (
  <div
    style={{
      height: '250px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '24px',
      textAlign: 'center',
      color: '#64748b',
      fontSize: '13px',
    }}
  >
    {message}
  </div>
);

const MonthlyChartCard = ({
  title,
  japaneseTitle,
  data,
  sourceText,
  large = false,
  highlightPartialFebruary2026 = false,
}) => (
  <div
    style={{
      backgroundColor: '#fff',
      border: '1px solid #e2e8f0',
      borderRadius: '9px',
      padding: '12px',
      minWidth: 0,
    }}
  >
    <BilingualHeading title={title} japaneseTitle={japaneseTitle} />
    <div style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 8px' }}>
      {sourceText}
    </div>

    {highlightPartialFebruary2026 &&
      data.some((item) => item.month === 2 && item.year === 2026) && (
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            marginBottom: '7px',
            padding: '5px 8px',
            borderRadius: '6px',
            backgroundColor: '#fff7ed',
            color: '#c2410c',
            fontSize: '11px',
          }}
        >
          <span
            style={{
              width: '10px',
              height: '10px',
              borderRadius: '2px',
              backgroundColor: PARTIAL_MONTH_BAR_COLOR,
            }}
          />
          Februari 2026 merupakan data parsial karena pengambilan data tidak dimulai
          dari awal bulan.
        </div>
      )}

    {data.length ? (
      <div style={{ width: '100%', height: large ? '320px' : '280px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{ top: 28, right: 18, left: 8, bottom: 8 }}
          >
            <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
            <XAxis dataKey="period" tick={{ fontSize: 11 }} interval={0} />
            <YAxis
              tick={{ fontSize: 11 }}
              tickFormatter={formatNumber}
              label={{
                value: 'kWh',
                angle: -90,
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontWeight: 700 },
              }}
            />
            <Tooltip
              formatter={(value) => [`${formatDecimal(value)} kWh`, 'Konsumsi']}
              labelFormatter={(label) => `Bulan: ${label}`}
              contentStyle={{
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
              }}
            />
            <Bar
              dataKey="kwh"
              fill={DEFAULT_MONTHLY_BAR_COLOR}
              radius={[4, 4, 0, 0]}
              name="Konsumsi (kWh)"
            >
              {data.map((item) => (
                <Cell
                  key={item.key}
                  fill={
                    highlightPartialFebruary2026 &&
                    item.month === 2 &&
                    item.year === 2026
                      ? PARTIAL_MONTH_BAR_COLOR
                      : DEFAULT_MONTHLY_BAR_COLOR
                  }
                />
              ))}
              <LabelList
                dataKey="kwh"
                position="top"
                formatter={formatNumber}
                fill="#334155"
                fontSize={10}
                fontWeight="bold"
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    ) : (
      <EmptyChart />
    )}
  </div>
);

const ParetoChartCard = ({
  title,
  japaneseTitle,
  data,
  periodText,
  isPartialFebruary2026 = false,
}) => (
  <div
    style={{
      backgroundColor: '#fff',
      border: '1px solid #e2e8f0',
      borderRadius: '9px',
      padding: '12px',
      minWidth: 0,
    }}
  >
    <BilingualHeading title={title} japaneseTitle={japaneseTitle} />
    <div style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 8px' }}>
      {periodText}
    </div>

    {isPartialFebruary2026 && (
      <div
        style={{
          marginBottom: '7px',
          padding: '6px 8px',
          borderRadius: '6px',
          backgroundColor: '#fff7ed',
          color: '#c2410c',
          fontSize: '11px',
        }}
      >
        Batang oranye menandai Februari 2026 sebagai data parsial, bukan konsumsi
        satu bulan penuh.
      </div>
    )}

    {data.length ? (
      <div style={{ width: '100%', height: '330px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            data={data}
            margin={{ top: 28, right: 20, left: 8, bottom: 8 }}
          >
            <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
            <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} />
            <YAxis
              yAxisId="left"
              tick={{ fontSize: 11 }}
              tickFormatter={formatNumber}
              label={{
                value: 'kWh',
                angle: -90,
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontWeight: 700 },
              }}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              domain={[0, 100]}
              tick={{ fontSize: 11 }}
              tickFormatter={(value) => `${value}%`}
            />
            <Tooltip
              formatter={(value, name) =>
                name === 'Kumulatif (%)'
                  ? [`${formatDecimal(value)}%`, name]
                  : [`${formatDecimal(value)} kWh`, name]
              }
              contentStyle={{
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
              }}
            />
            <Legend verticalAlign="top" height={28} />
            <Bar
              yAxisId="left"
              dataKey="value"
              name="Konsumsi (kWh)"
              fill={isPartialFebruary2026 ? PARTIAL_MONTH_BAR_COLOR : PARETO_BAR_COLOR}
              radius={[4, 4, 0, 0]}
            >
              <LabelList
                dataKey="value"
                position="top"
                formatter={formatNumber}
                fill="#334155"
                fontSize={10}
                fontWeight="bold"
              />
            </Bar>
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="cumulativePercent"
              name="Kumulatif (%)"
              stroke={PARETO_LINE_COLOR}
              strokeWidth={2.5}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    ) : (
      <EmptyChart message="Data compressor belum tersedia untuk membuat Pareto." />
    )}
  </div>
);

const DailyChartCard = ({
  title,
  japaneseTitle,
  data,
  sourceText,
  chartKey,
  large = false,
}) => {
  const gradientShift1 = `gradientShift1-${chartKey}`;
  const gradientShift2 = `gradientShift2-${chartKey}`;

  return (
    <div
      style={{
        backgroundColor: '#fff',
        border: '1px solid #e2e8f0',
        borderRadius: '9px',
        padding: '12px',
        minWidth: 0,
      }}
    >
      <BilingualHeading title={title} japaneseTitle={japaneseTitle} />
      <div style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 8px' }}>
        {sourceText}
      </div>

      {data.length ? (
        <div style={{ width: '100%', height: large ? '340px' : '300px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 28, right: 18, left: 8, bottom: 5 }}
            >
              <defs>
                <linearGradient id={gradientShift1} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#14b8a6" stopOpacity={1} />
                  <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.55} />
                </linearGradient>
                <linearGradient id={gradientShift2} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f46e5" stopOpacity={1} />
                  <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.55} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
              <XAxis
                dataKey="dateKey"
                tick={{ fontSize: 11 }}
                tickFormatter={(value) => {
                  const [, month, day] = String(value).split('-');
                  return `${day}/${month}`;
                }}
              />
              <YAxis
                tick={{ fontSize: 11 }}
                tickFormatter={formatNumber}
                label={{
                  value: 'kWh',
                  angle: -90,
                  position: 'insideLeft',
                  style: { textAnchor: 'middle', fontWeight: 700 },
                }}
              />
              <Tooltip
                formatter={(value, name) => [
                  `${formatDecimal(value)} kWh`,
                  name,
                ]}
                labelFormatter={(_, payload) =>
                  payload?.[0]?.payload?.date || '-'
                }
                contentStyle={{
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                }}
              />
              <Legend verticalAlign="top" height={28} />
              <Bar
                dataKey="shift1"
                fill={`url(#${gradientShift1})`}
                name="Shift 1"
                radius={[4, 4, 0, 0]}
              />
              <Bar
                dataKey="shift2"
                fill={`url(#${gradientShift2})`}
                name="Shift 2"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <EmptyChart />
      )}
    </div>
  );
};

const FilterSelect = ({ label, japaneseLabel, children }) => (
  <label
    style={{
      display: 'flex',
      flexDirection: 'column',
      gap: '3px',
      fontSize: '11px',
      color: '#64748b',
    }}
  >
    <span>
      {label}
      <span lang="ja" style={{ marginLeft: '5px', color: '#94a3b8' }}>
        {japaneseLabel}
      </span>
    </span>
    {children}
  </label>
);

const selectStyle = {
  padding: '7px 10px',
  borderRadius: '7px',
  border: '1px solid #cbd5e1',
  backgroundColor: '#fff',
  fontSize: '13px',
  minWidth: '120px',
};

const MainDashboardListrik = () => {
  const requestControllerRef = useRef(null);
  const initialSelectionDoneRef = useRef(false);

  const [kubShiftlyRaw, setKubShiftlyRaw] = useState([]);
  const [kubMonthlyRaw, setKubMonthlyRaw] = useState([]);
  const [compressorShiftlyRaw, setCompressorShiftlyRaw] = useState([]);
  const [compressorMonthlyRaw, setCompressorMonthlyRaw] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [lastFetchedAt, setLastFetchedAt] = useState(null);

  const now = new Date();
  const currentMonthNumber = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const [selectedLine, setSelectedLine] = useState(KUBIKAL_PRIMARY_LINE);
  const [monthlyMonth, setMonthlyMonth] = useState(currentMonthNumber);
  const [monthlyYear, setMonthlyYear] = useState(currentYear);
  const [shiftMonth, setShiftMonth] = useState(currentMonthNumber);
  const [shiftYear, setShiftYear] = useState(currentYear);
  const [showKubikal, setShowKubikal] = useState(true);
  const [showCompressor, setShowCompressor] = useState(true);

  const fetchData = useCallback(async (initialLoad = false) => {
    requestControllerRef.current?.abort();
    const controller = new AbortController();
    requestControllerRef.current = controller;

    if (initialLoad) setLoading(true);
    else setRefreshing(true);
    setError('');

    const requestConfig = {
      signal: controller.signal,
      timeout: 20000,
      params: { timestamp: Date.now() },
      headers: { 'Cache-Control': 'no-cache' },
    };

    const requestDefinitions = [
      {
        id: 'kub-shiftly',
        type: 'kubShiftly',
        label: KUB_SHIFTLY_API_URL,
        promise: axios.get(KUB_SHIFTLY_API_URL, requestConfig),
      },
      {
        id: 'kub-monthly',
        type: 'kubMonthly',
        label: KUB_MONTHLY_API_URL,
        promise: axios.get(KUB_MONTHLY_API_URL, requestConfig),
      },
      ...COMPRESSORS.flatMap((compressor) => [
        {
          id: `${compressor.key}-shiftly`,
          type: 'compressorShiftly',
          label: compressor.shiftly,
          compressor,
          promise: axios.get(compressor.shiftly, requestConfig),
        },
        {
          id: `${compressor.key}-monthly`,
          type: 'compressorMonthly',
          label: compressor.monthly,
          compressor,
          promise: axios.get(compressor.monthly, requestConfig),
        },
      ]),
    ];

    try {
      const settled = await Promise.allSettled(
        requestDefinitions.map((definition) => definition.promise)
      );

      if (controller.signal.aborted) return;

      const nextKubShiftly = [];
      const nextKubMonthly = [];
      const nextCompressorShiftly = [];
      const nextCompressorMonthly = [];
      const failedEndpoints = [];

      settled.forEach((result, index) => {
        const definition = requestDefinitions[index];

        if (result.status === 'rejected') {
          const reason = result.reason;
          if (
            axios.isCancel(reason) ||
            reason?.name === 'CanceledError' ||
            reason?.name === 'AbortError'
          ) {
            return;
          }
          failedEndpoints.push(definition.label);
          return;
        }

        try {
          const records = extractApiRecords(result.value, definition.label);

          if (definition.type === 'kubShiftly') {
            nextKubShiftly.push(
              ...records.filter((item) => item?.line_table && item?.shift_date)
            );
          } else if (definition.type === 'kubMonthly') {
            nextKubMonthly.push(
              ...records.filter((item) => item?.line_table && item?.month && item?.year)
            );
          } else if (definition.type === 'compressorShiftly') {
            nextCompressorShiftly.push(
              ...normalizeRecords(records, definition.compressor).filter(
                (item) => item?.shift_date
              )
            );
          } else if (definition.type === 'compressorMonthly') {
            nextCompressorMonthly.push(
              ...normalizeRecords(records, definition.compressor).filter(
                (item) => item?.month && item?.year
              )
            );
          }
        } catch (parseError) {
          console.error(parseError);
          failedEndpoints.push(definition.label);
        }
      });

      const totalRecordCount =
        nextKubShiftly.length +
        nextKubMonthly.length +
        nextCompressorShiftly.length +
        nextCompressorMonthly.length;

      if (!totalRecordCount && !controller.signal.aborted) {
        throw new Error('Seluruh endpoint dashboard gagal memberikan data.');
      }

      setKubShiftlyRaw(nextKubShiftly);
      setKubMonthlyRaw(nextKubMonthly);
      setCompressorShiftlyRaw(nextCompressorShiftly);
      setCompressorMonthlyRaw(nextCompressorMonthly);
      setLastFetchedAt(new Date());

      if (failedEndpoints.length) {
        setError(`Sebagian endpoint gagal dimuat: ${failedEndpoints.join(', ')}`);
      }

      if (!initialSelectionDoneRef.current) {
        const preferredLineExists = [...nextKubShiftly, ...nextKubMonthly].some(
          (item) => item.line_table === KUBIKAL_PRIMARY_LINE
        );
        const firstKubRecord = nextKubShiftly[0] || nextKubMonthly[0];
        setSelectedLine(
          preferredLineExists
            ? KUBIKAL_PRIMARY_LINE
            : firstKubRecord?.line_table || KUBIKAL_PRIMARY_LINE
        );

        const latestMonthly = getLatestMonthlyRecord([
          ...nextKubMonthly,
          ...nextCompressorMonthly,
        ]);
        const latestShift = getLatestShiftRecord([
          ...nextKubShiftly,
          ...nextCompressorShiftly,
        ]);

        setMonthlyMonth(
          getMonthNumber(latestMonthly?.month || latestMonthly?.month_name) ||
            currentMonthNumber
        );
        setMonthlyYear(toNumber(latestMonthly?.year) || currentYear);
        setShiftMonth(
          getMonthNumber(latestShift?.month || latestShift?.month_name) ||
            currentMonthNumber
        );
        setShiftYear(toNumber(latestShift?.year) || currentYear);
        initialSelectionDoneRef.current = true;
      }
    } catch (err) {
      if (
        axios.isCancel(err) ||
        err?.name === 'CanceledError' ||
        err?.name === 'AbortError'
      ) {
        return;
      }

      console.error('Gagal memuat dashboard energi gabungan:', err);
      setError(
        err?.response?.data?.message ||
          err?.message ||
          'Gagal memuat data dashboard.'
      );
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, [currentMonthNumber, currentYear]);

  useEffect(() => {
    fetchData(true);

    const intervalId = window.setInterval(() => {
      fetchData(false);
    }, REFRESH_INTERVAL_MS);

    return () => {
      window.clearInterval(intervalId);
      requestControllerRef.current?.abort();
    };
  }, [fetchData]);

  const lineOptions = useMemo(() => {
    const map = new Map();

    [...kubShiftlyRaw, ...kubMonthlyRaw].forEach((item) => {
      if (!map.has(item.line_table)) {
        map.set(
          item.line_table,
          formatLineLabel(item.line_table, item.line_name)
        );
      }
    });

    return [...map.entries()]
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label, 'id-ID'));
  }, [kubShiftlyRaw, kubMonthlyRaw]);

  const selectedLineLabel =
    lineOptions.find((item) => item.value === selectedLine)?.label || 'Kubikal';

  const monthlyYearOptions = useMemo(
    () =>
      [
        ...new Set(
          [...kubMonthlyRaw, ...compressorMonthlyRaw]
            .map((item) => toNumber(item.year))
            .filter(Boolean)
        ),
      ].sort((a, b) => b - a),
    [kubMonthlyRaw, compressorMonthlyRaw]
  );

  const shiftYearOptions = useMemo(
    () =>
      [
        ...new Set(
          [...kubShiftlyRaw, ...compressorShiftlyRaw]
            .map((item) => toNumber(item.year))
            .filter(Boolean)
        ),
      ].sort((a, b) => b - a),
    [kubShiftlyRaw, compressorShiftlyRaw]
  );

  const monthlyMonthOptions = useMemo(() => {
    const available = new Set(
      [...kubMonthlyRaw, ...compressorMonthlyRaw]
        .filter((item) => toNumber(item.year) === toNumber(monthlyYear))
        .map((item) => getMonthNumber(item.month || item.month_name))
        .filter(Boolean)
    );
    return MONTHS.map((name, index) => ({ name, number: index + 1 })).filter(
      (item) => available.has(item.number)
    );
  }, [kubMonthlyRaw, compressorMonthlyRaw, monthlyYear]);

  const shiftMonthOptions = useMemo(() => {
    const available = new Set(
      [...kubShiftlyRaw, ...compressorShiftlyRaw]
        .filter((item) => toNumber(item.year) === toNumber(shiftYear))
        .map((item) => getMonthNumber(item.month || item.month_name))
        .filter(Boolean)
    );
    return MONTHS.map((name, index) => ({ name, number: index + 1 })).filter(
      (item) => available.has(item.number)
    );
  }, [kubShiftlyRaw, compressorShiftlyRaw, shiftYear]);

  useEffect(() => {
    if (
      monthlyMonthOptions.length &&
      !monthlyMonthOptions.some((item) => item.number === monthlyMonth)
    ) {
      setMonthlyMonth(monthlyMonthOptions[monthlyMonthOptions.length - 1].number);
    }
  }, [monthlyMonthOptions, monthlyMonth]);

  useEffect(() => {
    if (
      shiftMonthOptions.length &&
      !shiftMonthOptions.some((item) => item.number === shiftMonth)
    ) {
      setShiftMonth(shiftMonthOptions[shiftMonthOptions.length - 1].number);
    }
  }, [shiftMonthOptions, shiftMonth]);

  const selectedKubShiftlyRecords = useMemo(
    () => kubShiftlyRaw.filter((item) => item.line_table === selectedLine),
    [kubShiftlyRaw, selectedLine]
  );

  const selectedKubMonthlyRecords = useMemo(
    () => kubMonthlyRaw.filter((item) => item.line_table === selectedLine),
    [kubMonthlyRaw, selectedLine]
  );

  const kubDailyData = useMemo(
    () => buildDailyData(selectedKubShiftlyRecords, shiftMonth, shiftYear),
    [selectedKubShiftlyRecords, shiftMonth, shiftYear]
  );

  const kubMonthlyData = useMemo(
    () => buildMonthlyData(selectedKubMonthlyRecords, monthlyYear, monthlyMonth),
    [selectedKubMonthlyRecords, monthlyYear, monthlyMonth]
  );

  const compressorDailyData = useMemo(() => {
    const result = {};
    COMPRESSORS.forEach((compressor) => {
      result[compressor.key] = buildDailyData(
        compressorShiftlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        shiftMonth,
        shiftYear
      );
    });
    return result;
  }, [compressorShiftlyRaw, shiftMonth, shiftYear]);

  const compressorMonthlyData = useMemo(() => {
    const result = {};
    COMPRESSORS.forEach((compressor) => {
      result[compressor.key] = buildMonthlyData(
        compressorMonthlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        monthlyYear,
        monthlyMonth
      );
    });
    return result;
  }, [compressorMonthlyRaw, monthlyYear, monthlyMonth]);

  const monthlyCompressorPareto = useMemo(() => {
    const ranked = COMPRESSORS.map((compressor) => ({
      key: compressor.key,
      name: compressor.label,
      value: sumMonthlyPeriod(
        compressorMonthlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        monthlyMonth,
        monthlyYear
      ),
    }))
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value);

    const total = ranked.reduce((sum, item) => sum + item.value, 0);
    let cumulative = 0;

    return ranked.map((item) => {
      cumulative += item.value;
      return {
        ...item,
        value: Number(item.value.toFixed(2)),
        cumulativePercent: total
          ? Number(((cumulative / total) * 100).toFixed(2))
          : 0,
      };
    });
  }, [compressorMonthlyRaw, monthlyMonth, monthlyYear]);

  const shiftlyCompressorPareto = useMemo(() => {
    const ranked = COMPRESSORS.map((compressor) => ({
      key: compressor.key,
      name: compressor.label,
      value: (compressorDailyData[compressor.key] || []).reduce(
        (sum, item) => sum + item.total,
        0
      ),
    }))
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value);

    const total = ranked.reduce((sum, item) => sum + item.value, 0);
    let cumulative = 0;

    return ranked.map((item) => {
      cumulative += item.value;
      return {
        ...item,
        value: Number(item.value.toFixed(2)),
        cumulativePercent: total
          ? Number(((cumulative / total) * 100).toFixed(2))
          : 0,
      };
    });
  }, [compressorDailyData]);

  const metrics = useMemo(() => {
    const totalShift1 = kubDailyData.reduce(
      (sum, item) => sum + item.shift1,
      0
    );
    const totalShift2 = kubDailyData.reduce(
      (sum, item) => sum + item.shift2,
      0
    );
    const totalKwh = totalShift1 + totalShift2;
    const daysCount = kubDailyData.length;
    const avgDaily = daysCount ? totalKwh / daysCount : 0;
    const peakValue = kubDailyData.length
      ? Math.max(
          ...kubDailyData.flatMap((item) => [item.shift1, item.shift2])
        )
      : 0;

    return {
      totalShift1,
      totalShift2,
      totalKwh,
      avgDaily,
      peakValue,
      totalCost: totalKwh * COST_PER_KWH,
      totalCo2: totalKwh * CO2_EMISSION_FACTOR,
      daysCount,
    };
  }, [kubDailyData]);

  const pieCalculation = useMemo(() => {
    const kubikalRecords = kubMonthlyRaw.filter(
      (item) => item.line_table === KUBIKAL_PRIMARY_LINE
    );
    const baseRecords = kubikalRecords.length
      ? kubikalRecords
      : selectedKubMonthlyRecords;

    const kubikal = sumMonthlyPeriod(baseRecords, monthlyMonth, monthlyYear);
    const compressorValues = COMPRESSORS.map((compressor) => ({
      key: compressor.key,
      name: compressor.label,
      value: sumMonthlyPeriod(
        compressorMonthlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        monthlyMonth,
        monthlyYear
      ),
    }));
    const compressorTotal = compressorValues.reduce(
      (sum, item) => sum + item.value,
      0
    );
    const oticsNetRaw = kubikal - compressorTotal;
    const oticsNet = Math.max(oticsNetRaw, 0);

    return {
      kubikal,
      compressorValues,
      compressorTotal,
      oticsNetRaw,
      data: [
        { name: 'WH Otics', value: Number(oticsNet.toFixed(2)) },
        ...compressorValues.map((item) => ({
          name: item.name,
          value: Number(item.value.toFixed(2)),
        })),
      ].filter((item) => item.value > 0),
    };
  }, [
    kubMonthlyRaw,
    selectedKubMonthlyRecords,
    compressorMonthlyRaw,
    monthlyMonth,
    monthlyYear,
  ]);

  const latestApiUpdate = useMemo(() => {
    const timestamps = [
      ...kubShiftlyRaw,
      ...kubMonthlyRaw,
      ...compressorShiftlyRaw,
      ...compressorMonthlyRaw,
    ]
      .map((item) =>
        new Date(String(item.updated_at || item.created_at || '').replace(' ', 'T'))
      )
      .filter((date) => !Number.isNaN(date.getTime()));

    if (!timestamps.length) return null;
    return new Date(Math.max(...timestamps.map((date) => date.getTime())));
  }, [
    kubShiftlyRaw,
    kubMonthlyRaw,
    compressorShiftlyRaw,
    compressorMonthlyRaw,
  ]);

  const exportToExcel = () => {
    const workbook = XLSX.utils.book_new();

    const appendSheet = (name, rows) => {
      const worksheet = XLSX.utils.json_to_sheet(rows);
      worksheet['!cols'] = Array.from({ length: 15 }, () => ({ wch: 18 }));
      XLSX.utils.book_append_sheet(workbook, worksheet, name.slice(0, 31));
    };

    const shiftRows = (records) =>
      records
        .filter(
          (item) =>
            getMonthNumber(item.month || item.month_name) === shiftMonth &&
            toNumber(item.year) === toNumber(shiftYear)
        )
        .map((item) => ({
          Tanggal: item.shift_date,
          Hari: item.day_name,
          Shift: item.shift,
          Line: item.line_name,
          'Mulai Shift': item.shift_start_datetime,
          'Akhir Shift': item.shift_end_datetime,
          'Start Meter': toNumber(item.start_kwh),
          'End Meter': toNumber(item.end_kwh),
          'Energi (kWh)': Number(toShiftlyKwh(item.total_kwh).toFixed(2)),
        }));

    const monthlyRows = (records) =>
      records
        .filter(
          (item) =>
            toNumber(item.year) === toNumber(monthlyYear) &&
            getMonthNumber(item.month || item.month_name) <= monthlyMonth
        )
        .map((item) => ({
          Tahun: item.year,
          Bulan: item.month_name || MONTHS[getMonthNumber(item.month) - 1],
          Line: item.line_name,
          'Tanggal Awal': item.month_start_date,
          'Tanggal Akhir': item.month_end_date,
          'Start Meter': toNumber(item.start_kwh),
          'End Meter': toNumber(item.end_kwh),
          'Energi (kWh)': Number(toMonthlyKwh(item.total_kwh).toFixed(2)),
        }));

    appendSheet('Kubikal Shiftly', shiftRows(selectedKubShiftlyRecords));
    appendSheet('Kubikal Monthly', monthlyRows(selectedKubMonthlyRecords));

    COMPRESSORS.forEach((compressor) => {
      appendSheet(
        `${compressor.label} Shiftly`,
        shiftRows(
          compressorShiftlyRaw.filter(
            (item) => item.source_key === compressor.key
          )
        )
      );
      appendSheet(
        `${compressor.label} Monthly`,
        monthlyRows(
          compressorMonthlyRaw.filter(
            (item) => item.source_key === compressor.key
          )
        )
      );
    });

    appendSheet('Total WH Otics', [
      {
        Periode: `${MONTHS[monthlyMonth - 1]} ${monthlyYear}`,
        'Kubikal (kWh)': Number(pieCalculation.kubikal.toFixed(2)),
        'Comp 19 (kWh)': Number(
          (pieCalculation.compressorValues[0]?.value || 0).toFixed(2)
        ),
        'Comp 20 (kWh)': Number(
          (pieCalculation.compressorValues[1]?.value || 0).toFixed(2)
        ),
        'Comp 21 (kWh)': Number(
          (pieCalculation.compressorValues[2]?.value || 0).toFixed(2)
        ),
        'Comp 24 (kWh)': Number(
          (pieCalculation.compressorValues[3]?.value || 0).toFixed(2)
        ),
        'Total WH Otics (kWh)': Number(pieCalculation.oticsNetRaw.toFixed(2)),
      },
    ]);

    XLSX.writeFile(
      workbook,
      `Energy_Gabungan_${MONTHS[monthlyMonth - 1]}_${monthlyYear}.xlsx`
    );
  };

  if (loading) {
    return (
      <Nais_Layout>
        <Container fluid className="p-1">
          <div style={{ padding: '24px', fontSize: '14px', color: '#475569' }}>
            Memuat dashboard energi gabungan...
          </div>
        </Container>
      </Nais_Layout>
    );
  }

  return (
    <Nais_Layout>
      <Container fluid className="p-1">
        <div
          style={{
            padding: '14px',
            fontFamily: 'Segoe UI, Arial, sans-serif',
            minHeight: '100%',
            background: '#f8fafc',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              gap: '12px',
              flexWrap: 'wrap',
              marginBottom: '12px',
            }}
          >
            <div>
              <h2
                style={{
                  color: '#0f5fa8',
                  margin: 0,
                  fontSize: '21px',
                  fontWeight: 800,
                }}
              >
                ⚡ Otics Indonesia Energy Dashboard — {selectedLineLabel}
              </h2>
              <div
                lang="ja"
                style={{ marginTop: '2px', fontSize: '12px', color: '#64748b' }}
              >
                オティックス・インドネシア エネルギーダッシュボード
              </div>
              <p style={{ margin: '4px 0 0', fontSize: '13px', color: '#64748b' }}>
                Dashboard gabungan Kubikal dan Compressor Panel 19, 20, 21, dan 24
              </p>
              <div style={{ marginTop: '5px', fontSize: '12px', color: '#94a3b8' }}>
                API diperbarui:{' '}
                {latestApiUpdate ? latestApiUpdate.toLocaleString('id-ID') : '-'}
                {' · '}Dashboard mengambil data:{' '}
                {lastFetchedAt ? lastFetchedAt.toLocaleString('id-ID') : '-'}
              </div>
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'flex-end',
                gap: '8px',
                flexWrap: 'wrap',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '6px',
                  border: '1px solid #cbd5e1',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                }}
              >
                <span style={{ fontSize: '11px', color: '#64748b', padding: '0 3px' }}>
                  Show / Hide
                </span>
                <button
                  type="button"
                  onClick={() => setShowKubikal((current) => !current)}
                  style={{
                    padding: '6px 9px',
                    border: showKubikal ? '1px solid #2563eb' : '1px solid #cbd5e1',
                    borderRadius: '6px',
                    backgroundColor: showKubikal ? '#dbeafe' : '#f8fafc',
                    color: showKubikal ? '#1d4ed8' : '#64748b',
                    cursor: 'pointer',
                    fontSize: '12px',
                    fontWeight: 700,
                  }}
                >
                  {showKubikal ? '✓ ' : ''}Kubikal
                </button>
                <button
                  type="button"
                  onClick={() => setShowCompressor((current) => !current)}
                  style={{
                    padding: '6px 9px',
                    border: showCompressor
                      ? '1px solid #ea580c'
                      : '1px solid #cbd5e1',
                    borderRadius: '6px',
                    backgroundColor: showCompressor ? '#ffedd5' : '#f8fafc',
                    color: showCompressor ? '#c2410c' : '#64748b',
                    cursor: 'pointer',
                    fontSize: '12px',
                    fontWeight: 700,
                  }}
                >
                  {showCompressor ? '✓ ' : ''}Compressor
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowKubikal(true);
                    setShowCompressor(true);
                  }}
                  style={{
                    padding: '6px 8px',
                    border: '1px solid #cbd5e1',
                    borderRadius: '6px',
                    backgroundColor: '#fff',
                    color: '#475569',
                    cursor: 'pointer',
                    fontSize: '12px',
                  }}
                >
                  Semua
                </button>
              </div>

              {showKubikal && (
              <FilterSelect label="Sumber Kubikal" japaneseLabel="キュービカル">
                <select
                  value={selectedLine}
                  onChange={(event) => setSelectedLine(event.target.value)}
                  style={selectStyle}
                >
                  {lineOptions.map((line) => (
                    <option key={line.value} value={line.value}>
                      {line.label}
                    </option>
                  ))}
                </select>
              </FilterSelect>
              )}

              <button
                type="button"
                onClick={() => fetchData(false)}
                disabled={refreshing}
                style={{
                  padding: '8px 11px',
                  border: 'none',
                  borderRadius: '7px',
                  backgroundColor: '#2563eb',
                  color: '#fff',
                  cursor: refreshing ? 'not-allowed' : 'pointer',
                  opacity: refreshing ? 0.65 : 1,
                  fontSize: '13px',
                  fontWeight: 600,
                }}
              >
                {refreshing ? 'Memperbarui...' : '↻ Refresh'}
              </button>

              <button
                type="button"
                onClick={exportToExcel}
                style={{
                  padding: '8px 11px',
                  border: 'none',
                  borderRadius: '7px',
                  backgroundColor: '#16a34a',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: 600,
                }}
              >
                📊 Export Excel
              </button>
            </div>
          </div>

          {error && (
            <div
              style={{
                padding: '10px 12px',
                marginBottom: '12px',
                borderRadius: '7px',
                border: '1px solid #fed7aa',
                backgroundColor: '#fff7ed',
                color: '#c2410c',
                fontSize: '13px',
              }}
            >
              {error}
            </div>
          )}

          {showKubikal && (
          <>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(165px, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <SummaryCard
              icon="⚡"
              title="Total Energy"
              japaneseTitle="全エネルギー"
              subtitle={`${MONTHS[shiftMonth - 1]} ${shiftYear}`}
              value={`${formatDecimal(metrics.totalKwh)} kWh`}
              accent="#0284c7"
            />
            <SummaryCard
              icon="💰"
              title="Estimated Cost"
              japaneseTitle="推定コスト"
              subtitle={`Tarif ${formatCurrency(COST_PER_KWH)}/kWh`}
              value={formatCurrency(metrics.totalCost)}
              accent="#d97706"
            />
            <SummaryCard
              icon="📈"
              title="Daily Average"
              japaneseTitle="1日平均"
              subtitle={`${metrics.daysCount} hari tercatat`}
              value={`${formatDecimal(metrics.avgDaily)} kWh`}
              accent="#16a34a"
            />
            <SummaryCard
              icon="☀️"
              title="Shift 1 Total"
              japaneseTitle="シフト1合計"
              subtitle="SHIFT 1"
              value={`${formatDecimal(metrics.totalShift1)} kWh`}
              accent="#0891b2"
            />
            <SummaryCard
              icon="🌙"
              title="Shift 2 Total"
              japaneseTitle="シフト2合計"
              subtitle="SHIFT 2"
              value={`${formatDecimal(metrics.totalShift2)} kWh`}
              accent="#4f46e5"
            />
            <SummaryCard
              icon="⬆️"
              title="Peak Shift"
              japaneseTitle="最大シフト"
              subtitle="Nilai shift tertinggi"
              value={`${formatDecimal(metrics.peakValue)} kWh`}
              accent="#dc2626"
            />
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                padding: '13px',
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
            >
              <BilingualHeading
                icon="🔥"
                title="CO₂ Emissions Summary"
                japaneseTitle="CO₂排出量概要"
                color="#dc2626"
              />
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '8px',
                  textAlign: 'center',
                  marginTop: '9px',
                }}
              >
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Monthly</div>
                  <strong>{formatDecimal(metrics.totalCo2)} kg</strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Daily Avg</div>
                  <strong>
                    {formatDecimal(
                      metrics.daysCount ? metrics.totalCo2 / metrics.daysCount : 0
                    )}{' '}
                    kg
                  </strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Projection</div>
                  <strong>{formatDecimal(metrics.totalCo2 * 12)} kg</strong>
                </div>
              </div>
            </div>

            <div
              style={{
                padding: '13px',
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
            >
              <BilingualHeading
                icon="💰"
                title="Cost Analysis"
                japaneseTitle="コスト分析"
                color="#d97706"
              />
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '8px',
                  textAlign: 'center',
                  marginTop: '9px',
                }}
              >
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Monthly</div>
                  <strong>{formatCurrency(metrics.totalCost)}</strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Daily Avg</div>
                  <strong>
                    {formatCurrency(
                      metrics.daysCount ? metrics.totalCost / metrics.daysCount : 0
                    )}
                  </strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Per kWh</div>
                  <strong>{formatCurrency(COST_PER_KWH)}</strong>
                </div>
              </div>
            </div>
          </div>
          </>
          )}

          <div
            style={{
              backgroundColor: '#eef6ff',
              border: '1px solid #bfdbfe',
              borderRadius: '9px',
              padding: '12px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-end',
                gap: '10px',
                flexWrap: 'wrap',
              }}
            >
              <BilingualHeading
                title="Filter Bulanan"
                japaneseTitle="月間フィルター"
                color="#0f5fa8"
              />
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <FilterSelect label="Bulan" japaneseLabel="月">
                  <select
                    value={monthlyMonth}
                    onChange={(event) => setMonthlyMonth(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {monthlyMonthOptions.length ? (
                      monthlyMonthOptions.map((month) => (
                        <option key={month.number} value={month.number}>
                          {month.name}
                        </option>
                      ))
                    ) : (
                      <option value={monthlyMonth}>{MONTHS[monthlyMonth - 1]}</option>
                    )}
                  </select>
                </FilterSelect>
                <FilterSelect label="Tahun" japaneseLabel="年">
                  <select
                    value={monthlyYear}
                    onChange={(event) => setMonthlyYear(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {monthlyYearOptions.length ? (
                      monthlyYearOptions.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))
                    ) : (
                      <option value={monthlyYear}>{monthlyYear}</option>
                    )}
                  </select>
                </FilterSelect>
              </div>
            </div>
          </div>

          <div style={{ marginBottom: '12px' }}>
            <div style={{ marginBottom: '8px' }}>
              <BilingualHeading
                title="Tren Konsumsi Energi Bulanan"
                japaneseTitle="月間エネルギー消費傾向"
                color="#0f5fa8"
              />
              <div style={{ marginTop: '3px', fontSize: '12px', color: '#64748b' }}>
                Menampilkan Januari sampai {MONTHS[monthlyMonth - 1]} {monthlyYear}
              </div>
            </div>

            {showKubikal && (
              <MonthlyChartCard
                title={`Kubikal — ${selectedLineLabel}`}
                japaneseTitle="キュービカル月間エネルギー"
                data={kubMonthlyData}
                sourceText={KUB_MONTHLY_API_URL}
                large
              />
            )}

            {showCompressor && (
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))',
                gap: '10px',
                marginTop: '10px',
              }}
            >
              {COMPRESSORS.map((compressor) => (
                <MonthlyChartCard
                  key={compressor.key}
                  title={`Monthly ${compressor.label}`}
                  japaneseTitle={`${compressor.japaneseLabel} 月間エネルギー`}
                  data={compressorMonthlyData[compressor.key] || []}
                  sourceText={compressor.monthly}
                  highlightPartialFebruary2026
                />
              ))}
            </div>
            )}

            {showCompressor && (
              <div style={{ marginTop: '10px' }}>
                <ParetoChartCard
                  title="Pareto Monthly Compressor"
                  japaneseTitle="コンプレッサー月間パレート分析"
                  data={monthlyCompressorPareto}
                  periodText={`Periode ${MONTHS[monthlyMonth - 1]} ${monthlyYear}`}
                  isPartialFebruary2026={
                    monthlyMonth === 2 && monthlyYear === 2026
                  }
                />
              </div>
            )}
          </div>

          {showKubikal && showCompressor && (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '9px',
                padding: '12px',
                minWidth: 0,
              }}
            >
              <BilingualHeading
                title="Total WH Otics"
                japaneseTitle="OTICS総電力量"
                color="#0f5fa8"
              />
              <div style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>
                Periode {MONTHS[monthlyMonth - 1]} {monthlyYear}
              </div>
              <div style={{ width: '100%', height: '330px' }}>
                {pieCalculation.data.length ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieCalculation.data}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="46%"
                        outerRadius={105}
                        label={({ name, percent }) =>
                          `${name} ${(percent * 100).toFixed(1)}%`
                        }
                      >
                        {pieCalculation.data.map((entry, index) => (
                          <Cell
                            key={`${entry.name}-${index}`}
                            fill={PIE_COLORS[index % PIE_COLORS.length]}
                          />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(value, name) => [
                          `${formatDecimal(value)} kWh`,
                          name,
                        ]}
                      />
                      <Legend verticalAlign="bottom" />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <EmptyChart message="Data monthly belum tersedia untuk membuat pie chart." />
                )}
              </div>
            </div>

            <div
              style={{
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '9px',
                padding: '14px',
              }}
            >
              <BilingualHeading
                title="Perhitungan WH Otics"
                japaneseTitle="OTICS電力量の計算"
              />
              <div
                style={{
                  marginTop: '12px',
                  padding: '10px',
                  borderRadius: '7px',
                  backgroundColor: '#f8fafc',
                  fontSize: '13px',
                  lineHeight: 1.7,
                }}
              >
                <div>
                  Kubikal: <strong>{formatDecimal(pieCalculation.kubikal)} kWh</strong>
                </div>
                {pieCalculation.compressorValues.map((item) => (
                  <div key={item.key}>
                    {item.name}: <strong>{formatDecimal(item.value)} kWh</strong>
                  </div>
                ))}
                <div
                  style={{
                    borderTop: '1px solid #cbd5e1',
                    marginTop: '8px',
                    paddingTop: '8px',
                    fontSize: '15px',
                  }}
                >
                  Total WH Otics:{' '}
                  <strong>{formatDecimal(pieCalculation.oticsNetRaw)} kWh</strong>
                </div>
              </div>
              <div
                style={{
                  marginTop: '10px',
                  fontSize: '12px',
                  lineHeight: 1.6,
                  color: '#475569',
                }}
              >
                Kubikal − Comp 19 − Comp 20 − Comp 21 − Comp 24 = Total WH Otics
              </div>
              {pieCalculation.oticsNetRaw < 0 && (
                <div
                  style={{
                    marginTop: '10px',
                    padding: '9px',
                    borderRadius: '7px',
                    backgroundColor: '#fef2f2',
                    color: '#b91c1c',
                    fontSize: '12px',
                  }}
                >
                  Hasil pengurangan bernilai negatif. Irisan WH Otics pada pie chart
                  ditampilkan sebagai 0 agar pie chart tetap valid. Periksa kesamaan
                  periode dan satuan seluruh endpoint.
                </div>
              )}
            </div>
          </div>
          )}

          <div
            style={{
              backgroundColor: '#f0fdf4',
              border: '1px solid #bbf7d0',
              borderRadius: '9px',
              padding: '12px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-end',
                gap: '10px',
                flexWrap: 'wrap',
              }}
            >
              <BilingualHeading
                title="Filter Shiftly"
                japaneseTitle="シフトフィルター"
                color="#15803d"
              />
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <FilterSelect label="Bulan" japaneseLabel="月">
                  <select
                    value={shiftMonth}
                    onChange={(event) => setShiftMonth(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {shiftMonthOptions.length ? (
                      shiftMonthOptions.map((month) => (
                        <option key={month.number} value={month.number}>
                          {month.name}
                        </option>
                      ))
                    ) : (
                      <option value={shiftMonth}>{MONTHS[shiftMonth - 1]}</option>
                    )}
                  </select>
                </FilterSelect>
                <FilterSelect label="Tahun" japaneseLabel="年">
                  <select
                    value={shiftYear}
                    onChange={(event) => setShiftYear(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {shiftYearOptions.length ? (
                      shiftYearOptions.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))
                    ) : (
                      <option value={shiftYear}>{shiftYear}</option>
                    )}
                  </select>
                </FilterSelect>
              </div>
            </div>
          </div>

          <div>
            <div style={{ marginBottom: '8px' }}>
              <BilingualHeading
                title="Konsumsi Energi Harian per Shift"
                japaneseTitle="シフト別日間エネルギー消費量"
                color="#15803d"
              />
              <div style={{ marginTop: '3px', fontSize: '12px', color: '#64748b' }}>
                Periode {MONTHS[shiftMonth - 1]} {shiftYear}
              </div>
            </div>

            {showKubikal && (
              <DailyChartCard
                title={`Kubikal — ${selectedLineLabel}`}
                japaneseTitle="キュービカル シフト別エネルギー"
                data={kubDailyData}
                sourceText={KUB_SHIFTLY_API_URL}
                chartKey="kubikal"
                large
              />
            )}

            {showCompressor && (
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))',
                gap: '10px',
                marginTop: '10px',
              }}
            >
              {COMPRESSORS.map((compressor) => (
                <DailyChartCard
                  key={compressor.key}
                  title={`Shiftly ${compressor.label}`}
                  japaneseTitle={`${compressor.japaneseLabel} シフト別エネルギー`}
                  data={compressorDailyData[compressor.key] || []}
                  sourceText={compressor.shiftly}
                  chartKey={compressor.key}
                />
              ))}
            </div>
            )}

            {showCompressor && (
              <div style={{ marginTop: '10px' }}>
                <ParetoChartCard
                  title="Pareto Shiftly Compressor"
                  japaneseTitle="コンプレッサーシフト別パレート分析"
                  data={shiftlyCompressorPareto}
                  periodText={`Periode ${MONTHS[shiftMonth - 1]} ${shiftYear}`}
                />
              </div>
            )}
          </div>
        </div>
      </Container>
    </Nais_Layout>
  );
};

export default MainDashboardListrik;
