import React, { useEffect, useMemo, useState } from 'react';
import {
  Area,
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import Layout from '../layout/Layout';

const API_BASE_URL = '/api';

/**
 * HARGA LISTRIK 2026
 *
 * Plant 1
 * Biasa : Rp 2.165,53 / kWh
 * PLTS  : Rp 1.430,21 / kWh
 * Saving: Rp 735,32 / kWh
 *
 * Plant 2
 * Biasa : Rp 1.301 / kWh
 * PLTS  : Rp 1.105,9 / kWh
 * Saving: Rp 195,1 / kWh
 */
const P1_BASE_ELECTRICITY_RATE_PER_KWH = 2165.53;
const P1_PLTS_RATE_PER_KWH = 1430.21;
const P1_SAVING_RATE_PER_KWH =
  P1_BASE_ELECTRICITY_RATE_PER_KWH - P1_PLTS_RATE_PER_KWH;

const P2_BASE_ELECTRICITY_RATE_PER_KWH = 1301;
const P2_PLTS_RATE_PER_KWH = 1105.9;
const P2_SAVING_RATE_PER_KWH =
  P2_BASE_ELECTRICITY_RATE_PER_KWH - P2_PLTS_RATE_PER_KWH;

const CO2_REDUCTION_KG_PER_KWH = 0.85;


const MONTH_OPTIONS = [
  { value: '01', label: 'Januari' },
  { value: '02', label: 'Februari' },
  { value: '03', label: 'Maret' },
  { value: '04', label: 'April' },
  { value: '05', label: 'Mei' },
  { value: '06', label: 'Juni' },
  { value: '07', label: 'Juli' },
  { value: '08', label: 'Agustus' },
  { value: '09', label: 'September' },
  { value: '10', label: 'Oktober' },
  { value: '11', label: 'November' },
  { value: '12', label: 'Desember' },
];

function getDateOnly(value) {
  if (!value) return '';

  if (typeof value === 'string') {
    return value.slice(0, 10);
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return '';

  return date.toISOString().slice(0, 10);
}

function getDateTimeOnly(value) {
  if (!value) return '';

  if (typeof value === 'string') {
    return value.replace('T', ' ').slice(0, 19);
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return '';

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hour = String(date.getHours()).padStart(2, '0');
  const minute = String(date.getMinutes()).padStart(2, '0');
  const second = String(date.getSeconds()).padStart(2, '0');

  return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
}

function formatDate(value) {
  const dateOnly = getDateOnly(value);

  if (!dateOnly) return '-';

  const [year, month, day] = dateOnly.split('-');
  const date = new Date(Number(year), Number(month) - 1, Number(day));

  return date.toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
  });
}

function formatHour(value) {
  const dateTime = getDateTimeOnly(value);

  if (!dateTime) return '-';

  return dateTime.slice(11, 16);
}

function formatDateHour(value) {
  const dateOnly = getDateOnly(value);
  const hourOnly = formatHour(value);

  if (!dateOnly || hourOnly === '-') return '-';

  const [, month, day] = dateOnly.split('-');

  return `${day}/${month} ${hourOnly}`;
}

function toNumber(value) {
  const number = Number(value);

  return Number.isFinite(number) ? number : 0;
}

function sumBy(data, key) {
  return data.reduce((total, item) => total + toNumber(item[key]), 0);
}

function maxBy(data, key) {
  return data.reduce((max, item) => Math.max(max, toNumber(item[key])), 0);
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function formatNumber(value) {
  return new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(toNumber(value));
}

function formatCurrency(value) {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(toNumber(value));
}

function formatRupiahPlain(value) {
  return `Rp ${formatNumber(value)}`;
}

function formatCo2(valueKg) {
  const kg = toNumber(valueKg);

  if (kg >= 1000) {
    return `${formatNumber(kg / 1000)} ton`;
  }

  return `${formatNumber(kg)} kg`;
}

function formatPercent(value) {
  return `${formatNumber(value)}%`;
}

function getTodayDateString() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  return `${year}-${month}-${day}`;
}

function getCurrentYear() {
  return String(new Date().getFullYear());
}

function getCurrentMonth() {
  return String(new Date().getMonth() + 1).padStart(2, '0');
}

function getCurrentMonthStart() {
  return `${getCurrentYear()}-${getCurrentMonth()}-01`;
}

function getMonthStartDate(year, month) {
  return `${year}-${month}-01`;
}

function getMonthEndDate(year, month) {
  const today = getTodayDateString();
  const currentYear = getCurrentYear();
  const currentMonth = getCurrentMonth();

  if (String(year) === currentYear && String(month) === currentMonth) {
    return today;
  }

  const lastDate = new Date(Number(year), Number(month), 0).getDate();

  return `${year}-${month}-${String(lastDate).padStart(2, '0')}`;
}

function getDaysInMonth(year, month) {
  const days = new Date(Number(year), Number(month), 0).getDate();

  return Number.isFinite(days) ? days : 0;
}

function getMonthLabel(month) {
  return MONTH_OPTIONS.find((item) => item.value === String(month))?.label || '-';
}

function filterByDate(data, startDate, endDate) {
  return data.filter((item) => {
    if (!item.energy_date) return false;
    if (startDate && item.energy_date < startDate) return false;
    if (endDate && item.energy_date > endDate) return false;

    return true;
  });
}

function filterHourlyBySingleDate(data, selectedDate) {
  return data.filter((item) => {
    if (!selectedDate) return false;
    if (!item.date_custom) return false;

    return item.date_custom === selectedDate;
  });
}

function getMinDate(...datasets) {
  const dates = datasets
    .flat()
    .map((item) => item.energy_date)
    .filter(Boolean)
    .sort();

  return dates[0] || '';
}

function getMaxDate(...datasets) {
  const dates = datasets
    .flat()
    .map((item) => item.energy_date)
    .filter(Boolean)
    .sort();

  return dates[dates.length - 1] || '';
}

function createYearOptions(...datasets) {
  const years = datasets
    .flat()
    .map((item) => String(item.energy_date || '').slice(0, 4))
    .filter(Boolean);

  years.push(getCurrentYear());

  return [...new Set(years)].sort((a, b) => Number(b) - Number(a));
}

function normalizeP1(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateOnly(item.energy_date),
    date_label: formatDate(item.energy_date),
    plts_production_kwh: toNumber(
      item.plts_production_kwh ?? item.production_kwh
    ),
    inverter1_kwh: toNumber(item.inverter1_kwh),
    inverter2_kwh: toNumber(item.inverter2_kwh),
  }));
}

function normalizeP2(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateOnly(item.energy_date),
    date_label: formatDate(item.energy_date),
    purchased_from_grid_kwh: toNumber(item.purchased_from_grid_kwh),
    plts_production_kwh: toNumber(
      item.plts_production_kwh ?? item.generated_by_pv_kwh
    ),
    fed_to_grid_kwh: toNumber(item.fed_to_grid_kwh),
    consumed_by_appliances_kwh: toNumber(item.consumed_by_appliances_kwh),
  }));
}

function normalizeP1Hourly(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateTimeOnly(item.energy_date),
    date_custom: getDateOnly(item.date_custom ?? item.energy_date),
    time_label: formatHour(item.energy_date),
    datetime_label: formatDateHour(item.energy_date),
    plts_production_kwh: toNumber(
      item.plts_production_kwh ?? item.production_kwh
    ),
    inverter1_kwh: toNumber(item.inverter1_kwh),
    inverter2_kwh: toNumber(item.inverter2_kwh),
  }));
}

function normalizeP2Hourly(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateTimeOnly(item.energy_date),
    date_custom: getDateOnly(item.date_custom ?? item.energy_date),
    time_label: formatHour(item.energy_date),
    datetime_label: formatDateHour(item.energy_date),
    purchased_from_grid_kwh: toNumber(item.purchased_from_grid_kwh),
    plts_production_kwh: toNumber(
      item.plts_production_kwh ??
        item.generated_by_pv_kwh ??
        item.production_kwh
    ),
    fed_to_grid_kwh: toNumber(item.fed_to_grid_kwh),
    consumed_by_appliances_kwh: toNumber(item.consumed_by_appliances_kwh),
  }));
}

function buildPvComparisonData(p1Rows = [], p2Rows = []) {
  const p2Map = new Map(
    p2Rows.map((item) => [item.energy_date, item.plts_production_kwh])
  );

  return p1Rows.map((p1Item) => {
    const p1Production = toNumber(p1Item.plts_production_kwh);
    const p2Production = toNumber(p2Map.get(p1Item.energy_date));

    return {
      energy_date: p1Item.energy_date,
      date_label: p1Item.date_label,
      plant1_plts_production_kwh: p1Production,
      plant2_plts_production_kwh: p2Production,
      difference_kwh: p1Production - p2Production,
    };
  });
}

function buildCo2AnalysisData(rows = []) {
  return rows.map((item) => {
    const plant1Co2 =
      toNumber(item.plant1_plts_production_kwh) * CO2_REDUCTION_KG_PER_KWH;
    const plant2Co2 =
      toNumber(item.plant2_plts_production_kwh) * CO2_REDUCTION_KG_PER_KWH;

    return {
      ...item,
      plant1_co2_reduced_kg: plant1Co2,
      plant2_co2_reduced_kg: plant2Co2,
      total_co2_reduced_kg: plant1Co2 + plant2Co2,
    };
  });
}

function StatCard({ label, value, unit, note }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white px-3 py-3 shadow-sm">
      <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">
        {label}
      </p>

      <div className="mt-1 flex items-end gap-1">
        <span className="text-lg font-black text-slate-900">{value}</span>
        {unit && (
          <span className="mb-0.5 text-xs font-semibold text-slate-500">
            {unit}
          </span>
        )}
      </div>

      {note && <p className="mt-1 text-[11px] text-slate-500">{note}</p>}
    </div>
  );
}

function GaugeCard({
  title,
  value = 0,
  max = 100,
  unit = '%',
  color = '#10b981',
  subtitle = '',
  reverse = false,
}) {
  const safeValue = toNumber(value);
  const safeMax = toNumber(max);
  const hasTarget = safeMax > 0;
  const percent = hasTarget ? clamp((safeValue / safeMax) * 100, 0, 100) : 0;
  const gaugePercent = unit === '%' ? clamp(safeValue, 0, 100) : percent;
  const displayValue = unit === '%' ? safeValue : percent;

  const statusText = !hasTarget
    ? 'No Data'
    : reverse
      ? gaugePercent <= 40
        ? 'Good'
        : gaugePercent <= 70
          ? 'Watch'
          : 'High'
      : gaugePercent >= 80
        ? 'Good'
        : gaugePercent >= 50
          ? 'Progress'
          : 'Low';

  const targetText = hasTarget
    ? `${formatNumber(safeValue)} / ${formatNumber(safeMax)} ${unit}`
    : `Belum ada target ${unit}`;

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-sm font-black text-slate-800">{title}</h3>
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600">
          {statusText}
        </span>
      </div>

      <div className="mt-4 flex justify-center">
        <div
          className="relative flex h-32 w-32 items-center justify-center rounded-full"
          style={{
            background: `conic-gradient(${color} ${gaugePercent}%, #e5e7eb ${gaugePercent}% 100%)`,
          }}
        >
          <div className="flex h-24 w-24 flex-col items-center justify-center rounded-full bg-white shadow-inner">
            <span className="text-2xl font-black text-slate-900">
              {formatNumber(displayValue)}
            </span>
            <span className="text-xs font-bold text-slate-500">%</span>
          </div>
        </div>
      </div>

      <p className="mt-3 text-center text-xs font-semibold text-slate-600">
        {unit === '%' ? `${formatNumber(safeValue)}%` : targetText}
      </p>

      {subtitle && (
        <p className="mt-1 text-center text-[11px] text-slate-500">
          {subtitle}
        </p>
      )}
    </div>
  );
}

function ChartCard({ title, description, children }) {
  return (
    <div className="rounded-2xl border border-slate-100 bg-slate-50 p-3">
      <div className="mb-2">
        <h3 className="text-sm font-black text-slate-900">{title}</h3>
        {description && (
          <p className="text-[11px] text-slate-500">{description}</p>
        )}
      </div>
      {children}
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="flex h-full items-center justify-center rounded-xl border border-dashed border-slate-300 bg-white px-4 text-center text-xs text-slate-500">
      Tidak ada data pada rentang tanggal ini.
    </div>
  );
}

function LoadingBox() {
  return (
    <div className="flex min-h-[260px] items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white text-sm text-slate-500">
      Memuat data dashboard...
    </div>
  );
}

function ErrorBox({ message }) {
  return (
    <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700">
      <p className="font-bold">Gagal memuat data</p>
      <p className="mt-1 text-sm">{message}</p>
    </div>
  );
}

function PlantPanel({ title, subtitle, badge, children }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-md shadow-slate-200/70">
      <div className="mb-3 flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">
            {title}
          </p>
          <h2 className="mt-1 text-lg font-black text-slate-950">
            {subtitle}
          </h2>
        </div>

        <div className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700">
          {badge}
        </div>
      </div>

      {children}
    </section>
  );
}

export default function App() {
  const [p1Data, setP1Data] = useState([]);
  const [p2Data, setP2Data] = useState([]);
  const [p1HourlyData, setP1HourlyData] = useState([]);
  const [p2HourlyData, setP2HourlyData] = useState([]);

  const [selectedYear, setSelectedYear] = useState(getCurrentYear());
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  const [startDate, setStartDate] = useState(getCurrentMonthStart());
  const [endDate, setEndDate] = useState(getTodayDateString());
  const [hourlyDate, setHourlyDate] = useState(getTodayDateString());

  const [loading, setLoading] = useState(true);
  const [hourlyLoading, setHourlyLoading] = useState(false);
  const [error, setError] = useState('');
  const [hourlyError, setHourlyError] = useState('');

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        setLoading(true);
        setError('');

        const [p1Response, p2Response] = await Promise.all([
          fetch(`${API_BASE_URL}/plts-p1-daily-full-stack`),
          fetch(`${API_BASE_URL}/plts-p2-daily-full-stack`),
        ]);

        if (!p1Response.ok) {
          throw new Error('Endpoint P1 tidak dapat diakses');
        }

        if (!p2Response.ok) {
          throw new Error('Endpoint P2 tidak dapat diakses');
        }

        const p1Json = await p1Response.json();
        const p2Json = await p2Response.json();

        const normalizedP1 = normalizeP1(p1Json.data || []);
        const normalizedP2 = normalizeP2(p2Json.data || []);

        setP1Data(normalizedP1);
        setP2Data(normalizedP2);

        const currentYear = getCurrentYear();
        const currentMonth = getCurrentMonth();
        const monthStart = getMonthStartDate(currentYear, currentMonth);
        const monthEnd = getMonthEndDate(currentYear, currentMonth);

        setSelectedYear(currentYear);
        setSelectedMonth(currentMonth);
        setStartDate(monthStart);
        setEndDate(monthEnd);
        setHourlyDate(monthEnd);
      } catch (err) {
        setError(err.message || 'Terjadi kesalahan saat mengambil data');
      } finally {
        setLoading(false);
      }
    }

    fetchDashboardData();
  }, []);

  useEffect(() => {
    async function fetchHourlyData() {
      try {
        setHourlyLoading(true);
        setHourlyError('');

        const selectedDate = hourlyDate || getTodayDateString();

        const [p1HourlyResponse, p2HourlyResponse] = await Promise.all([
          fetch(
            `${API_BASE_URL}/plts-p1-hourly-full-stack?date=${selectedDate}&limit=2000&order=ASC`
          ),
          fetch(
            `${API_BASE_URL}/plts-p2-hourly-full-stack?date=${selectedDate}&limit=2000&order=ASC`
          ),
        ]);

        if (!p1HourlyResponse.ok) {
          throw new Error('Endpoint hourly P1 tidak dapat diakses');
        }

        if (!p2HourlyResponse.ok) {
          throw new Error('Endpoint hourly P2 tidak dapat diakses');
        }

        const p1HourlyJson = await p1HourlyResponse.json();
        const p2HourlyJson = await p2HourlyResponse.json();

        setP1HourlyData(normalizeP1Hourly(p1HourlyJson.data || []));
        setP2HourlyData(normalizeP2Hourly(p2HourlyJson.data || []));
      } catch (err) {
        setP1HourlyData([]);
        setP2HourlyData([]);
        setHourlyError(
          err.message || 'Terjadi kesalahan saat mengambil data hourly'
        );
      } finally {
        setHourlyLoading(false);
      }
    }

    fetchHourlyData();
  }, [hourlyDate]);

  const minAvailableDate = useMemo(
    () => getMinDate(p1Data, p2Data),
    [p1Data, p2Data]
  );

  const maxAvailableDate = useMemo(
    () => getMaxDate(p1Data, p2Data),
    [p1Data, p2Data]
  );

  const yearOptions = useMemo(
    () => createYearOptions(p1Data, p2Data),
    [p1Data, p2Data]
  );

  const filteredP1Data = useMemo(
    () => filterByDate(p1Data, startDate, endDate),
    [p1Data, startDate, endDate]
  );

  const filteredP2Data = useMemo(
    () => filterByDate(p2Data, startDate, endDate),
    [p2Data, startDate, endDate]
  );

  const filteredP1HourlyData = useMemo(
    () => filterHourlyBySingleDate(p1HourlyData, hourlyDate),
    [p1HourlyData, hourlyDate]
  );

  const filteredP2HourlyData = useMemo(
    () => filterHourlyBySingleDate(p2HourlyData, hourlyDate),
    [p2HourlyData, hourlyDate]
  );

  const p1Summary = useMemo(() => {
    const totalProduction = sumBy(filteredP1Data, 'plts_production_kwh');

    return {
      totalProduction,
      inverter1: sumBy(filteredP1Data, 'inverter1_kwh'),
      inverter2: sumBy(filteredP1Data, 'inverter2_kwh'),
      peakProduction: maxBy(filteredP1Data, 'plts_production_kwh'),
      baseCost: totalProduction * P1_BASE_ELECTRICITY_RATE_PER_KWH,
      pltsCost: totalProduction * P1_PLTS_RATE_PER_KWH,
      estimatedSaving: totalProduction * P1_SAVING_RATE_PER_KWH,
      co2Reduced: totalProduction * CO2_REDUCTION_KG_PER_KWH,
    };
  }, [filteredP1Data]);

  const p2Summary = useMemo(() => {
    const totalConsumption = sumBy(
      filteredP2Data,
      'consumed_by_appliances_kwh'
    );
    const purchasedGrid = sumBy(filteredP2Data, 'purchased_from_grid_kwh');
    const generatedPv = sumBy(filteredP2Data, 'plts_production_kwh');

    return {
      totalConsumption,
      generatedPv,
      purchasedGrid,
      fedGrid: sumBy(filteredP2Data, 'fed_to_grid_kwh'),
      baseConsumptionCost:
        totalConsumption * P2_BASE_ELECTRICITY_RATE_PER_KWH,
      gridCost: purchasedGrid * P2_BASE_ELECTRICITY_RATE_PER_KWH,
      pltsCost: generatedPv * P2_PLTS_RATE_PER_KWH,
      estimatedSaving: generatedPv * P2_SAVING_RATE_PER_KWH,
      co2Reduced: generatedPv * CO2_REDUCTION_KG_PER_KWH,
      pvContribution:
        totalConsumption > 0 ? (generatedPv / totalConsumption) * 100 : 0,
      gridDependency:
        totalConsumption > 0 ? (purchasedGrid / totalConsumption) * 100 : 0,
    };
  }, [filteredP2Data]);

  const p1HourlySummary = useMemo(() => {
    return {
      totalProduction: sumBy(filteredP1HourlyData, 'plts_production_kwh'),
      inverter1: sumBy(filteredP1HourlyData, 'inverter1_kwh'),
      inverter2: sumBy(filteredP1HourlyData, 'inverter2_kwh'),
      peakProduction: maxBy(filteredP1HourlyData, 'plts_production_kwh'),
    };
  }, [filteredP1HourlyData]);

  const p2HourlySummary = useMemo(() => {
    return {
      generatedPv: sumBy(filteredP2HourlyData, 'plts_production_kwh'),
      purchasedGrid: sumBy(filteredP2HourlyData, 'purchased_from_grid_kwh'),
      fedGrid: sumBy(filteredP2HourlyData, 'fed_to_grid_kwh'),
      totalConsumption: sumBy(
        filteredP2HourlyData,
        'consumed_by_appliances_kwh'
      ),
      peakPv: maxBy(filteredP2HourlyData, 'plts_production_kwh'),
    };
  }, [filteredP2HourlyData]);

  const pvComparisonData = useMemo(
    () => buildPvComparisonData(filteredP1Data, filteredP2Data),
    [filteredP1Data, filteredP2Data]
  );

  const pvComparisonSummary = useMemo(() => {
    const plant1Total = sumBy(
      pvComparisonData,
      'plant1_plts_production_kwh'
    );
    const plant2Total = sumBy(
      pvComparisonData,
      'plant2_plts_production_kwh'
    );

    return {
      plant1Total,
      plant2Total,
      difference: plant1Total - plant2Total,
    };
  }, [pvComparisonData]);

  const co2AnalysisData = useMemo(
    () => buildCo2AnalysisData(pvComparisonData),
    [pvComparisonData]
  );

  const co2Summary = useMemo(() => {
    const plant1Co2Reduced = sumBy(
      co2AnalysisData,
      'plant1_co2_reduced_kg'
    );
    const plant2Co2Reduced = sumBy(
      co2AnalysisData,
      'plant2_co2_reduced_kg'
    );

    const totalCo2Reduced = plant1Co2Reduced + plant2Co2Reduced;

    const totalPvGenerated =
      pvComparisonSummary.plant1Total + pvComparisonSummary.plant2Total;

    const estimatedSaving =
      pvComparisonSummary.plant1Total * P1_SAVING_RATE_PER_KWH +
      pvComparisonSummary.plant2Total * P2_SAVING_RATE_PER_KWH;

    const pltsCost =
      pvComparisonSummary.plant1Total * P1_PLTS_RATE_PER_KWH +
      pvComparisonSummary.plant2Total * P2_PLTS_RATE_PER_KWH;

    const baseCost =
      pvComparisonSummary.plant1Total * P1_BASE_ELECTRICITY_RATE_PER_KWH +
      pvComparisonSummary.plant2Total * P2_BASE_ELECTRICITY_RATE_PER_KWH;

    const totalDays = co2AnalysisData.length;

    return {
      plant1Co2Reduced,
      plant2Co2Reduced,
      totalCo2Reduced,
      totalPvGenerated,
      estimatedSaving,
      pltsCost,
      baseCost,
      averageCo2PerDay: totalDays > 0 ? totalCo2Reduced / totalDays : 0,
      plant1Contribution:
        totalCo2Reduced > 0
          ? (plant1Co2Reduced / totalCo2Reduced) * 100
          : 0,
      plant2Contribution:
        totalCo2Reduced > 0
          ? (plant2Co2Reduced / totalCo2Reduced) * 100
          : 0,
    };
  }, [co2AnalysisData, pvComparisonSummary]);

  const selectedMonthDays = useMemo(
    () => getDaysInMonth(selectedYear, selectedMonth),
    [selectedYear, selectedMonth]
  );

  const monthlyGaugeSummary = useMemo(() => {
    const p1PeakDailyProduction = maxBy(filteredP1Data, 'plts_production_kwh');
    const p2PeakDailyProduction = maxBy(filteredP2Data, 'plts_production_kwh');

    const p1ProductionTarget = p1PeakDailyProduction * selectedMonthDays;
    const p2ProductionTarget = p2PeakDailyProduction * selectedMonthDays;

    const p1Co2Target =
      p1PeakDailyProduction * CO2_REDUCTION_KG_PER_KWH * selectedMonthDays;
    const p2Co2Target =
      p2PeakDailyProduction * CO2_REDUCTION_KG_PER_KWH * selectedMonthDays;

    return {
      daysInMonth: selectedMonthDays,
      monthLabel: getMonthLabel(selectedMonth),
      p1PeakDailyProduction,
      p2PeakDailyProduction,
      p1ProductionTarget,
      p2ProductionTarget,
      p1Co2Target,
      p2Co2Target,
    };
  }, [filteredP1Data, filteredP2Data, selectedMonth, selectedMonthDays]);

  function applyMonthFilter(year, month) {
    const monthStart = getMonthStartDate(year, month);
    const monthEnd = getMonthEndDate(year, month);

    setSelectedYear(year);
    setSelectedMonth(month);
    setStartDate(monthStart);
    setEndDate(monthEnd);
    setHourlyDate(monthEnd);
  }

  function resetFilter() {
    applyMonthFilter(getCurrentYear(), getCurrentMonth());
  }

  return (
    <Layout>
      <main className="min-h-screen bg-gradient-to-br from-slate-50 via-stone-50 to-emerald-50 p-3 text-slate-900 sm:p-4 lg:p-5">
        <div className="mx-auto max-w-[1700px]">
          <header className="mb-4 rounded-2xl border border-slate-200 bg-white/90 p-4 shadow-sm backdrop-blur sm:p-5">
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-emerald-600">
              PLTS Monitoring
            </p>

            <h1 className="mt-1 text-xl font-extrabold tracking-tight text-slate-800 sm:text-2xl">
              Dashboard Harian Plant 1 & Plant 2
            </h1>

            <p className="mt-1 text-sm text-slate-600">
              Dashboard monitoring produksi PLTS, konsumsi energi, estimasi
              biaya listrik, saving, dan reduksi CO2 berdasarkan tarif 2026
              masing-masing plant.
            </p>
          </header>

          {loading && <LoadingBox />}
          {!loading && error && <ErrorBox message={error} />}

          {!loading && !error && (
            <>
              <section className="mb-4 rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-md shadow-slate-200/70">
                <div className="grid gap-3 xl:grid-cols-[1fr_auto] xl:items-end">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">
                      Filter & Tarif
                    </p>

                    <h2 className="mt-1 text-lg font-black text-slate-800">
                      Filter Bulanan dan Harga Listrik 2026
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                      Plant 1 dan Plant 2 menggunakan harga berbeda, sehingga
                      perhitungan biaya listrik, biaya PLTS, dan estimasi
                      saving sudah dipisahkan berdasarkan tarif masing-masing
                      plant.
                    </p>
                  </div>

                  <div className="grid gap-2 sm:grid-cols-3">
                    <label className="block">
                      <span className="text-[11px] font-bold uppercase text-slate-500">
                        Tahun
                      </span>

                      <select
                        value={selectedYear}
                        onChange={(event) =>
                          applyMonthFilter(event.target.value, selectedMonth)
                        }
                        className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                      >
                        {yearOptions.map((year) => (
                          <option key={year} value={year}>
                            {year}
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="block">
                      <span className="text-[11px] font-bold uppercase text-slate-500">
                        Bulan
                      </span>

                      <select
                        value={selectedMonth}
                        onChange={(event) =>
                          applyMonthFilter(selectedYear, event.target.value)
                        }
                        className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                      >
                        {MONTH_OPTIONS.map((month) => (
                          <option key={month.value} value={month.value}>
                            {month.label}
                          </option>
                        ))}
                      </select>
                    </label>

                    <button
                      type="button"
                      onClick={resetFilter}
                      className="rounded-xl bg-slate-950 px-4 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-slate-800 sm:self-end"
                    >
                      Bulan Ini
                    </button>
                  </div>
                </div>

                <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                  <StatCard
                    label="Plant 1 Biasa"
                    value={formatRupiahPlain(P1_BASE_ELECTRICITY_RATE_PER_KWH)}
                    unit="/ kWh"
                  />

                  <StatCard
                    label="Plant 1 PLTS"
                    value={formatRupiahPlain(P1_PLTS_RATE_PER_KWH)}
                    unit="/ kWh"
                    note={`Saving ${formatRupiahPlain(P1_SAVING_RATE_PER_KWH)} / kWh`}
                  />

                  <StatCard
                    label="Plant 2 Biasa"
                    value={formatRupiahPlain(P2_BASE_ELECTRICITY_RATE_PER_KWH)}
                    unit="/ kWh"
                  />

                  <StatCard
                    label="Plant 2 PLTS"
                    value={formatRupiahPlain(P2_PLTS_RATE_PER_KWH)}
                    unit="/ kWh"
                    note={`Saving ${formatRupiahPlain(P2_SAVING_RATE_PER_KWH)} / kWh`}
                  />
                </div>

                <div className="mt-4 rounded-2xl border border-emerald-100 bg-emerald-50 p-4">
                  <div className="mb-3">
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-700">
                      Rumus Saving
                    </p>

                    <h3 className="mt-1 text-sm font-black text-slate-800">
                      Perhitungan Estimasi Penghematan PLTS
                    </h3>

                    <p className="mt-1 text-xs text-slate-600">
                      Rumus ini digunakan untuk menghitung estimasi saving
                      berdasarkan produksi PV masing-masing plant dan selisih
                      tarif listrik biasa dengan tarif PLTS tahun 2026.
                    </p>
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="rounded-xl border border-emerald-200 bg-white p-3 shadow-sm">
                      <p className="text-[11px] font-bold uppercase text-slate-500">
                        Plant 1
                      </p>

                      <p className="mt-1 text-sm font-black text-slate-900">
                        Saving P1 = PV P1 ×{' '}
                        {formatRupiahPlain(P1_SAVING_RATE_PER_KWH)}
                      </p>

                      <p className="mt-1 text-[11px] text-slate-500">
                        Selisih tarif:{' '}
                        {formatRupiahPlain(P1_BASE_ELECTRICITY_RATE_PER_KWH)} -{' '}
                        {formatRupiahPlain(P1_PLTS_RATE_PER_KWH)}
                      </p>
                    </div>

                    <div className="rounded-xl border border-emerald-200 bg-white p-3 shadow-sm">
                      <p className="text-[11px] font-bold uppercase text-slate-500">
                        Plant 2
                      </p>

                      <p className="mt-1 text-sm font-black text-slate-900">
                        Saving P2 = PV P2 ×{' '}
                        {formatRupiahPlain(P2_SAVING_RATE_PER_KWH)}
                      </p>

                      <p className="mt-1 text-[11px] text-slate-500">
                        Selisih tarif:{' '}
                        {formatRupiahPlain(P2_BASE_ELECTRICITY_RATE_PER_KWH)} -{' '}
                        {formatRupiahPlain(P2_PLTS_RATE_PER_KWH)}
                      </p>
                    </div>
                  </div>
                </div>
              </section>

              <section className="mb-4 rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-md shadow-slate-200/70">
                <div className="mb-3 grid gap-3 border-b border-slate-100 pb-3 xl:grid-cols-[1fr_auto] xl:items-end">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">
                      Hourly PV Production
                    </p>

                    <h2 className="mt-1 text-lg font-black text-slate-800">
                      Produksi Hourly Plant 1 dan Plant 2
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                      Data hourly ditampilkan berdasarkan satu tanggal yang
                      dipilih.
                    </p>
                  </div>

                  <label className="block rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                    <span className="text-[11px] font-bold uppercase text-slate-500">
                      Tanggal Hourly
                    </span>

                    <input
                      type="date"
                      value={hourlyDate}
                      min={startDate || minAvailableDate}
                      max={endDate || maxAvailableDate}
                      onChange={(event) => setHourlyDate(event.target.value)}
                      className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                    />
                  </label>
                </div>

                <div className="mb-3 grid grid-cols-2 gap-2 lg:grid-cols-4">
                  <StatCard
                    label="Hourly P1"
                    value={formatNumber(p1HourlySummary.totalProduction)}
                    unit="kWh"
                  />

                  <StatCard
                    label="Peak P1"
                    value={formatNumber(p1HourlySummary.peakProduction)}
                    unit="kWh"
                  />

                  <StatCard
                    label="Hourly P2 PV"
                    value={formatNumber(p2HourlySummary.generatedPv)}
                    unit="kWh"
                  />

                  <StatCard
                    label="Peak P2 PV"
                    value={formatNumber(p2HourlySummary.peakPv)}
                    unit="kWh"
                  />
                </div>

                {hourlyLoading && (
                  <p className="mb-3 rounded-xl bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-500">
                    Memuat data hourly...
                  </p>
                )}

                {hourlyError && (
                  <p className="mb-3 rounded-xl bg-red-50 px-3 py-2 text-xs font-semibold text-red-700">
                    {hourlyError}
                  </p>
                )}

                <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                  <ChartCard
                    title="Plant 1 Hourly PV Production"
                    description="Bar chart produksi hourly Plant 1"
                  >
                    <div className="h-[280px]">
                      {filteredP1HourlyData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={filteredP1HourlyData}
                            margin={{ top: 8, right: 8, left: -18, bottom: 0 }}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              stroke="#e2e8f0"
                            />
                            <XAxis
                              dataKey="datetime_label"
                              tick={{ fontSize: 10 }}
                              stroke="#64748b"
                              interval="preserveStartEnd"
                            />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plts_production_kwh"
                              name="Plant 1 Hourly Production"
                              fill="#10b981"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard
                    title="Plant 2 Hourly PV Production"
                    description="Bar chart produksi PV hourly Plant 2"
                  >
                    <div className="h-[280px]">
                      {filteredP2HourlyData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={filteredP2HourlyData}
                            margin={{ top: 8, right: 8, left: -18, bottom: 0 }}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              stroke="#e2e8f0"
                            />
                            <XAxis
                              dataKey="datetime_label"
                              tick={{ fontSize: 10 }}
                              stroke="#64748b"
                              interval="preserveStartEnd"
                            />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plts_production_kwh"
                              name="Plant 2 Hourly PV"
                              fill="#6366f1"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>
                </div>
              </section>

              <section className="mb-4 rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-md shadow-slate-200/70">
                <div className="mb-3 grid gap-3 border-b border-slate-100 pb-3 xl:grid-cols-[1fr_auto] xl:items-end">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">
                      PV Comparison
                    </p>

                    <h2 className="mt-1 text-lg font-black text-slate-800">
                      Perbandingan Produksi PV Plant 1 dan Plant 2
                    </h2>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <StatCard
                      label="Total P1"
                      value={formatNumber(pvComparisonSummary.plant1Total)}
                      unit="kWh"
                    />

                    <StatCard
                      label="Total P2"
                      value={formatNumber(pvComparisonSummary.plant2Total)}
                      unit="kWh"
                    />

                    <StatCard
                      label="Selisih"
                      value={formatNumber(pvComparisonSummary.difference)}
                      unit="kWh"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                  <ChartCard
                    title="Plant 1 PLTS Production"
                    description="Produksi harian Plant 1"
                  >
                    <div className="h-[280px]">
                      {pvComparisonData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={pvComparisonData}
                            margin={{ top: 8, right: 8, left: -18, bottom: 0 }}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              stroke="#e2e8f0"
                            />
                            <XAxis
                              dataKey="date_label"
                              tick={{ fontSize: 10 }}
                              stroke="#64748b"
                              interval="preserveStartEnd"
                            />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plant1_plts_production_kwh"
                              name="Plant 1 PLTS"
                              fill="#10b981"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard
                    title="Plant 2 PLTS Production"
                    description="Produksi harian PV Plant 2"
                  >
                    <div className="h-[280px]">
                      {pvComparisonData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={pvComparisonData}
                            margin={{ top: 8, right: 8, left: -18, bottom: 0 }}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              stroke="#e2e8f0"
                            />
                            <XAxis
                              dataKey="date_label"
                              tick={{ fontSize: 10 }}
                              stroke="#64748b"
                              interval="preserveStartEnd"
                            />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plant2_plts_production_kwh"
                              name="Plant 2 PLTS"
                              fill="#6366f1"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>
                </div>
              </section>

              <section className="mb-4 rounded-2xl border border-emerald-100 bg-white/95 p-4 shadow-md shadow-emerald-100/70">
                <div className="mb-3 border-b border-emerald-50 pb-3">
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">
                    CO2 Reduction Analysis
                  </p>

                  <h2 className="mt-1 text-lg font-black text-slate-800">
                    Analisa Pengurangan Emisi dan Saving
                  </h2>

                  <p className="mt-1 text-xs text-slate-500">
                    CO2 dihitung dari total PV kWh ×{' '}
                    {CO2_REDUCTION_KG_PER_KWH} kg CO2/kWh. Saving dihitung
                    berdasarkan tarif masing-masing plant.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 lg:grid-cols-5">
                  <StatCard
                    label="Total PV"
                    value={formatNumber(co2Summary.totalPvGenerated)}
                    unit="kWh"
                  />

                  <StatCard
                    label="CO2 Reduce"
                    value={formatCo2(co2Summary.totalCo2Reduced)}
                  />

                  <StatCard
                    label="Avg CO2/Hari"
                    value={formatCo2(co2Summary.averageCo2PerDay)}
                  />

                  <StatCard
                    label="Biaya PLTS"
                    value={formatCurrency(co2Summary.pltsCost)}
                  />

                  <StatCard
                    label="Estimasi Saving"
                    value={formatCurrency(co2Summary.estimatedSaving)}
                  />
                </div>

                <div className="mt-3 grid grid-cols-1 gap-3 lg:grid-cols-[1.2fr_0.8fr]">
                  <ChartCard
                    title="Daily CO2 Reduction"
                    description="P1 dan P2 dikonversi menjadi estimasi CO2 reduction"
                  >
                    <div className="h-[280px]">
                      {co2AnalysisData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={co2AnalysisData}
                            margin={{ top: 8, right: 8, left: -18, bottom: 0 }}
                          >
                            <CartesianGrid
                              strokeDasharray="3 3"
                              stroke="#e2e8f0"
                            />
                            <XAxis
                              dataKey="date_label"
                              tick={{ fontSize: 10 }}
                              stroke="#64748b"
                              interval="preserveStartEnd"
                            />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plant1_co2_reduced_kg"
                              name="P1 CO2 Reduce"
                              stackId="co2"
                              fill="#10b981"
                              radius={[6, 6, 0, 0]}
                            />
                            <Bar
                              dataKey="plant2_co2_reduced_kg"
                              name="P2 CO2 Reduce"
                              stackId="co2"
                              fill="#6366f1"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard
                    title="Kontribusi CO2"
                    description="Komposisi kontribusi berdasarkan plant"
                  >
                    <div className="space-y-4 rounded-xl bg-white p-3">
                      <div>
                        <div className="mb-1 flex justify-between text-xs font-bold text-slate-600">
                          <span>Plant 1</span>
                          <span>
                            {formatPercent(co2Summary.plant1Contribution)}
                          </span>
                        </div>

                        <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                          <div
                            className="h-full rounded-full bg-emerald-500"
                            style={{
                              width: `${co2Summary.plant1Contribution}%`,
                            }}
                          />
                        </div>

                        <p className="mt-1 text-[11px] text-slate-500">
                          {formatCo2(co2Summary.plant1Co2Reduced)}
                        </p>
                      </div>

                      <div>
                        <div className="mb-1 flex justify-between text-xs font-bold text-slate-600">
                          <span>Plant 2</span>
                          <span>
                            {formatPercent(co2Summary.plant2Contribution)}
                          </span>
                        </div>

                        <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                          <div
                            className="h-full rounded-full bg-indigo-500"
                            style={{
                              width: `${co2Summary.plant2Contribution}%`,
                            }}
                          />
                        </div>

                        <p className="mt-1 text-[11px] text-slate-500">
                          {formatCo2(co2Summary.plant2Co2Reduced)}
                        </p>
                      </div>

                      <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">
                        <p className="font-black text-slate-800">Catatan</p>
                        <p className="mt-1">
                          Nilai CO2 reduction adalah estimasi. Ubah konstanta
                          CO2_REDUCTION_KG_PER_KWH bila perusahaan memakai
                          faktor emisi resmi yang berbeda.
                        </p>
                      </div>
                    </div>
                  </ChartCard>
                </div>
              </section>

              <section className="mb-4 rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-md shadow-slate-200/70">
                <div className="mb-3 border-b border-slate-100 pb-3">
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">
                    Main Gauge Indicator
                  </p>

                  <h2 className="mt-1 text-lg font-black text-slate-800">
                    Ringkasan Performa Bulanan
                  </h2>

                  <p className="mt-1 text-xs text-slate-500">
                    Target otomatis dihitung dari nilai harian tertinggi pada
                    bulan {monthlyGaugeSummary.monthLabel} {selectedYear} ×{' '}
                    {monthlyGaugeSummary.daysInMonth} hari.
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
                  <div className="rounded-2xl border border-emerald-100 bg-emerald-50/60 p-3">
                    <div className="mb-3 flex items-start justify-between gap-2">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-emerald-700">
                          Plant 1
                        </p>
                        <h3 className="mt-1 text-sm font-black text-slate-800">
                          Production & CO2 Reduction
                        </h3>
                      </div>

                      <span className="rounded-full bg-white px-2 py-1 text-[10px] font-bold text-emerald-700 shadow-sm">
                        Peak {formatNumber(monthlyGaugeSummary.p1PeakDailyProduction)} kWh
                      </span>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <GaugeCard
                        title="P1 Production"
                        value={p1Summary.totalProduction}
                        max={monthlyGaugeSummary.p1ProductionTarget}
                        unit="kWh"
                        color="#10b981"
                        subtitle={`Target = peak harian ${formatNumber(
                          monthlyGaugeSummary.p1PeakDailyProduction
                        )} kWh × ${monthlyGaugeSummary.daysInMonth} hari`}
                      />

                      <GaugeCard
                        title="CO2 Reduction"
                        value={p1Summary.co2Reduced}
                        max={monthlyGaugeSummary.p1Co2Target}
                        unit="kg"
                        color="#0ea5e9"
                        subtitle={`Target = ${formatCo2(
                          monthlyGaugeSummary.p1Co2Target
                        )}`}
                      />
                    </div>
                  </div>

                  <div className="rounded-2xl border border-indigo-100 bg-indigo-50/60 p-3">
                    <div className="mb-3 flex items-start justify-between gap-2">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-indigo-700">
                          Plant 2
                        </p>
                        <h3 className="mt-1 text-sm font-black text-slate-800">
                          Production & CO2 Reduction
                        </h3>
                      </div>

                      <span className="rounded-full bg-white px-2 py-1 text-[10px] font-bold text-indigo-700 shadow-sm">
                        Peak {formatNumber(monthlyGaugeSummary.p2PeakDailyProduction)} kWh
                      </span>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <GaugeCard
                        title="P2 Production"
                        value={p2Summary.generatedPv}
                        max={monthlyGaugeSummary.p2ProductionTarget}
                        unit="kWh"
                        color="#6366f1"
                        subtitle={`Target = peak harian ${formatNumber(
                          monthlyGaugeSummary.p2PeakDailyProduction
                        )} kWh × ${monthlyGaugeSummary.daysInMonth} hari`}
                      />

                      <GaugeCard
                        title="CO2 Reduction"
                        value={p2Summary.co2Reduced}
                        max={monthlyGaugeSummary.p2Co2Target}
                        unit="kg"
                        color="#06b6d4"
                        subtitle={`Target = ${formatCo2(
                          monthlyGaugeSummary.p2Co2Target
                        )}`}
                      />
                    </div>
                  </div>
                </div>
              </section>

              <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                <PlantPanel
                  title="Plant 1"
                  subtitle="Produksi Harian PLTS"
                  badge={`${filteredP1Data.length} data`}
                >
                  <div className="grid grid-cols-2 gap-2 xl:grid-cols-4">
                    <StatCard
                      label="Total Produksi"
                      value={formatNumber(p1Summary.totalProduction)}
                      unit="kWh"
                    />

                    <StatCard
                      label="Peak Harian"
                      value={formatNumber(p1Summary.peakProduction)}
                      unit="kWh"
                    />

                    <StatCard
                      label="Biaya Biasa P1"
                      value={formatCurrency(p1Summary.baseCost)}
                    />

                    <StatCard
                      label="Biaya PLTS P1"
                      value={formatCurrency(p1Summary.pltsCost)}
                    />

                    <StatCard
                      label="Saving P1"
                      value={formatCurrency(p1Summary.estimatedSaving)}
                    />

                    <StatCard
                      label="Inverter 1"
                      value={formatNumber(p1Summary.inverter1)}
                      unit="kWh"
                    />

                    <StatCard
                      label="Inverter 2"
                      value={formatNumber(p1Summary.inverter2)}
                      unit="kWh"
                    />

                    <StatCard
                      label="CO2 Reduce"
                      value={formatCo2(p1Summary.co2Reduced)}
                    />
                  </div>

                  <div className="mt-3 space-y-3">
                    <ChartCard
                      title="Chart kWh Harian P1"
                      description="plts_production_kwh, inverter1_kwh, inverter2_kwh"
                    >
                      <div className="h-[300px]">
                        {filteredP1Data.length === 0 ? (
                          <EmptyChart />
                        ) : (
                          <ResponsiveContainer width="100%" height="100%">
                            <ComposedChart
                              data={filteredP1Data}
                              margin={{
                                top: 8,
                                right: 8,
                                left: -18,
                                bottom: 0,
                              }}
                            >
                              <CartesianGrid
                                strokeDasharray="3 3"
                                stroke="#e2e8f0"
                              />
                              <XAxis
                                dataKey="date_label"
                                tick={{ fontSize: 10 }}
                                stroke="#64748b"
                                interval="preserveStartEnd"
                              />
                              <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                              <Tooltip />
                              <Legend wrapperStyle={{ fontSize: 11 }} />
                              <Area
                                type="monotone"
                                dataKey="plts_production_kwh"
                                name="Produksi"
                                stroke="#10b981"
                                fill="#d1fae5"
                                strokeWidth={3}
                              />
                              <Line
                                type="monotone"
                                dataKey="inverter1_kwh"
                                name="Inverter 1"
                                stroke="#6366f1"
                                strokeWidth={2}
                                dot={false}
                              />
                              <Line
                                type="monotone"
                                dataKey="inverter2_kwh"
                                name="Inverter 2"
                                stroke="#f59e0b"
                                strokeWidth={2}
                                dot={false}
                              />
                            </ComposedChart>
                          </ResponsiveContainer>
                        )}
                      </div>
                    </ChartCard>

                    <ChartCard
                      title="Perbandingan Inverter P1"
                      description="Inverter 1 dan Inverter 2"
                    >
                      <div className="h-[220px]">
                        {filteredP1Data.length === 0 ? (
                          <EmptyChart />
                        ) : (
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              data={filteredP1Data}
                              margin={{
                                top: 8,
                                right: 8,
                                left: -18,
                                bottom: 0,
                              }}
                            >
                              <CartesianGrid
                                strokeDasharray="3 3"
                                stroke="#e2e8f0"
                              />
                              <XAxis
                                dataKey="date_label"
                                tick={{ fontSize: 10 }}
                                stroke="#64748b"
                                interval="preserveStartEnd"
                              />
                              <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                              <Tooltip />
                              <Legend wrapperStyle={{ fontSize: 11 }} />
                              <Bar
                                dataKey="inverter1_kwh"
                                name="Inverter 1"
                                fill="#6366f1"
                                radius={[6, 6, 0, 0]}
                              />
                              <Bar
                                dataKey="inverter2_kwh"
                                name="Inverter 2"
                                fill="#f59e0b"
                                radius={[6, 6, 0, 0]}
                              />
                            </BarChart>
                          </ResponsiveContainer>
                        )}
                      </div>
                    </ChartCard>
                  </div>
                </PlantPanel>

                <PlantPanel
                  title="Plant 2"
                  subtitle="Konsumsi dan PV Harian"
                  badge={`${filteredP2Data.length} data`}
                >
                  <div className="grid grid-cols-2 gap-2 xl:grid-cols-3">
                    <StatCard
                      label="Total Konsumsi"
                      value={formatNumber(p2Summary.totalConsumption)}
                      unit="kWh"
                    />

                    <StatCard
                      label="PV Generate"
                      value={formatNumber(p2Summary.generatedPv)}
                      unit="kWh"
                    />

                    <StatCard
                      label="Biaya Biasa P2"
                      value={formatCurrency(p2Summary.baseConsumptionCost)}
                    />

                    <StatCard
                      label="Biaya PLTS P2"
                      value={formatCurrency(p2Summary.pltsCost)}
                    />

                    <StatCard
                      label="Saving P2"
                      value={formatCurrency(p2Summary.estimatedSaving)}
                    />

                    <StatCard
                      label="Beli Grid"
                      value={formatNumber(p2Summary.purchasedGrid)}
                      unit="kWh"
                    />

                    <StatCard
                      label="Biaya Grid"
                      value={formatCurrency(p2Summary.gridCost)}
                    />

                    <StatCard
                      label="CO2 Reduce"
                      value={formatCo2(p2Summary.co2Reduced)}
                    />
                  </div>

                  <div className="mt-3 space-y-3">
                    <ChartCard
                      title="Chart Konsumsi Harian P2"
                      description="consumed_by_appliances_kwh, plts_production_kwh, purchased_from_grid_kwh"
                    >
                      <div className="h-[300px]">
                        {filteredP2Data.length === 0 ? (
                          <EmptyChart />
                        ) : (
                          <ResponsiveContainer width="100%" height="100%">
                            <ComposedChart
                              data={filteredP2Data}
                              margin={{
                                top: 8,
                                right: 8,
                                left: -18,
                                bottom: 0,
                              }}
                            >
                              <CartesianGrid
                                strokeDasharray="3 3"
                                stroke="#e2e8f0"
                              />
                              <XAxis
                                dataKey="date_label"
                                tick={{ fontSize: 10 }}
                                stroke="#64748b"
                                interval="preserveStartEnd"
                              />
                              <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                              <Tooltip />
                              <Legend wrapperStyle={{ fontSize: 11 }} />
                              <Area
                                type="monotone"
                                dataKey="consumed_by_appliances_kwh"
                                name="Konsumsi"
                                stroke="#f97316"
                                fill="#ffedd5"
                                strokeWidth={3}
                              />
                              <Line
                                type="monotone"
                                dataKey="plts_production_kwh"
                                name="PV Generate"
                                stroke="#10b981"
                                strokeWidth={2}
                                dot={false}
                              />
                              <Line
                                type="monotone"
                                dataKey="purchased_from_grid_kwh"
                                name="Beli Grid"
                                stroke="#0f172a"
                                strokeWidth={2}
                                dot={false}
                              />
                            </ComposedChart>
                          </ResponsiveContainer>
                        )}
                      </div>
                    </ChartCard>

                    <ChartCard
                      title="Distribusi Energi P2"
                      description="Grid, PV, dan kirim grid"
                    >
                      <div className="h-[220px]">
                        {filteredP2Data.length === 0 ? (
                          <EmptyChart />
                        ) : (
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              data={filteredP2Data}
                              margin={{
                                top: 8,
                                right: 8,
                                left: -18,
                                bottom: 0,
                              }}
                            >
                              <CartesianGrid
                                strokeDasharray="3 3"
                                stroke="#e2e8f0"
                              />
                              <XAxis
                                dataKey="date_label"
                                tick={{ fontSize: 10 }}
                                stroke="#64748b"
                                interval="preserveStartEnd"
                              />
                              <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                              <Tooltip />
                              <Legend wrapperStyle={{ fontSize: 11 }} />
                              <Bar
                                dataKey="purchased_from_grid_kwh"
                                name="Beli Grid"
                                fill="#0f172a"
                                radius={[6, 6, 0, 0]}
                              />
                              <Bar
                                dataKey="plts_production_kwh"
                                name="PV Generate"
                                fill="#10b981"
                                radius={[6, 6, 0, 0]}
                              />
                              <Bar
                                dataKey="fed_to_grid_kwh"
                                name="Kirim Grid"
                                fill="#06b6d4"
                                radius={[6, 6, 0, 0]}
                              />
                            </BarChart>
                          </ResponsiveContainer>
                        )}
                      </div>
                    </ChartCard>
                  </div>
                </PlantPanel>
              </div>
            </>
          )}
        </div>
      </main>
    </Layout>
  );
}