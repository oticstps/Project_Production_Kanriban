import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Container } from 'react-bootstrap';
import axios from 'axios';
import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import * as XLSX from 'xlsx';
import Nais_Layout from '../layout/Layout';

// URL relatif ini akan diteruskan oleh proxy Vite ke:
// http://172.27.6.191:4000/api/pm-shiftly-kub-kwh
const SHIFTLY_API_URL = '/api/pm-shiftly-kub-kwh';
const MONTHLY_API_URL = '/api/pm-monthly-kub-kwh';

const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92; // kg CO2 per kWh

// Kedua endpoint mengirim nilai meter/energi dalam unit dasar yang perlu dibagi 1000
// agar ditampilkan sebagai kWh pada dashboard.
const SHIFTLY_RAW_TO_KWH_DIVISOR = 1000;
const MONTHLY_RAW_TO_KWH_DIVISOR = 1000;
const REFRESH_INTERVAL_MS = 5 * 60 * 1000;

const MONTHS = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];


const MONTH_NUMBER_BY_NAME = {
  januari: 1,
  january: 1,
  februari: 2,
  february: 2,
  maret: 3,
  march: 3,
  april: 4,
  mei: 5,
  may: 5,
  juni: 6,
  june: 6,
  juli: 7,
  july: 7,
  agustus: 8,
  august: 8,
  september: 9,
  oktober: 10,
  october: 10,
  november: 11,
  desember: 12,
  december: 12,
};

const getMonthNumber = (value) => {
  const numericValue = toNumber(value);
  if (numericValue >= 1 && numericValue <= 12) return numericValue;

  return MONTH_NUMBER_BY_NAME[String(value || '').trim().toLowerCase()] || 0;
};

const numberFormatter = new Intl.NumberFormat('id-ID', {
  maximumFractionDigits: 0,
});

const decimalFormatter = new Intl.NumberFormat('id-ID', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

const currencyFormatter = new Intl.NumberFormat('id-ID', {
  style: 'currency',
  currency: 'IDR',
  maximumFractionDigits: 0,
});

const formatNumber = (value) => numberFormatter.format(Number(value) || 0);
const formatDecimal = (value) => decimalFormatter.format(Number(value) || 0);
const formatCurrency = (value) => currencyFormatter.format(Number(value) || 0);

const toNumber = (value) => {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
};

const toShiftlyKwh = (value) =>
  toNumber(value) / SHIFTLY_RAW_TO_KWH_DIVISOR;

const toMonthlyKwh = (value) =>
  toNumber(value) / MONTHLY_RAW_TO_KWH_DIVISOR;

const normalizeShift = (value) => {
  const normalized = String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');

  if (normalized === 'SHIFT 1' || normalized.endsWith(' 1')) return 'shift1';
  if (normalized === 'SHIFT 2' || normalized.endsWith(' 2')) return 'shift2';
  return null;
};

const formatLineLabel = (lineTable, lineName) => {
  const readableName = String(lineName || lineTable || '-')
    .replace(/^tb_/, '')
    .replace(/_total_kwh$/i, '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());

  return readableName;
};

const parseDate = (value) => {
  if (!value) return new Date(0);
  return new Date(`${String(value).slice(0, 10)}T00:00:00`);
};

const getLatestRecord = (records) => {
  return [...records].sort(
    (a, b) => parseDate(b.shift_date) - parseDate(a.shift_date)
  )[0];
};

const SummaryCard = ({ icon, title, subtitle, value, accent }) => (
  <div
    style={{
      backgroundColor: '#fff',
      padding: '12px',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(15, 23, 42, 0.08)',
      border: '1px solid #edf2f7',
      minHeight: '112px',
    }}
  >
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '7px',
        marginBottom: '5px',
      }}
    >
      <span style={{ fontSize: '20px' }}>{icon}</span>
      <span style={{ fontSize: '14px', fontWeight: 700, color: accent }}>
        {title}
      </span>
    </div>
    <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>
      {subtitle}
    </div>
    <div
      style={{
        fontSize: '20px',
        lineHeight: 1.25,
        fontWeight: 800,
        color: '#1e293b',
        wordBreak: 'break-word',
      }}
    >
      {value}
    </div>
  </div>
);

const MainDashboardListrik = () => {
  const requestControllerRef = useRef(null);
  const initialSelectionDoneRef = useRef(false);

  const [rawData, setRawData] = useState([]);
  const [monthlyRawData, setMonthlyRawData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [lastFetchedAt, setLastFetchedAt] = useState(null);

  const currentMonth = new Date().toLocaleString('id-ID', { month: 'long' });
  const currentYear = new Date().getFullYear();

  const [selectedLine, setSelectedLine] = useState('');
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedYear, setSelectedYear] = useState(currentYear);

  const fetchData = useCallback(async (initialLoad = false) => {
    requestControllerRef.current?.abort();
    const controller = new AbortController();
    requestControllerRef.current = controller;

    if (initialLoad) setLoading(true);
    else setRefreshing(true);

    setError('');

    try {
      const requestConfig = {
        signal: controller.signal,
        timeout: 20000,
        params: { timestamp: Date.now() },
        headers: { 'Cache-Control': 'no-cache' },
      };

      const [shiftlyResponse, monthlyResponse] = await Promise.all([
        axios.get(SHIFTLY_API_URL, requestConfig),
        axios.get(MONTHLY_API_URL, requestConfig),
      ]);

      if (
        shiftlyResponse.data?.success !== true ||
        !Array.isArray(shiftlyResponse.data?.data)
      ) {
        throw new Error('Format respons API shiftly tidak valid.');
      }

      if (
        monthlyResponse.data?.success !== true ||
        !Array.isArray(monthlyResponse.data?.data)
      ) {
        throw new Error('Format respons API bulanan tidak valid.');
      }

      const records = shiftlyResponse.data.data.filter(
        (item) => item && item.line_table && item.shift_date
      );

      const monthlyRecords = monthlyResponse.data.data.filter(
        (item) => item && item.line_table && item.month && item.year
      );

      setRawData(records);
      setMonthlyRawData(monthlyRecords);
      setLastFetchedAt(new Date());

      if (!initialSelectionDoneRef.current && records.length > 0) {
        const latest = getLatestRecord(records);
        const kubikal1Exists = records.some(
          (item) => item.line_table === 'tb_kub1_total_kwh'
        );

        setSelectedLine(
          kubikal1Exists ? 'tb_kub1_total_kwh' : latest.line_table
        );
        setSelectedMonth(latest.month_name || currentMonth);
        setSelectedYear(toNumber(latest.year) || currentYear);
        initialSelectionDoneRef.current = true;
      }
    } catch (err) {
      if (
        axios.isCancel(err) ||
        err?.name === 'CanceledError' ||
        err?.name === 'AbortError'
      ) {
        return;
      }

      console.error('Gagal memuat dashboard energi:', err);
      setError(
        err?.response?.data?.message ||
          err?.message ||
          'Gagal memuat data dari server.'
      );
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, [currentMonth, currentYear]);

  useEffect(() => {
    fetchData(true);

    const intervalId = window.setInterval(() => {
      fetchData(false);
    }, REFRESH_INTERVAL_MS);

    return () => {
      window.clearInterval(intervalId);
      requestControllerRef.current?.abort();
    };
  }, [fetchData]);

  const lineOptions = useMemo(() => {
    const map = new Map();

    rawData.forEach((item) => {
      if (!map.has(item.line_table)) {
        map.set(
          item.line_table,
          formatLineLabel(item.line_table, item.line_name)
        );
      }
    });

    return [...map.entries()]
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label, 'id-ID'));
  }, [rawData]);

  const yearOptions = useMemo(() => {
    return [...new Set(rawData.map((item) => toNumber(item.year)).filter(Boolean))]
      .sort((a, b) => b - a);
  }, [rawData]);

  const selectedLineRecords = useMemo(() => {
    return rawData.filter((item) => item.line_table === selectedLine);
  }, [rawData, selectedLine]);

  const monthOptions = useMemo(() => {
    const available = new Set(
      selectedLineRecords
        .filter((item) => toNumber(item.year) === toNumber(selectedYear))
        .map((item) => item.month_name)
        .filter(Boolean)
    );

    return MONTHS.filter((month) => available.has(month));
  }, [selectedLineRecords, selectedYear]);

  useEffect(() => {
    if (monthOptions.length > 0 && !monthOptions.includes(selectedMonth)) {
      setSelectedMonth(monthOptions[monthOptions.length - 1]);
    }
  }, [monthOptions, selectedMonth]);

  const filteredRecords = useMemo(() => {
    return selectedLineRecords.filter(
      (item) =>
        String(item.month_name || '').toLowerCase() ===
          String(selectedMonth || '').toLowerCase() &&
        toNumber(item.year) === toNumber(selectedYear)
    );
  }, [selectedLineRecords, selectedMonth, selectedYear]);

  const dailyData = useMemo(() => {
    const grouped = new Map();

    filteredRecords.forEach((item) => {
      const dateKey = String(item.shift_date).slice(0, 10);
      const shiftKey = normalizeShift(item.shift);
      if (!shiftKey) return;

      if (!grouped.has(dateKey)) {
        grouped.set(dateKey, {
          dateKey,
          date: `${item.day_name || ''}, ${item.day || ''} ${String(
            item.month_name || ''
          ).slice(0, 3)}`,
          shift1: 0,
          shift2: 0,
          records: [],
        });
      }

      const group = grouped.get(dateKey);
      const kwh = toShiftlyKwh(item.total_kwh);

      group[shiftKey] += kwh;
      group.records.push({
        ...item,
        normalizedShift: shiftKey,
        kwh,
        cost: kwh * COST_PER_KWH,
        co2Kg: kwh * CO2_EMISSION_FACTOR,
      });
    });

    return [...grouped.values()]
      .sort((a, b) => parseDate(a.dateKey) - parseDate(b.dateKey))
      .map((item) => ({
        ...item,
        shift1: Number(item.shift1.toFixed(2)),
        shift2: Number(item.shift2.toFixed(2)),
        total: Number((item.shift1 + item.shift2).toFixed(2)),
      }));
  }, [filteredRecords]);

  const selectedLineMonthlyRecords = useMemo(() => {
    return monthlyRawData.filter((item) => item.line_table === selectedLine);
  }, [monthlyRawData, selectedLine]);

  const monthlyData = useMemo(() => {
    const grouped = new Map();

    selectedLineMonthlyRecords.forEach((item) => {
      const year = toNumber(item.year);
      const monthNumber = getMonthNumber(item.month);
      if (!year || !monthNumber) return;

      const monthName =
        String(item.month_name || '').trim() || MONTHS[monthNumber - 1];
      const key = `${year}-${String(monthNumber).padStart(2, '0')}`;

      if (!grouped.has(key)) {
        grouped.set(key, {
          key,
          year,
          month: monthNumber,
          monthName,
          period: `${monthName.slice(0, 3)} ${year}`,
          kwh: 0,
          rawTotalKwh: 0,
          startKwh: null,
          endKwh: null,
          startDate: item.month_start_date || null,
          endDate: item.month_end_date || null,
          startDatetime: item.month_start_datetime || null,
          endDatetime: item.month_end_datetime || null,
          updatedAt: item.updated_at || item.created_at || null,
        });
      }

      const group = grouped.get(key);
      const rawTotalKwh = toNumber(item.total_kwh);

      group.rawTotalKwh += rawTotalKwh;
      group.kwh += toMonthlyKwh(rawTotalKwh);

      if (item.start_kwh != null) {
        const startKwh = toNumber(item.start_kwh);
        if (group.startKwh == null || startKwh < group.startKwh) {
          group.startKwh = startKwh;
        }
      }

      if (item.end_kwh != null) {
        const endKwh = toNumber(item.end_kwh);
        if (group.endKwh == null || endKwh > group.endKwh) {
          group.endKwh = endKwh;
        }
      }

      if (
        item.month_start_datetime &&
        (!group.startDatetime || item.month_start_datetime < group.startDatetime)
      ) {
        group.startDatetime = item.month_start_datetime;
      }

      if (
        item.month_end_datetime &&
        (!group.endDatetime || item.month_end_datetime > group.endDatetime)
      ) {
        group.endDatetime = item.month_end_datetime;
      }

      if (
        item.month_start_date &&
        (!group.startDate || item.month_start_date < group.startDate)
      ) {
        group.startDate = item.month_start_date;
      }

      if (
        item.month_end_date &&
        (!group.endDate || item.month_end_date > group.endDate)
      ) {
        group.endDate = item.month_end_date;
      }

      const itemUpdatedAt = item.updated_at || item.created_at;
      if (itemUpdatedAt && (!group.updatedAt || itemUpdatedAt > group.updatedAt)) {
        group.updatedAt = itemUpdatedAt;
      }
    });

    return [...grouped.values()]
      .sort((a, b) => a.key.localeCompare(b.key))
      .map((item) => ({
        ...item,
        kwh: Number(item.kwh.toFixed(2)),
      }));
  }, [selectedLineMonthlyRecords]);

  const metrics = useMemo(() => {
    const totalShift1 = dailyData.reduce((sum, item) => sum + item.shift1, 0);
    const totalShift2 = dailyData.reduce((sum, item) => sum + item.shift2, 0);
    const totalKwh = totalShift1 + totalShift2;
    const daysCount = dailyData.length;
    const avgDaily = daysCount ? totalKwh / daysCount : 0;
    const peakValue = dailyData.length
      ? Math.max(...dailyData.flatMap((item) => [item.shift1, item.shift2]))
      : 0;

    return {
      totalShift1,
      totalShift2,
      totalKwh,
      avgDaily,
      peakValue,
      totalCost: totalKwh * COST_PER_KWH,
      totalCo2: totalKwh * CO2_EMISSION_FACTOR,
      daysCount,
    };
  }, [dailyData]);

  const latestApiUpdate = useMemo(() => {
    if (!filteredRecords.length) return null;

    const timestamps = filteredRecords
      .map((item) => new Date(String(item.updated_at || '').replace(' ', 'T')))
      .filter((date) => !Number.isNaN(date.getTime()));

    if (!timestamps.length) return null;
    return new Date(Math.max(...timestamps.map((date) => date.getTime())));
  }, [filteredRecords]);

  const selectedLineLabel =
    lineOptions.find((item) => item.value === selectedLine)?.label || 'Energi';

  const exportToExcel = () => {
    const detailRows = filteredRecords
      .slice()
      .sort((a, b) => {
        const dateDiff = parseDate(a.shift_date) - parseDate(b.shift_date);
        if (dateDiff !== 0) return dateDiff;
        return String(a.shift).localeCompare(String(b.shift));
      })
      .map((record) => {
        const kwh = toShiftlyKwh(record.total_kwh);

        return {
          Tanggal: record.shift_date,
          Hari: record.day_name,
          Shift: record.shift,
          'Mulai Shift': record.shift_start_datetime,
          'Akhir Shift': record.shift_end_datetime,
          Line: record.line_name,
          'Start Meter': toNumber(record.start_kwh),
          'End Meter': toNumber(record.end_kwh),
          'Energi (kWh)': Number(kwh.toFixed(2)),
          'Biaya (IDR)': Math.round(kwh * COST_PER_KWH),
          'Emisi CO2 (kg)': Number(
            (kwh * CO2_EMISSION_FACTOR).toFixed(2)
          ),
        };
      });

    detailRows.push({});
    detailRows.push({
      Tanggal: 'TOTAL',
      Shift: '-',
      'Energi (kWh)': Number(metrics.totalKwh.toFixed(2)),
      'Biaya (IDR)': Math.round(metrics.totalCost),
      'Emisi CO2 (kg)': Number(metrics.totalCo2.toFixed(2)),
    });

    const worksheet = XLSX.utils.json_to_sheet(detailRows);
    worksheet['!cols'] = [
      { wch: 13 },
      { wch: 12 },
      { wch: 10 },
      { wch: 20 },
      { wch: 20 },
      { wch: 18 },
      { wch: 18 },
      { wch: 18 },
      { wch: 16 },
      { wch: 18 },
      { wch: 18 },
    ];

    const monthlyRows = monthlyData.map((item) => ({
      Periode: item.period,
      Tahun: item.year,
      'Nomor Bulan': item.month,
      Bulan: item.monthName,
      'Tanggal Awal Bulan': item.startDate,
      'Tanggal Akhir Bulan': item.endDate,
      'Mulai Pengukuran': item.startDatetime,
      'Akhir Pengukuran': item.endDatetime,
      'Start Meter': item.startKwh,
      'End Meter': item.endKwh,
      'Total API': item.rawTotalKwh,
      'Energi (kWh)': item.kwh,
      'Biaya (IDR)': Math.round(item.kwh * COST_PER_KWH),
      'Emisi CO2 (kg)': Number(
        (item.kwh * CO2_EMISSION_FACTOR).toFixed(2)
      ),
      'Terakhir Diperbarui': item.updatedAt,
    }));

    const monthlyWorksheet = XLSX.utils.json_to_sheet(monthlyRows);
    monthlyWorksheet['!cols'] = [
      { wch: 14 },
      { wch: 10 },
      { wch: 12 },
      { wch: 12 },
      { wch: 18 },
      { wch: 18 },
      { wch: 20 },
      { wch: 20 },
      { wch: 18 },
      { wch: 18 },
      { wch: 18 },
      { wch: 16 },
      { wch: 18 },
      { wch: 18 },
      { wch: 20 },
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Shiftly Energy');
    XLSX.utils.book_append_sheet(workbook, monthlyWorksheet, 'Monthly Energy');

    const safeLineName = selectedLineLabel.replace(/[^a-zA-Z0-9_-]+/g, '_');
    XLSX.writeFile(
      workbook,
      `Energy_${safeLineName}_${selectedMonth}_${selectedYear}.xlsx`
    );
  };

  if (loading) {
    return (
      <Nais_Layout>
        <Container fluid className="p-1">
          <div style={{ padding: '24px', fontSize: '14px', color: '#475569' }}>
            Memuat dashboard energi...
          </div>
        </Container>
      </Nais_Layout>
    );
  }

  return (
    <Nais_Layout>
      <Container fluid className="p-1">
        <div
          style={{
            padding: '14px',
            fontFamily: 'Segoe UI, Arial, sans-serif',
            minHeight: '100%',
            background: '#f8fafc',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              gap: '12px',
              flexWrap: 'wrap',
              marginBottom: '12px',
            }}
          >
            <div>
              <h2
                style={{
                  color: '#0f5fa8',
                  margin: 0,
                  fontSize: '21px',
                  fontWeight: 800,
                }}
              >
                ⚡ Otics Indonesia Energy Dashboard — {selectedLineLabel}
              </h2>
              <p style={{ margin: '4px 0 0', fontSize: '13px', color: '#64748b' }}>
                Monitoring konsumsi energi berdasarkan data shift harian
              </p>
              <div style={{ marginTop: '5px', fontSize: '12px', color: '#94a3b8' }}>
                API diperbarui:{' '}
                {latestApiUpdate
                  ? latestApiUpdate.toLocaleString('id-ID')
                  : '-'}
                {' · '}Dashboard mengambil data:{' '}
                {lastFetchedAt ? lastFetchedAt.toLocaleString('id-ID') : '-'}
              </div>
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                flexWrap: 'wrap',
              }}
            >
              <select
                value={selectedLine}
                onChange={(event) => setSelectedLine(event.target.value)}
                style={{
                  padding: '7px 10px',
                  borderRadius: '7px',
                  border: '1px solid #cbd5e1',
                  backgroundColor: '#fff',
                  fontSize: '13px',
                }}
              >
                {lineOptions.map((line) => (
                  <option key={line.value} value={line.value}>
                    {line.label}
                  </option>
                ))}
              </select>

              <select
                value={selectedMonth}
                onChange={(event) => setSelectedMonth(event.target.value)}
                style={{
                  padding: '7px 10px',
                  borderRadius: '7px',
                  border: '1px solid #cbd5e1',
                  backgroundColor: '#fff',
                  fontSize: '13px',
                }}
              >
                {monthOptions.length ? (
                  monthOptions.map((month) => (
                    <option key={month} value={month}>
                      {month}
                    </option>
                  ))
                ) : (
                  <option value={selectedMonth}>{selectedMonth}</option>
                )}
              </select>

              <select
                value={selectedYear}
                onChange={(event) => setSelectedYear(Number(event.target.value))}
                style={{
                  padding: '7px 10px',
                  borderRadius: '7px',
                  border: '1px solid #cbd5e1',
                  backgroundColor: '#fff',
                  fontSize: '13px',
                }}
              >
                {yearOptions.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => fetchData(false)}
                disabled={refreshing}
                style={{
                  padding: '7px 11px',
                  border: 'none',
                  borderRadius: '7px',
                  backgroundColor: '#2563eb',
                  color: '#fff',
                  cursor: refreshing ? 'not-allowed' : 'pointer',
                  opacity: refreshing ? 0.65 : 1,
                  fontSize: '13px',
                  fontWeight: 600,
                }}
              >
                {refreshing ? 'Memperbarui...' : '↻ Refresh'}
              </button>

              <button
                type="button"
                onClick={exportToExcel}
                disabled={!filteredRecords.length}
                style={{
                  padding: '7px 11px',
                  border: 'none',
                  borderRadius: '7px',
                  backgroundColor: '#16a34a',
                  color: '#fff',
                  cursor: filteredRecords.length ? 'pointer' : 'not-allowed',
                  opacity: filteredRecords.length ? 1 : 0.55,
                  fontSize: '13px',
                  fontWeight: 600,
                }}
              >
                📊 Export Excel
              </button>
            </div>
          </div>

          {error && (
            <div
              style={{
                padding: '10px 12px',
                marginBottom: '12px',
                borderRadius: '7px',
                border: '1px solid #fecaca',
                backgroundColor: '#fef2f2',
                color: '#b91c1c',
                fontSize: '13px',
              }}
            >
              {error}
            </div>
          )}

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(165px, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <SummaryCard
              icon="⚡"
              title="Total Energy"
              subtitle={`${selectedMonth} ${selectedYear}`}
              value={`${formatDecimal(metrics.totalKwh)} kWh`}
              accent="#0284c7"
            />


            





            <SummaryCard
              icon="💰"
              title="Estimated Cost"
              subtitle={`Tarif ${formatCurrency(COST_PER_KWH)}/kWh`}
              value={formatCurrency(metrics.totalCost)}
              accent="#d97706"
            />
            <SummaryCard
              icon="📈"
              title="Daily Average"
              subtitle={`${metrics.daysCount} hari tercatat`}
              value={`${formatDecimal(metrics.avgDaily)} kWh`}
              accent="#16a34a"
            />
            <SummaryCard
              icon="☀️"
              title="Shift 1 Total"
              subtitle="SHIFT 1"
              value={`${formatDecimal(metrics.totalShift1)} kWh`}
              accent="#0891b2"
            />
            <SummaryCard
              icon="🌙"
              title="Shift 2 Total"
              subtitle="SHIFT 2"
              value={`${formatDecimal(metrics.totalShift2)} kWh`}
              accent="#4f46e5"
            />
            <SummaryCard
              icon="⬆️"
              title="Peak Shift"
              subtitle="Nilai shift tertinggi"
              value={`${formatDecimal(metrics.peakValue)} kWh`}
              accent="#dc2626"
            />
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                padding: '13px',
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
            >
              <div style={{ fontWeight: 800, color: '#dc2626', marginBottom: '9px' }}>
                🔥 CO₂ Emissions Summary
              </div>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '8px',
                  textAlign: 'center',
                }}
              >
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Monthly</div>
                  <strong>{formatDecimal(metrics.totalCo2)} kg</strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Daily Avg</div>
                  <strong>
                    {formatDecimal(
                      metrics.daysCount ? metrics.totalCo2 / metrics.daysCount : 0
                    )}{' '}
                    kg
                  </strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Projection</div>
                  <strong>{formatDecimal(metrics.totalCo2 * 12)} kg</strong>
                </div>
              </div>
            </div>

            <div
              style={{
                padding: '13px',
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
            >
              <div style={{ fontWeight: 800, color: '#d97706', marginBottom: '9px' }}>
                💰 Cost Analysis
              </div>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '8px',
                  textAlign: 'center',
                }}
              >
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Monthly</div>
                  <strong>{formatCurrency(metrics.totalCost)}</strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Daily Avg</div>
                  <strong>
                    {formatCurrency(
                      metrics.daysCount ? metrics.totalCost / metrics.daysCount : 0
                    )}
                  </strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Per kWh</div>
                  <strong>{formatCurrency(COST_PER_KWH)}</strong>
                </div>
              </div>
            </div>
          </div>

          <div
            style={{
              backgroundColor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: '9px',
              padding: '12px',
              marginBottom: '12px',
            }}
          >
            <div style={{ fontWeight: 800, color: '#1e293b', marginBottom: '4px' }}>
              Konsumsi Energi Harian per Shift
            </div>
            <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '8px' }}>
              {selectedMonth} {selectedYear} · {selectedLineLabel}
            </div>

            {dailyData.length ? (
              <div style={{ width: '100%', height: '330px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={dailyData}
                    margin={{ top: 28, right: 18, left: 8, bottom: 5 }}
                  >
                    <defs>
                      <linearGradient id="gradientShift1" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#14b8a6" stopOpacity={1} />
                        <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.55} />
                      </linearGradient>
                      <linearGradient id="gradientShift2" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4f46e5" stopOpacity={1} />
                        <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.55} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
                    <XAxis
                      dataKey="dateKey"
                      tick={{ fontSize: 11 }}
                      tickFormatter={(value) => {
                        const [, month, day] = String(value).split('-');
                        return `${day}/${month}`;
                      }}
                    />
                    <YAxis
                      tick={{ fontSize: 11 }}
                      tickFormatter={formatNumber}
                      label={{
                        value: 'kWh',
                        angle: -90,
                        position: 'insideLeft',
                        style: { textAnchor: 'middle', fontWeight: 700 },
                      }}
                    />
                    <Tooltip
                      formatter={(value, name) => [
                        `${formatDecimal(value)} kWh`,
                        name,
                      ]}
                      labelFormatter={(_, payload) =>
                        payload?.[0]?.payload?.date || '-'
                      }
                      contentStyle={{
                        borderRadius: '8px',
                        border: '1px solid #cbd5e1',
                      }}
                    />
                    <Legend verticalAlign="top" height={28} />
                    <Bar
                      dataKey="shift1"
                      fill="url(#gradientShift1)"
                      name="Shift 1"
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar
                      dataKey="shift2"
                      fill="url(#gradientShift2)"
                      name="Shift 2"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div
                style={{
                  padding: '32px',
                  textAlign: 'center',
                  color: '#64748b',
                  fontSize: '13px',
                }}
              >
                Tidak ada data untuk filter yang dipilih.
              </div>
            )}
          </div>

          <div
            style={{
              backgroundColor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: '9px',
              padding: '12px',
            }}
          >
            <div style={{ fontWeight: 800, color: '#1e293b', marginBottom: '4px' }}>
              Tren Konsumsi Energi Bulanan
            </div>
            <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '8px' }}>
              Sumber data: /api/pm-monthly-kub-kwh · {selectedLineLabel}
            </div>

            <div style={{ width: '100%', height: '300px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={monthlyData}
                  margin={{ top: 28, right: 18, left: 8, bottom: 10 }}
                >
                  <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
                  <XAxis
                    dataKey="period"
                    tick={{ fontSize: 11 }}
                    interval={0}
                  />
                  <YAxis
                    tick={{ fontSize: 11 }}
                    tickFormatter={formatNumber}
                    label={{
                      value: 'kWh',
                      angle: -90,
                      position: 'insideLeft',
                      style: { textAnchor: 'middle', fontWeight: 700 },
                    }}
                  />
                  <Tooltip
                    formatter={(value) => [`${formatDecimal(value)} kWh`, 'Konsumsi']}
                    labelFormatter={(label) => `Periode: ${label}`}
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid #cbd5e1',
                    }}
                  />
                  <Bar
                    dataKey="kwh"
                    fill="#0284c7"
                    radius={[4, 4, 0, 0]}
                    name="Konsumsi (kWh)"
                  >
                    <LabelList
                      dataKey="kwh"
                      position="top"
                      formatter={formatNumber}
                      fill="#334155"
                      fontSize={10}
                      fontWeight="bold"
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </Container>
    </Nais_Layout>
  );
};

export default MainDashboardListrik;