import React, { useState, useRef, useCallback, useEffect } from 'react';
import Layout from '../layout/Layout';

const API_ENDPOINT = '/api/layout-otics';

const LayoutListrikOtics1 = () => {
  const [panels, setPanels] = useState([
    {
      id: 'panel-lpf_qad',
      name: 'LPF_QAD',
      label: 'Low Pressure Filter QAD',
      description: 'Filtration component for QAD system',
      position: { top: '80.70%', left: '92.82%' },
      status: 'operational',
      labelPos: { top: '80.70%', left: '87.00%' },
    },
    {
      id: 'panel-hla',
      name: 'HLA',
      label: 'Hydraulic Lash Adjuster',
      description: 'Engine valve train component',
      position: { top: '84.30%', left: '85.72%' },
      status: 'operational',
      labelPos: { top: '84.30%', left: '80.00%' },
    },
    {
      id: 'panel-roller-arm',
      name: 'Roller Arm',
      label: 'Engine Roller Arm',
      description: 'Valve train roller component',
      position: { top: '63.88%', left: '68.01%' },
      status: 'operational',
      labelPos: { top: '60.00%', left: '68.01%' },
    },
    {
      id: 'panel-balance-shaft-1',
      name: 'Balance Shaft 1',
      label: 'Engine Balance Shaft 1',
      description: 'Vibration reduction component 1',
      position: { top: '51.20%', left: '78.50%' },
      status: 'operational',
      labelPos: { top: '47.00%', left: '78.50%' },
    },
    {
      id: 'panel-balance-shaft-2',
      name: 'Balance Shaft 2',
      label: 'Engine Balance Shaft 2',
      description: 'Vibration reduction component 2',
      position: { top: '59.88%', left: '78.36%' },
      status: 'operational',
      labelPos: { top: '64.00%', left: '78.36%' },
    },
    {
      id: 'panel-connector',
      name: 'Connector',
      label: 'System Connector',
      description: 'Electrical or fluid connector',
      position: { top: '48.57%', left: '78.13%' },
      status: 'operational',
      labelPos: { top: '48.57%', left: '83.00%' },
    },
    {
      id: 'panel-retainer',
      name: 'Retainer',
      label: 'Component Retainer',
      description: 'Holding mechanism component',
      position: { top: '48.44%', left: '74.20%' },
      status: 'operational',
      labelPos: { top: '48.44%', left: '70.00%' },
    },
    {
      id: 'panel-cam-cap-123',
      name: 'Cam cap 123',
      label: 'Camshaft Cap 123',
      description: 'Camshaft housing cap assembly',
      position: { top: '78.78%', left: '58.29%' },
      status: 'operational',
      labelPos: { top: '75.00%', left: '58.29%' },
    },
    {
      id: 'panel-d-mtc',
      name: 'Panel D MTC',
      label: 'Distribution Panel D MTC',
      description: 'Monitoring panel for MTC area',
      position: { top: '86.47%', left: '51.53%' },
      status: 'operational',
      labelPos: { top: '91.00%', left: '51.53%' },
    },
    {
      id: 'panel-cam-housing-ef',
      name: 'Cam Housing EF',
      label: 'Cam Housing Assembly EF',
      description: 'Camshaft housing section EF',
      position: { top: '78.88%', left: '51.48%' },
      status: 'operational',
      labelPos: { top: '75.00%', left: '51.48%' },
    },
    {
      id: 'panel-cam-cap-45',
      name: 'Cam cap 45',
      label: 'Camshaft Cap 45',
      description: 'Camshaft housing cap assembly',
      position: { top: '70.04%', left: '55.50%' },
      status: 'operational',
      labelPos: { top: '70.04%', left: '60.00%' },
    },
    {
      id: 'panel-cam-housing-sub-assy-c',
      name: 'Cam Housing Sub Assy C',
      label: 'Cam Housing Sub Assembly C',
      description: 'Sub assembly for cam housing section C',
      position: { top: '70.04%', left: '49.35%' },
      status: 'operational',
      labelPos: { top: '70.04%', left: '44.00%' },
    },
    {
      id: 'panel-common-rail-12',
      name: 'Common Rail 12',
      label: 'Fuel Common Rail 12',
      description: 'High pressure fuel line 12',
      position: { top: '59.70%', left: '55.03%' },
      status: 'operational',
      labelPos: { top: '65.00%', left: '55.03%' },
    },
    {
      id: 'panel-common-rail-11',
      name: 'Common Rail 11',
      label: 'Fuel Common Rail 11',
      description: 'High pressure fuel line 11',
      position: { top: '59.75%', left: '49.25%' },
      status: 'operational',
      labelPos: { top: '65.00%', left: '49.25%' },
    },
    {
      id: 'panel-common-rail-10',
      name: 'Common Rail 10',
      label: 'Fuel Common Rail 10',
      description: 'High pressure fuel line 10',
      position: { top: '48.85%', left: '63.95%' },
      status: 'operational',
      labelPos: { top: '44.00%', left: '63.95%' },
    },
    {
      id: 'panel-common-rail-9',
      name: 'Common Rail 9',
      label: 'Fuel Common Rail 9',
      description: 'High pressure fuel line 9',
      position: { top: '48.77%', left: '48.71%' },
      status: 'operational',
      labelPos: { top: '44.00%', left: '48.71%' },
    },
    {
      id: 'panel-kubikal-2',
      name: 'Kubikal 2',
      label: 'Kubikal Unit 2',
      description: 'Control unit kubikal 2',
      position: { top: '92.65%', left: '24.45%' },
      status: 'operational',
      labelPos: { top: '97.00%', left: '24.45%' },
    },
    {
      id: 'panel-workshop-eng',
      name: 'Panel Workshop Eng',
      label: 'Workshop Engine Panel',
      description: 'Monitoring panel for workshop engine',
      position: { top: '87.10%', left: '21.02%' },
      status: 'operational',
      labelPos: { top: '92.00%', left: '21.02%' },
    },
    {
      id: 'panel-cam-housing-cd',
      name: 'Cam Housing CD',
      label: 'Cam Housing Assembly CD',
      description: 'Camshaft housing section CD',
      position: { top: '78.73%', left: '22.65%' },
      status: 'operational',
      labelPos: { top: '75.00%', left: '22.65%' },
    },
    {
      id: 'panel-cam-housing-ab',
      name: 'Cam Housing AB',
      label: 'Cam Housing Assembly AB',
      description: 'Camshaft housing section AB',
      position: { top: '78.77%', left: '21.43%' },
      status: 'operational',
      labelPos: { top: '75.00%', left: '21.43%' },
    },
    {
      id: 'panel-cam-housing-sub-assy-a',
      name: 'Cam Housing Sub Assy A',
      label: 'Cam Housing Sub Assembly A',
      description: 'Sub assembly for cam housing section A',
      position: { top: '70.20%', left: '19.78%' },
      status: 'operational',
      labelPos: { top: '70.20%', left: '24.00%' },
    },
    {
      id: 'panel-cam-housing-sub-assy-b',
      name: 'Cam Housing Sub Assy B',
      label: 'Cam Housing Sub Assembly B',
      description: 'Sub assembly for cam housing section B',
      position: { top: '69.97%', left: '32.02%' },
      status: 'operational',
      labelPos: { top: '69.97%', left: '27.00%' },
    },
    {
      id: 'panel-common-rail-7',
      name: 'Common Rail 7',
      label: 'Fuel Common Rail 7',
      description: 'High pressure fuel line 7',
      position: { top: '59.88%', left: '10.52%' },
      status: 'operational',
      labelPos: { top: '59.88%', left: '15.00%' },
    },
    {
      id: 'panel-common-rail-8',
      name: 'Common Rail 8',
      label: 'Fuel Common Rail 8',
      description: 'High pressure fuel line 8',
      position: { top: '59.79%', left: '25.77%' },
      status: 'operational',
      labelPos: { top: '65.00%', left: '25.77%' },
    },
    {
      id: 'panel-common-rail-5',
      name: 'Common Rail 5',
      label: 'Fuel Common Rail 5',
      description: 'High pressure fuel line 5',
      position: { top: '40.62%', left: '22.94%' },
      status: 'operational',
      labelPos: { top: '37.00%', left: '22.94%' },
    },
    {
      id: 'panel-common-rail-6',
      name: 'Common Rail 6',
      label: 'Fuel Common Rail 6',
      description: 'High pressure fuel line 6',
      position: { top: '40.85%', left: '29.23%' },
      status: 'operational',
      labelPos: { top: '45.00%', left: '29.23%' },
    },
    {
      id: 'panel-common-rail-4',
      name: 'Common Rail 4',
      label: 'Fuel Common Rail 4',
      description: 'High pressure fuel line 4',
      position: { top: '38.99%', left: '24.98%' },
      status: 'operational',
      labelPos: { top: '35.00%', left: '24.98%' },
    },
    {
      id: 'panel-common-rail-3',
      name: 'Common Rail 3',
      label: 'Fuel Common Rail 3',
      description: 'High pressure fuel line 3',
      position: { top: '38.95%', left: '10.59%' },
      status: 'operational',
      labelPos: { top: '38.95%', left: '15.00%' },
    },
    {
      id: 'panel-common-rail-2',
      name: 'Common Rail 2',
      label: 'Fuel Common Rail 2',
      description: 'High pressure fuel line 2',
      position: { top: '19.43%', left: '22.94%' },
      status: 'operational',
      labelPos: { top: '24.00%', left: '22.94%' },
    },
    {
      id: 'panel-common-rail-1',
      name: 'Common Rail 1',
      label: 'Fuel Common Rail 1',
      description: 'High pressure fuel line 1',
      position: { top: '19.51%', left: '16.04%' },
      status: 'operational',
      labelPos: { top: '19.51%', left: '21.00%' },
    },
    {
      id: 'panel-lpacr1cr2',
      name: 'LPACR1CR2',
      label: 'Low Pressure AC Rail 1 CR 2',
      description: 'Low pressure assembly component',
      position: { top: '16.75%', left: '21.18%' },
      status: 'operational',
      labelPos: { top: '21.00%', left: '21.18%' },
    },
    {
      id: 'panel-lpf2',
      name: 'LPF2',
      label: 'Low Pressure Filter 2',
      description: 'Filtration component unit 2',
      position: { top: '62.94%', left: '64.33%' },
      status: 'operational',
      labelPos: { top: '67.00%', left: '64.33%' },
    },
    {
      id: 'panel-lpf1',
      name: 'LPF1',
      label: 'Low Pressure Filter 1',
      description: 'Filtration component unit 1',
      position: { top: '57.48%', left: '88.07%' },
      status: 'operational',
      labelPos: { top: '57.48%', left: '83.00%' },
    },
    {
      id: 'panel-lpf3',
      name: 'LPF3',
      label: 'Low Pressure Filter 3',
      description: 'Filtration component unit 3',
      position: { top: '86.61%', left: '25.32%' },
      status: 'operational',
      labelPos: { top: '91.00%', left: '25.32%' },
    },
  ]);

  const [apiData, setApiData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  const [scale, setScale] = useState(1);
  const [calibrationMode, setCalibrationMode] = useState(false);
  const [mousePos, setMousePos] = useState({ x: null, y: null });

  const [draggingLabelId, setDraggingLabelId] = useState(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [dragStartLabelPos, setDragStartLabelPos] = useState({ top: 0, left: 0 });

  const scaleRef = useRef(scale);
  const containerRef = useRef(null);
  const contentRef = useRef(null);

  const [isDragging, setIsDragging] = useState(false);
  const [startMouse, setStartMouse] = useState({ x: 0, y: 0 });
  const [startScroll, setStartScroll] = useState({ left: 0, top: 0 });

  useEffect(() => {
    scaleRef.current = scale;
  }, [scale]);

  const fieldMapping = {
    'panel-lpf_qad': { pm200: null, pm220: null, other: 'tb_lpqad_value' },
    'panel-hla': { pm200: 'tb_pm200_hla_value', pm220: 'tb_pm220_hla_value' },
    'panel-roller-arm': { pm200: 'tb_pm200_ra_value', pm220: 'tb_pm220_ra_value' },
    'panel-balance-shaft-1': { pm200: 'tb_pm200_bs1_value', pm220: 'tb_pm220_bs1_value' },
    'panel-balance-shaft-2': { pm200: 'tb_pm200_bs2_value', pm220: 'tb_pm220_bs2_value' },
    'panel-connector': { pm200: 'tb_pm200_conn_value', pm220: 'tb_pm220_conn_value' },
    'panel-retainer': { pm200: 'tb_pm200_ret_value', pm220: 'tb_pm220_ret_value' },
    'panel-cam-cap-123': { pm200: 'tb_pm200_cc234_value', pm220: 'tb_pm220_cc234_value' },
    'panel-d-mtc': { pm200: null, pm220: null, other: 'tb_lp_dmtc_value' },
    'panel-cam-housing-ef': { pm200: 'tb_pm200_chef_value', pm220: 'tb_pm220_chef_value' },
    'panel-cam-cap-45': { pm200: 'tb_pm200_cc1_value', pm220: 'tb_pm220_cc1_value' },
    'panel-cam-housing-sub-assy-c': { pm200: 'tb_pm200_chsac_value', pm220: 'tb_pm220_chsac_value' },
    'panel-common-rail-12': { pm200: 'tb_pm200_cr12_value', pm220: 'tb_pm220_cr12_value' },
    'panel-common-rail-11': { pm200: 'tb_pm200_cr11_value', pm220: 'tb_pm220_cr11_value' },
    'panel-common-rail-10': { pm200: 'tb_pm200_cr10_value', pm220: 'tb_pm220_cr10_value' },
    'panel-common-rail-9': { pm200: 'tb_pm200_cr9_value', pm220: 'tb_pm220_cr9_value' },
    'panel-kubikal-2': { pm200: null, pm220: null, other: 'tb_kub2_panel_1_total_kwh_value' },
    'panel-workshop-eng': { pm200: 'tb_pm200_weng_value', pm220: null },
    'panel-cam-housing-cd': { pm200: 'tb_pm200_chcd_value', pm220: 'tb_pm220_chcd_value' },
    'panel-cam-housing-ab': { pm200: 'tb_pm200_chab_value', pm220: 'tb_pm220_chab_value' },
    'panel-cam-housing-sub-assy-a': { pm200: 'tb_pm200_chsaa_value', pm220: 'tb_pm220_chsaa_value' },
    'panel-cam-housing-sub-assy-b': { pm200: 'tb_pm200_chsab_value', pm220: 'tb_pm220_chsab_value' },
    'panel-common-rail-7': { pm200: 'tb_pm200_cr7_value', pm220: 'tb_pm220_cr7_value' },
    'panel-common-rail-8': { pm200: 'tb_pm200_cr8_value', pm220: 'tb_pm220_cr8_value' },
    'panel-common-rail-5': { pm200: 'tb_pm200_cr5_value', pm220: 'tb_pm220_cr5_value' },
    'panel-common-rail-6': { pm200: 'tb_pm200_cr6_value', pm220: 'tb_pm220_cr6_value' },
    'panel-common-rail-4': { pm200: 'tb_pm200_cr4_value', pm220: 'tb_pm220_cr4_value' },
    'panel-common-rail-3': { pm200: 'tb_pm200_cr3_value', pm220: 'tb_pm220_cr3_value' },
    'panel-common-rail-2': { pm200: 'tb_pm200_cr2_value', pm220: 'tb_pm220_cr2_value' },
    'panel-common-rail-1': { pm200: 'tb_pm200_cr1_value', pm220: 'tb_pm220_cr1_value' },
    'panel-lpacr1cr2': { pm200: null, pm220: null, other: 'tb_area_cr1cr2_value' },
    'panel-lpf2': { pm200: null, pm220: null, other: 'tb_lpf2_value' },
    'panel-lpf1': { pm200: null, pm220: null, other: 'tb_lpf1_value' },
    'panel-lpf3': { pm200: null, pm220: 'tb_pm220_lpf3_value' },
  };

  useEffect(() => {
    const controller = new AbortController();

    const fetchLayoutData = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(API_ENDPOINT, {
          method: 'GET',
          headers: {
            Accept: 'application/json',
          },
          signal: controller.signal,
        });

        if (!response.ok) {
          throw new Error(`Gagal mengambil data. Status: ${response.status}`);
        }

        const result = await response.json();

        if (result.success && Array.isArray(result.data) && result.data.length > 0) {
          setApiData(result.data[0]);
          setLastUpdated(result.data[0].date_time);
        } else {
          setApiData(null);
          setLastUpdated(null);
          setError('Tidak ada data tersedia');
        }
      } catch (err) {
        if (err.name !== 'AbortError') {
          setError(err.message || 'Terjadi kesalahan saat mengambil data');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchLayoutData();

    return () => {
      controller.abort();
    };
  }, []);

  const formatValue = (value) => {
    if (value === null || value === undefined) return null;

    const num = parseFloat(value);

    if (Number.isNaN(num)) return null;

    return num;
  };

  const formatNumber = (num) => {
    if (num === null || num === undefined) return null;

    return num.toLocaleString('id-ID', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  const getPanelValues = (panelId) => {
    if (!apiData) {
      return {
        pm200: null,
        pm220: null,
        other: null,
      };
    }

    const mapping = fieldMapping[panelId];

    if (!mapping) {
      return {
        pm200: null,
        pm220: null,
        other: null,
      };
    }

    let pm200 = null;
    let pm220 = null;
    let other = null;

    if (mapping.pm200) {
      pm200 = formatValue(apiData[mapping.pm200]);
    }

    if (mapping.pm220) {
      pm220 = formatValue(apiData[mapping.pm220]);
    }

    if (mapping.other) {
      other = formatValue(apiData[mapping.other]);
    }

    return {
      pm200,
      pm220,
      other,
    };
  };

  const handleWheel = useCallback((e) => {
    if (!e.ctrlKey) return;

    e.preventDefault();

    const container = containerRef.current;
    const content = contentRef.current;

    if (!container || !content) return;

    const rect = container.getBoundingClientRect();

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const contentX = mouseX + container.scrollLeft;
    const contentY = mouseY + container.scrollTop;

    const delta = -e.deltaY * 0.001;
    const oldScale = scaleRef.current;
    const newScale = Math.min(Math.max(oldScale + delta, 0.5), 3);

    const newScrollLeft = (contentX * newScale) / oldScale - mouseX;
    const newScrollTop = (contentY * newScale) / oldScale - mouseY;

    setScale(newScale);

    container.scrollLeft = newScrollLeft;
    container.scrollTop = newScrollTop;
  }, []);

  const handleMouseMoveOnImage = useCallback((e) => {
    if (!calibrationMode) return;

    const img = e.target;

    if (img.tagName !== 'IMG') return;

    const rect = img.getBoundingClientRect();

    const leftPercent = ((e.clientX - rect.left) / rect.width) * 100;
    const topPercent = ((e.clientY - rect.top) / rect.height) * 100;

    setMousePos({
      x: leftPercent.toFixed(2),
      y: topPercent.toFixed(2),
    });
  }, [calibrationMode]);

  const handleImageClick = (e) => {
    if (!calibrationMode) return;

    const img = e.target;

    if (img.tagName !== 'IMG') return;

    const rect = img.getBoundingClientRect();

    const leftPercent = ((e.clientX - rect.left) / rect.width) * 100;
    const topPercent = ((e.clientY - rect.top) / rect.height) * 100;

    alert(`Koordinat: left: ${leftPercent.toFixed(2)}%, top: ${topPercent.toFixed(2)}%`);
  };

  useEffect(() => {
    if (!calibrationMode) return;

    const handleClickOutside = (e) => {
      if (!e.target.closest('img')) {
        setCalibrationMode(false);
        setMousePos({
          x: null,
          y: null,
        });
      }
    };

    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [calibrationMode]);

  const handleMouseDown = useCallback((e) => {
    if (e.button !== 0) return;

    if (e.target.closest('.marker')) return;

    e.preventDefault();

    setIsDragging(true);

    setStartMouse({
      x: e.clientX,
      y: e.clientY,
    });

    setStartScroll({
      left: containerRef.current.scrollLeft,
      top: containerRef.current.scrollTop,
    });
  }, []);

  const handleMouseMove = useCallback(
    (e) => {
      if (draggingLabelId) {
        e.preventDefault();

        const img = contentRef.current?.querySelector('img');

        if (!img) return;

        const dx = e.clientX - dragStart.x;
        const dy = e.clientY - dragStart.y;

        const imgWidth = img.offsetWidth / scaleRef.current;
        const imgHeight = img.offsetHeight / scaleRef.current;

        const deltaLeft = (dx / imgWidth) * 100 * 0.5;
        const deltaTop = (dy / imgHeight) * 100 * 0.5;

        const newLeft = parseFloat(dragStartLabelPos.left) + deltaLeft;
        const newTop = parseFloat(dragStartLabelPos.top) + deltaTop;

        setPanels((prev) =>
          prev.map((panel) =>
            panel.id === draggingLabelId
              ? {
                  ...panel,
                  labelPos: {
                    left: `${newLeft}%`,
                    top: `${newTop}%`,
                  },
                }
              : panel
          )
        );

        return;
      }

      if (!isDragging) return;

      e.preventDefault();

      const dx = e.clientX - startMouse.x;
      const dy = e.clientY - startMouse.y;

      containerRef.current.scrollLeft = startScroll.left - dx;
      containerRef.current.scrollTop = startScroll.top - dy;
    },
    [
      isDragging,
      startMouse,
      startScroll,
      draggingLabelId,
      dragStart,
      dragStartLabelPos,
    ]
  );

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setDraggingLabelId(null);
  }, []);

  useEffect(() => {
    if (isDragging || draggingLabelId) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    } else {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, draggingLabelId, handleMouseMove, handleMouseUp]);

  const handleLabelMouseDown = (e, panelId, currentLabelPos) => {
    e.stopPropagation();
    e.preventDefault();

    setDraggingLabelId(panelId);

    setDragStart({
      x: e.clientX,
      y: e.clientY,
    });

    setDragStartLabelPos({
      left: currentLabelPos.left,
      top: currentLabelPos.top,
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'operational':
        return 'bg-green-500';
      case 'warning':
        return 'bg-yellow-500';
      case 'maintenance':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 p-2 sm:p-4">
        <div className="w-full mx-auto bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-4 border-b border-gray-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">
                Layout Listrik Otics 1
              </h1>

              {loading && (
                <p className="text-sm text-blue-500">
                  Memuat data...
                </p>
              )}

              {error && (
                <p className="text-sm text-red-500">
                  Error: {error}
                </p>
              )}

              {lastUpdated && (
                <p className="text-xs text-gray-500 mt-1">
                  Terakhir diperbarui:{' '}
                  {new Date(lastUpdated).toLocaleString('id-ID')}
                </p>
              )}
            </div>

            <div className="flex items-center space-x-2 flex-wrap">
              <div className="flex items-center bg-gray-100 rounded-lg border border-gray-300">
                <button
                  onClick={() => setScale((s) => Math.max(s - 0.2, 0.5))}
                  className="px-3 py-2 text-gray-700 hover:bg-gray-200 rounded-l-lg"
                >
                  -
                </button>

                <span className="px-3 py-2 text-sm font-medium text-gray-700 border-x border-gray-300">
                  {Math.round(scale * 100)}%
                </span>

                <button
                  onClick={() => setScale((s) => Math.min(s + 0.2, 3))}
                  className="px-3 py-2 text-gray-700 hover:bg-gray-200"
                >
                  +
                </button>

                <button
                  onClick={() => setScale(1)}
                  className="px-3 py-2 text-gray-700 hover:bg-gray-200 rounded-r-lg border-l border-gray-300"
                >
                  ⟲
                </button>
              </div>

              <button
                onClick={() => setCalibrationMode(!calibrationMode)}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  calibrationMode
                    ? 'bg-red-500 hover:bg-red-600 text-white'
                    : 'bg-blue-500 hover:bg-blue-600 text-white'
                }`}
              >
                {calibrationMode
                  ? 'Mode Kalibrasi (klik gambar)'
                  : 'Kalibrasi'}
              </button>
            </div>
          </div>

          <div
            ref={containerRef}
            className="relative overflow-auto bg-gray-100"
            style={{
              height: '80vh',
              cursor: isDragging ? 'grabbing' : 'grab',
            }}
            onWheel={handleWheel}
            onMouseDown={handleMouseDown}
          >
            <div
              ref={contentRef}
              style={{
                transform: `scale(${scale})`,
                transformOrigin: 'top left',
                display: 'inline-block',
                position: 'relative',
              }}
            >
              <img
                src="/l1.jpg"
                alt="Electrical Layout"
                className="block max-w-full h-auto"
                onClick={handleImageClick}
                onMouseMove={handleMouseMoveOnImage}
                onMouseLeave={() =>
                  setMousePos({
                    x: null,
                    y: null,
                  })
                }
              />

              <svg
                className="absolute top-0 left-0 w-full h-full pointer-events-none"
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
                style={{ zIndex: 15 }}
              >
                {panels.map((panel) => {
                  const startX = parseFloat(panel.position.left);
                  const startY = parseFloat(panel.position.top);
                  const endX = parseFloat(panel.labelPos.left);
                  const endY = parseFloat(panel.labelPos.top);

                  return (
                    <line
                      key={`line-${panel.id}`}
                      x1={startX}
                      y1={startY}
                      x2={endX}
                      y2={endY}
                      stroke="#6b7280"
                      strokeWidth="0.2"
                      strokeDasharray="2 2"
                    />
                  );
                })}
              </svg>

              {panels.map((panel) => {
                const values = getPanelValues(panel.id);

                const hasPm200 = values.pm200 !== null;
                const hasPm220 = values.pm220 !== null;
                const hasOther = values.other !== null;

                return (
                  <React.Fragment key={panel.id}>
                    <div
                      className="absolute marker"
                      style={{
                        top: panel.position.top,
                        left: panel.position.left,
                        transform: 'translate(-50%, -50%)',
                        zIndex: 20,
                      }}
                    >
                      <div
                        className={`w-3 h-3 border border-white shadow-md cursor-pointer group ${getStatusColor(
                          panel.status
                        )}`}
                        style={{
                          boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
                        }}
                      >
                        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-56 bg-white border border-gray-200 rounded-lg shadow-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 text-xs">
                          <div className="font-bold text-gray-800 mb-1">
                            {panel.name}
                          </div>

                          <div className="text-gray-600">
                            {panel.label}
                          </div>

                          <div className="text-gray-500 mt-1">
                            {panel.description}
                          </div>

                          <div className="mt-2 space-y-1">
                            {hasPm200 && (
                              <div>
                                <span className="font-medium">PM200:</span>{' '}
                                {formatNumber(values.pm200)} kWh
                              </div>
                            )}

                            {hasPm220 && (
                              <div>
                                <span className="font-medium">PM220:</span>{' '}
                                {formatNumber(values.pm220)} kWh
                              </div>
                            )}

                            {hasOther && (
                              <div>
                                <span className="font-medium">Nilai:</span>{' '}
                                {formatNumber(values.other)} kWh
                              </div>
                            )}

                            {!hasPm200 && !hasPm220 && !hasOther && (
                              <div>Data tidak tersedia</div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      className="absolute whitespace-nowrap bg-yellow-300 bg-opacity-90 px-1 py-0.5 rounded shadow-sm border border-gray-200 text-[8px] leading-tight flex flex-col cursor-move select-none"
                      style={{
                        top: panel.labelPos.top,
                        left: panel.labelPos.left,
                        transform: 'translate(-50%, -50%)',
                        zIndex: 30,
                      }}
                      onMouseDown={(e) =>
                        handleLabelMouseDown(e, panel.id, panel.labelPos)
                      }
                    >
                      {hasPm200 && (
                        <div className="text-blue-900">
                          PM200: {formatNumber(values.pm200)} Wh
                        </div>
                      )}

                      {hasPm220 && (
                        <div className="text-purple-900">
                          PM220: {formatNumber(values.pm220)} Wh
                        </div>
                      )}

                      {hasOther && (
                        <div className="text-green-900">
                          {formatNumber(values.other)} kWh
                        </div>
                      )}

                      {!hasPm200 && !hasPm220 && !hasOther && (
                        <span className="text-gray-400">N/A</span>
                      )}
                    </div>
                  </React.Fragment>
                );
              })}
            </div>

            {calibrationMode && mousePos.x && mousePos.y && (
              <div className="fixed bottom-4 right-4 bg-black text-white px-3 py-1 rounded shadow-lg text-sm z-50">
                Koordinat: left {mousePos.x}%, top {mousePos.y}%
              </div>
            )}
          </div>

          <div className="p-4 flex flex-wrap gap-4 text-xs border-t border-gray-200">
            <span className="flex items-center">
              <span className="w-3 h-3 bg-green-500 mr-1"></span>
              Operational
            </span>

            <span className="flex items-center">
              <span className="w-3 h-3 bg-yellow-500 mr-1"></span>
              Warning
            </span>

            <span className="flex items-center">
              <span className="w-3 h-3 bg-red-500 mr-1"></span>
              Maintenance
            </span>

            <span className="flex items-center">
              <span className="w-3 h-3 bg-blue-500 mr-1"></span>
              PM200
            </span>

            <span className="flex items-center">
              <span className="w-3 h-3 bg-purple-500 mr-1"></span>
              PM220
            </span>

            <span className="flex items-center">
              <span className="w-3 h-3 bg-green-500 mr-1"></span>
              Nilai tunggal
            </span>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default LayoutListrikOtics1;