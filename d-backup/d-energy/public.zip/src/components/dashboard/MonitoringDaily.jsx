import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Layout from '../layout/Layout';



const REFRESH_INTERVAL_MS = 600_000;
const REQUEST_CONCURRENCY = 6;
const MAX_POINTS_PER_CHART = 120;
const API_ROW_LIMIT = 500;
const STALE_TIMEOUT_MS = 10 * 60 * 1000;
const STALE_CHECK_INTERVAL_MS = 10_000;

const FALLBACK_TABLES = [
  'tb_pm200_bs1',
  'tb_pm200_bs2',
  'tb_pm200_cc1',
  'tb_pm200_cc234',
  'tb_pm200_chab',
  'tb_pm200_chcd',
  'tb_pm200_chef',
  'tb_pm200_chsaa',
  'tb_pm200_chsab',
  'tb_pm200_chsac',
  'tb_pm200_conn',
  'tb_pm200_cr1',
  'tb_pm200_cr10',
  'tb_pm200_cr11',
  'tb_pm200_cr12',
  'tb_pm200_cr2',
  'tb_pm200_cr3',
  'tb_pm200_cr4',
  'tb_pm200_cr5',
  'tb_pm200_cr6',
  'tb_pm200_cr7',
  'tb_pm200_cr8',
  'tb_pm200_cr9',
  'tb_pm200_ct',
  'tb_pm200_hla',
  'tb_pm200_ra',
  'tb_pm200_ret',
  'tb_pm200_weng',
  'tb_pm220_bs1',
  'tb_pm220_bs2',
  'tb_pm220_cc1',
  'tb_pm220_cc234',
  'tb_pm220_chab',
  'tb_pm220_chcd',
  'tb_pm220_chef',
  'tb_pm220_chsaa',
  'tb_pm220_chsab',
  'tb_pm220_chsac',
  'tb_pm220_conn',
  'tb_pm220_cr1',
  'tb_pm220_cr10',
  'tb_pm220_cr11',
  'tb_pm220_cr12',
  'tb_pm220_cr2',
  'tb_pm220_cr3',
  'tb_pm220_cr4',
  'tb_pm220_cr5',
  'tb_pm220_cr5_b',
  'tb_pm220_cr6',
  'tb_pm220_cr7',
  'tb_pm220_cr8',
  'tb_pm220_cr9',
  'tb_pm220_ct',
  'tb_pm220_hla',
  'tb_pm220_ra',
  'tb_pm220_ret',
];

function getLocalDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatDateLabel(dateString) {
  if (!dateString) return '-';

  return new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  }).format(new Date(`${dateString}T00:00:00`));
}

function formatDateTime(dateTime) {
  if (!dateTime) return '-';

  const normalized = String(dateTime).replace(' ', 'T');
  const date = new Date(normalized);

  if (Number.isNaN(date.getTime())) return String(dateTime);

  return new Intl.DateTimeFormat('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(date);
}

function parseDateTimeMs(dateTime) {
  if (!dateTime) return null;

  const normalized = String(dateTime).replace(' ', 'T');
  const date = new Date(normalized);

  return Number.isNaN(date.getTime()) ? null : date.getTime();
}

function formatValue(value) {
  const number = Number(value);

  if (!Number.isFinite(number)) return '-';

  return new Intl.NumberFormat('id-ID', {
    maximumFractionDigits: 2,
  }).format(number);
}

// Nama tabel diawali "tb_pm200_" atau "tb_pm220_" — ini dipakai untuk label singkat di matriks indikator.
function getShortLabel(tableName) {
  return String(tableName).replace(/^tb_pm(200|220)_/, '').toUpperCase();
}

// Sumber tunggal untuk menentukan status sebuah tabel, dipakai bersama oleh
// TableCard, ringkasan statistik header, dan matriks indikator OK/NG.
function getCardStatus(item, now, isLiveDay) {
  const rows = item.rows || [];
  const hasData = item.status === 'success' && rows.length > 0;
  const isError = item.status === 'error';
  const latestMs = hasData ? parseDateTimeMs(rows.at(-1)?.date_time) : null;
  const isStale = isLiveDay && hasData && latestMs != null && now - latestMs > STALE_TIMEOUT_MS;

  if (item.loading) return 'loading';
  if (isError) return 'error';
  if (isStale) return 'stale';
  if (hasData) return 'active';
  return 'empty';
}

function extractTables(payload) {
  const candidates = [
    payload,
    payload?.data,
    payload?.tables,
    payload?.data?.tables,
    payload?.result,
  ];

  for (const candidate of candidates) {
    if (!Array.isArray(candidate)) continue;

    const tables = candidate
      .map((item) => {
        if (typeof item === 'string') return item;
        return item?.table_name || item?.tableName || item?.name || item?.table;
      })
      .filter(Boolean);

    if (tables.length > 0) return tables;
  }

  return [];
}

function extractRows(payload) {
  const candidates = [
    payload,
    payload?.data,
    payload?.rows,
    payload?.data?.rows,
    payload?.result,
    payload?.data?.result,
  ];

  return candidates.find(Array.isArray) || [];
}

function downsampleRows(rows, maxPoints = MAX_POINTS_PER_CHART) {
  if (rows.length <= maxPoints) return rows;

  const step = (rows.length - 1) / (maxPoints - 1);
  const sampled = [];

  for (let index = 0; index < maxPoints; index += 1) {
    sampled.push(rows[Math.round(index * step)]);
  }

  return sampled;
}

function createChartPoints(rows, width = 280, height = 64, padding = 6) {
  const values = rows
    .map((row) => Number(row.value))
    .filter((value) => Number.isFinite(value));

  if (values.length === 0) return '';

  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const drawableWidth = width - padding * 2;
  const drawableHeight = height - padding * 2;

  return values
    .map((value, index) => {
      const x =
        values.length === 1
          ? width / 2
          : padding + (index / (values.length - 1)) * drawableWidth;
      const y = padding + ((max - value) / range) * drawableHeight;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(' ');
}

async function fetchJson(url, signal) {
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
    },
    signal,
  });

  if (!response.ok) {
    let message = `HTTP ${response.status}`;

    try {
      const payload = await response.json();
      message = payload?.message || payload?.error || message;
    } catch {
      // Respons bukan JSON.
    }

    throw new Error(message);
  }

  return response.json();
}

async function runWithConcurrency(items, limit, worker) {
  const results = new Array(items.length);
  let cursor = 0;

  async function runner() {
    while (cursor < items.length) {
      const currentIndex = cursor;
      cursor += 1;

      try {
        results[currentIndex] = await worker(items[currentIndex], currentIndex);
      } catch (error) {
        results[currentIndex] = {
          status: 'error',
          error: error instanceof Error ? error.message : 'Gagal memuat data',
        };
      }
    }
  }

  const runners = Array.from(
    { length: Math.min(limit, items.length) },
    () => runner(),
  );

  await Promise.all(runners);
  return results;
}

const STATUS_STYLES = {
  active: {
    accent: 'before:bg-teal-500',
    badge: 'bg-teal-50 text-teal-700 ring-1 ring-inset ring-teal-600/20',
    label: 'AKTIF',
    stroke: 'rgb(13 148 136)',
    fill: 'rgba(13, 148, 136, 0.1)',
    grid: 'rgba(15, 23, 42, 0.06)',
  },
  empty: {
    accent: 'before:bg-rose-400',
    badge: 'bg-rose-50 text-rose-700 ring-1 ring-inset ring-rose-600/20',
    label: 'KOSONG',
    stroke: 'rgb(225 29 72)',
    fill: 'rgba(225, 29, 72, 0.08)',
    grid: 'rgba(15, 23, 42, 0.06)',
  },
  stale: {
    accent: 'before:bg-red-600',
    badge: 'bg-red-50 text-red-700 ring-1 ring-inset ring-red-600/30',
    label: 'TIMEOUT',
    stroke: 'rgb(220 38 38)',
    fill: 'rgba(220, 38, 38, 0.1)',
    grid: 'rgba(15, 23, 42, 0.06)',
  },
  error: {
    accent: 'before:bg-amber-400',
    badge: 'bg-amber-50 text-amber-700 ring-1 ring-inset ring-amber-600/20',
    label: 'ERROR',
    stroke: 'rgb(217 119 6)',
    fill: 'rgba(217, 119, 6, 0.1)',
    grid: 'rgba(15, 23, 42, 0.06)',
  },
  loading: {
    accent: 'before:bg-slate-300',
    badge: 'bg-slate-100 text-slate-500 ring-1 ring-inset ring-slate-300/60',
    label: 'MEMUAT',
    stroke: 'rgb(148 163 184)',
    fill: 'rgba(148, 163, 184, 0.1)',
    grid: 'rgba(15, 23, 42, 0.06)',
  },
};

// Grid padat berisi satu kotak kecil per tabel, hanya hijau (OK) atau merah (NG).
// Ini rekap cepat sebelum melihat detail kartu di bawah.
function StatusMatrix({ items, now, isLiveDay }) {
  const ngCount = useMemo(
    () =>
      items.filter((item) => {
        const status = getCardStatus(item, now, isLiveDay);
        return status !== 'active' && status !== 'loading';
      }).length,
    [items, now, isLiveDay],
  );

  return (
    <div className="mt-3 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <p className="font-mono text-[11.5px] font-extrabold uppercase tracking-wider text-slate-700">
          Rekap Indikator Tabel
        </p>
        <div className="flex items-center gap-3 font-mono text-[10.5px] font-bold">
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-emerald-500" />
            <span className="font-extrabold text-slate-900">OK</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-red-600" />
            <span className="font-extrabold text-slate-900">NG</span>
            <span className="font-extrabold text-red-700">({ngCount})</span>
          </span>
        </div>
      </div>

      <div className="flex flex-wrap gap-1">
        {items.map((item) => {
          const status = getCardStatus(item, now, isLiveDay);
          const isLoading = status === 'loading';
          const isOk = status === 'active';
          const statusLabel = isLoading ? 'MEMUAT' : STATUS_STYLES[status]?.label || status;

          return (
            <div
              key={item.tableName}
              title={`${item.tableName} — ${statusLabel}`}
              className={`flex h-7 w-10 shrink-0 items-center justify-center rounded-sm font-mono text-[8.5px] font-extrabold leading-none tracking-tight transition-colors ${
                isLoading
                  ? 'bg-slate-200 text-slate-600'
                  : isOk
                    ? 'bg-emerald-600 text-white'
                    : 'bg-red-600 text-red-50'
              }`}
            >
              {getShortLabel(item.tableName).slice(0, 5)}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MiniChart({ rows, statusKey }) {
  const sampledRows = useMemo(() => downsampleRows(rows), [rows]);
  const points = useMemo(() => createChartPoints(sampledRows), [sampledRows]);
  const style = STATUS_STYLES[statusKey];

  return (
    <div className="relative h-16 overflow-hidden rounded-lg bg-slate-50">
      <svg viewBox="0 0 280 64" preserveAspectRatio="none" className="h-full w-full" role="img" aria-label="Grafik data">
        <line x1="0" y1="16" x2="280" y2="16" stroke={style.grid} strokeWidth="1" />
        <line x1="0" y1="32" x2="280" y2="32" stroke={style.grid} strokeWidth="1" />
        <line x1="0" y1="48" x2="280" y2="48" stroke={style.grid} strokeWidth="1" />

        {points ? (
          <>
            <polygon points={`6,58 ${points} 274,58`} fill={style.fill} />
            <polyline
              points={points}
              fill="none"
              stroke={style.stroke}
              strokeWidth="1.75"
              strokeLinecap="round"
              strokeLinejoin="round"
              vectorEffect="non-scaling-stroke"
            />
          </>
        ) : (
          <text x="140" y="36" textAnchor="middle" className="fill-slate-500" style={{ fontSize: '11px', fontFamily: 'ui-monospace, monospace', fontWeight: 800 }}>
            NO DATA
          </text>
        )}
      </svg>
    </div>
  );
}

function TableCard({ item, now, isLiveDay }) {
  const rows = item.rows || [];
  const numericValues = rows
    .map((row) => Number(row.value))
    .filter((value) => Number.isFinite(value));

  const latestRow = rows.at(-1);
  const minValue = numericValues.length ? Math.min(...numericValues) : null;
  const maxValue = numericValues.length ? Math.max(...numericValues) : null;
  const hasData = item.status === 'success' && rows.length > 0;
  const isError = item.status === 'error';

  const latestMs = hasData ? parseDateTimeMs(latestRow?.date_time) : null;
  const statusKey = getCardStatus(item, now, isLiveDay);
  const isStale = statusKey === 'stale';
  const style = STATUS_STYLES[statusKey];

  return (
    <article
      className={`group relative overflow-hidden rounded-lg border border-slate-200 bg-white p-3 shadow-sm transition-shadow before:absolute before:inset-y-0 before:left-0 before:w-[3px] hover:shadow-md ${style.accent}`}
    >
      <div className="mb-2 flex items-start justify-between gap-2 pl-1.5">
        <h2
          className="truncate font-mono text-[13px] font-extrabold tracking-tight text-slate-950"
          title={item.tableName}
        >
          {item.tableName}
        </h2>
        <span className={`shrink-0 rounded px-2 py-0.5 font-mono text-[10px] font-extrabold tracking-wider ${style.badge}`}>
          {style.label}
        </span>
      </div>

      {item.loading ? (
        <div className="h-16 animate-pulse rounded-lg bg-slate-100" />
      ) : isError ? (
        <div className="flex h-16 items-center justify-center rounded-lg bg-amber-50/60 px-2 text-center font-mono text-[11px] font-bold leading-tight text-amber-900">
          {item.error || 'Terjadi kesalahan'}
        </div>
      ) : (
        <MiniChart rows={rows} statusKey={statusKey} />
      )}

      <div className="mt-2 grid grid-cols-3 divide-x divide-slate-200 rounded-md bg-slate-50 py-1.5 pl-1.5">
        <div className="px-1.5 leading-tight">
          <p className="text-[9px] font-extrabold uppercase tracking-wider text-slate-600">Terakhir</p>
          <p className="truncate font-mono text-[12px] font-extrabold text-slate-950">
            {hasData ? formatValue(latestRow?.value) : '-'}
          </p>
        </div>
        <div className="px-1.5 leading-tight">
          <p className="text-[9px] font-extrabold uppercase tracking-wider text-slate-600">Min</p>
          <p className="truncate font-mono text-[12px] font-extrabold text-slate-900">
            {minValue === null ? '-' : formatValue(minValue)}
          </p>
        </div>
        <div className="px-1.5 leading-tight">
          <p className="text-[9px] font-extrabold uppercase tracking-wider text-slate-600">Max</p>
          <p className="truncate font-mono text-[12px] font-extrabold text-slate-900">
            {maxValue === null ? '-' : formatValue(maxValue)}
          </p>
        </div>
      </div>

      <div className="mt-1.5 flex items-center justify-between gap-2 pl-1.5 font-mono text-[10px] font-extrabold text-slate-900">
        <span className="truncate text-slate-700">{latestRow?.power_meter || '—'}</span>
        <span className={`shrink-0 ${isStale ? 'font-extrabold text-red-700' : 'font-bold text-slate-800'}`}>
          {hasData ? formatDateTime(latestRow?.date_time) : '--:--:--'}
          {isStale && latestMs != null ? ` · ${Math.floor((now - latestMs) / 60000)} mnt lalu` : ''}
        </span>
      </div>
    </article>
  );
}

export default function MonitoringDaily() {
  const today = useMemo(() => getLocalDateString(), []);
  const abortControllerRef = useRef(null);

  const [selectedDate, setSelectedDate] = useState(today);
  const [search, setSearch] = useState('');
  const [tables, setTables] = useState(FALLBACK_TABLES);
  const [items, setItems] = useState(() =>
    FALLBACK_TABLES.map((tableName) => ({
      tableName,
      rows: [],
      loading: true,
      status: 'loading',
      error: null,
    })),
  );
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [globalError, setGlobalError] = useState('');
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const intervalId = window.setInterval(() => setNow(Date.now()), STALE_CHECK_INTERVAL_MS);
    return () => window.clearInterval(intervalId);
  }, []);

  const loadTables = useCallback(async (signal) => {
    try {
      const payload = await fetchJson('/api/power-meters/tables', signal);
      const apiTables = extractTables(payload);

      if (apiTables.length > 0) {
        const uniqueTables = [...new Set(apiTables)].sort((a, b) => a.localeCompare(b));
        setTables(uniqueTables);
        return uniqueTables;
      }
    } catch (error) {
      if (error?.name === 'AbortError') throw error;
      console.warn('Daftar tabel dari API tidak tersedia. Memakai daftar lokal.', error);
    }

    return FALLBACK_TABLES;
  }, []);

  const loadDailyData = useCallback(
    async ({ forceReloadTables = false } = {}) => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      const controller = new AbortController();
      abortControllerRef.current = controller;
      setIsRefreshing(true);
      setGlobalError('');

      try {
        const activeTables =
          forceReloadTables || tables.length === 0
            ? await loadTables(controller.signal)
            : tables;

        setItems(
          activeTables.map((tableName) => ({
            tableName,
            rows: [],
            loading: true,
            status: 'loading',
            error: null,
          })),
        );

        const results = await runWithConcurrency(
          activeTables,
          REQUEST_CONCURRENCY,
          async (tableName) => {
            const query = new URLSearchParams({
              date: selectedDate,
              page: '1',
              limit: String(API_ROW_LIMIT),
              order: 'desc',
            });

            const payload = await fetchJson(
              `/api/power-meters/${encodeURIComponent(tableName)}/data?${query.toString()}`,
              controller.signal,
            );

            const rows = extractRows(payload)
              .filter((row) => row && row.date_time != null)
              .sort((a, b) => String(a.date_time).localeCompare(String(b.date_time)));

            return {
              tableName,
              rows,
              loading: false,
              status: 'success',
              error: null,
            };
          },
        );

        if (!controller.signal.aborted) {
          setItems(
            results.map((result, index) => ({
              tableName: activeTables[index],
              rows: result?.rows || [],
              loading: false,
              status: result?.status || 'error',
              error: result?.error || null,
            })),
          );
          setLastUpdated(new Date());
        }
      } catch (error) {
        if (error?.name !== 'AbortError') {
          setGlobalError(error instanceof Error ? error.message : 'Gagal memuat dashboard');
        }
      } finally {
        if (!controller.signal.aborted) {
          setIsRefreshing(false);
        }
      }
    },
    [loadTables, selectedDate, tables],
  );

  useEffect(() => {
    loadDailyData({ forceReloadTables: true });

    return () => {
      abortControllerRef.current?.abort();
    };
    // Pemanggilan awal hanya sekali. Perubahan tanggal ditangani efek di bawah.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!lastUpdated) return;
    loadDailyData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate]);

  useEffect(() => {
    if (selectedDate !== today) return undefined;

    const intervalId = window.setInterval(() => {
      loadDailyData();
    }, REFRESH_INTERVAL_MS);

    return () => window.clearInterval(intervalId);
  }, [loadDailyData, selectedDate, today]);

  const filteredItems = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    if (!keyword) return items;

    return items.filter((item) => item.tableName.toLowerCase().includes(keyword));
  }, [items, search]);

  const isLiveDay = selectedDate === today;

  const summary = useMemo(() => {
    return items.reduce(
      (result, item) => {
        const status = getCardStatus(item, now, isLiveDay);

        if (status === 'loading') result.loading += 1;
        else if (status === 'error') result.error += 1;
        else if (status === 'stale') result.stale += 1;
        else if (status === 'active') result.active += 1;
        else result.empty += 1;

        return result;
      },
      { active: 0, empty: 0, error: 0, loading: 0, stale: 0 },
    );
  }, [items, now, isLiveDay]);

  return (


    <Layout>
        <main className="min-h-screen bg-slate-100 text-slate-900 antialiased">
        <div className="mx-auto max-w-[2000px] px-3 py-4 sm:px-5 lg:px-6">
            {/* Header */}
            <header className="sticky top-0 z-10 rounded-xl border border-slate-200 bg-white/90 px-4 py-3 shadow-sm backdrop-blur-md">
            <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
                <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-teal-50 ring-1 ring-inset ring-teal-600/20">
                    <span className="h-2 w-2 rounded-full bg-teal-500" />
                </div>
                <div>
                    <p className="font-mono text-[11px] font-extrabold uppercase tracking-[0.2em] text-teal-800">
                    Power Meter Dashboard · EMS
                    </p>
                    <h1 className="text-xl font-extrabold tracking-tight text-slate-950 sm:text-2xl">
                    Monitoring
                    </h1>
                </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 xl:gap-3">
                {/* Compact stat pills */}
                <div className="flex items-center divide-x divide-slate-200 rounded-lg border border-slate-200 bg-slate-50 font-mono text-[11.5px] font-bold">
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-teal-500" />
                    <span className="font-extrabold text-teal-800">{summary.active}</span>
                    <span className="font-extrabold text-slate-900">aktif</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-rose-400" />
                    <span className="font-extrabold text-rose-700">{summary.empty}</span>
                    <span className="font-extrabold text-slate-900">kosong</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                    <span className="font-extrabold text-red-700">{summary.stale}</span>
                    <span className="font-extrabold text-slate-900">timeout</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
                    <span className="font-extrabold text-amber-700">{summary.error}</span>
                    <span className="font-extrabold text-slate-900">error</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1.5">
                    <span className="font-extrabold text-slate-900">{items.length}</span>
                    <span className="font-extrabold text-slate-900">total</span>
                    </div>
                </div>

                <input
                    type="date"
                    value={selectedDate}
                    max={today}
                    onChange={(event) => setSelectedDate(event.target.value)}
                    className="h-8 rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-[11.5px] font-bold text-slate-900 outline-none transition focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
                />

                <input
                    type="search"
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Cari tabel..."
                    className="h-8 w-36 rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-[11.5px] font-bold text-slate-900 outline-none transition placeholder:font-semibold placeholder:text-slate-500 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 sm:w-44"
                />

                <button
                    type="button"
                    onClick={() => loadDailyData({ forceReloadTables: true })}
                    disabled={isRefreshing}
                    className="flex h-8 items-center gap-1.5 rounded-lg bg-slate-900 px-3 font-mono text-[11.5px] font-extrabold tracking-wide text-white transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:bg-slate-300"
                >
                    <svg
                    className={isRefreshing ? 'h-3.5 w-3.5 animate-spin' : 'h-3.5 w-3.5'}
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    >
                    <path d="M21 12a9 9 0 1 1-2.64-6.36" strokeLinecap="round" />
                    <path d="M21 3v6h-6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    {isRefreshing ? 'MEMUAT' : 'REFRESH'}
                </button>
                </div>
            </div>

            <div className="mt-2 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 border-t border-slate-100 pt-2 font-mono text-[11px] font-semibold text-slate-700">
                <p>{formatDateLabel(selectedDate)}</p>
                <p>
                Auto-refresh 10 menit (hari ini) · Update terakhir:{' '}
                <span className="font-extrabold text-slate-900">
                    {lastUpdated
                    ? new Intl.DateTimeFormat('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        hour12: false,
                        }).format(lastUpdated)
                    : '-'}
                </span>
                </p>
            </div>
            </header>

            <StatusMatrix items={items} now={now} isLiveDay={isLiveDay} />

            {globalError && (
            <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 font-mono text-[11.5px] font-bold text-amber-900">
                {globalError}
            </div>
            )}

            {/* Dense grid: more columns, tighter gaps */}
            <section className="mt-3 grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 2xl:grid-cols-6">
            {filteredItems.map((item) => (
                <TableCard key={item.tableName} item={item} now={now} isLiveDay={isLiveDay} />
            ))}
            </section>

            {filteredItems.length === 0 && (
            <div className="mt-3 rounded-xl border border-slate-200 bg-white p-8 text-center font-mono text-[12px] font-bold text-slate-600">
                Tidak ada nama tabel yang sesuai dengan pencarian.
            </div>
            )}
        </div>
        </main>
    </Layout>    

  );
}