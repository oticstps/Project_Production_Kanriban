import React, { useMemo, useRef, useState } from "react";
import Layout from "../layout/Layout";
export default function ConvertToJson() {
  const API_URL = "http://172.27.6.191:4000/api/files/upload";

  const [selectedFile, setSelectedFile] = useState(null);
  const [jsonData, setJsonData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [copied, setCopied] = useState(false);

  const inputRef = useRef(null);

  const columns = useMemo(() => {
    if (!Array.isArray(jsonData) || jsonData.length === 0) return [];
    const keySet = new Set();
    jsonData.forEach((row) => {
      if (row && typeof row === "object") {
        Object.keys(row).forEach((key) => keySet.add(key));
      }
    });
    return Array.from(keySet);
  }, [jsonData]);

  const prettyJson = useMemo(() => {
    return JSON.stringify(jsonData, null, 2);
  }, [jsonData]);

  const handleFileChange = (file) => {
    setError("");
    setSuccess("");
    setCopied(false);

    if (!file) return;

    const allowedExtensions = [".xlsx", ".xls", ".csv"];
    const lowerName = file.name.toLowerCase();
    const isValid = allowedExtensions.some((ext) => lowerName.endsWith(ext));

    if (!isValid) {
      setSelectedFile(null);
      setJsonData([]);
      setError("Format file tidak didukung. Gunakan file .xlsx, .xls, atau .csv.");
      return;
    }

    setSelectedFile(file);
  };

  const handleInputChange = (event) => {
    const file = event.target.files?.[0];
    handleFileChange(file);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (event) => {
    event.preventDefault();
    setDragActive(false);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setDragActive(false);
    const file = event.dataTransfer.files?.[0];
    handleFileChange(file);
  };

  const handleUpload = async () => {
    setError("");
    setSuccess("");
    setCopied(false);

    if (!selectedFile) {
      setError("Silakan pilih file terlebih dahulu.");
      return;
    }

    try {
      setLoading(true);

      const formData = new FormData();
      formData.append("file", selectedFile);

      const response = await fetch(API_URL, {
        method: "POST",
        body: formData,
      });

      const contentType = response.headers.get("content-type") || "";
      const responseData = contentType.includes("application/json")
        ? await response.json()
        : await response.text();

      if (!response.ok) {
        const message =
          typeof responseData === "object" && responseData !== null
            ? responseData.message || "Gagal mengonversi file."
            : "Gagal mengonversi file.";
        throw new Error(message);
      }

      if (!Array.isArray(responseData)) {
        throw new Error("Respons server bukan array JSON yang valid.");
      }

      setJsonData(responseData);
      setSuccess(`Berhasil mengonversi file. Total ${responseData.length} baris data.`);
    } catch (err) {
      setJsonData([]);
      setError(err.message || "Terjadi kesalahan saat upload file.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setJsonData([]);
    setError("");
    setSuccess("");
    setCopied(false);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  const handleCopyJson = async () => {
    try {
      await navigator.clipboard.writeText(prettyJson);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError("Gagal menyalin JSON ke clipboard.");
    }
  };

  const handleDownloadJson = () => {
    try {
      const blob = new Blob([prettyJson], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");

      const baseName = selectedFile?.name
        ? selectedFile.name.replace(/\.[^/.]+$/, "")
        : "converted-data";

      a.href = url;
      a.download = `${baseName}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      setError("Gagal mengunduh file JSON.");
    }
  };

  return (



    <>
    <Layout>
    <div className="min-h-screen bg-slate-100 py-10 px-4">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-slate-800">Excel atau CSV ke JSON Converter</h1>
          <p className="mt-2 text-sm text-slate-600">
            Upload file Excel atau CSV, lalu sistem akan mengubahnya menjadi JSON.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="rounded-2xl bg-white p-6 shadow-lg">
            <h2 className="text-xl font-semibold text-slate-800">Upload File</h2>
            <p className="mt-1 text-sm text-slate-500">
              Format yang didukung: .xlsx, .xls, .csv
            </p>

            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`mt-5 rounded-2xl border-2 border-dashed p-8 text-center transition ${
                dragActive
                  ? "border-blue-500 bg-blue-50"
                  : "border-slate-300 bg-slate-50"
              }`}
            >
              <div className="flex flex-col items-center justify-center gap-3">
                <div className="rounded-full bg-slate-200 px-4 py-2 text-sm font-medium text-slate-700">
                  Drag and drop file di sini
                </div>
                <p className="text-sm text-slate-500">atau</p>
                <button
                  type="button"
                  onClick={() => inputRef.current?.click()}
                  className="rounded-xl bg-blue-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-blue-700"
                >
                  Pilih File
                </button>
                <input
                  ref={inputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={handleInputChange}
                  className="hidden"
                />
              </div>
            </div>

            <div className="mt-5 rounded-xl bg-slate-50 p-4">
              <p className="text-sm text-slate-600">
                <span className="font-semibold">File terpilih:</span>{" "}
                {selectedFile ? selectedFile.name : "Belum ada file"}
              </p>
              {selectedFile && (
                <p className="mt-1 text-xs text-slate-500">
                  Ukuran: {(selectedFile.size / 1024).toFixed(2)} KB
                </p>
              )}
            </div>

            {error && (
              <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            )}

            {success && (
              <div className="mt-4 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
                {success}
              </div>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleUpload}
                disabled={loading}
                className="rounded-xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? "Memproses..." : "Upload dan Konversi"}
              </button>

              <button
                type="button"
                onClick={handleReset}
                className="rounded-xl bg-slate-700 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800"
              >
                Reset
              </button>
            </div>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-semibold text-slate-800">Hasil JSON</h2>
                <p className="mt-1 text-sm text-slate-500">
                  Data JSON siap disalin atau diunduh.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={handleCopyJson}
                  disabled={jsonData.length === 0}
                  className="rounded-xl bg-amber-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-amber-600 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {copied ? "Tersalin" : "Copy JSON"}
                </button>

                <button
                  type="button"
                  onClick={handleDownloadJson}
                  disabled={jsonData.length === 0}
                  className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Download JSON
                </button>
              </div>
            </div>

            <div className="mt-5 max-h-[500px] overflow-auto rounded-2xl bg-slate-900 p-4">
              <pre className="whitespace-pre-wrap break-words text-sm text-green-300">
                {jsonData.length > 0
                  ? prettyJson
                  : 'Belum ada data. Upload file lalu klik "Upload dan Konversi".'}
              </pre>
            </div>
          </div>
        </div>

        {jsonData.length > 0 && (
          <div className="mt-6 rounded-2xl bg-white p-6 shadow-lg">
            <div className="mb-4">
              <h2 className="text-xl font-semibold text-slate-800">Preview Tabel</h2>
              <p className="mt-1 text-sm text-slate-500">
                Menampilkan {jsonData.length} baris data hasil konversi.
              </p>
            </div>

            <div className="overflow-auto rounded-2xl border border-slate-200">
              <table className="min-w-full text-sm">
                <thead className="bg-slate-100">
                  <tr>
                    {columns.map((column) => (
                      <th
                        key={column}
                        className="whitespace-nowrap border-b border-slate-200 px-4 py-3 text-left font-semibold text-slate-700"
                      >
                        {column}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {jsonData.map((row, rowIndex) => (
                    <tr key={rowIndex} className="hover:bg-slate-50">
                      {columns.map((column) => (
                        <td
                          key={`${rowIndex}-${column}`}
                          className="whitespace-nowrap border-b border-slate-100 px-4 py-3 text-slate-600"
                        >
                          {row?.[column] !== undefined && row?.[column] !== null
                            ? String(row[column])
                            : "-"}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
    </Layout>
    </>

  );
}