import { useState, useEffect } from "react";
import Layout from "../layout/Layout";

// ===== KONFIGURASI PANEL =====
const PANELS = [
  { label: "Kubikal 1 (Sumber)", value: "kubikal1", endpoint: "http://172.27.6.191:4000/api/kubikal1realtime" },
  { label: "Kubikal 2 Panel 63 (Pintu 8)", value: "kub63", endpoint: "http://172.27.6.191:4000/api/kubikal2panel63realtime" },
  { label: "Kubikal 2 Panel 64 (Pintu 8)", value: "kub64", endpoint: "http://172.27.6.191:4000/api/kubikal2panel64realtime" },
];

const REFRESH_INTERVAL = 5000;
const HISTORY_LENGTH = 10;

// ── Utility Functions ──────────────────────────────────────────────────────
const safeParse = (val) => {
  const num = parseFloat(val);
  return Number.isFinite(num) ? num : 0;
};

const formatDelta = (current, prev) => {
  if (!Number.isFinite(prev) || prev === 0) return null;
  const delta = current - prev;
  if (Math.abs(delta) < 0.001) return null;
  const sign = delta > 0 ? "▲" : "▼";
  const color = delta > 0 ? "text-red-600" : "text-green-600";
  return { sign, value: Math.abs(delta).toFixed(3), color };
};

// ── SVG Icons ─────────────────────────────────────────────────────────────
const Icon = {
  bolt: (props) => (
    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
    </svg>
  ),
  voltage: (props) => (
    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <circle cx="12" cy="12" r="9" />
      <path strokeLinecap="round" d="M8 12h2l2-4 2 8 2-4h2" />
    </svg>
  ),
  current: (props) => (
    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 12h16M4 7l4 5-4 5M20 7l-4 5 4 5" />
    </svg>
  ),
  pf: (props) => (
    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1m0 16v1M4.22 4.22l.7.7m13.16 13.16.7.7M3 12h1m16 0h1M4.22 19.78l.7-.7M19.08 4.92l-.7.7" />
      <circle cx="12" cy="12" r="4" />
    </svg>
  ),
  chart: (props) => (
    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 3v18h18" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M7 16l4-6 4 4 4-8" />
    </svg>
  ),
  live: (props) => (
    <svg className="w-3 h-3" viewBox="0 0 10 10" fill="currentColor" {...props}>
      <circle cx="5" cy="5" r="5" />
    </svg>
  ),
  warn: (props) => (
    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
    </svg>
  ),
  refresh: (props) => (
    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
    </svg>
  ),
  pause: (props) => (
    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  play: (props) => (
    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
};

// ── Komponen UI (dengan penyesuaian responsif) ────────────────────────────

function Pill({ ok, warn, children }) {
  const base = "text-[11px] sm:text-xs font-mono font-black px-2 py-0.5 rounded border tracking-wider flex items-center gap-1";
  if (warn) return <span className={`${base} text-amber-900 bg-amber-100 border-amber-500`}>{children}</span>;
  if (ok)   return <span className={`${base} text-emerald-900 bg-emerald-100 border-emerald-500`}>{children}</span>;
  return      <span className={`${base} text-red-900 bg-red-100 border-red-500`}>{children}</span>;
}

function SectionHead({ icon, title, color = "blue" }) {
  const colors = {
    green:  "bg-emerald-700 border-emerald-600",
    blue:   "bg-blue-700 border-blue-600",
    indigo: "bg-indigo-700 border-indigo-600",
    violet: "bg-violet-700 border-violet-600",
    slate:  "bg-slate-700 border-slate-600",
  };
  return (
    <div className={`px-2 sm:px-3 py-2 border-b-2 flex items-center gap-2 ${colors[color] || colors.slate}`}>
      <span className="text-white opacity-90">{icon}</span>
      <span className="text-[11px] sm:text-xs font-black text-white uppercase tracking-[0.18em]">{title}</span>
    </div>
  );
}

function KPI({ label, value, unit, sub, color = "blue", warn = false, delta = null }) {
  const borders = {
    blue:   "border-blue-500",
    green:  "border-emerald-500",
    orange: "border-orange-500",
  };
  const border = warn ? "border-amber-500" : (borders[color] || "border-blue-500");
  const bg     = warn ? "bg-amber-50" : "bg-slate-50";
  return (
    <div className={`border-2 rounded border-l-4 p-1.5 sm:p-2.5 ${border} ${bg} relative`}>
      <div className="text-[10px] sm:text-[11px] font-black text-slate-600 uppercase tracking-wider flex items-center gap-1">
        {label}
        {delta && (
          <span className={`text-[9px] sm:text-[10px] font-black ${delta.color} ml-1`} title={`Perubahan dari sebelumnya`}>
            {delta.sign} {delta.value}
          </span>
        )}
      </div>
      <div className="flex items-baseline gap-1 mt-0.5">
        <span className="text-lg sm:text-xl md:text-2xl font-black text-slate-950 tabular-nums leading-none">{value}</span>
        <span className="text-[10px] sm:text-xs font-black text-slate-500">{unit}</span>
      </div>
      {sub && <div className="text-[9px] sm:text-[11px] font-bold text-slate-500 mt-1 leading-tight font-mono">{sub}</div>}
    </div>
  );
}

function HBar({ label, value, max, color, unit = "A", labelColor, delta = null }) {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <div className="flex items-center gap-2 mb-1.5">
      <span className="text-xs sm:text-sm font-black w-5 text-center flex items-center" style={{ color: labelColor || color }}>
        {label}
        {delta && <span className={`text-[8px] sm:text-[9px] ml-1 ${delta.color}`} title={`Perubahan: ${delta.sign} ${delta.value}`}>{delta.sign}</span>}
      </span>
      <div className="flex-1 h-2 sm:h-3 bg-slate-200 rounded-sm border border-slate-300 overflow-hidden">
        <div className="h-full transition-all duration-700" style={{ width: `${pct}%`, backgroundColor: color }} />
      </div>
      <span className="text-[11px] sm:text-xs font-black text-slate-900 w-14 sm:w-16 text-right tabular-nums font-mono">{value.toFixed(3)}</span>
      <span className="text-[9px] sm:text-[11px] font-bold text-slate-500 w-7 sm:w-9">{unit}</span>
    </div>
  );
}

function PFBar({ label, value, delta = null }) {
  const color = value >= 0.95 ? "#166534" : value >= 0.85 ? "#92400e" : "#991b1b";
  const bg    = value >= 0.95 ? "#dcfce7" : value >= 0.85 ? "#fef3c7" : "#fee2e2";
  const text  = value >= 0.95 ? "GOOD" : value >= 0.85 ? "FAIR" : "LOW";
  return (
    <div className="flex items-center gap-2 mb-2">
      <span className="text-xs sm:text-sm font-black text-slate-800 w-5 text-center flex items-center">
        {label}
        {delta && <span className={`text-[8px] sm:text-[9px] ml-1 ${delta.color}`} title={`Perubahan: ${delta.sign} ${delta.value}`}>{delta.sign}</span>}
      </span>
      <div className="flex-1 h-2 sm:h-3 bg-slate-200 rounded-sm border border-slate-300 overflow-hidden">
        <div className="h-full transition-all duration-700" style={{ width: `${value * 100}%`, backgroundColor: color }} />
      </div>
      <span className="text-[11px] sm:text-xs font-black text-slate-900 w-12 text-right tabular-nums font-mono">{value.toFixed(3)}</span>
      <span className="text-[8px] sm:text-[10px] font-black rounded px-1 py-0.5 w-10 sm:w-11 text-center" style={{ backgroundColor: bg, color }}>{text}</span>
    </div>
  );
}

function PFGauge({ value }) {
  const r = 36, cx = 52, cy = 48;
  const circ = Math.PI * r;
  const offset = circ * (1 - Math.min(value, 1));
  const color = value >= 0.95 ? "#166534" : value >= 0.85 ? "#92400e" : "#991b1b";
  const label = value >= 0.95 ? "BAIK" : value >= 0.85 ? "CUKUP" : "RENDAH";
  return (
    <svg viewBox="0 0 104 60" className="w-full max-w-[170px] mx-auto">
      <path d={`M ${cx-r} ${cy} A ${r} ${r} 0 0 1 ${cx+r} ${cy}`} fill="none" stroke="#e2e8f0" strokeWidth="10" strokeLinecap="round" />
      <path d={`M ${cx-r} ${cy} A ${r} ${r} 0 0 1 ${cx+r} ${cy}`} fill="none" stroke={color} strokeWidth="10" strokeLinecap="round"
        strokeDasharray={circ} strokeDashoffset={offset} style={{ transition: "all 0.7s ease" }} />
      <text x={cx} y={cy-8} textAnchor="middle" fontSize="14" fill="#0f172a" fontFamily="monospace" fontWeight="900">{value.toFixed(3)}</text>
      <text x={cx} y={cy+6} textAnchor="middle" fontSize="8.5" fill={color} fontFamily="monospace" fontWeight="900">{label}</text>
    </svg>
  );
}

function PowerTriangle({ P, Q, S }) {
  const max = Math.max(P, Q, S, 1);
  const sc = 90 / max;
  const pw = P * sc, qh = Q * sc;
  const ox = 12, oy = 96;
  return (
    <svg viewBox="0 0 160 118" className="w-full">
      <line x1={ox} y1={oy} x2={ox+pw} y2={oy} stroke="#166534" strokeWidth="3.5" strokeLinecap="round" />
      <line x1={ox+pw} y1={oy} x2={ox+pw} y2={oy-qh} stroke="#92400e" strokeWidth="3.5" strokeLinecap="round" />
      <line x1={ox} y1={oy} x2={ox+pw} y2={oy-qh} stroke="#1d4ed8" strokeWidth="2" strokeLinecap="round" strokeDasharray="5 3" />
      <text x={ox+pw/2} y={oy+11} textAnchor="middle" fontSize="8" fill="#166534" fontFamily="monospace" fontWeight="bold">P {P.toFixed(2)} kW</text>
      <text x={ox+pw+4} y={oy-qh/2+3} fontSize="7.5" fill="#92400e" fontFamily="monospace" fontWeight="bold">Q {Q.toFixed(2)}</text>
      <text x={Math.max(ox+4, ox+pw/2-24)} y={Math.max(10, oy-qh/2-6)} fontSize="7.5" fill="#1d4ed8" fontFamily="monospace" fontWeight="bold">S {S.toFixed(2)}</text>
    </svg>
  );
}

function TRow({ label, value, unit = "", highlight = false, warn = false, delta = null }) {
  return (
    <tr className="border-t border-slate-200">
      <td className="py-1 text-[10px] sm:text-[11px] font-black text-slate-600 pr-2 leading-tight flex items-center gap-1">
        {label}
        {delta && <span className={`text-[8px] sm:text-[9px] ${delta.color}`} title={`Perubahan: ${delta.sign} ${delta.value}`}>{delta.sign}</span>}
      </td>
      <td className={`py-1 text-xs sm:text-sm font-black tabular-nums text-right font-mono leading-tight ${warn ? "text-red-800" : highlight ? "text-blue-900" : "text-slate-950"}`}>
        {value}<span className="text-[8px] sm:text-[10px] font-bold text-slate-500 ml-0.5">{unit}</span>
      </td>
    </tr>
  );
}

function Divider({ title }) {
  return (
    <div className="flex items-center gap-1.5 my-2">
      <span className="text-[9px] sm:text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">{title}</span>
      <div className="flex-1 h-px bg-slate-300" />
    </div>
  );
}

function StatusDot({ ok }) {
  return <div className={`w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full border-2 ${ok ? "bg-emerald-400 border-emerald-600" : "bg-red-400 border-red-600"}`} />;
}

function Sparkline({ data, color = "#3b82f6", height = 20 }) {
  if (!data || data.length < 2) return null;
  const max = Math.max(...data, 0.001);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const points = data.map((val, i) => `${i * (100 / (data.length - 1))},${height - ((val - min) / range) * height}`).join(" ");
  return (
    <svg viewBox={`0 0 100 ${height}`} className="w-full h-4 sm:h-5 overflow-visible">
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────
export default function Kub() {
  const [currentPanel, setCurrentPanel] = useState("kubikal1");
  const [dataCache, setDataCache] = useState({});
  const [prevDataCache, setPrevDataCache] = useState({});
  const [currentData, setCurrentData] = useState(null);
  const [currentPrevData, setCurrentPrevData] = useState(null);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [isPaused, setIsPaused] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [history, setHistory] = useState([]);

  const getEndpoint = (panel) => PANELS.find(p => p.value === panel)?.endpoint || PANELS[0].endpoint;

  const fetchDataForPanel = async (panel) => {
    if (isPaused) return;
    setIsFetching(true);
    try {
      const url = getEndpoint(panel);
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();

      setDataCache(prev => ({ ...prev, [panel]: json }));
      setPrevDataCache(prev => ({ ...prev, [panel]: dataCache[panel] }));

      if (panel === currentPanel) {
        setCurrentData(json);
        setCurrentPrevData(dataCache[panel] || null);
        const newP = safeParse(json.active_power_total);
        setHistory(prev => {
          const newHistory = [...prev, newP];
          if (newHistory.length > HISTORY_LENGTH) newHistory.shift();
          return newHistory;
        });
      }

      setLastUpdated(new Date());
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setIsFetching(false);
    }
  };

  // Fetch data untuk panel default saat pertama kali
  useEffect(() => {
    fetchDataForPanel(currentPanel);
  }, []);

  // Interval refresh
  useEffect(() => {
    const t = setInterval(() => {
      fetchDataForPanel(currentPanel);
    }, REFRESH_INTERVAL);
    return () => clearInterval(t);
  }, [currentPanel, isPaused]);

  // Ganti panel
  const handlePanelChange = (e) => {
    const newPanel = e.target.value;
    setCurrentPanel(newPanel);
    setHistory([]);
    if (dataCache[newPanel]) {
      setCurrentData(dataCache[newPanel]);
      setCurrentPrevData(prevDataCache[newPanel] || null);
    } else {
      setCurrentData(null);
      setCurrentPrevData(null);
    }
    fetchDataForPanel(newPanel);
  };

  const getDelta = (currentVal, prevVal) => {
    if (!currentPrevData || !Number.isFinite(prevVal) || !Number.isFinite(currentVal)) return null;
    return formatDelta(currentVal, prevVal);
  };

  // Jika error dan belum ada data sama sekali, tampilkan halaman error
  if (error && !currentData) {
    return (
      <Layout>
        <div className="min-h-screen bg-slate-200 flex items-center justify-center p-4">
          <div className="border-2 border-red-500 bg-white rounded p-6 text-center shadow max-w-md">
            <div className="text-red-800 font-black text-sm mb-2">Koneksi Gagal</div>
            <div className="text-slate-600 font-mono font-bold text-xs break-all">{error}</div>
            <button
              onClick={() => fetchDataForPanel(currentPanel)}
              className="mt-4 px-4 py-2 bg-slate-800 text-white text-xs font-black rounded hover:bg-slate-700"
            >
              Coba Lagi
            </button>
          </div>
        </div>
      </Layout>
    );
  }

  // Data sudah ada atau sedang loading pertama kali? Kita akan render layout, dan di dalamnya tampilkan spinner jika currentData null
  const d = currentData || {}; // untuk header, kita tetap pakai objek kosong agar header tidak error (nilai 0)

  // Parsing data (akan menghasilkan 0 jika properti undefined)
  const P  = safeParse(d.active_power_total);
  const Pa = safeParse(d.active_power_a);
  const Pb = safeParse(d.active_power_b);
  const Pc = safeParse(d.active_power_c);
  const Q  = safeParse(d.reactive_power_total);
  const Qa = safeParse(d.reactive_power_a);
  const Qb = safeParse(d.reactive_power_b);
  const Qc = safeParse(d.reactive_power_c);
  const S  = safeParse(d.apparent_power_total);
  const Sa = safeParse(d.apparent_power_a);
  const Sb = safeParse(d.apparent_power_b);
  const Sc = safeParse(d.apparent_power_c);

  const pfT   = safeParse(d.power_factor_total);
  const pfA   = safeParse(d.power_factor_a);
  const pfB   = safeParse(d.power_factor_b);
  const pfC   = safeParse(d.power_factor_c);
  const pfAvg = (pfA + pfB + pfC) / 3;

  const freq  = safeParse(d.data_freq);
  const iAvg  = safeParse(d.current_avg);
  const iA    = safeParse(d.current_a);
  const iB    = safeParse(d.current_b);
  const iC    = safeParse(d.current_c);
  const iN    = safeParse(d.current_n);
  const iMax  = Math.max(iA, iB, iC, 0.001) * 1.15;

  const vLL    = safeParse(d.voltage_ll_avg);
  const vLN    = safeParse(d.voltage_ln_avg);
  const vAB    = safeParse(d.voltage_ab);
  const vBC    = safeParse(d.voltage_bc);
  const vCA    = safeParse(d.voltage_ca);
  const vAN    = safeParse(d.voltage_an);
  const vBN    = safeParse(d.voltage_bn);
  const vCN    = safeParse(d.voltage_cn);
  const vLLmax = Math.max(vAB, vBC, vCA, 0.001);
  const vLLmin = Math.min(vAB, vBC, vCA, 0.001);
  const vLNmax = Math.max(vAN, vBN, vCN, 0.001);

  const imbalI   = iAvg > 0 ? (Math.max(Math.abs(iA-iAvg), Math.abs(iB-iAvg), Math.abs(iC-iAvg)) / iAvg) * 100 : 0;
  const imbalV   = vLL > 0 ? (vLLmax - vLLmin) / vLL * 100 : 0;
  const freqOk   = freq >= 49.5 && freq <= 50.5;
  const pfOk     = pfT >= 0.9;
  const imbalIOk = imbalI <= 5;
  const imbalVOk = imbalV <= 1;
  const iNOk     = iN < 1;

  const phi      = Math.acos(Math.min(pfT, 1));
  const Qtgt95   = P * Math.tan(Math.acos(0.95));
  const Qtgt90   = P * Math.tan(Math.acos(0.90));
  const QcNeeded = Q - Qtgt95;
  const efficiency = S > 0 ? (P / S * 100) : 0;
  const pMax     = Math.max(Pa, Pb, Pc, 0.001) * 1.1;
  const qMax     = Math.max(Qa, Qb, Qc, 0.001) * 1.1;

  const alertCount = (!freqOk?1:0) + (!pfOk?1:0) + (!imbalIOk?1:0) + (!imbalVOk?1:0) + (!iNOk?1:0);

  const prev = currentPrevData ? {
    P: safeParse(currentPrevData.active_power_total),
    Q: safeParse(currentPrevData.reactive_power_total),
    S: safeParse(currentPrevData.apparent_power_total),
    pfT: safeParse(currentPrevData.power_factor_total),
    iAvg: safeParse(currentPrevData.current_avg),
    iA: safeParse(currentPrevData.current_a),
    iB: safeParse(currentPrevData.current_b),
    iC: safeParse(currentPrevData.current_c),
    vLL: safeParse(currentPrevData.voltage_ll_avg),
    freq: safeParse(currentPrevData.data_freq),
    Pa: safeParse(currentPrevData.active_power_a),
    Pb: safeParse(currentPrevData.active_power_b),
    Pc: safeParse(currentPrevData.active_power_c),
    Qa: safeParse(currentPrevData.reactive_power_a),
    Qb: safeParse(currentPrevData.reactive_power_b),
    Qc: safeParse(currentPrevData.reactive_power_c),
    pfA: safeParse(currentPrevData.power_factor_a),
    pfB: safeParse(currentPrevData.power_factor_b),
    pfC: safeParse(currentPrevData.power_factor_c),
  } : null;

  const deltaP = getDelta(P, prev?.P);
  const deltaQ = getDelta(Q, prev?.Q);
  const deltaS = getDelta(S, prev?.S);
  const deltaPf = getDelta(pfT, prev?.pfT);
  const deltaIAvg = getDelta(iAvg, prev?.iAvg);
  const deltaIA = getDelta(iA, prev?.iA);
  const deltaIB = getDelta(iB, prev?.iB);
  const deltaIC = getDelta(iC, prev?.iC);
  const deltaVLL = getDelta(vLL, prev?.vLL);
  const deltaFreq = getDelta(freq, prev?.freq);

  return (
    <Layout>
      <div className="min-h-screen bg-blue-50 p-1 sm:p-2 font-mono">
        <div className="border-2 border-slate-600 rounded-sm bg-white shadow-xl overflow-hidden" style={{ maxWidth: 1440, margin: "0 auto" }}>

          {/* ══ HEADER ══ */}
          <div className="bg-white border-b-2 border-slate-300 px-2 sm:px-4 py-2 flex flex-wrap items-center justify-between gap-2 shadow-sm">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="flex gap-0.5 items-end h-4 sm:h-5">
                <div className="w-1 bg-blue-400 rounded-t" style={{ height: `${(iA / iMax) * 60}%` }} />
                <div className="w-1 bg-emerald-400 rounded-t" style={{ height: `${(iB / iMax) * 85}%` }} />
                <div className="w-1 bg-orange-400 rounded-t" style={{ height: `${(iC / iMax) * 70}%` }} />
              </div>
              <div className="w-px h-5 sm:h-7 bg-slate-300" />
              <div>
                <div className="text-xs sm:text-sm font-black text-slate-800 tracking-widest uppercase">
                  {d.panel?.toUpperCase() || 'PANEL'} · Monitor
                </div>
                <div className="text-[10px] sm:text-[11px] text-slate-500 tracking-wider font-bold mt-0.5">
                  ID #{d.id || '-'} · {d.date_time || '-'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1 sm:gap-2 flex-wrap justify-end">
              <select
                value={currentPanel}
                onChange={handlePanelChange}
                className="text-[11px] sm:text-xs font-bold bg-white border border-slate-300 rounded px-1 sm:px-2 py-1 pr-4 sm:pr-6 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                {PANELS.map(p => (
                  <option key={p.value} value={p.value}>{p.label}</option>
                ))}
              </select>

              {isFetching && (
                <div className="animate-spin h-3 w-3 sm:h-4 sm:w-4 border-2 border-blue-500 border-t-transparent rounded-full" />
              )}

              <Pill ok={!error}>
                <span className={`animate-pulse ${error ? "text-red-500" : "text-emerald-500"}`}>{Icon.live({})}</span>
                {error ? "OFFLINE" : "LIVE"}
              </Pill>
              <Pill ok={freqOk}>
                {freq.toFixed(2)} Hz
                {deltaFreq && <span className={`text-[8px] sm:text-[9px] ${deltaFreq.color}`}>({deltaFreq.sign}{deltaFreq.value})</span>}
              </Pill>
              <Pill ok={pfOk}>
                PF {pfT.toFixed(2)}
                {deltaPf && <span className={`text-[8px] sm:text-[9px] ${deltaPf.color}`}>({deltaPf.sign}{deltaPf.value})</span>}
              </Pill>
              <Pill ok={imbalIOk}>I-IMB {imbalI.toFixed(1)}%</Pill>
              <Pill ok={imbalVOk}>V-IMB {imbalV.toFixed(2)}%</Pill>
              {alertCount > 0 && (
                <Pill warn>
                  <span className="text-amber-600">{Icon.warn({})}</span>
                  {alertCount}
                </Pill>
              )}
              {lastUpdated && (
                <span className="text-[10px] sm:text-[11px] text-slate-500 font-bold ml-1">
                  {lastUpdated.toLocaleTimeString("id-ID")}
                </span>
              )}
              <button
                onClick={() => setIsPaused(!isPaused)}
                className="px-2 sm:px-3 py-1 bg-slate-200 border border-slate-400 text-slate-800 rounded hover:bg-slate-300 transition-colors text-[10px] sm:text-[11px] font-black tracking-wider flex items-center gap-1"
                title={isPaused ? "Lanjutkan" : "Jeda"}
              >
                {isPaused ? Icon.play({}) : Icon.pause({})} {isPaused ? "PLAY" : "PAUSE"}
              </button>
              <button
                onClick={() => fetchDataForPanel(currentPanel)}
                className="px-2 sm:px-3 py-1 bg-blue-500 border border-blue-400 text-white rounded hover:bg-blue-600 transition-colors text-[10px] sm:text-[11px] font-black tracking-wider flex items-center gap-1"
              >
                {Icon.refresh({})} REFRESH
              </button>
            </div>
          </div>

          {/* ══ ALERT BAR ══ */}
          {alertCount > 0 && (
            <div className="bg-red-50 border-b-2 border-red-400 px-2 sm:px-4 py-1 flex flex-wrap gap-2 sm:gap-4 text-[10px] sm:text-xs font-black items-center">
              <span className="text-red-500 flex-shrink-0">{Icon.warn({})}</span>
              {!freqOk   && <span className="text-red-900">FREK {freq.toFixed(3)} Hz</span>}
              {!pfOk     && <span className="text-red-900">PF {pfT.toFixed(3)}</span>}
              {!imbalIOk && <span className="text-amber-900">I-IMB {imbalI.toFixed(2)}%</span>}
              {!imbalVOk && <span className="text-amber-900">V-IMB {imbalV.toFixed(3)}%</span>}
              {!iNOk     && <span className="text-orange-900">I-N {iN.toFixed(3)} A</span>}
            </div>
          )}

          {/* ══ KONTEN UTAMA ══ */}
          {currentData === null ? (
            // Tampilkan loading saat pertama kali panel dipilih dan data belum ada
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin h-8 w-8 sm:h-10 sm:w-10 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                <div className="text-slate-600 font-mono font-bold text-sm sm:text-base">Memuat data panel...</div>
              </div>
            </div>
          ) : (
            // Grid 5 kolom (konten lengkap)
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 divide-x-0 md:divide-x-2 divide-slate-300">
              
              
              
              {/* Kolom 1: DAYA */}
              <div className="flex flex-col divide-y divide-slate-200">
                <SectionHead icon={Icon.bolt({})} title="DAYA" color="green" />
                <div className="p-1.5 sm:p-2.5 space-y-2">
                  <KPI label="Active P" value={P.toFixed(3)} unit="kW" color="green" delta={deltaP}
                    sub={`A:${Pa.toFixed(2)} B:${Pb.toFixed(2)} C:${Pc.toFixed(2)}`}
                  />
                  <KPI label="Reactive Q" value={Q.toFixed(3)} unit="kVAR" delta={deltaQ}
                    sub={`A:${Qa.toFixed(2)} B:${Qb.toFixed(2)} C:${Qc.toFixed(2)}`}
                  />
                  <KPI label="Apparent S" value={S.toFixed(3)} unit="kVA" delta={deltaS}
                    sub={`A:${Sa.toFixed(2)} B:${Sb.toFixed(2)} C:${Sc.toFixed(2)}`}
                  />
                </div>
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Beban Aktif (kW)" />
                  <HBar label="A" value={Pa} max={pMax} color="#166534" unit="kW" labelColor="#166534" delta={getDelta(Pa, prev?.Pa)} />
                  <HBar label="B" value={Pb} max={pMax} color="#166534" unit="kW" labelColor="#166534" delta={getDelta(Pb, prev?.Pb)} />
                  <HBar label="C" value={Pc} max={pMax} color="#166534" unit="kW" labelColor="#166534" delta={getDelta(Pc, prev?.Pc)} />
                  <Divider title="Beban Reaktif (kVAR)" />
                  <HBar label="A" value={Qa} max={qMax} color="#92400e" unit="kVAR" labelColor="#92400e" delta={getDelta(Qa, prev?.Qa)} />
                  <HBar label="B" value={Qb} max={qMax} color="#92400e" unit="kVAR" labelColor="#92400e" delta={getDelta(Qb, prev?.Qb)} />
                  <HBar label="C" value={Qc} max={qMax} color="#92400e" unit="kVAR" labelColor="#92400e" delta={getDelta(Qc, prev?.Qc)} />
                </div>
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Segitiga Daya" />
                  <PowerTriangle P={P} Q={Q} S={S} />
                </div>
                <div className="p-1.5 sm:p-2.5 flex-1">
                  <Divider title="Efisiensi" />
                  <table className="w-full">
                    <tbody>
                      <TRow label="P/S" value={efficiency.toFixed(2)} unit="%" highlight />
                      <TRow label="Q/S" value={(Q/S*100).toFixed(2)} unit="%" warn={Q/S > 0.30} />
                      <TRow label="S–P" value={(S-P).toFixed(3)} unit="kVA" />
                    </tbody>
                  </table>
                </div>
              </div>





              {/* Kolom 2: TEGANGAN */}
              <div className="flex flex-col divide-y divide-slate-200">
                <SectionHead icon={Icon.voltage({})} title="TEGANGAN" color="blue" />

                {/* KPI (SEKARANG 1 KOLOM) */}
                <div className="p-1.5 sm:p-2.5 flex flex-col gap-2">
                  <KPI label="V L-L Avg" value={vLL.toFixed(1)} unit="V" color="blue" delta={deltaVLL} />
                  <KPI label="V L-N Avg" value={vLN.toFixed(1)} unit="V" color="blue" />
                  <KPI label="Imb V" value={imbalV.toFixed(3)} unit="%" warn={!imbalVOk} />
                  <KPI label="Δ V L-L" value={(vLLmax - vLLmin).toFixed(1)} unit="V" warn={!imbalVOk} />
                </div>

                {/* LINE TO LINE */}
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Line-to-Line" />
                  {[["V AB", vAB], ["V BC", vBC], ["V CA", vCA]].map(([l, v]) => (
                    <div key={l} className="flex items-center gap-2 mb-2">
                      <span className="text-xs sm:text-sm font-black text-slate-700 w-10 shrink-0">
                        {l}
                      </span>
                      <div className="flex-1 h-2 sm:h-3 bg-slate-200 border border-slate-300 rounded-sm overflow-hidden">
                        <div
                          className="h-full bg-blue-600 transition-all duration-700"
                          style={{ width: `${vLLmax ? (v / vLLmax) * 100 : 0}%` }}
                        />
                      </div>
                      <span className="text-[11px] sm:text-xs font-black text-slate-950 tabular-nums w-20 sm:w-24 text-right">
                        {v.toFixed(1)} V
                      </span>
                    </div>
                  ))}

                  <table className="w-full mt-1">
                    <tbody>
                      <TRow label="V AB" value={vAB.toFixed(1)} unit="V" />
                      <TRow label="V BC" value={vBC.toFixed(1)} unit="V" />
                      <TRow label="V CA" value={vCA.toFixed(1)} unit="V" />
                      <TRow label="Rata L-L" value={vLL.toFixed(1)} unit="V" highlight />
                    </tbody>
                  </table>
                </div>

                {/* LINE TO NEUTRAL */}
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Line-to-Neutral" />
                  {[["V AN", vAN], ["V BN", vBN], ["V CN", vCN]].map(([l, v]) => (
                    <div key={l} className="flex items-center gap-2 mb-2">
                      <span className="text-xs sm:text-sm font-black text-slate-700 w-10 shrink-0">
                        {l}
                      </span>
                      <div className="flex-1 h-2 sm:h-3 bg-slate-200 border border-slate-300 rounded-sm overflow-hidden">
                        <div
                          className="h-full bg-indigo-500 transition-all duration-700"
                          style={{ width: `${vLNmax ? (v / vLNmax) * 100 : 0}%` }}
                        />
                      </div>
                      <span className="text-[11px] sm:text-xs font-black text-slate-950 tabular-nums w-20 sm:w-24 text-right">
                        {v.toFixed(1)} V
                      </span>
                    </div>
                  ))}

                  <table className="w-full mt-1">
                    <tbody>
                      <TRow label="V AN" value={vAN.toFixed(1)} unit="V" />
                      <TRow label="V BN" value={vBN.toFixed(1)} unit="V" />
                      <TRow label="V CN" value={vCN.toFixed(1)} unit="V" />
                      <TRow label="Rata L-N" value={vLN.toFixed(1)} unit="V" highlight />
                    </tbody>
                  </table>
                </div>

                {/* DEVIASI */}
                <div className="p-1.5 sm:p-2.5 flex-1">
                  <Divider title="Deviasi 20 kV" />
                  {[["V AB", vAB], ["V BC", vBC], ["V CA", vCA]].map(([l, v]) => {
                    const nominal = 20000;
                    const dev = (v - nominal) / nominal * 100;
                    const ok = Math.abs(dev) <= 5;

                    return (
                      <div key={l} className="flex justify-between items-center border-t border-slate-100 py-1.5">
                        <span className="text-[11px] sm:text-xs font-black text-slate-700">
                          {l}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs sm:text-sm font-black tabular-nums ${ok ? "text-emerald-800" : "text-red-800"}`}>
                            {dev > 0 ? "+" : ""}
                            {dev.toFixed(2)}%
                          </span>
                          <span className={`text-[8px] sm:text-[10px] font-black rounded px-1 py-0.5 ${ok ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}`}>
                            {ok ? "OK" : "FAIL"}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>






              {/* Kolom 3: ARUS */}
              <div className="flex flex-col divide-y divide-slate-200">
                <SectionHead icon={Icon.current({})} title="ARUS" color="indigo" />
                <div className="p-1.5 sm:p-2.5 grid grid-cols-2 gap-2">
                  <KPI label="I Avg" value={iAvg.toFixed(3)} unit="A" color="blue" delta={deltaIAvg} />
                  <KPI label="Imb I" value={`${imbalI.toFixed(2)}%`} unit="" warn={!imbalIOk} />
                  <KPI label="I N" value={iN.toFixed(3)} unit="A" warn={!iNOk} />
                  <KPI label="Freq" value={freq.toFixed(3)} unit="Hz" warn={!freqOk} delta={deltaFreq} />
                </div>
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Arus per Fasa (A)" />
                  <HBar label="A" value={iA} max={iMax} color="#1d4ed8" labelColor="#1d4ed8" delta={deltaIA} />
                  <HBar label="B" value={iB} max={iMax} color="#166534" labelColor="#166534" delta={deltaIB} />
                  <HBar label="C" value={iC} max={iMax} color="#b45309" labelColor="#b45309" delta={deltaIC} />
                </div>
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Delta Arus" />
                  <table className="w-full">
                    <thead>
                      <tr className="border-b-2 border-slate-400">
                        <th className="text-[10px] sm:text-[11px] font-black text-slate-700 text-left pb-1">Fasa</th>
                        <th className="text-[10px] sm:text-[11px] font-black text-slate-700 text-right pb-1">I (A)</th>
                        <th className="text-[10px] sm:text-[11px] font-black text-slate-700 text-right pb-1">Δ Avg</th>
                        <th className="text-[10px] sm:text-[11px] font-black text-slate-700 text-right pb-1">%</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { l:"A", v:iA, c:"#1d4ed8" },
                        { l:"B", v:iB, c:"#166534" },
                        { l:"C", v:iC, c:"#b45309" },
                      ].map(({ l, v, c }) => {
                        const delta = v - iAvg;
                        const pct   = iAvg > 0 ? (Math.abs(delta)/iAvg*100).toFixed(2) : "0.00";
                        return (
                          <tr key={l} className="border-t border-slate-200">
                            <td className="py-1 text-xs sm:text-sm font-black" style={{ color: c }}>{l}</td>
                            <td className="py-1 text-xs sm:text-sm font-black text-slate-950 tabular-nums text-right">{v.toFixed(3)}</td>
                            <td className={`py-1 text-xs sm:text-sm font-black tabular-nums text-right ${delta>0?"text-blue-800":"text-red-800"}`}>
                              {delta>0?"+":""}{delta.toFixed(3)}
                            </td>
                            <td className="py-1 text-[11px] sm:text-xs font-black text-slate-600 tabular-nums text-right">{pct}%</td>
                          </tr>
                        );
                      })}
                      <tr className="border-t-2 border-slate-400">
                        <td className="py-1 text-[10px] sm:text-[11px] font-black text-slate-500">AVG</td>
                        <td className="py-1 text-xs sm:text-sm font-black text-blue-900 tabular-nums text-right">{iAvg.toFixed(3)}</td>
                        <td colSpan={2} className="py-1 text-[10px] sm:text-[11px] font-black text-slate-400 text-right">—</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="p-1.5 sm:p-2.5 flex-1">
                  <Divider title="Diagnosa Arus Netral" />
                  <div className={`border-2 rounded p-2 mb-2 ${iNOk ? "border-emerald-400 bg-emerald-50" : "border-amber-400 bg-amber-50"}`}>
                    <div className="text-sm sm:text-base font-black text-slate-950">I<sub>N</sub> = {iN.toFixed(3)} A</div>
                    <div className={`text-[10px] sm:text-[11px] font-black mt-0.5 ${iNOk?"text-emerald-800":"text-amber-900"}`}>
                      {iNOk ? "✓ Seimbang" : "⚠ Tidak seimbang"}
                    </div>
                  </div>
                  <Divider title="SPLN" />
                  {[
                    { l:"Imb Arus", v:imbalI.toFixed(2)+"%", ok:imbalIOk },
                    { l:"Imb Teg", v:imbalV.toFixed(3)+"%", ok:imbalVOk },
                    { l:"Frekuensi", v:freq.toFixed(3)+" Hz", ok:freqOk },
                    { l:"Arus N", v:iN.toFixed(3)+" A", ok:iNOk },
                  ].map(({ l, v, ok }) => (
                    <div key={l} className="flex items-center justify-between border-t border-slate-100 py-1">
                      <span className="text-[10px] sm:text-[11px] font-black text-slate-700">{l}</span>
                      <div className="flex items-center gap-1">
                        <span className={`text-xs sm:text-sm font-black tabular-nums ${ok?"text-emerald-900":"text-red-900"}`}>{v}</span>
                        <StatusDot ok={ok} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Kolom 4: POWER FACTOR */}
              <div className="flex flex-col divide-y divide-slate-200">
                <SectionHead icon={Icon.pf({})} title="PF" color="violet" />
                <div className="p-1.5 sm:p-2.5 text-center">
                  <div className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase">PF Total</div>
                  <PFGauge value={pfT} />
                  {deltaPf && <div className={`text-[9px] sm:text-[10px] font-black ${deltaPf.color}`}>{deltaPf.sign} {deltaPf.value}</div>}
                </div>
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="PF per Fasa" />
                  <PFBar label="A" value={pfA} delta={getDelta(pfA, prev?.pfA)} />
                  <PFBar label="B" value={pfB} delta={getDelta(pfB, prev?.pfB)} />
                  <PFBar label="C" value={pfC} delta={getDelta(pfC, prev?.pfC)} />
                  <table className="w-full mt-2">
                    <tbody>
                      <TRow label="PF Total" value={pfT.toFixed(4)} highlight delta={deltaPf} />
                      <TRow label="PF A" value={pfA.toFixed(4)} />
                      <TRow label="PF B" value={pfB.toFixed(4)} />
                      <TRow label="PF C" value={pfC.toFixed(4)} />
                      <TRow label="PF Rata" value={pfAvg.toFixed(4)} />
                    </tbody>
                  </table>
                </div>
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Sudut Fasa" />
                  <table className="w-full">
                    <tbody>
                      <TRow label="φ (°)" value={(phi*180/Math.PI).toFixed(3)} unit="°" />
                      <TRow label="cos φ" value={pfT.toFixed(5)} highlight />
                      <TRow label="sin φ" value={Math.sqrt(Math.max(0,1-pfT**2)).toFixed(5)} />
                      <TRow label="tan φ" value={(Q/P).toFixed(5)} />
                    </tbody>
                  </table>
                </div>
                <div className="p-1.5 sm:p-2.5 flex-1">
                  <Divider title="Kapasitor Bank" />
                  <div className={`border-2 rounded p-2 mb-2 ${QcNeeded > 0 ? "border-amber-500 bg-amber-50" : "border-emerald-500 bg-emerald-50"}`}>
                    {QcNeeded > 0 ? (
                      <>
                        <div className="text-[10px] sm:text-[11px] font-black text-amber-900">PERLU KAPASITOR</div>
                        <div className="text-base sm:text-lg font-black text-amber-950">{QcNeeded.toFixed(3)} kVAR</div>
                      </>
                    ) : (
                      <div className="text-[10px] sm:text-[11px] font-black text-emerald-900">✓ PF MEMADAI</div>
                    )}
                  </div>
                  <table className="w-full">
                    <tbody>
                      <TRow label="Q" value={Q.toFixed(3)} unit="kVAR" warn={Q > Qtgt95} />
                      <TRow label="Q target 0.95" value={Qtgt95.toFixed(3)} unit="kVAR" />
                      <TRow label="Qc" value={QcNeeded > 0 ? QcNeeded.toFixed(3) : "0"} unit="kVAR" warn={QcNeeded > 0} />
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Kolom 5: ANALISA */}
              <div className="flex flex-col divide-y divide-slate-200">
                <SectionHead icon={Icon.chart({})} title="ANALISA" color="slate" />
                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Status" />
                  {[
                    { l:"P", v:`${P.toFixed(3)} kW`, ok:true, delta:deltaP },
                    { l:"Q", v:`${Q.toFixed(3)} kVAR`, ok:QcNeeded<=0, delta:deltaQ },
                    { l:"PF", v:pfT.toFixed(4), ok:pfOk, delta:deltaPf },
                    { l:"Freq", v:`${freq.toFixed(3)} Hz`, ok:freqOk, delta:deltaFreq },
                    { l:"Imb I", v:`${imbalI.toFixed(2)}%`, ok:imbalIOk },
                    { l:"Imb V", v:`${imbalV.toFixed(3)}%`, ok:imbalVOk },
                    { l:"I N", v:`${iN.toFixed(3)} A`, ok:iNOk },
                  ].map(({ l, v, ok, delta }) => (
                    <div key={l} className="flex items-center justify-between border-t border-slate-100 py-1">
                      <span className="text-[10px] sm:text-[11px] font-black text-slate-700 flex items-center gap-1">
                        {l}
                        {delta && <span className={`text-[8px] sm:text-[9px] ${delta.color}`}>({delta.sign}{delta.value})</span>}
                      </span>
                      <div className="flex items-center gap-1">
                        <span className={`text-xs sm:text-sm font-black tabular-nums ${ok?"text-slate-950":"text-red-900"}`}>{v}</span>
                        <StatusDot ok={ok} />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Distribusi Daya" />
                  {[
                    { l:"A", p:Pa, q:Qa, s:Sa, c:"#1d4ed8" },
                    { l:"B", p:Pb, q:Qb, s:Sb, c:"#166534" },
                    { l:"C", p:Pc, q:Qc, s:Sc, c:"#b45309" },
                  ].map(({ l, p, q, s, c }) => (
                    <div key={l} className="border-t border-slate-100 py-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs sm:text-sm font-black" style={{ color:c }}>Fasa {l}</span>
                        <span className="text-[8px] sm:text-[10px] font-black text-slate-500">
                          P:{(p/P*100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="h-2 bg-slate-200 border border-slate-300 rounded-sm overflow-hidden">
                        <div className="h-full" style={{ width:`${p/P*100}%`, backgroundColor:c }} />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-1.5 sm:p-2.5">
                  <Divider title="Rekomendasi" />
                  <div className="space-y-1">
                    {pfT < 0.95 && (
                      <div className="border-l-4 border-amber-500 pl-2 py-1 bg-amber-50 rounded-r text-[10px] sm:text-[11px] font-black text-amber-900">
                        Pasang kapasitor {QcNeeded.toFixed(2)} kVAR
                      </div>
                    )}
                    {!imbalIOk && (
                      <div className="border-l-4 border-red-500 pl-2 py-1 bg-red-50 rounded-r text-[10px] sm:text-[11px] font-black text-red-900">
                        Redistribusi beban
                      </div>
                    )}
                    {!imbalVOk && (
                      <div className="border-l-4 border-orange-500 pl-2 py-1 bg-orange-50 rounded-r text-[10px] sm:text-[11px] font-black text-orange-900">
                        Periksa impedansi
                      </div>
                    )}
                    {!iNOk && (
                      <div className="border-l-4 border-orange-400 pl-2 py-1 bg-orange-50 rounded-r text-[10px] sm:text-[11px] font-black text-orange-900">
                        Cek harmonisa
                      </div>
                    )}
                    {!freqOk && (
                      <div className="border-l-4 border-red-600 pl-2 py-1 bg-red-50 rounded-r text-[10px] sm:text-[11px] font-black text-red-900">
                        Frekuensi abnormal
                      </div>
                    )}
                    {pfT >= 0.95 && imbalIOk && imbalVOk && iNOk && freqOk && (
                      <div className="border-l-4 border-emerald-500 pl-2 py-1 bg-emerald-50 rounded-r text-[10px] sm:text-[11px] font-black text-emerald-900">
                        ✓ Normal
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-1.5 sm:p-2.5 flex-1">
                  <Divider title="Tren P" />
                  <Sparkline data={history} color="#166534" height={20} />
                  <div className="flex justify-between text-[8px] sm:text-[9px] font-bold text-slate-500 mt-0.5">
                    <span>min: {Math.min(...history, 0).toFixed(2)} kW</span>
                    <span>max: {Math.max(...history, 0).toFixed(2)} kW</span>
                  </div>
                  <Divider title="Info" />
                  <table className="w-full">
                    <tbody>
                      <TRow label="Panel" value={d.panel?.toUpperCase()} />
                      <TRow label="ID" value={`#${d.id}`} />
                    </tbody>
                  </table>
                </div>
              </div>





            </div>
          )}

          {/* ══ FOOTER ══ */}
          <div className="border-t-2 border-slate-600 bg-slate-800 px-2 sm:px-4 py-1 flex flex-wrap justify-between items-center text-[10px] sm:text-[11px] font-bold text-slate-400">
            <span>Panel: <span className="text-white font-black">{d.panel?.toUpperCase() || '-'}</span></span>
            <span>Server: <span className="text-white font-black">{d.date_time || '-'}</span></span>
          </div>

        </div>
      </div>
    </Layout>
  );
}