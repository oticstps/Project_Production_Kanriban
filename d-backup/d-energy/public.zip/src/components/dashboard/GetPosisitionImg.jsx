import React, { useState, useRef, useEffect } from 'react';
import Layout from '../layout/Layout';

const GetPosisitionImg = () => {
  const [imageUrl, setImageUrl] = useState(null);
  const [isSelecting, setIsSelecting] = useState(false);
  const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
  const [endPoint, setEndPoint] = useState({ x: 0, y: 0 });
  const [selection, setSelection] = useState(null);
  const imgRef = useRef(null);
  const containerRef = useRef(null);
  const fileInputRef = useRef(null);

  // Handle upload gambar
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Bersihkan URL sebelumnya
      if (imageUrl) {
        URL.revokeObjectURL(imageUrl);
      }
      const url = URL.createObjectURL(file);
      setImageUrl(url);
      // Reset seleksi
      setSelection(null);
      setIsSelecting(false);
    }
  };

  // Bersihkan object URL saat komponen unmount
  useEffect(() => {
    return () => {
      if (imageUrl) {
        URL.revokeObjectURL(imageUrl);
      }
    };
  }, [imageUrl]);

  // Mulai seleksi
  const handleMouseDown = (e) => {
    if (!imgRef.current || !imageUrl) return;
    const rect = imgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setStartPoint({ x, y });
    setEndPoint({ x, y });
    setIsSelecting(true);
    setSelection(null);
  };

  // Saat mouse bergerak
  const handleMouseMove = (e) => {
    if (!isSelecting || !imgRef.current) return;
    const rect = imgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    // Batasi agar tidak keluar dari gambar
    const clampedX = Math.min(Math.max(x, 0), rect.width);
    const clampedY = Math.min(Math.max(y, 0), rect.height);
    setEndPoint({ x: clampedX, y: clampedY });
  };

  // Saat mouse dilepas
  const handleMouseUp = () => {
    if (isSelecting) {
      setIsSelecting(false);
      // Hitung area seleksi
      const x1 = Math.min(startPoint.x, endPoint.x);
      const y1 = Math.min(startPoint.y, endPoint.y);
      const x2 = Math.max(startPoint.x, endPoint.x);
      const y2 = Math.max(startPoint.y, endPoint.y);
      const width = x2 - x1;
      const height = y2 - y1;
      if (width > 5 && height > 5) {
        setSelection({
          x: Math.round(x1),
          y: Math.round(y1),
          width: Math.round(width),
          height: Math.round(height),
        });
      }
    }
  };

  // Event listener global
  useEffect(() => {
    if (isSelecting) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    } else {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isSelecting, startPoint, endPoint]);

  // Salin koordinat ke clipboard
  const copyToClipboard = () => {
    if (selection) {
      const text = `x: ${selection.x}, y: ${selection.y}, width: ${selection.width}, height: ${selection.height}`;
      navigator.clipboard.writeText(text);
      alert('Koordinat disalin!');
    }
  };

  return (
    <Layout>
      <div className="p-4 bg-white rounded shadow">
        <h2 className="text-lg font-bold mb-2">Get Position from Image</h2>
        <p className="text-sm text-gray-600 mb-2">
          Upload gambar, lalu klik dan drag pada gambar untuk memilih area. Lepaskan mouse untuk mendapatkan koordinat.
        </p>

        {/* Input file */}
        <div className="mb-4">
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            ref={fileInputRef}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
        </div>

        {/* Area gambar */}
        {imageUrl ? (
          <div
            ref={containerRef}
            className="relative inline-block border border-gray-300 rounded"
            onMouseDown={handleMouseDown}
            style={{ userSelect: 'none' }}
          >
            <img
              ref={imgRef}
              src={imageUrl}
              alt="Uploaded"
              className="max-w-full h-auto block"
              draggable="false"
            />
            {/* Overlay seleksi aktif */}
            {isSelecting && (
              <div
                className="absolute border-2 border-blue-500 bg-blue-200 bg-opacity-30 pointer-events-none"
                style={{
                  left: Math.min(startPoint.x, endPoint.x),
                  top: Math.min(startPoint.y, endPoint.y),
                  width: Math.abs(endPoint.x - startPoint.x),
                  height: Math.abs(endPoint.y - startPoint.y),
                }}
              />
            )}
            {/* Area yang sudah dipilih */}
            {selection && !isSelecting && (
              <div
                className="absolute border-2 border-green-500 bg-green-200 bg-opacity-20 pointer-events-none"
                style={{
                  left: selection.x,
                  top: selection.y,
                  width: selection.width,
                  height: selection.height,
                }}
              />
            )}
          </div>
        ) : (
          <div className="border-2 border-dashed border-gray-300 rounded p-8 text-center text-gray-400">
            Belum ada gambar. Silakan upload.
          </div>
        )}

        {/* Hasil koordinat */}
        {selection && (
          <div className="mt-4 p-3 bg-gray-100 rounded">
            <p className="font-mono text-sm">
              x: {selection.x}, y: {selection.y}, width: {selection.width}, height: {selection.height}
            </p>
            <button
              onClick={copyToClipboard}
              className="mt-2 px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm"
            >
              Salin Koordinat
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default GetPosisitionImg;