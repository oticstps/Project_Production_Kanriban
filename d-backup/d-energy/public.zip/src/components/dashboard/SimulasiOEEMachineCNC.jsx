import React, { useCallback, useEffect, useMemo, useState } from "react";

const MACHINE_COUNT = 14;

const baseSettings = {
  shiftDuration: 480,
  plannedDowntime: 30,
  idealCycleTime: 1.2,
  targetOEE: 85,
  tickMinutes: 5,
  simulationSpeed: 700,
  machineHourCost: 250000,
  rejectCost: 15000,
  profitPerGood: 8000,
};

const causePool = [
  "Tool wear / insert aus",
  "Setting fixture ulang",
  "Alarm spindle",
  "Menunggu material/QC",
  "Program CNC dikoreksi",
  "Chip menumpuk",
  "Pergantian tool mendadak",
  "Hydraulic pressure drop",
  "Coolant kurang stabil",
  "Clamp kurang presisi",
];

const sixLosses = [
  ["Breakdown Loss", "Mesin berhenti karena kerusakan/alarm", "Availability", "Unplanned downtime naik"],
  ["Setup & Adjustment", "Setting, changeover, kalibrasi, trial", "Availability", "Operating time berkurang"],
  ["Minor Stop", "Stop pendek karena sensor, chip, handling", "Performance", "Cycle efektif melambat"],
  ["Reduced Speed", "Mesin lebih lambat dari standar", "Performance", "Output aktual < output ideal"],
  ["Process Defect", "Reject saat proses stabil", "Quality", "Good output turun"],
  ["Reduced Yield", "Reject awal produksi/startup", "Quality", "Yield awal rendah"],
];

function createMachine(index) {
  const type = index % 4;
  const profile = [
    { downtimeProbability: 7, defectProbability: 2, speedLossRate: 4, microStopRate: 2 },
    { downtimeProbability: 14, defectProbability: 4, speedLossRate: 8, microStopRate: 5 },
    { downtimeProbability: 22, defectProbability: 5, speedLossRate: 10, microStopRate: 7 },
    { downtimeProbability: 10, defectProbability: 9, speedLossRate: 13, microStopRate: 8 },
  ][type];

  return {
    id: `CNC-${String(index + 1).padStart(2, "0")}`,
    name: `CNC Machine ${String(index + 1).padStart(2, "0")}`,
    operator: `Operator ${String.fromCharCode(65 + index)}`,
    shift: "Shift 1",
    status: "IDLE",
    elapsed: 0,
    totalProduced: 0,
    goodProduced: 0,
    rejectProduced: 0,
    plannedDowntimeElapsed: 0,
    unplannedDowntime: 0,
    microStopMinutes: 0,
    logs: [],
    ...profile,
  };
}

const initialMachines = Array.from({ length: MACHINE_COUNT }, (_, index) => createMachine(index));

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function pct(value, digits = 2) {
  if (!Number.isFinite(value)) return "0,00%";
  return `${value.toLocaleString("id-ID", { minimumFractionDigits: digits, maximumFractionDigits: digits })}%`;
}

function num(value, digits = 0) {
  if (!Number.isFinite(value)) return "0";
  return value.toLocaleString("id-ID", { maximumFractionDigits: digits });
}

function rupiah(value) {
  return `Rp ${num(value)}`;
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function overlapMinutes(aStart, aEnd, bStart, bEnd) {
  return Math.max(0, Math.min(aEnd, bEnd) - Math.max(aStart, bStart));
}

function clock(minute) {
  const base = 8 * 60;
  const total = base + Math.floor(minute);
  const h = Math.floor(total / 60) % 24;
  const m = total % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function statusClass(value) {
  if (value >= 85) return "border-emerald-200 bg-emerald-50 text-emerald-700";
  if (value >= 70) return "border-amber-200 bg-amber-50 text-amber-700";
  return "border-red-200 bg-red-50 text-red-700";
}

function barClass(value) {
  if (value >= 85) return "bg-emerald-500";
  if (value >= 70) return "bg-amber-500";
  return "bg-red-500";
}

function eventClass(status) {
  if (status === "RUNNING") return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (status === "DOWNTIME") return "bg-red-50 text-red-700 border-red-200";
  if (status === "PLANNED STOP") return "bg-sky-50 text-sky-700 border-sky-200";
  return "bg-slate-50 text-slate-700 border-slate-200";
}

function calcMachine(machine, settings) {
  const scheduledTime = machine.elapsed;
  const plannedStop = machine.plannedDowntimeElapsed;
  const loadingTime = Math.max(scheduledTime - plannedStop, 0);
  const operatingTime = Math.max(loadingTime - machine.unplannedDowntime, 0);
  const netOperatingTime = Number(settings.idealCycleTime || 0) * machine.totalProduced;
  const fullyProductiveTime = Number(settings.idealCycleTime || 0) * machine.goodProduced;
  const availability = loadingTime > 0 ? (operatingTime / loadingTime) * 100 : 0;
  const performanceRaw = operatingTime > 0 ? (netOperatingTime / operatingTime) * 100 : 0;
  const performance = Math.min(performanceRaw, 100);
  const quality = machine.totalProduced > 0 ? (machine.goodProduced / machine.totalProduced) * 100 : 0;
  const oee = (availability * performance * quality) / 10000;
  const theoreticalOutput = Number(settings.idealCycleTime || 0) > 0 ? Math.floor(operatingTime / Number(settings.idealCycleTime)) : 0;
  const outputGap = Math.max(theoreticalOutput - machine.totalProduced, 0);
  const speedLossTime = Math.max(operatingTime - netOperatingTime, 0);
  const qualityLossTime = Math.max(netOperatingTime - fullyProductiveTime, 0);
  const productiveRatio = scheduledTime > 0 ? (fullyProductiveTime / scheduledTime) * 100 : 0;
  const progress = (machine.elapsed / Number(settings.shiftDuration || 1)) * 100;

  const weakest = [
    { key: "Availability", value: availability, problem: "kerugian waktu", action: "prioritaskan preventive maintenance, analisis alarm, waiting material, dan recovery time." },
    { key: "Performance", value: performance, problem: "kerugian kecepatan", action: "validasi cycle time aktual, micro stop, handling, feeding, dan parameter cutting." },
    { key: "Quality", value: quality, problem: "kerugian mutu", action: "telusuri reject, tool wear, fixture, dimensi kritis, dan first-piece inspection." },
  ].sort((a, b) => a.value - b.value)[0];

  return {
    scheduledTime,
    plannedStop,
    loadingTime,
    operatingTime,
    netOperatingTime,
    fullyProductiveTime,
    availability,
    performanceRaw,
    performance,
    quality,
    oee,
    theoreticalOutput,
    outputGap,
    speedLossTime,
    qualityLossTime,
    productiveRatio,
    progress,
    weakest,
  };
}

function aggregateMachines(machines, settings) {
  const total = machines.reduce(
    (acc, m) => {
      acc.elapsed += m.elapsed;
      acc.totalProduced += m.totalProduced;
      acc.goodProduced += m.goodProduced;
      acc.rejectProduced += m.rejectProduced;
      acc.plannedDowntimeElapsed += m.plannedDowntimeElapsed;
      acc.unplannedDowntime += m.unplannedDowntime;
      acc.microStopMinutes += m.microStopMinutes;
      return acc;
    },
    { elapsed: 0, totalProduced: 0, goodProduced: 0, rejectProduced: 0, plannedDowntimeElapsed: 0, unplannedDowntime: 0, microStopMinutes: 0 }
  );

  return calcMachine({ ...total, logs: [] }, settings);
}

function simulateMachineTick(machine, settings, plannedWindow) {
  const shiftDuration = Number(settings.shiftDuration) || 1;
  if (machine.elapsed >= shiftDuration) return { ...machine, status: "DONE" };

  const tick = Math.min(Number(settings.tickMinutes) || 1, shiftDuration - machine.elapsed);
  const start = machine.elapsed;
  const end = start + tick;
  const plannedStop = overlapMinutes(start, end, plannedWindow.start, plannedWindow.end);
  const available = Math.max(tick - plannedStop, 0);

  let status = "RUNNING";
  let cause = "Normal cutting";
  let unplanned = 0;
  let microStop = 0;
  let produced = 0;
  let reject = 0;
  let good = 0;
  let actualCycleTime = 0;

  if (plannedStop >= tick) {
    status = "PLANNED STOP";
    cause = "Planned downtime: briefing, preventive check, istirahat, atau setup terjadwal";
  } else if (available > 0) {
    const downtimeOccurs = Math.random() * 100 < Number(machine.downtimeProbability || 0);
    if (downtimeOccurs) {
      unplanned = Math.min(available, randInt(1, Math.max(1, Math.ceil(available))));
      status = "DOWNTIME";
      cause = pick(causePool);
    }

    const runMinutes = Math.max(available - unplanned, 0);
    microStop = runMinutes * (Number(machine.microStopRate || 0) / 100);
    const cuttingMinutes = Math.max(runMinutes - microStop, 0);
    const randomVariation = 1 + (Math.random() - 0.5) * 0.1;
    actualCycleTime = Math.max(0.05, Number(settings.idealCycleTime || 1) * (1 + Number(machine.speedLossRate || 0) / 100) * randomVariation);
    produced = Math.floor(cuttingMinutes / actualCycleTime);

    for (let i = 0; i < produced; i += 1) {
      if (Math.random() * 100 < Number(machine.defectProbability || 0)) reject += 1;
    }

    good = Math.max(produced - reject, 0);
    if (status === "RUNNING" && microStop > 0) cause = "Running dengan micro stop dan reduced speed";
    if (status === "RUNNING" && produced === 0) cause = "Cycle belum selesai, output belum terbentuk";
  }

  const log = {
    id: `${machine.id}-${Date.now()}-${start}`,
    machineId: machine.id,
    start,
    end,
    status,
    produced,
    good,
    reject,
    plannedStop,
    unplanned,
    microStop,
    actualCycleTime,
    cause,
  };

  return {
    ...machine,
    status,
    elapsed: end,
    totalProduced: machine.totalProduced + produced,
    goodProduced: machine.goodProduced + good,
    rejectProduced: machine.rejectProduced + reject,
    plannedDowntimeElapsed: machine.plannedDowntimeElapsed + plannedStop,
    unplannedDowntime: machine.unplannedDowntime + unplanned,
    microStopMinutes: machine.microStopMinutes + microStop,
    logs: [log, ...machine.logs].slice(0, 100),
  };
}

export default function SimulasiOEEMachineCNC() {
  const [settings, setSettings] = useState(baseSettings);
  const [machines, setMachines] = useState(initialMachines);
  const [selectedId, setSelectedId] = useState("CNC-01");
  const [running, setRunning] = useState(false);
  const [tab, setTab] = useState("fleet");
  const [whatIf, setWhatIf] = useState({ downtimeReduction: 20, speedLossReduction: 20, rejectReduction: 20 });

  const plannedWindow = useMemo(() => {
    const start = Math.floor(Number(settings.shiftDuration || 0) * 0.5);
    const end = start + Number(settings.plannedDowntime || 0);
    return { start, end };
  }, [settings.shiftDuration, settings.plannedDowntime]);

  const selectedMachine = machines.find((m) => m.id === selectedId) || machines[0];
  const selectedCalc = useMemo(() => calcMachine(selectedMachine, settings), [selectedMachine, settings]);
  const fleetCalc = useMemo(() => aggregateMachines(machines, settings), [machines, settings]);

  const rankedMachines = useMemo(() => {
    return machines
      .map((machine) => ({ machine, calc: calcMachine(machine, settings) }))
      .sort((a, b) => b.calc.oee - a.calc.oee);
  }, [machines, settings]);

  const fleetDecision = useMemo(() => {
    const allLogs = machines.flatMap((m) => m.logs.map((log) => ({ ...log, machineName: m.name })));

    const downtimeByCause = allLogs.reduce((acc, item) => {
      if (item.unplanned > 0) acc[item.cause] = (acc[item.cause] || 0) + item.unplanned;
      return acc;
    }, {});

    const paretoDowntime = Object.entries(downtimeByCause)
      .map(([cause, minutes]) => ({ cause, minutes }))
      .sort((a, b) => b.minutes - a.minutes);

    const rejectHotspot = allLogs
      .filter((item) => item.reject > 0)
      .map((item) => ({ machineId: item.machineId, time: `${clock(item.start)}-${clock(item.end)}`, reject: item.reject, cause: item.cause }))
      .sort((a, b) => b.reject - a.reject)
      .slice(0, 8);

    const reducedUnplanned = machines.reduce((sum, m) => sum + m.unplannedDowntime, 0) * (1 - Number(whatIf.downtimeReduction || 0) / 100);
    const adjustedOperating = Math.max(fleetCalc.loadingTime - reducedUnplanned, 0);
    const adjustedSpeedLoss = fleetCalc.speedLossTime * (1 - Number(whatIf.speedLossReduction || 0) / 100);
    const adjustedNetOperating = Math.max(adjustedOperating - adjustedSpeedLoss, 0);
    const estimatedTotal = Number(settings.idealCycleTime || 0) > 0 ? Math.floor(adjustedNetOperating / Number(settings.idealCycleTime)) : machines.reduce((s, m) => s + m.totalProduced, 0);
    const actualReject = machines.reduce((s, m) => s + m.rejectProduced, 0);
    const actualGood = machines.reduce((s, m) => s + m.goodProduced, 0);
    const estimatedReject = Math.max(0, Math.round(actualReject * (1 - Number(whatIf.rejectReduction || 0) / 100)));
    const estimatedGood = Math.max(estimatedTotal - estimatedReject, 0);
    const predAvailability = fleetCalc.loadingTime > 0 ? (adjustedOperating / fleetCalc.loadingTime) * 100 : 0;
    const predPerformanceRaw = adjustedOperating > 0 ? ((Number(settings.idealCycleTime || 0) * estimatedTotal) / adjustedOperating) * 100 : 0;
    const predPerformance = Math.min(predPerformanceRaw, 100);
    const predQuality = estimatedTotal > 0 ? (estimatedGood / estimatedTotal) * 100 : 0;
    const predOEE = (predAvailability * predPerformance * predQuality) / 10000;

    const downtimeCost = (machines.reduce((s, m) => s + m.unplannedDowntime, 0) / 60) * Number(settings.machineHourCost || 0);
    const rejectCost = actualReject * Number(settings.rejectCost || 0);
    const opportunityCost = rankedMachines.reduce((sum, item) => sum + item.calc.outputGap, 0) * Number(settings.profitPerGood || 0);
    const totalCost = downtimeCost + rejectCost + opportunityCost;
    const predictedGain = Math.max(0, estimatedGood - actualGood) * Number(settings.profitPerGood || 0);

    const alarms = [];
    if (fleetCalc.oee < Number(settings.targetOEE || 0)) alarms.push("OEE line 14 mesin belum mencapai target.");
    if (fleetCalc.availability < 70) alarms.push("Availability line kritis: downtime kolektif terlalu tinggi.");
    if (fleetCalc.performance < 70) alarms.push("Performance line kritis: speed loss/micro stop dominan.");
    if (fleetCalc.quality < 95 && machines.some((m) => m.totalProduced > 0)) alarms.push("Quality line perlu perhatian: reject mulai menekan good output.");
    const bottom = [...rankedMachines].sort((a, b) => a.calc.oee - b.calc.oee).slice(0, 3);
    if (bottom.length) alarms.push(`Mesin prioritas audit: ${bottom.map((x) => x.machine.id).join(", ")}.`);

    return {
      paretoDowntime,
      rejectHotspot,
      predicted: { availability: predAvailability, performance: predPerformance, quality: predQuality, oee: predOEE, total: estimatedTotal, good: estimatedGood, reject: estimatedReject, gain: predictedGain },
      cost: { downtimeCost, rejectCost, opportunityCost, totalCost },
      alarms,
    };
  }, [machines, fleetCalc, whatIf, settings, rankedMachines]);

  const stepAll = useCallback(() => {
    setMachines((prev) => prev.map((machine) => simulateMachineTick(machine, settings, plannedWindow)));
  }, [settings, plannedWindow]);

  useEffect(() => {
    if (!running) return undefined;
    const timer = window.setInterval(stepAll, Number(settings.simulationSpeed) || 700);
    return () => window.clearInterval(timer);
  }, [running, settings.simulationSpeed, stepAll]);

  useEffect(() => {
    if (machines.every((m) => m.elapsed >= Number(settings.shiftDuration || 0))) setRunning(false);
  }, [machines, settings.shiftDuration]);

  const updateSetting = (e) => {
    const { name, value, type } = e.target;
    setSettings((prev) => ({ ...prev, [name]: type === "number" || type === "range" ? Number(value) : value }));
  };

  const updateMachine = (id, field, value) => {
    setMachines((prev) => prev.map((m) => (m.id === id ? { ...m, [field]: value } : m)));
  };

  const updateWhatIf = (e) => {
    const { name, value } = e.target;
    setWhatIf((prev) => ({ ...prev, [name]: Number(value) }));
  };

  const resetAll = () => {
    setRunning(false);
    setMachines(Array.from({ length: MACHINE_COUNT }, (_, index) => createMachine(index)));
  };

  const applyScenario = (type) => {
    const map = {
      stable: { downtimeProbability: 5, defectProbability: 1.5, speedLossRate: 3, microStopRate: 2 },
      downtime: { downtimeProbability: 35, defectProbability: 3, speedLossRate: 8, microStopRate: 6 },
      quality: { downtimeProbability: 8, defectProbability: 14, speedLossRate: 5, microStopRate: 3 },
      speed: { downtimeProbability: 8, defectProbability: 3, speedLossRate: 24, microStopRate: 16 },
    };
    setMachines((prev) => prev.map((m) => ({ ...m, ...map[type], elapsed: 0, totalProduced: 0, goodProduced: 0, rejectProduced: 0, plannedDowntimeElapsed: 0, unplannedDowntime: 0, microStopMinutes: 0, logs: [], status: "IDLE" })));
    setRunning(false);
  };

  const exportCSV = () => {
    const header = ["machine", "start", "end", "status", "output", "good", "reject", "planned_stop", "unplanned_downtime", "micro_stop", "actual_cycle_time", "cause"];
    const rows = machines.flatMap((machine) => machine.logs.slice().reverse().map((item) => [
      machine.id,
      clock(item.start),
      clock(item.end),
      item.status,
      item.produced,
      item.good,
      item.reject,
      num(item.plannedStop, 2),
      num(item.unplanned, 2),
      num(item.microStop, 2),
      num(item.actualCycleTime, 3),
      `"${String(item.cause).replaceAll('"', '""')}"`,
    ]));
    const csv = [header, ...rows].map((row) => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `oee-14-mesin-log-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportJSON = () => {
    const payload = {
      settings,
      machines,
      fleetCalculation: fleetCalc,
      ranking: rankedMachines.map((x) => ({ id: x.machine.id, oee: x.calc.oee, availability: x.calc.availability, performance: x.calc.performance, quality: x.calc.quality })),
      decision: fleetDecision,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `oee-14-mesin-summary-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const formulaRows = [
    ["Scheduled Time", "Waktu shift berjalan", "ST", `${num(fleetCalc.scheduledTime, 1)} menit`],
    ["Planned Downtime", "Stop yang direncanakan", "PDT", `${num(fleetCalc.plannedStop, 1)} menit`],
    ["Loading Time", "Scheduled Time − Planned Downtime", "LT = ST − PDT", `${num(fleetCalc.loadingTime, 1)} menit`],
    ["Operating Time", "Loading Time − Unplanned Downtime", "OT = LT − UDT", `${num(fleetCalc.operatingTime, 1)} menit`],
    ["Net Operating Time", "Ideal Cycle Time × Total Output", "NOT = ICT × Total Count", `${num(fleetCalc.netOperatingTime, 1)} menit`],
    ["Fully Productive Time", "Ideal Cycle Time × Good Output", "FPT = ICT × Good Count", `${num(fleetCalc.fullyProductiveTime, 1)} menit`],
    ["Availability", "Operating Time ÷ Loading Time × 100%", "A = OT / LT × 100%", pct(fleetCalc.availability)],
    ["Performance", "Net Operating Time ÷ Operating Time × 100%", "P = NOT / OT × 100%", `${pct(fleetCalc.performance)} raw ${pct(fleetCalc.performanceRaw)}`],
    ["Quality", "Good Output ÷ Total Output × 100%", "Q = Good / Total × 100%", pct(fleetCalc.quality)],
    ["OEE", "Availability × Performance × Quality", "OEE = A × P × Q", pct(fleetCalc.oee)],
    ["Speed Loss Time", "Operating Time − Net Operating Time", "SLT = OT − NOT", `${num(fleetCalc.speedLossTime, 1)} menit`],
    ["Quality Loss Time", "Net Operating Time − Fully Productive Time", "QLT = NOT − FPT", `${num(fleetCalc.qualityLossTime, 1)} menit`],
  ];

  const academicText = `Secara agregat, 14 mesin CNC menghasilkan OEE line sebesar ${pct(fleetCalc.oee)} dengan Availability ${pct(fleetCalc.availability)}, Performance ${pct(fleetCalc.performance)}, dan Quality ${pct(fleetCalc.quality)}. Komponen pembatas utama adalah ${fleetCalc.weakest.key}, sehingga intervensi awal lebih rasional diarahkan pada ${fleetCalc.weakest.problem}. Ranking mesin menunjukkan variasi efektivitas antar unit; mesin dengan OEE terendah harus diaudit lebih dahulu karena berpotensi menjadi bottleneck line produksi.`;

  return (
    <main className="min-h-screen bg-slate-100 p-2 text-slate-900 sm:p-3">
      <section className="mx-auto max-w-[1700px] space-y-2">
        <header className="rounded-xl bg-slate-950 p-3 text-white shadow-sm">
          <div className="grid gap-3 xl:grid-cols-[1.1fr_0.9fr]">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.22em] text-cyan-300">Compact Multi-Machine OEE Simulator</p>
              <h1 className="mt-1 text-xl font-black tracking-tight sm:text-2xl">Simulasi OEE 14 Mesin CNC</h1>
              <p className="mt-1 max-w-5xl text-xs leading-5 text-slate-300">
                Dashboard realtime untuk 14 mesin: OEE line, ranking mesin, Gantt per mesin, Pareto downtime, what-if improvement, estimasi biaya kerugian, dan analisis akademik berbasis data simulasi.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <MiniDark label="OEE Line" value={pct(fleetCalc.oee)} />
              <MiniDark label="Good Output" value={`${num(machines.reduce((s, m) => s + m.goodProduced, 0))}`} />
              <MiniDark label="Reject" value={`${num(machines.reduce((s, m) => s + m.rejectProduced, 0))}`} />
              <MiniDark label="Mesin" value={`${MACHINE_COUNT} unit`} />
            </div>
          </div>
        </header>

        <div className="grid gap-2 xl:grid-cols-[315px_1fr]">
          <aside className="space-y-2">
            <Panel title="Kontrol Line 14 Mesin">
              <div className="grid grid-cols-3 gap-1.5">
                <button onClick={() => setRunning((v) => !v)} className={running ? "rounded-lg bg-amber-500 px-2 py-1.5 text-xs font-black text-white" : "rounded-lg bg-cyan-600 px-2 py-1.5 text-xs font-black text-white"}>{running ? "Pause" : "Start"}</button>
                <button onClick={stepAll} disabled={running || machines.every((m) => m.elapsed >= settings.shiftDuration)} className="rounded-lg bg-slate-900 px-2 py-1.5 text-xs font-black text-white disabled:opacity-40">Step All</button>
                <button onClick={resetAll} className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs font-black text-slate-700">Reset</button>
              </div>

              <div className="mt-2 grid grid-cols-4 gap-1.5">
                <ScenarioButton onClick={() => applyScenario("stable")}>Stabil</ScenarioButton>
                <ScenarioButton onClick={() => applyScenario("downtime")}>Down</ScenarioButton>
                <ScenarioButton onClick={() => applyScenario("quality")}>Reject</ScenarioButton>
                <ScenarioButton onClick={() => applyScenario("speed")}>Speed</ScenarioButton>
              </div>

              <div className="mt-2 grid grid-cols-2 gap-1.5">
                <button onClick={exportCSV} className="rounded-lg border border-emerald-200 bg-emerald-50 px-2 py-1.5 text-[10px] font-black text-emerald-700">Export CSV</button>
                <button onClick={exportJSON} className="rounded-lg border border-violet-200 bg-violet-50 px-2 py-1.5 text-[10px] font-black text-violet-700">Export JSON</button>
              </div>

              <div className="mt-2 grid grid-cols-2 gap-1.5">
                <TinyNumber label="Durasi" name="shiftDuration" value={settings.shiftDuration} onChange={updateSetting} unit="mnt" />
                <TinyNumber label="Planned" name="plannedDowntime" value={settings.plannedDowntime} onChange={updateSetting} unit="mnt" />
                <TinyNumber label="Ideal CT" name="idealCycleTime" value={settings.idealCycleTime} onChange={updateSetting} unit="mnt/u" step="0.01" />
                <TinyNumber label="Target" name="targetOEE" value={settings.targetOEE} onChange={updateSetting} unit="%" />
                <TinyNumber label="Tick" name="tickMinutes" value={settings.tickMinutes} onChange={updateSetting} unit="mnt" />
                <TinyNumber label="Speed UI" name="simulationSpeed" value={settings.simulationSpeed} onChange={updateSetting} unit="ms" />
              </div>
            </Panel>

            <Panel title="Pilih & Set Mesin">
              <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="h-8 w-full rounded-lg border border-slate-200 bg-white px-2 text-xs font-bold outline-none focus:border-cyan-500">
                {machines.map((m) => <option key={m.id} value={m.id}>{m.id} - {m.name}</option>)}
              </select>
              <div className="mt-2 grid grid-cols-2 gap-1.5">
                <TinyInput label="Nama" value={selectedMachine.name} onChange={(e) => updateMachine(selectedMachine.id, "name", e.target.value)} />
                <TinyInput label="Operator" value={selectedMachine.operator} onChange={(e) => updateMachine(selectedMachine.id, "operator", e.target.value)} />
              </div>
              <div className="mt-2 space-y-1.5">
                <TinyRange label="Breakdown" value={selectedMachine.downtimeProbability} onChange={(e) => updateMachine(selectedMachine.id, "downtimeProbability", Number(e.target.value))} suffix="%/tick" />
                <TinyRange label="Reject" value={selectedMachine.defectProbability} onChange={(e) => updateMachine(selectedMachine.id, "defectProbability", Number(e.target.value))} suffix="%/unit" />
                <TinyRange label="Speed Loss" value={selectedMachine.speedLossRate} onChange={(e) => updateMachine(selectedMachine.id, "speedLossRate", Number(e.target.value))} suffix="%" />
                <TinyRange label="Micro Stop" value={selectedMachine.microStopRate} onChange={(e) => updateMachine(selectedMachine.id, "microStopRate", Number(e.target.value))} suffix="% run" />
              </div>
            </Panel>
          </aside>

          <section className="space-y-2">
            <div className="flex flex-wrap gap-1 rounded-xl border border-slate-200 bg-white p-1 shadow-sm">
              <Tab active={tab === "fleet"} onClick={() => setTab("fleet")}>Fleet 14 Mesin</Tab>
              <Tab active={tab === "detail"} onClick={() => setTab("detail")}>Detail Mesin</Tab>
              <Tab active={tab === "gantt"} onClick={() => setTab("gantt")}>Gantt</Tab>
              <Tab active={tab === "rumus"} onClick={() => setTab("rumus")}>Rumus</Tab>
              <Tab active={tab === "decision"} onClick={() => setTab("decision")}>Decision Lab</Tab>
              <Tab active={tab === "analisis"} onClick={() => setTab("analisis")}>Analisis</Tab>
              <Tab active={tab === "log"} onClick={() => setTab("log")}>Log</Tab>
            </div>

            {tab === "fleet" && (
              <div className="space-y-2">
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                  <Stat label="OEE Line" value={pct(fleetCalc.oee)} note={`Target ${pct(settings.targetOEE, 0)} | gap ${pct(fleetCalc.oee - settings.targetOEE)}`} />
                  <Stat label="Total Output" value={`${num(machines.reduce((s, m) => s + m.totalProduced, 0))} unit`} note={`Good ${num(machines.reduce((s, m) => s + m.goodProduced, 0))}`} />
                  <Stat label="Downtime Line" value={`${num(machines.reduce((s, m) => s + m.unplannedDowntime, 0), 1)} mnt`} note="akumulasi 14 mesin" />
                  <Stat label="Total Loss Est." value={rupiah(fleetDecision.cost.totalCost)} note="downtime + reject + opportunity" />
                </div>

                <div className="grid gap-2 lg:grid-cols-4">
                  <BigMetric label="Availability" value={fleetCalc.availability} helper="OT ÷ LT agregat" />
                  <BigMetric label="Performance" value={fleetCalc.performance} helper={`NOT ÷ OT | raw ${pct(fleetCalc.performanceRaw)}`} />
                  <BigMetric label="Quality" value={fleetCalc.quality} helper="Good ÷ Total agregat" />
                  <BigMetric label="OEE" value={fleetCalc.oee} helper="A × P × Q agregat" />
                </div>

                <Panel title="Ranking OEE 14 Mesin">
                  <div className="grid gap-1 md:grid-cols-2 xl:grid-cols-3">
                    {rankedMachines.map(({ machine, calc }, index) => (
                      <button key={machine.id} onClick={() => { setSelectedId(machine.id); setTab("detail"); }} className="rounded-lg border border-slate-200 bg-white p-1.5 text-left hover:bg-slate-50">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[10px] font-black text-slate-500">#{index + 1} {machine.id}</span>
                          <span className={`rounded-full border px-1.5 py-0.5 text-[9px] font-black ${statusClass(calc.oee)}`}>{pct(calc.oee, 1)}</span>
                        </div>
                        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${barClass(calc.oee)}`} style={{ width: `${clamp(calc.oee, 0, 100)}%` }} /></div>
                        <p className="mt-1 truncate text-[10px] text-slate-500">A {pct(calc.availability, 0)} | P {pct(calc.performance, 0)} | Q {pct(calc.quality, 0)} | {machine.status}</p>
                      </button>
                    ))}
                  </div>
                </Panel>
              </div>
            )}

            {tab === "detail" && (
              <div className="space-y-2">
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                  <Stat label={selectedMachine.id} value={selectedMachine.name} note={`${selectedMachine.operator} | ${selectedMachine.status}`} />
                  <Stat label="Output" value={`${num(selectedMachine.totalProduced)} unit`} note={`good ${num(selectedMachine.goodProduced)} | reject ${num(selectedMachine.rejectProduced)}`} />
                  <Stat label="Downtime" value={`${num(selectedMachine.unplannedDowntime, 1)} mnt`} note={`micro ${num(selectedMachine.microStopMinutes, 1)} mnt`} />
                  <Stat label="Weakest" value={selectedCalc.weakest.key} note={selectedCalc.weakest.problem} />
                </div>
                <div className="grid gap-2 lg:grid-cols-4">
                  <BigMetric label="Availability" value={selectedCalc.availability} helper="OT ÷ LT" />
                  <BigMetric label="Performance" value={selectedCalc.performance} helper={`raw ${pct(selectedCalc.performanceRaw)}`} />
                  <BigMetric label="Quality" value={selectedCalc.quality} helper="Good ÷ Total" />
                  <BigMetric label="OEE" value={selectedCalc.oee} helper="A × P × Q" />
                </div>
                <Panel title="Analisis Mesin Terpilih">
                  <p className="text-[11px] leading-5 text-slate-600">
                    Mesin {selectedMachine.id} memiliki OEE {pct(selectedCalc.oee)}. Komponen pembatas utama adalah <b>{selectedCalc.weakest.key}</b> dengan nilai {pct(selectedCalc.weakest.value)}. Rekomendasi: {selectedCalc.weakest.action}
                  </p>
                </Panel>
              </div>
            )}

            {tab === "gantt" && (
              <div className="space-y-2">
                <Panel title="Gantt Line 14 Mesin: Awal Sampai Selesai Shift">
                  <div className="flex justify-between text-[10px] font-bold text-slate-500"><span>{clock(0)}</span><span>Planned stop {clock(plannedWindow.start)}-{clock(plannedWindow.end)}</span><span>{clock(settings.shiftDuration)}</span></div>
                  <div className="mt-1 space-y-1">
                    {machines.map((machine) => (
                      <FleetGanttRow key={machine.id} machine={machine} settings={settings} selected={machine.id === selectedId} onClick={() => setSelectedId(machine.id)} />
                    ))}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1 text-[10px] font-bold text-slate-600">
                    <Legend color="bg-emerald-500" label="Running" />
                    <Legend color="bg-red-500" label="Downtime" />
                    <Legend color="bg-sky-500" label="Planned Stop" />
                  </div>
                </Panel>

                <Panel title={`Gantt Detail ${selectedMachine.id} + Output per Tick`}>
                  <MachineGantt machine={selectedMachine} settings={settings} plannedWindow={plannedWindow} />
                </Panel>
              </div>
            )}

            {tab === "rumus" && (
              <Panel title="Rumus OEE Agregat 14 Mesin">
                <div className="overflow-x-auto">
                  <table className="min-w-full text-[11px]">
                    <thead><tr className="border-b border-slate-200 bg-slate-50 text-left text-[10px] uppercase tracking-wide text-slate-500"><th className="px-2 py-1.5">Variabel</th><th className="px-2 py-1.5">Definisi</th><th className="px-2 py-1.5">Rumus</th><th className="px-2 py-1.5 text-right">Hasil Line</th></tr></thead>
                    <tbody className="divide-y divide-slate-100">
                      {formulaRows.map(([name, desc, formula, result]) => (
                        <tr key={name} className="hover:bg-slate-50"><td className="px-2 py-1.5 font-black text-slate-900">{name}</td><td className="px-2 py-1.5 text-slate-600">{desc}</td><td className="px-2 py-1.5 font-mono text-[10px] text-slate-700">{formula}</td><td className="px-2 py-1.5 text-right font-black text-slate-950">{result}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Panel>
            )}

            {tab === "decision" && (
              <div className="space-y-2">
                <div className="grid gap-2 xl:grid-cols-[1.1fr_0.9fr]">
                  <Panel title="Pareto Downtime & Reject Hotspot Line">
                    <div className="grid gap-2 lg:grid-cols-2">
                      <div>
                        <h3 className="mb-1 text-[11px] font-black text-slate-800">Pareto Unplanned Downtime</h3>
                        <div className="space-y-1">
                          {fleetDecision.paretoDowntime.length === 0 ? <EmptyMini text="Belum ada downtime." /> : fleetDecision.paretoDowntime.slice(0, 7).map((item) => <CompactBar key={item.cause} label={item.cause} value={item.minutes} max={Math.max(...fleetDecision.paretoDowntime.map((x) => x.minutes), 1)} suffix="mnt" color="bg-red-500" />)}
                        </div>
                      </div>
                      <div>
                        <h3 className="mb-1 text-[11px] font-black text-slate-800">Reject Hotspot</h3>
                        <div className="space-y-1">
                          {fleetDecision.rejectHotspot.length === 0 ? <EmptyMini text="Belum ada reject." /> : fleetDecision.rejectHotspot.map((item) => <CompactBar key={`${item.machineId}-${item.time}`} label={`${item.machineId} | ${item.time} | ${item.cause}`} value={item.reject} max={Math.max(...fleetDecision.rejectHotspot.map((x) => x.reject), 1)} suffix="unit" color="bg-violet-500" />)}
                        </div>
                      </div>
                    </div>
                  </Panel>

                  <Panel title="Alarm Produksi Otomatis">
                    <div className="space-y-1">
                      {fleetDecision.alarms.length === 0 ? <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-2 text-[11px] font-bold text-emerald-700">Tidak ada alarm kritis.</div> : fleetDecision.alarms.map((alarm) => <div key={alarm} className="rounded-lg border border-amber-200 bg-amber-50 p-2 text-[11px] font-bold leading-5 text-amber-800">⚠ {alarm}</div>)}
                    </div>
                  </Panel>
                </div>

                <div className="grid gap-2 xl:grid-cols-[0.9fr_1.1fr]">
                  <Panel title="What-if Improvement 14 Mesin">
                    <div className="grid gap-2 lg:grid-cols-3">
                      <TinyRange label="Kurangi Downtime" name="downtimeReduction" value={whatIf.downtimeReduction} onChange={updateWhatIf} suffix="%" max="90" />
                      <TinyRange label="Kurangi Speed Loss" name="speedLossReduction" value={whatIf.speedLossReduction} onChange={updateWhatIf} suffix="%" max="90" />
                      <TinyRange label="Kurangi Reject" name="rejectReduction" value={whatIf.rejectReduction} onChange={updateWhatIf} suffix="%" max="90" />
                    </div>
                    <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                      <Stat label="Pred OEE" value={pct(fleetDecision.predicted.oee)} note={`naik ${pct(fleetDecision.predicted.oee - fleetCalc.oee)}`} />
                      <Stat label="Pred Good" value={`${num(fleetDecision.predicted.good)} unit`} note={`aktual ${num(machines.reduce((s, m) => s + m.goodProduced, 0))}`} />
                      <Stat label="Pred Reject" value={`${num(fleetDecision.predicted.reject)} unit`} note={`aktual ${num(machines.reduce((s, m) => s + m.rejectProduced, 0))}`} />
                      <Stat label="Potensi Gain" value={rupiah(fleetDecision.predicted.gain)} note="berbasis profit per good unit" />
                    </div>
                  </Panel>

                  <Panel title="Estimasi Biaya Kerugian Line">
                    <div className="grid grid-cols-3 gap-1.5">
                      <TinyNumber label="Cost Mesin/Jam" name="machineHourCost" value={settings.machineHourCost} onChange={updateSetting} unit="Rp" />
                      <TinyNumber label="Cost Reject" name="rejectCost" value={settings.rejectCost} onChange={updateSetting} unit="Rp" />
                      <TinyNumber label="Profit/Good" name="profitPerGood" value={settings.profitPerGood} onChange={updateSetting} unit="Rp" />
                    </div>
                    <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                      <Stat label="Downtime Cost" value={rupiah(fleetDecision.cost.downtimeCost)} note="UDT × cost mesin/jam" />
                      <Stat label="Reject Cost" value={rupiah(fleetDecision.cost.rejectCost)} note="reject × cost reject" />
                      <Stat label="Opportunity" value={rupiah(fleetDecision.cost.opportunityCost)} note="gap output × profit" />
                      <Stat label="Total Loss" value={rupiah(fleetDecision.cost.totalCost)} note="estimasi kerugian line" />
                    </div>
                  </Panel>
                </div>
              </div>
            )}

            {tab === "analisis" && (
              <div className="space-y-2">
                <Panel title="Analisis Akademik Line 14 Mesin">
                  <p className="text-[11px] leading-5 text-slate-600">{academicText}</p>
                </Panel>
                <div className="grid gap-2 lg:grid-cols-3">
                  <Panel title="Implikasi Operasional"><p className="text-[11px] leading-5 text-slate-600">Ranking mesin menunjukkan prioritas tindakan. Mesin dengan OEE paling rendah perlu dianalisis melalui log downtime, reject hotspot, dan parameter proses. Perbaikan harus diarahkan pada komponen dominan, bukan sekadar menaikkan output.</p></Panel>
                  <Panel title="Implikasi Manajerial"><p className="text-[11px] leading-5 text-slate-600">Line 14 mesin membutuhkan dashboard agregat dan individual. Keputusan maintenance, inspeksi kualitas, dan penjadwalan operator dapat berbasis OEE tiap mesin, bukan rata-rata line semata.</p></Panel>
                  <Panel title="Six Big Losses"><div className="space-y-1">{sixLosses.map(([loss, meaning, comp]) => <div key={loss} className="rounded-lg bg-slate-50 p-1.5 text-[10px] leading-4"><b>{loss}</b> ({comp}) — {meaning}</div>)}</div></Panel>
                </div>
              </div>
            )}

            {tab === "log" && (
              <Panel title={`Event Log ${selectedMachine.id}`}>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-[10px]">
                    <thead><tr className="border-b border-slate-200 bg-slate-50 text-left uppercase tracking-wide text-slate-500"><th className="px-1.5 py-1.5">Waktu</th><th className="px-1.5 py-1.5">Status</th><th className="px-1.5 py-1.5 text-right">Out</th><th className="px-1.5 py-1.5 text-right">Good</th><th className="px-1.5 py-1.5 text-right">Reject</th><th className="px-1.5 py-1.5 text-right">PDT</th><th className="px-1.5 py-1.5 text-right">UDT</th><th className="px-1.5 py-1.5 text-right">Micro</th><th className="px-1.5 py-1.5">Penyebab</th></tr></thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedMachine.logs.length === 0 ? <tr><td colSpan="9" className="py-6 text-center text-xs font-bold text-slate-400">Belum ada log.</td></tr> : selectedMachine.logs.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50"><td className="px-1.5 py-1.5 font-black text-slate-900">{clock(item.start)}-{clock(item.end)}</td><td className="px-1.5 py-1.5"><span className={`rounded-full border px-1.5 py-0.5 font-black ${eventClass(item.status)}`}>{item.status}</span></td><td className="px-1.5 py-1.5 text-right font-bold">{item.produced}</td><td className="px-1.5 py-1.5 text-right">{item.good}</td><td className="px-1.5 py-1.5 text-right">{item.reject}</td><td className="px-1.5 py-1.5 text-right">{num(item.plannedStop, 1)}</td><td className="px-1.5 py-1.5 text-right">{num(item.unplanned, 1)}</td><td className="px-1.5 py-1.5 text-right">{num(item.microStop, 1)}</td><td className="px-1.5 py-1.5 text-slate-600">{item.cause}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Panel>
            )}
          </section>
        </div>
      </section>
    </main>
  );
}

function Panel({ title, children }) {
  return <div className="rounded-xl border border-slate-200 bg-white p-2 shadow-sm"><h2 className="mb-1.5 text-xs font-black uppercase tracking-wide text-slate-800">{title}</h2>{children}</div>;
}

function Tab({ active, onClick, children }) {
  return <button onClick={onClick} className={active ? "rounded-lg bg-slate-950 px-2.5 py-1.5 text-xs font-black text-white" : "rounded-lg px-2.5 py-1.5 text-xs font-black text-slate-600 hover:bg-slate-100"}>{children}</button>;
}

function MiniDark({ label, value }) {
  return <div className="rounded-lg border border-white/10 bg-white/10 p-2"><p className="text-[9px] font-bold uppercase tracking-wide text-slate-400">{label}</p><p className="mt-0.5 truncate text-sm font-black text-white">{value}</p></div>;
}

function Stat({ label, value, note }) {
  return <div className="rounded-xl border border-slate-200 bg-white p-2 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">{label}</p><h3 className="mt-0.5 truncate text-lg font-black text-slate-950">{value}</h3><p className="mt-0.5 text-[11px] leading-4 text-slate-500">{note}</p></div>;
}

function BigMetric({ label, value, helper }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-2 shadow-sm">
      <div className="flex items-center justify-between gap-2"><p className="text-[10px] font-black uppercase tracking-wide text-slate-500">{label}</p><span className={`rounded-full border px-1.5 py-0.5 text-[9px] font-black ${statusClass(value)}`}>{value >= 85 ? "BAIK" : value >= 70 ? "CUKUP" : "RENDAH"}</span></div>
      <h3 className="mt-1 text-xl font-black text-slate-950">{pct(value)}</h3>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${barClass(value)}`} style={{ width: `${clamp(value, 0, 100)}%` }} /></div>
      <p className="mt-1 text-[10px] text-slate-500">{helper}</p>
    </div>
  );
}

function TinyInput({ label, ...props }) {
  return <div><label className="mb-0.5 block text-[10px] font-bold text-slate-500">{label}</label><input {...props} className="h-8 w-full rounded-lg border border-slate-200 bg-white px-2 text-xs outline-none focus:border-cyan-500" /></div>;
}

function TinyNumber({ label, unit, step = "1", ...props }) {
  return <div><label className="mb-0.5 block text-[10px] font-bold text-slate-500">{label}</label><div className="relative"><input type="number" min="0" step={step} {...props} className="h-8 w-full rounded-lg border border-slate-200 bg-white px-2 pr-10 text-xs outline-none focus:border-cyan-500" /><span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-400">{unit}</span></div></div>;
}

function TinyRange({ label, value, onChange, suffix, max = "40", name }) {
  return <div><div className="flex justify-between gap-2 text-[10px] font-bold text-slate-500"><span>{label}</span><span>{num(Number(value), 1)} {suffix}</span></div><input type="range" min="0" max={max} step="0.5" name={name} value={value} onChange={onChange} className="h-3 w-full accent-cyan-600" /></div>;
}

function ScenarioButton({ children, onClick }) {
  return <button onClick={onClick} className="rounded-lg border border-slate-200 bg-slate-50 px-1.5 py-1 text-[10px] font-black text-slate-700 hover:bg-slate-100">{children}</button>;
}

function Legend({ color, label }) {
  return <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-white px-2 py-0.5"><span className={`h-2 w-2 rounded-full ${color}`} />{label}</span>;
}

function EmptyMini({ text }) {
  return <div className="rounded-lg border border-slate-200 bg-slate-50 p-2 text-[11px] font-bold text-slate-400">{text}</div>;
}

function CompactBar({ label, value, max, suffix, color }) {
  const width = Math.max(2, (Number(value || 0) / Number(max || 1)) * 100);
  return <div className="rounded-lg border border-slate-200 bg-white p-1.5"><div className="flex items-center justify-between gap-2 text-[10px]"><span className="truncate font-bold text-slate-700" title={label}>{label}</span><span className="shrink-0 font-black text-slate-950">{num(value, 1)} {suffix}</span></div><div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${color}`} style={{ width: `${width}%` }} /></div></div>;
}

function FleetGanttRow({ machine, settings, selected, onClick }) {
  const calc = calcMachine(machine, settings);
  return (
    <button onClick={onClick} className={selected ? "grid w-full grid-cols-[58px_1fr_58px] items-center gap-1 rounded-lg border border-cyan-300 bg-cyan-50 p-1" : "grid w-full grid-cols-[58px_1fr_58px] items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 hover:bg-slate-50"}>
      <span className="text-left text-[10px] font-black text-slate-700">{machine.id}</span>
      <div className="relative h-4 rounded bg-slate-100">
        {machine.logs.slice().reverse().map((item) => {
          const left = (item.start / Number(settings.shiftDuration || 1)) * 100;
          const width = Math.max(0.35, ((item.end - item.start) / Number(settings.shiftDuration || 1)) * 100);
          const color = item.status === "DOWNTIME" ? "bg-red-500" : item.status === "PLANNED STOP" ? "bg-sky-500" : "bg-emerald-500";
          return <div key={`fg-${item.id}`} className={`absolute top-1 h-2 rounded ${color}`} style={{ left: `${left}%`, width: `${width}%` }} title={`${machine.id} | ${clock(item.start)}-${clock(item.end)} | ${item.status} | ${item.cause}`} />;
        })}
      </div>
      <span className={`rounded-full border px-1 py-0.5 text-[9px] font-black ${statusClass(calc.oee)}`}>{pct(calc.oee, 0)}</span>
    </button>
  );
}

function MachineGantt({ machine, settings, plannedWindow }) {
  const logs = machine.logs.slice().reverse();
  const maxOutput = Math.max(1, ...logs.map((x) => x.produced));
  return (
    <div className="rounded-lg border border-slate-200 bg-slate-50 p-2">
      <div className="relative h-5 rounded bg-white">
        <div className="absolute top-0 h-full rounded bg-sky-100" style={{ left: `${(plannedWindow.start / Number(settings.shiftDuration || 1)) * 100}%`, width: `${(Number(settings.plannedDowntime || 0) / Number(settings.shiftDuration || 1)) * 100}%` }} />
        <div className="absolute inset-0 flex justify-between px-1 text-[9px] font-bold text-slate-400"><span>0%</span><span>25%</span><span>50%</span><span>75%</span><span>100%</span></div>
      </div>
      <GanttRow label="RUN" settings={settings} data={logs.filter((item) => item.status === "RUNNING")} color="bg-emerald-500" />
      <GanttRow label="DOWN" settings={settings} data={logs.filter((item) => item.status === "DOWNTIME")} color="bg-red-500" />
      <GanttRow label="PLAN" settings={settings} data={logs.filter((item) => item.status === "PLANNED STOP")} color="bg-sky-500" />
      <div className="mt-1 grid grid-cols-[44px_1fr] items-end gap-1">
        <div className="text-[9px] font-black text-slate-500">OUTPUT</div>
        <div className="relative flex h-16 items-end gap-[1px] rounded bg-white px-1 py-1">
          {logs.length === 0 ? <div className="flex h-full w-full items-center justify-center text-[10px] font-bold text-slate-400">Belum ada data.</div> : logs.map((item) => <div key={`out-${item.id}`} className="flex h-full flex-1 items-end"><div className={item.status === "DOWNTIME" ? "w-full rounded-t bg-red-300" : item.status === "PLANNED STOP" ? "w-full rounded-t bg-sky-300" : "w-full rounded-t bg-cyan-500"} style={{ height: `${Math.max(3, (item.produced / maxOutput) * 100)}%` }} title={`${clock(item.start)}-${clock(item.end)} | Output ${item.produced}`} /></div>)}
        </div>
      </div>
      <div className="mt-1 grid grid-cols-[44px_1fr] gap-1 text-[9px] font-bold text-slate-400"><span /><div className="flex justify-between"><span>{clock(0)}</span><span>{clock(settings.shiftDuration * 0.25)}</span><span>{clock(settings.shiftDuration * 0.5)}</span><span>{clock(settings.shiftDuration * 0.75)}</span><span>{clock(settings.shiftDuration)}</span></div></div>
    </div>
  );
}

function GanttRow({ label, settings, data, color }) {
  return (
    <div className="mt-1 grid grid-cols-[44px_1fr] items-center gap-1">
      <div className="text-[9px] font-black text-slate-500">{label}</div>
      <div className="relative h-5 rounded bg-white">
        {data.length === 0 ? <div className="absolute inset-0 flex items-center px-1 text-[9px] font-bold text-slate-300">-</div> : data.map((item) => {
          const left = (item.start / Number(settings.shiftDuration || 1)) * 100;
          const width = Math.max(0.45, ((item.end - item.start) / Number(settings.shiftDuration || 1)) * 100);
          return <div key={`gantt-${label}-${item.id}`} className={`absolute top-1 h-3 rounded ${color}`} style={{ left: `${left}%`, width: `${width}%` }} title={`${clock(item.start)}-${clock(item.end)} | ${item.status} | output ${item.produced} | ${item.cause}`} />;
        })}
      </div>
    </div>
  );
}
