import React, { useMemo, useState } from "react";
import commonRailLayout from "./common-rail-9-layout.png";

const MACHINES = [
  { no: 1, process: "OP10-1", code: "IMC-45", mt: 158 },
  { no: 2, process: "OP10-2", code: "IMC-229", mt: 157 },
  { no: 3, process: "OP-20", code: "IDH-23", mt: 299 },
  { no: 4, process: "OP30-1", code: "IMC-251", mt: 270 },
  { no: 5, process: "OP30-1", code: "IMC-61", mt: 265 },
  { no: 6, process: "OP70", code: "IMC-94", mt: 314 },
  { no: 7, process: "OP70", code: "IMC-103", mt: 329 },
  { no: 8, process: "OP80-1", code: "IMC-19", mt: 974 },
  { no: 9, process: "OP80-1", code: "IMC-20", mt: 892 },
  { no: 10, process: "OP80-3", code: "IMC-21", mt: 913 },
  { no: 11, process: "OP80-4", code: "IMC-29", mt: 1012 },
  { no: 12, process: "OP80-5", code: "IMC-40", mt: 865 },
  { no: 13, process: "OP80-6", code: "IMC-28", mt: 917 },
  { no: 14, process: "OP80-7", code: "IMC-10", mt: 77 },
  { no: 15, process: "OP90", code: "IPO-6", mt: null },
  { no: 16, process: "OP100", code: "ISC-11", mt: null },
  { no: 17, process: "OP110", code: "ISC-4", mt: null },
  { no: 18, process: "OP120", code: "IAM-13", mt: null },
];

// Posisi marker berdasarkan layout Common Rail-9 yang diberikan pengguna.
// Nilai x/y menggunakan persentase terhadap ukuran gambar agar tetap responsif.
const MACHINE_LAYOUT_POSITIONS = {
  "IMC-21": { x: 8.4, y: 31.0 },
  "IMC-20": { x: 18.2, y: 31.0 },
  "IMC-19": { x: 28.0, y: 31.0 },
  "IMC-103": { x: 39.1, y: 31.0 },
  "IMC-94": { x: 50.2, y: 31.0 },
  "IMC-61": { x: 61.6, y: 31.0 },
  "IMC-251": { x: 72.7, y: 31.0 },
  "IDH-23": { x: 85.0, y: 31.0 },
  "IMC-29": { x: 8.4, y: 69.5 },
  "IMC-40": { x: 18.4, y: 69.5 },
  "IMC-28": { x: 28.2, y: 69.5 },
  "IMC-10": { x: 39.0, y: 69.5 },
  "IPO-6": { x: 46.0, y: 66.5 },
  "ISC-11": { x: 49.9, y: 81.0 },
  "ISC-4": { x: 54.0, y: 81.0 },
  "IAM-13": { x: 59.2, y: 69.3 },
  "IMC-45": { x: 76.4, y: 70.2 },
  "IMC-229": { x: 89.0, y: 70.2 },
};

const SHIFT_CONFIG = {
  shift1: {
    label: "Shift 1",
    short: "S1",
    startHour: 7,
    startMinute: 10,
    endHour: 19,
    endMinute: 50,
    duration: 12 * 60 + 40, // 07:10 -> 19:50 = 760 menit
  },
  shift2: {
    label: "Shift 2",
    short: "S2",
    startHour: 19,
    startMinute: 50,
    endHour: 7,
    endMinute: 10,
    duration: 11 * 60 + 20, // 19:50 -> 07:10 hari berikutnya = 680 menit
  },
};

const STATUS = {
  process: {
    label: "Process / Running",
    color: "#22c55e",
    badge: "bg-emerald-100 text-emerald-700 ring-emerald-200",
  },
  trouble: {
    label: "Machine Trouble",
    color: "#ef4444",
    badge: "bg-red-100 text-red-700 ring-red-200",
  },
  idle: {
    label: "Idle / No Process",
    color: "#facc15",
    badge: "bg-amber-100 text-amber-800 ring-amber-200",
  },
};

function pad2(value) {
  return String(value).padStart(2, "0");
}

function toLocalDateInputValue(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function hashString(input) {
  let hash = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function mulberry32(seed) {
  let t = seed >>> 0;
  return function random() {
    t += 0x6d2b79f5;
    let r = t;
    r = Math.imul(r ^ (r >>> 15), r | 1);
    r ^= r + Math.imul(r ^ (r >>> 7), r | 61);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function pickStatus(random, previousStatus) {
  const roll = random();
  let status;

  if (roll < 0.67) status = "process";
  else if (roll < 0.92) status = "idle";
  else status = "trouble";

  if (status === previousStatus && random() < 0.68) {
    const alternatives = ["process", "idle", "trouble"].filter(
      (item) => item !== previousStatus
    );
    status = alternatives[Math.floor(random() * alternatives.length)];
  }

  return status;
}

function generateShiftSegments(machineCode, dayKey, shiftKey) {
  const shift = SHIFT_CONFIG[shiftKey];
  const random = mulberry32(hashString(`${machineCode}-${dayKey}-${shiftKey}`));
  const segments = [];
  let cursor = 0;
  let previousStatus = null;

  while (cursor < shift.duration) {
    const status = pickStatus(random, previousStatus);

    let minLength = 24;
    let maxLength = 120;

    if (status === "trouble") {
      minLength = 10;
      maxLength = 60;
    } else if (status === "process") {
      minLength = 35;
      maxLength = 150;
    }

    const proposed = Math.round(minLength + random() * (maxLength - minLength));
    const duration = Math.min(proposed, shift.duration - cursor);

    if (duration < 8 && segments.length > 0) {
      segments[segments.length - 1].duration += duration;
      segments[segments.length - 1].end += duration;
      cursor += duration;
      break;
    }

    segments.push({
      status,
      start: cursor,
      end: cursor + duration,
      duration,
    });

    previousStatus = status;
    cursor += duration;
  }

  return segments;
}

function buildGradient(segments, totalDuration) {
  const stops = [];

  segments.forEach((segment) => {
    const startPct = (segment.start / totalDuration) * 100;
    const endPct = (segment.end / totalDuration) * 100;
    const color = STATUS[segment.status].color;
    stops.push(`${color} ${startPct}%`, `${color} ${endPct}%`);
  });

  return `linear-gradient(to right, ${stops.join(", ")})`;
}

function getStatusDuration(segments, status) {
  return segments
    .filter((segment) => segment.status === status)
    .reduce((total, segment) => total + segment.duration, 0);
}

function aggregateSegments(segments, accumulator) {
  segments.forEach((segment) => {
    accumulator[segment.status] += segment.duration;
  });
}

function formatHours(minutes) {
  return `${(minutes / 60).toFixed(1)} h`;
}

function formatPercent(value) {
  return `${value.toFixed(1)}%`;
}

function parseSelectedDate(selectedDate) {
  const [year, month, day] = selectedDate.split("-").map(Number);
  return { year, monthIndex: month - 1, day };
}

function createDateAtShiftStart(selectedDate, shiftKey) {
  const { year, monthIndex, day } = parseSelectedDate(selectedDate);
  const shift = SHIFT_CONFIG[shiftKey];

  return new Date(
    year,
    monthIndex,
    day,
    shift.startHour,
    shift.startMinute,
    0,
    0
  );
}

function addMinutes(date, minutes) {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

function formatClock(date) {
  return `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
}

function getHourlyTicks(shiftKey) {
  const shift = SHIFT_CONFIG[shiftKey];
  const baseDate = new Date(2026, 0, 1, shift.startHour, shift.startMinute, 0, 0);
  const endDate = addMinutes(baseDate, shift.duration);
  const ticks = [
    { offset: 0, label: formatClock(baseDate), boundary: true },
  ];

  const cursor = new Date(baseDate);
  cursor.setMinutes(0, 0, 0);
  cursor.setHours(cursor.getHours() + 1);

  while (cursor < endDate) {
    const offset = Math.round((cursor.getTime() - baseDate.getTime()) / 60000);
    ticks.push({
      offset,
      label: formatClock(cursor),
      boundary: false,
    });
    cursor.setHours(cursor.getHours() + 1);
  }

  ticks.push({
    offset: shift.duration,
    label: formatClock(endDate),
    boundary: true,
  });

  return ticks;
}

function formatDateTime(date) {
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(date);
}

function formatSelectedDate(selectedDate) {
  const { year, monthIndex, day } = parseSelectedDate(selectedDate);
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(new Date(year, monthIndex, day));
}

function formatShiftClock(shiftKey, offsetMinutes) {
  const shift = SHIFT_CONFIG[shiftKey];
  const totalMinutes = shift.startHour * 60 + shift.startMinute + offsetMinutes;
  const normalized = ((totalMinutes % (24 * 60)) + 24 * 60) % (24 * 60);
  const hour = Math.floor(normalized / 60);
  const minute = normalized % 60;
  return `${pad2(hour)}:${pad2(minute)}`;
}

function getDominantStatus(summary) {
  if (!summary) return "idle";
  return [
    ["process", summary.process],
    ["idle", summary.idle],
    ["trouble", summary.trouble],
  ].sort((a, b) => b[1] - a[1])[0][0];
}

export default function RunningMachine() {
  const [selectedDate, setSelectedDate] = useState(() =>
    toLocalDateInputValue(new Date())
  );
  const [timelineZoom, setTimelineZoom] = useState("normal");
  const [selectedMachineCode, setSelectedMachineCode] = useState(null);

  const timelineWidth = { compact: 420, normal: 560, detail: 760 }[timelineZoom];
  const timelineGrid = `56px 125px 120px 72px minmax(${timelineWidth}px, 1fr) minmax(${timelineWidth}px, 1fr)`;
  const timelineMinWidth = 56 + 125 + 120 + 72 + timelineWidth * 2;

  const simulation = useMemo(() => {
    const data = {};

    MACHINES.forEach((machine) => {
      data[machine.code] = {
        shift1: generateShiftSegments(machine.code, selectedDate, "shift1"),
        shift2: generateShiftSegments(machine.code, selectedDate, "shift2"),
      };
    });

    return data;
  }, [selectedDate]);

  const machineSummary = useMemo(() => {
    const result = {};

    MACHINES.forEach((machine) => {
      const totals = { process: 0, trouble: 0, idle: 0 };
      aggregateSegments(simulation[machine.code].shift1, totals);
      aggregateSegments(simulation[machine.code].shift2, totals);

      const totalMinutes = totals.process + totals.trouble + totals.idle;

      result[machine.code] = {
        ...totals,
        totalMinutes,
      };
    });

    return result;
  }, [simulation]);

  const overallSummary = useMemo(() => {
    const totals = { process: 0, trouble: 0, idle: 0 };

    MACHINES.forEach((machine) => {
      const summary = machineSummary[machine.code];
      totals.process += summary.process;
      totals.trouble += summary.trouble;
      totals.idle += summary.idle;
    });

    const totalMinutes = totals.process + totals.trouble + totals.idle;

    return {
      ...totals,
      totalMinutes,
    };
  }, [machineSummary]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <div className="mx-auto max-w-[1900px] p-2 md:p-3">
        <header className="mb-2 border border-slate-300 bg-white p-2 md:p-3">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-blue-600">
                CNC Production Monitoring
              </p>
              <h1 className="mt-1 text-2xl font-bold tracking-tight text-slate-900 md:text-3xl">
                Daily Running Machine Timeline
              </h1>
              <p className="mt-1 text-sm text-slate-500">
                Monitoring seluruh mesin berdasarkan tanggal, Shift 1 dan Shift 2.
              </p>
            </div>

            <label className="w-full sm:w-[280px]">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Pilih tanggal
              </span>
              <div className="flex w-full min-w-0 rounded-xl border border-slate-300 bg-white px-3 py-2 shadow-sm transition focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100">
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(event) => {
                    setSelectedDate(event.target.value);
                  }}
                  className="block w-full min-w-0 border-0 bg-transparent p-0 text-sm font-semibold text-slate-800 outline-none"
                />
              </div>
            </label>
          </div>
        </header>

        <div>
          <main className="min-w-0 space-y-2">
            <section className="grid gap-0 border border-slate-300 sm:grid-cols-3">
              <SummaryCard
                label="Running / Process"
                value={formatHours(overallSummary.process)}
                subValue={formatPercent(
                  overallSummary.totalMinutes
                    ? (overallSummary.process / overallSummary.totalMinutes) * 100
                    : 0
                )}
                dotClass="bg-green-500"
              />
              <SummaryCard
                label="Machine Trouble"
                value={formatHours(overallSummary.trouble)}
                subValue={formatPercent(
                  overallSummary.totalMinutes
                    ? (overallSummary.trouble / overallSummary.totalMinutes) * 100
                    : 0
                )}
                dotClass="bg-red-500"
              />
              <SummaryCard
                label="Idle / No Process"
                value={formatHours(overallSummary.idle)}
                subValue={formatPercent(
                  overallSummary.totalMinutes
                    ? (overallSummary.idle / overallSummary.totalMinutes) * 100
                    : 0
                )}
                dotClass="bg-yellow-400"
              />
            </section>

            <section className="border border-slate-300 bg-white">
              <div className="border-b border-slate-300 px-2 py-2">
                <div className="flex flex-col gap-1 xl:flex-row xl:items-center xl:justify-between">
                  <div>
                    <p className="text-sm font-bold text-slate-900">
                      {formatSelectedDate(selectedDate)}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      Shift 1: 07:10–19:50 · Shift 2: 19:50–07:10 hari berikutnya
                    </p>
                    <p className="mt-0.5 text-[11px] text-slate-400">
                      Arahkan pointer ke warna untuk melihat status, jam mulai–selesai, dan durasi.
                    </p>
                  </div>

                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                    <div className="flex flex-wrap gap-x-2 gap-y-0.5 text-xs text-slate-600">
                      <Legend colorClass="bg-green-500" label="Process / Running" />
                      <Legend colorClass="bg-red-500" label="Machine Trouble" />
                      <Legend colorClass="bg-yellow-400" label="Idle / No Process" />
                    </div>

                    <div className="flex items-center gap-0 border border-slate-300 bg-slate-50 p-0">
                      <span className="px-2 text-[10px] font-bold uppercase tracking-wide text-slate-400">Zoom</span>
                      {[
                        ["compact", "Ringkas"],
                        ["normal", "Normal"],
                        ["detail", "Detail"],
                      ].map(([value, label]) => (
                        <button
                          key={value}
                          type="button"
                          onClick={() => setTimelineZoom(value)}
                          className={`border-l border-slate-200 px-2 py-1 text-[10px] font-semibold transition ${
                            timelineZoom === value
                              ? "bg-white text-blue-700"
                              : "text-slate-500 hover:bg-white hover:text-slate-800"
                          }`}
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <div style={{ minWidth: `${timelineMinWidth}px` }}>
                  <div
                    className="grid border-b border-slate-300 bg-slate-100 text-xs font-semibold text-slate-600"
                    style={{ gridTemplateColumns: timelineGrid }}
                  >
                    <div className="sticky left-0 z-30 border-r border-slate-300 bg-slate-100 px-1 py-1.5 text-center">No.</div>
                    <div
                      className="sticky z-30 border-r border-slate-300 bg-slate-100 px-1 py-1.5"
                      style={{ left: 56 }}
                    >
                      Proses
                    </div>
                    <div
                      className="sticky z-30 border-r border-slate-300 bg-slate-100 px-1 py-1.5"
                      style={{ left: 181 }}
                    >
                      Machine
                    </div>
                    <div
                      className="sticky z-30 border-r border-slate-300 bg-slate-100 px-1 py-1.5 text-center"
                      style={{ left: 301 }}
                    >
                      MT
                    </div>
                    <div className="px-1 py-1">
                      <TimelineHeader shiftKey="shift1" />
                    </div>
                    <div className="border-l border-slate-300 px-1 py-1">
                      <TimelineHeader shiftKey="shift2" />
                    </div>
                  </div>

                  <div>
                    {MACHINES.map((machine) => {
                      const dayData = simulation[machine.code];

                      return (
                        <div
                          key={machine.code}
                          className={`group grid border-b border-slate-300 last:border-b-0 ${
                            selectedMachineCode === machine.code
                              ? "bg-blue-100/70"
                              : "hover:bg-blue-50/30"
                          }`}
                          style={{ gridTemplateColumns: timelineGrid }}
                        >
                          <div className={`sticky left-0 z-20 flex items-center justify-center border-r border-slate-300 px-1 py-0.5 text-xs font-semibold text-slate-600 ${selectedMachineCode === machine.code ? "bg-blue-100" : "bg-white group-hover:bg-blue-50"}`}>
                            {machine.no}
                          </div>

                          <div
                            className={`sticky z-20 flex items-center border-r border-slate-300 px-1 py-0.5 ${selectedMachineCode === machine.code ? "bg-blue-100" : "bg-white group-hover:bg-blue-50"}`}
                            style={{ left: 56 }}
                          >
                            <span className="text-xs font-semibold text-slate-900">{machine.process}</span>
                          </div>

                          <div
                            className={`sticky z-20 flex items-center border-r border-slate-300 px-1 py-0.5 ${selectedMachineCode === machine.code ? "bg-blue-100" : "bg-white group-hover:bg-blue-50"}`}
                            style={{ left: 181 }}
                          >
                            <span className="font-mono text-[11px] font-semibold text-blue-600">{machine.code}</span>
                          </div>

                          <div
                            className={`sticky z-20 flex items-center justify-center border-r border-slate-300 px-1 py-0.5 text-xs font-semibold text-slate-700 ${selectedMachineCode === machine.code ? "bg-blue-100" : "bg-white group-hover:bg-blue-50"}`}
                            style={{ left: 301 }}
                          >
                            {machine.mt ?? "-"}
                          </div>

                          <div className="px-0 py-0">
                            <DailyShiftBar
                              segments={dayData.shift1}
                              shiftKey="shift1"
                            />
                          </div>

                          <div className="border-l border-slate-300 px-0 py-0">
                            <DailyShiftBar
                              segments={dayData.shift2}
                              shiftKey="shift2"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </section>

            <FloorLayout
              machineSummary={machineSummary}
              selectedMachineCode={selectedMachineCode}
              onSelectMachine={setSelectedMachineCode}
            />

            <MachineResume
              selectedDate={selectedDate}
              machineSummary={machineSummary}
              overallSummary={overallSummary}
              selectedMachineCode={selectedMachineCode}
              onSelectMachine={setSelectedMachineCode}
            />
          </main>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, subValue, dotClass }) {
  return (
    <div className="border-r border-slate-300 bg-white px-2 py-1.5 last:border-r-0">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
        <span className={`h-2.5 w-2.5 rounded-full ${dotClass}`} />
        {label}
      </div>
      <div className="mt-0.5 flex items-end justify-between gap-2">
        <div className="text-xl font-bold tracking-tight text-slate-900">{value}</div>
        <div className="pb-0.5 text-xs font-semibold text-slate-500">{subValue}</div>
      </div>
    </div>
  );
}

function Legend({ colorClass, label }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={`h-3 w-3 rounded-sm ${colorClass}`} />
      <span>{label}</span>
    </div>
  );
}

function TimelineHeader({ shiftKey }) {
  const shift = SHIFT_CONFIG[shiftKey];
  const ticks = getHourlyTicks(shiftKey);

  return (
    <div>
      <div className="mb-0.5 flex items-center justify-between">
        <span className="font-bold text-slate-700">{shift.label}</span>
        <span className="border border-slate-300 bg-white px-1.5 py-0.5 text-[9px] font-semibold text-slate-500">
          {shiftKey === "shift1" ? "07:10–19:50" : "19:50–07:10"}
        </span>
      </div>

      <div className="relative h-6 border-t border-slate-300">
        {ticks.map((tick, index) => {
          const left = (tick.offset / shift.duration) * 100;
          const isFirst = index === 0;
          const isLast = index === ticks.length - 1;

          return (
            <div
              key={`${shiftKey}-${tick.offset}`}
              className="absolute top-0 h-full"
              style={{ left: `${left}%` }}
            >
              <span
                className={`absolute top-0 h-2 border-l ${
                  tick.boundary ? "border-slate-400" : "border-slate-300"
                }`}
              />
              <span
                className={`absolute top-2 whitespace-nowrap font-mono text-[8px] font-semibold ${
                  tick.boundary ? "text-slate-600" : "text-slate-400"
                } ${
                  isFirst
                    ? "left-0"
                    : isLast
                    ? "right-0 translate-x-0"
                    : "left-0 -translate-x-1/2"
                }`}
              >
                {tick.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function HourGrid({ shiftKey, strong = false }) {
  const shift = SHIFT_CONFIG[shiftKey];
  const ticks = getHourlyTicks(shiftKey);

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      {ticks.map((tick, index) => {
        if (index === 0 || index === ticks.length - 1) return null;
        const left = (tick.offset / shift.duration) * 100;

        return (
          <span
            key={`grid-${shiftKey}-${tick.offset}`}
            className={`absolute inset-y-0 border-l ${
              strong ? "border-white/55" : "border-white/45"
            }`}
            style={{ left: `${left}%` }}
          />
        );
      })}
    </div>
  );
}

function DailyShiftBar({ segments, shiftKey }) {
  const shift = SHIFT_CONFIG[shiftKey];
  const process = getStatusDuration(segments, "process");
  const trouble = getStatusDuration(segments, "trouble");
  const idle = getStatusDuration(segments, "idle");
  const [hoveredSegment, setHoveredSegment] = useState(null);

  return (
    <div className="relative w-full p-0 text-left">
      {hoveredSegment && (
        <div
          className="pointer-events-none absolute z-40 -translate-x-1/2 -translate-y-full rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-2 text-[10px] text-white shadow-xl"
          style={{
            left: `${((hoveredSegment.start + hoveredSegment.duration / 2) / shift.duration) * 100}%`,
            top: 2,
          }}
        >
          <div className="whitespace-nowrap font-bold">{STATUS[hoveredSegment.status].label}</div>
          <div className="mt-0.5 whitespace-nowrap text-slate-300">
            {formatShiftClock(shiftKey, hoveredSegment.start)}–{formatShiftClock(shiftKey, hoveredSegment.end)} · {hoveredSegment.duration} min
          </div>
        </div>
      )}

      <div className="relative h-9 w-full overflow-hidden border-0 bg-slate-100">
        {segments.map((segment, index) => {
          const left = (segment.start / shift.duration) * 100;
          const width = (segment.duration / shift.duration) * 100;

          return (
            <div
              key={`${segment.start}-${segment.end}-${index}`}
              className="absolute inset-y-0 z-[2] transition hover:brightness-95"
              style={{
                left: `${left}%`,
                width: `${width}%`,
                backgroundColor: STATUS[segment.status].color,
              }}
              onMouseEnter={(event) => {
                event.stopPropagation();
                setHoveredSegment(segment);
              }}
              onMouseLeave={() => setHoveredSegment(null)}
              title={`${STATUS[segment.status].label} | ${formatShiftClock(shiftKey, segment.start)}–${formatShiftClock(shiftKey, segment.end)} | ${segment.duration} min`}
            />
          );
        })}
        <HourGrid shiftKey={shiftKey} />
        <div className="pointer-events-none absolute inset-x-0 top-0 z-20 h-px bg-white/70" />
      </div>

      <div className="flex h-4 items-center justify-between border-t border-slate-200 px-1 text-[8px] leading-none text-slate-500">
        <span className="font-semibold text-emerald-700">Run {formatHours(process)}</span>
        <span className="font-semibold text-red-600">Trb {formatHours(trouble)}</span>
        <span className="font-semibold text-amber-700">Idle {formatHours(idle)}</span>
      </div>
    </div>
  );
}

function FloorLayout({ machineSummary, selectedMachineCode, onSelectMachine }) {
  const selectedMachine = MACHINES.find((machine) => machine.code === selectedMachineCode) || null;
  const selectedSummary = selectedMachine ? machineSummary[selectedMachine.code] : null;
  const selectedDominant = selectedSummary ? getDominantStatus(selectedSummary) : null;

  return (
    <section className="border border-slate-300 bg-white">
      <div className="flex flex-col gap-1 border-b border-slate-300 px-2 py-1.5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-sm font-bold text-slate-900">Layout Machine · Common Rail-9</h2>
          <p className="mt-0.5 text-[11px] text-slate-500">
            Klik marker mesin pada layout untuk menyorot machine yang sama di timeline dan resume.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-[10px] font-semibold text-slate-600">
          <Legend colorClass="bg-green-500" label="Running dominan" />
          <Legend colorClass="bg-red-500" label="Trouble dominan" />
          <Legend colorClass="bg-yellow-400" label="Idle dominan" />
          {selectedMachineCode && (
            <button
              type="button"
              onClick={() => onSelectMachine(null)}
              className="border border-slate-300 bg-slate-50 px-2 py-1 text-slate-600 hover:bg-white"
            >
              Hapus pilihan
            </button>
          )}
        </div>
      </div>

      <div className="grid lg:grid-cols-[minmax(0,1fr)_260px]">
        <div className="overflow-x-auto border-b border-slate-300 lg:border-b-0 lg:border-r">
          <div className="relative min-w-[920px] bg-white">
            <img
              src={commonRailLayout}
              alt="Layout Common Rail-9"
              className="block h-auto w-full select-none"
              draggable="false"
            />

            {MACHINES.map((machine) => {
              const position = MACHINE_LAYOUT_POSITIONS[machine.code];
              if (!position) return null;
              const summary = machineSummary[machine.code];
              const dominant = getDominantStatus(summary);
              const isSelected = selectedMachineCode === machine.code;

              return (
                <button
                  key={`layout-${machine.code}`}
                  type="button"
                  onClick={() => onSelectMachine(machine.code)}
                  className={`absolute z-20 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white shadow-md transition hover:z-30 hover:scale-125 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    isSelected ? "h-6 w-6 ring-2 ring-blue-600 ring-offset-1" : "h-4 w-4"
                  }`}
                  style={{
                    left: `${position.x}%`,
                    top: `${position.y}%`,
                    backgroundColor: STATUS[dominant].color,
                  }}
                  title={`${machine.process} · ${machine.code} | MT ${machine.mt ?? "-"} | Dominan: ${STATUS[dominant].label}`}
                  aria-label={`Pilih ${machine.process} ${machine.code}`}
                />
              );
            })}
          </div>
        </div>

        <div className="min-w-0 bg-slate-50">
          <div className="border-b border-slate-300 bg-slate-100 px-2 py-1.5">
            <h3 className="text-xs font-bold text-slate-900">Machine Terpilih</h3>
          </div>

          {selectedMachine && selectedSummary ? (
            <div className="text-[11px]">
              <div className="grid grid-cols-[76px_1fr] border-b border-slate-300">
                <div className="border-r border-slate-300 px-2 py-1 font-semibold text-slate-500">Proses</div>
                <div className="px-2 py-1 font-bold text-slate-900">{selectedMachine.process}</div>
              </div>
              <div className="grid grid-cols-[76px_1fr] border-b border-slate-300">
                <div className="border-r border-slate-300 px-2 py-1 font-semibold text-slate-500">Machine</div>
                <div className="px-2 py-1 font-mono font-bold text-blue-700">{selectedMachine.code}</div>
              </div>
              <div className="grid grid-cols-[76px_1fr] border-b border-slate-300">
                <div className="border-r border-slate-300 px-2 py-1 font-semibold text-slate-500">MT</div>
                <div className="px-2 py-1 font-bold text-slate-800">{selectedMachine.mt ?? "-"}</div>
              </div>
              <div className="grid grid-cols-[76px_1fr] border-b border-slate-300">
                <div className="border-r border-slate-300 px-2 py-1 font-semibold text-slate-500">Dominan</div>
                <div className="px-2 py-1">
                  <span className={`inline-flex px-1.5 py-0.5 text-[9px] font-semibold ${STATUS[selectedDominant].badge}`}>
                    {STATUS[selectedDominant].label}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 border-b border-slate-300 text-center">
                <div className="border-r border-slate-300 px-1 py-2">
                  <div className="text-[9px] font-semibold uppercase text-slate-400">Running</div>
                  <div className="mt-0.5 font-bold text-emerald-700">{formatHours(selectedSummary.process)}</div>
                </div>
                <div className="border-r border-slate-300 px-1 py-2">
                  <div className="text-[9px] font-semibold uppercase text-slate-400">Trouble</div>
                  <div className="mt-0.5 font-bold text-red-600">{formatHours(selectedSummary.trouble)}</div>
                </div>
                <div className="px-1 py-2">
                  <div className="text-[9px] font-semibold uppercase text-slate-400">Idle</div>
                  <div className="mt-0.5 font-bold text-amber-700">{formatHours(selectedSummary.idle)}</div>
                </div>
              </div>

              <div className="px-2 py-2 text-[10px] leading-relaxed text-slate-500">
                Marker warna pada layout memakai <b>status dominan harian</b> agar sesuai dengan rekap tanggal yang sedang dipilih.
              </div>
            </div>
          ) : (
            <div className="px-3 py-8 text-center text-[11px] text-slate-400">
              Klik salah satu marker pada layout untuk melihat resume machine.
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function MachineResume({ selectedDate, machineSummary, overallSummary, selectedMachineCode, onSelectMachine }) {
  return (
    <section className="border border-slate-300 bg-white">
      <div className="flex flex-col gap-1 border-b border-slate-300 px-2 py-1.5 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-sm font-bold text-slate-900">Resume Keseluruhan Machine</h2>
          <p className="mt-0.5 text-[11px] text-slate-500">
            Rekap Running, Machine Trouble, dan Idle seluruh mesin pada {formatSelectedDate(selectedDate)}.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-0 text-[10px] font-semibold">
          <span className="border border-emerald-200 bg-emerald-50 px-2 py-1 text-emerald-700">
            Running {formatHours(overallSummary.process)}
          </span>
          <span className="border-y border-r border-red-200 bg-red-50 px-2 py-1 text-red-700">
            Trouble {formatHours(overallSummary.trouble)}
          </span>
          <span className="border-y border-r border-amber-200 bg-amber-50 px-2 py-1 text-amber-700">
            Idle {formatHours(overallSummary.idle)}
          </span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[860px] border-collapse text-[11px]">
          <thead className="bg-slate-100 text-slate-600">
            <tr>
              <th className="border border-slate-300 px-1 py-1 text-center font-semibold">No.</th>
              <th className="border border-slate-300 px-1 py-1 text-left font-semibold">Proses</th>
              <th className="border border-slate-300 px-1 py-1 text-left font-semibold">Machine</th>
              <th className="border border-slate-300 px-1 py-1 text-center font-semibold">MT</th>
              <th className="border border-slate-300 px-1 py-1 text-right font-semibold">Running</th>
              <th className="border border-slate-300 px-1 py-1 text-right font-semibold">Machine Trouble</th>
              <th className="border border-slate-300 px-1 py-1 text-right font-semibold">Idle</th>
              <th className="border border-slate-300 px-1 py-1 text-center font-semibold">Status Dominan</th>
            </tr>
          </thead>
          <tbody>
            {MACHINES.map((machine) => {
              const summary = machineSummary[machine.code];
              const dominant = getDominantStatus(summary);
              return (
                <tr key={`resume-${machine.code}`} onClick={() => onSelectMachine(machine.code)} className={`${selectedMachineCode === machine.code ? "bg-blue-100" : "hover:bg-slate-50"} cursor-pointer`}>
                  <td className="border border-slate-300 px-1 py-0.5 text-center text-slate-500">{machine.no}</td>
                  <td className="border border-slate-300 px-1 py-0.5 font-semibold text-slate-800">{machine.process}</td>
                  <td className="border border-slate-300 px-1 py-0.5 font-mono font-semibold text-blue-600">{machine.code}</td>
                  <td className="border border-slate-300 px-1 py-0.5 text-center text-slate-600">{machine.mt ?? "-"}</td>
                  <td className="border border-slate-300 px-1 py-0.5 text-right font-semibold text-emerald-700">{formatHours(summary.process)}</td>
                  <td className="border border-slate-300 px-1 py-0.5 text-right font-semibold text-red-600">{formatHours(summary.trouble)}</td>
                  <td className="border border-slate-300 px-1 py-0.5 text-right font-semibold text-amber-700">{formatHours(summary.idle)}</td>
                  <td className="border border-slate-300 px-1 py-0.5 text-center">
                    <span className={`inline-flex px-1.5 py-0.5 text-[9px] font-semibold ${STATUS[dominant].badge}`}>
                      {STATUS[dominant].label}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <OverallStatusPie overallSummary={overallSummary} />
    </section>
  );
}

function OverallStatusPie({ overallSummary }) {
  const total = overallSummary.totalMinutes || 1;
  const runningPct = (overallSummary.process / total) * 100;
  const troublePct = (overallSummary.trouble / total) * 100;
  const idlePct = (overallSummary.idle / total) * 100;
  const runningEnd = runningPct;
  const troubleEnd = runningPct + troublePct;

  const pieBackground = `conic-gradient(
    #22c55e 0% ${runningEnd}%,
    #ef4444 ${runningEnd}% ${troubleEnd}%,
    #facc15 ${troubleEnd}% 100%
  )`;

  return (
    <div className="grid border-t border-slate-300 md:grid-cols-[260px_minmax(0,1fr)]">
      <div className="flex items-center justify-center border-b border-slate-300 p-3 md:border-b-0 md:border-r">
        <div
          className="h-44 w-44 rounded-full border border-slate-300 shadow-inner"
          style={{ background: pieBackground }}
          title={`Running ${formatPercent(runningPct)} | Machine Trouble ${formatPercent(troublePct)} | Idle ${formatPercent(idlePct)}`}
        />
      </div>

      <div className="min-w-0">
        <div className="border-b border-slate-300 bg-slate-100 px-2 py-1.5">
          <h3 className="text-xs font-bold text-slate-900">Pie Chart Status Keseluruhan Machine</h3>
          <p className="mt-0.5 text-[10px] text-slate-500">
            Proporsi total waktu Running, Machine Trouble, dan Idle seluruh machine pada tanggal terpilih.
          </p>
        </div>

        <div className="grid grid-cols-3 border-b border-slate-300 text-[10px]">
          <div className="border-r border-slate-300 px-2 py-2">
            <div className="flex items-center gap-1.5 font-semibold text-slate-600">
              <span className="h-2.5 w-2.5 bg-green-500" /> Running
            </div>
            <div className="mt-1 text-base font-bold text-emerald-700">{formatPercent(runningPct)}</div>
            <div className="font-semibold text-slate-500">{formatHours(overallSummary.process)}</div>
          </div>
          <div className="border-r border-slate-300 px-2 py-2">
            <div className="flex items-center gap-1.5 font-semibold text-slate-600">
              <span className="h-2.5 w-2.5 bg-red-500" /> Machine Trouble
            </div>
            <div className="mt-1 text-base font-bold text-red-600">{formatPercent(troublePct)}</div>
            <div className="font-semibold text-slate-500">{formatHours(overallSummary.trouble)}</div>
          </div>
          <div className="px-2 py-2">
            <div className="flex items-center gap-1.5 font-semibold text-slate-600">
              <span className="h-2.5 w-2.5 bg-yellow-400" /> Idle
            </div>
            <div className="mt-1 text-base font-bold text-amber-700">{formatPercent(idlePct)}</div>
            <div className="font-semibold text-slate-500">{formatHours(overallSummary.idle)}</div>
          </div>
        </div>

        <div className="grid grid-cols-[120px_1fr] text-[10px]">
          <div className="border-r border-slate-300 bg-slate-50 px-2 py-1 font-semibold text-slate-600">Total waktu</div>
          <div className="px-2 py-1 font-bold text-slate-800">{formatHours(overallSummary.totalMinutes)}</div>
        </div>
      </div>
    </div>
  );
}

