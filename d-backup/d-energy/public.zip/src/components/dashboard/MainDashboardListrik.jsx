import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Container } from 'react-bootstrap';
import axios from 'axios';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  LabelList,
  Legend,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import * as XLSX from 'xlsx';
import Nais_Layout from '../layout/Layout';

const API_ROOT = '/api';

const KUB_SHIFTLY_API_URL = `${API_ROOT}/pm-shiftly-kub-kwh`;
const KUB_MONTHLY_API_URL = `${API_ROOT}/pm-monthly-kub-kwh`;
const KUBIKAL_PRIMARY_LINE = 'tb_kub1_total_kwh';

const COMPRESSORS = [
  {
    key: 'comp19',
    label: 'PANEL 19',
    japaneseLabel: 'パネル19',
    lineTable: 'tb_comp_19',
    shiftly: `${API_ROOT}/comp19Shiftly`,
    monthly: `${API_ROOT}/comp19Monthly`,
  },
  {
    key: 'comp20',
    label: 'PANEL 20',
    japaneseLabel: 'パネル20',
    lineTable: 'tb_comp_20',
    shiftly: `${API_ROOT}/comp20Shiftly`,
    monthly: `${API_ROOT}/comp20Monthly`,
  },
  {
    key: 'comp21',
    label: 'PANEL 21',
    japaneseLabel: 'パネル21',
    lineTable: 'tb_comp_21',
    shiftly: `${API_ROOT}/comp21Shiftly`,
    monthly: `${API_ROOT}/comp21Monthly`,
  },
  {
    key: 'comp24',
    label: 'PANEL 24',
    japaneseLabel: 'パネル24',
    lineTable: 'tb_comp_24',
    shiftly: `${API_ROOT}/comp24Shiftly`,
    monthly: `${API_ROOT}/comp24Monthly`,
  },
];

const PANEL_REFERENCE_INFO = [
  {
    panel: 'PANEL 20',
    unit: 'MWH',
    equipment: 'Compressor 6, Compressor 9, Baby Compressor, Air Dryer-6',
  },
  {
    panel: 'PANEL 19',
    unit: 'KWH',
    equipment: 'Compressor 5, Air Dryer-3',
  },
  {
    panel: 'PANEL 24',
    unit: 'GWH',
    equipment: 'Compressor 7, Compressor 10, Air Dryer-5',
  },
  {
    panel: 'PANEL 21',
    unit: 'GWH',
    equipment: 'Compressor 8, Compressor 11, Air Dryer-7',
  },
  {
    panel: 'PANEL 9',
    unit: 'GWH',
    equipment: 'Belum ada detail equipment',
  },
  {
    panel: 'PANEL 16',
    unit: 'GWH',
    equipment: 'Belum ada detail equipment',
  },
  {
    panel: 'PANEL 17',
    unit: 'GWH',
    equipment: 'Belum ada detail equipment',
  },
];

const PRODUCTION_LINES = [
  { key: 'pm200_bs1', label: 'PM 200 - BS1', lineTable: 'tb_pm200_bs1' },
  { key: 'pm200_bs2', label: 'PM 200 - BS2', lineTable: 'tb_pm200_bs2' },
  { key: 'pm200_cc1', label: 'PM 200 - CC1', lineTable: 'tb_pm200_cc1' },
  { key: 'pm200_cc234', label: 'PM 200 - CC234', lineTable: 'tb_pm200_cc234' },
  { key: 'pm200_chab', label: 'PM 200 - CHAB', lineTable: 'tb_pm200_chab' },
  { key: 'pm200_chcd', label: 'PM 200 - CHCD', lineTable: 'tb_pm200_chcd' },
  { key: 'pm200_chef', label: 'PM 200 - CHEF', lineTable: 'tb_pm200_chef' },
  { key: 'pm200_chsaa', label: 'PM 200 - CHSAA', lineTable: 'tb_pm200_chsaa' },
  { key: 'pm200_chsab', label: 'PM 200 - CHSAB', lineTable: 'tb_pm200_chsab' },
  { key: 'pm200_chsac', label: 'PM 200 - CHSAC', lineTable: 'tb_pm200_chsac' },
  { key: 'pm200_conn', label: 'PM 200 - CONN', lineTable: 'tb_pm200_conn' },
  { key: 'pm200_cr1', label: 'PM 200 - CR1', lineTable: 'tb_pm200_cr1' },
  { key: 'pm200_cr10', label: 'PM 200 - CR10', lineTable: 'tb_pm200_cr10' },
  { key: 'pm200_cr11', label: 'PM 200 - CR11', lineTable: 'tb_pm200_cr11' },
  { key: 'pm200_cr12', label: 'PM 200 - CR12', lineTable: 'tb_pm200_cr12' },
  { key: 'pm200_cr2', label: 'PM 200 - CR2', lineTable: 'tb_pm200_cr2' },
  { key: 'pm200_cr3', label: 'PM 200 - CR3', lineTable: 'tb_pm200_cr3' },
  { key: 'pm200_cr4', label: 'PM 200 - CR4', lineTable: 'tb_pm200_cr4' },
  { key: 'pm200_cr5', label: 'PM 200 - CR5', lineTable: 'tb_pm200_cr5' },
  { key: 'pm200_cr6', label: 'PM 200 - CR6', lineTable: 'tb_pm200_cr6' },
  { key: 'pm200_cr7', label: 'PM 200 - CR7', lineTable: 'tb_pm200_cr7' },
  { key: 'pm200_cr8', label: 'PM 200 - CR8', lineTable: 'tb_pm200_cr8' },
  { key: 'pm200_cr9', label: 'PM 200 - CR9', lineTable: 'tb_pm200_cr9' },
  { key: 'pm200_ct', label: 'PM 200 - CT', lineTable: 'tb_pm200_ct' },
  { key: 'pm200_hla', label: 'PM 200 - HLA', lineTable: 'tb_pm200_hla' },
  { key: 'pm200_ra', label: 'PM 200 - RA', lineTable: 'tb_pm200_ra' },
  { key: 'pm200_ret', label: 'PM 200 - RET', lineTable: 'tb_pm200_ret' },
  { key: 'pm220_bs1', label: 'PM 220 - BS1', lineTable: 'tb_pm220_bs1' },
  { key: 'pm220_bs2', label: 'PM 220 - BS2', lineTable: 'tb_pm220_bs2' },
  { key: 'pm220_cc1', label: 'PM 220 - CC1', lineTable: 'tb_pm220_cc1' },
  { key: 'pm220_cc234', label: 'PM 220 - CC234', lineTable: 'tb_pm220_cc234' },
  { key: 'pm220_chab', label: 'PM 220 - CHAB', lineTable: 'tb_pm220_chab' },
  { key: 'pm220_chcd', label: 'PM 220 - CHCD', lineTable: 'tb_pm220_chcd' },
  { key: 'pm220_chef', label: 'PM 220 - CHEF', lineTable: 'tb_pm220_chef' },
  { key: 'pm220_chsaa', label: 'PM 220 - CHSAA', lineTable: 'tb_pm220_chsaa' },
  { key: 'pm220_chsab', label: 'PM 220 - CHSAB', lineTable: 'tb_pm220_chsab' },
  { key: 'pm220_chsac', label: 'PM 220 - CHSAC', lineTable: 'tb_pm220_chsac' },
  { key: 'pm220_conn', label: 'PM 220 - CONN', lineTable: 'tb_pm220_conn' },
  { key: 'pm220_cr1', label: 'PM 220 - CR1', lineTable: 'tb_pm220_cr1' },
  { key: 'pm220_cr10', label: 'PM 220 - CR10', lineTable: 'tb_pm220_cr10' },
  { key: 'pm220_cr11', label: 'PM 220 - CR11', lineTable: 'tb_pm220_cr11' },
  { key: 'pm220_cr12', label: 'PM 220 - CR12', lineTable: 'tb_pm220_cr12' },
  { key: 'pm220_cr2', label: 'PM 220 - CR2', lineTable: 'tb_pm220_cr2' },
  { key: 'pm220_cr3', label: 'PM 220 - CR3', lineTable: 'tb_pm220_cr3' },
  { key: 'pm220_cr4', label: 'PM 220 - CR4', lineTable: 'tb_pm220_cr4' },
  { key: 'pm220_cr5', label: 'PM 220 - CR5', lineTable: 'tb_pm220_cr5' },
  { key: 'pm220_cr6', label: 'PM 220 - CR6', lineTable: 'tb_pm220_cr6' },
  { key: 'pm220_cr7', label: 'PM 220 - CR7', lineTable: 'tb_pm220_cr7' },
  { key: 'pm220_cr8', label: 'PM 220 - CR8', lineTable: 'tb_pm220_cr8' },
  { key: 'pm220_cr9', label: 'PM 220 - CR9', lineTable: 'tb_pm220_cr9' },
  { key: 'pm220_ct', label: 'PM 220 - CT', lineTable: 'tb_pm220_ct' },
  { key: 'pm220_hla', label: 'PM 220 - HLA', lineTable: 'tb_pm220_hla' },
  { key: 'pm220_ra', label: 'PM 220 - RA', lineTable: 'tb_pm220_ra' },
  { key: 'pm220_ret', label: 'PM 220 - RET', lineTable: 'tb_pm220_ret' },
];

const PRODUCTION_ENDPOINT_SUMMARY =
  `${PRODUCTION_LINES.length} line PM 200 / PM 220`;


const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92;
const SHIFTLY_RAW_TO_KWH_DIVISOR = 1000;
const MONTHLY_RAW_TO_KWH_DIVISOR = 1000;
const REFRESH_INTERVAL_MS = 5 * 60 * 1000;

const MONTHS = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

const MONTH_NUMBER_BY_NAME = {
  januari: 1,
  january: 1,
  februari: 2,
  february: 2,
  maret: 3,
  march: 3,
  april: 4,
  mei: 5,
  may: 5,
  juni: 6,
  june: 6,
  juli: 7,
  july: 7,
  agustus: 8,
  august: 8,
  september: 9,
  oktober: 10,
  october: 10,
  november: 11,
  desember: 12,
  december: 12,
};

const PIE_COLORS = ['#0f5fa8', '#14b8a6', '#f59e0b', '#8b5cf6', '#ef4444', '#22c55e'];
const DEFAULT_MONTHLY_BAR_COLOR = '#0284c7';
const PARTIAL_MONTH_BAR_COLOR = '#f97316';
const PARETO_BAR_COLOR = '#0ea5e9';
const PARETO_LINE_COLOR = '#dc2626';

const toNumber = (value) => {
  const result = Number(value);
  return Number.isFinite(result) ? result : 0;
};

const getMonthNumber = (value) => {
  const numericValue = toNumber(value);
  if (numericValue >= 1 && numericValue <= 12) return numericValue;
  return MONTH_NUMBER_BY_NAME[String(value || '').trim().toLowerCase()] || 0;
};

const pad2 = (value) => String(value).padStart(2, '0');

const getMonthDateRange = (year, monthNumber) => {
  const safeYear = toNumber(year);
  const safeMonth = toNumber(monthNumber);
  const lastDay = new Date(safeYear, safeMonth, 0).getDate();

  return {
    startDate: `${safeYear}-${pad2(safeMonth)}-01`,
    endDate: `${safeYear}-${pad2(safeMonth)}-${pad2(lastDay)}`,
  };
};

const getRecordTimestamp = (item) => {
  const value = item?.updated_at || item?.created_at || '';
  const timestamp = new Date(String(value).replace(' ', 'T')).getTime();
  return Number.isFinite(timestamp) ? timestamp : 0;
};

const choosePreferredRecord = (current, candidate) => {
  if (!current) return candidate;

  const currentHasUpdated = Boolean(current?.updated_at);
  const candidateHasUpdated = Boolean(candidate?.updated_at);

  if (candidateHasUpdated !== currentHasUpdated) {
    return candidateHasUpdated ? candidate : current;
  }

  const currentTimestamp = getRecordTimestamp(current);
  const candidateTimestamp = getRecordTimestamp(candidate);

  if (candidateTimestamp !== currentTimestamp) {
    return candidateTimestamp > currentTimestamp ? candidate : current;
  }

  return Math.abs(toNumber(candidate?.total_kwh)) >
    Math.abs(toNumber(current?.total_kwh))
    ? candidate
    : current;
};

const dedupeMonthlyRecords = (records) => {
  const map = new Map();

  records.forEach((item) => {
    const monthNumber = getMonthNumber(item?.month || item?.month_name);
    const key = `${item?.source_key || item?.line_table || '-'}|${toNumber(
      item?.year
    )}|${monthNumber}`;

    map.set(key, choosePreferredRecord(map.get(key), item));
  });

  return [...map.values()];
};

const dedupeShiftlyRecords = (records) => {
  const map = new Map();

  records.forEach((item) => {
    const key = `${item?.source_key || item?.line_table || '-'}|${
      item?.shift_date || '-'
    }|${normalizeShift(item?.shift) || item?.shift || '-'}`;

    map.set(key, choosePreferredRecord(map.get(key), item));
  });

  return [...map.values()];
};

const numberFormatter = new Intl.NumberFormat('id-ID', {
  maximumFractionDigits: 0,
});

const decimalFormatter = new Intl.NumberFormat('id-ID', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

const currencyFormatter = new Intl.NumberFormat('id-ID', {
  style: 'currency',
  currency: 'IDR',
  maximumFractionDigits: 0,
});

const formatNumber = (value) => numberFormatter.format(toNumber(value));
const formatDecimal = (value) => decimalFormatter.format(toNumber(value));
const formatCurrency = (value) => currencyFormatter.format(toNumber(value));
const toShiftlyKwh = (value) =>
  toNumber(value) / SHIFTLY_RAW_TO_KWH_DIVISOR;
const toMonthlyKwh = (value) =>
  toNumber(value) / MONTHLY_RAW_TO_KWH_DIVISOR;

const normalizeShift = (value) => {
  const normalized = String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');

  if (normalized === 'SHIFT 1' || normalized.endsWith(' 1')) return 'shift1';
  if (normalized === 'SHIFT 2' || normalized.endsWith(' 2')) return 'shift2';
  return null;
};

const parseDate = (value) => {
  if (!value) return new Date(0);
  return new Date(`${String(value).slice(0, 10)}T00:00:00`);
};

const formatLineLabel = (lineTable, lineName) =>
  String(lineName || lineTable || '-')
    .replace(/^tb_/, '')
    .replace(/_total_kwh$/i, '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());

const extractApiRecords = (response, endpointLabel) => {
  const payload = response?.data;

  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data)) return payload.data;

  throw new Error(`Format respons ${endpointLabel} tidak valid.`);
};

const normalizeRecords = (records, source) =>
  records.map((item) => ({
    ...item,
    source_key: source.key,
    source_label: source.label,
    line_table: item?.line_table || source.lineTable,
    line_name: item?.line_name || source.label,
  }));

const getLatestShiftRecord = (records) =>
  records
    .slice()
    .sort((a, b) => parseDate(b.shift_date) - parseDate(a.shift_date))[0] || null;

const getLatestMonthlyRecord = (records) =>
  records
    .slice()
    .sort((a, b) => {
      const yearDifference = toNumber(b.year) - toNumber(a.year);
      if (yearDifference !== 0) return yearDifference;
      return (
        getMonthNumber(b.month || b.month_name) -
        getMonthNumber(a.month || a.month_name)
      );
    })[0] || null;

const buildDailyData = (records, monthNumber, year) => {
  const grouped = new Map();

  records
    .filter(
      (item) =>
        getMonthNumber(item.month || item.month_name) === monthNumber &&
        toNumber(item.year) === toNumber(year)
    )
    .forEach((item) => {
      const dateKey = String(item.shift_date || '').slice(0, 10);
      const shiftKey = normalizeShift(item.shift);
      if (!dateKey || !shiftKey) return;

      if (!grouped.has(dateKey)) {
        grouped.set(dateKey, {
          dateKey,
          date: `${item.day_name || ''}, ${item.day || ''} ${String(
            item.month_name || MONTHS[monthNumber - 1] || ''
          ).slice(0, 3)}`,
          shift1: 0,
          shift2: 0,
        });
      }

      grouped.get(dateKey)[shiftKey] += toShiftlyKwh(item.total_kwh);
    });

  return [...grouped.values()]
    .sort((a, b) => parseDate(a.dateKey) - parseDate(b.dateKey))
    .map((item) => ({
      ...item,
      shift1: Number(item.shift1.toFixed(2)),
      shift2: Number(item.shift2.toFixed(2)),
      total: Number((item.shift1 + item.shift2).toFixed(2)),
    }));
};

const buildMonthlyData = (records, year, throughMonthNumber) => {
  const grouped = new Map();

  records
    .filter((item) => {
      const monthNumber = getMonthNumber(item.month || item.month_name);
      return (
        toNumber(item.year) === toNumber(year) &&
        monthNumber >= 1 &&
        monthNumber <= throughMonthNumber
      );
    })
    .forEach((item) => {
      const monthNumber = getMonthNumber(item.month || item.month_name);
      const monthName = MONTHS[monthNumber - 1] || item.month_name || '-';
      const key = `${year}-${String(monthNumber).padStart(2, '0')}`;

      if (!grouped.has(key)) {
        grouped.set(key, {
          key,
          year: toNumber(year),
          month: monthNumber,
          monthName,
          period: monthName.slice(0, 3),
          kwh: 0,
          rawTotalKwh: 0,
        });
      }

      const group = grouped.get(key);
      const rawTotalKwh = toNumber(item.total_kwh);
      group.rawTotalKwh += rawTotalKwh;
      group.kwh += toMonthlyKwh(rawTotalKwh);
    });

  return [...grouped.values()]
    .sort((a, b) => a.month - b.month)
    .map((item) => ({
      ...item,
      kwh: Number(item.kwh.toFixed(2)),
    }));
};

const sumMonthlyPeriod = (records, monthNumber, year) =>
  records
    .filter(
      (item) =>
        getMonthNumber(item.month || item.month_name) === monthNumber &&
        toNumber(item.year) === toNumber(year)
    )
    .reduce((sum, item) => sum + toMonthlyKwh(item.total_kwh), 0);

const buildParetoRows = (entries, maxVisible = 15) => {
  const ranked = entries
    .filter((item) => toNumber(item.value) > 0)
    .sort((a, b) => b.value - a.value);

  const visible =
    ranked.length > maxVisible
      ? [
          ...ranked.slice(0, maxVisible),
          {
            key: 'others',
            name: 'LAINNYA',
            value: ranked
              .slice(maxVisible)
              .reduce((sum, item) => sum + toNumber(item.value), 0),
          },
        ]
      : ranked;

  const total = visible.reduce((sum, item) => sum + toNumber(item.value), 0);
  let cumulative = 0;

  return visible.map((item) => {
    cumulative += toNumber(item.value);
    return {
      ...item,
      value: Number(toNumber(item.value).toFixed(2)),
      cumulativePercent: total
        ? Number(((cumulative / total) * 100).toFixed(2))
        : 0,
    };
  });
};

const SummaryCard = ({
  icon,
  title,
  japaneseTitle,
  subtitle,
  value,
  accent,
}) => (
  <div
    style={{
      backgroundColor: '#fff',
      padding: '12px',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(15, 23, 42, 0.08)',
      border: '1px solid #edf2f7',
      minHeight: '122px',
    }}
  >
    <div
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '7px',
        marginBottom: '5px',
      }}
    >
      <span style={{ fontSize: '20px' }}>{icon}</span>
      <div>
        <div style={{ fontSize: '14px', fontWeight: 700, color: accent }}>
          {title}
        </div>
        <div
          lang="ja"
          style={{
            marginTop: '1px',
            fontSize: '11px',
            lineHeight: 1.25,
            fontWeight: 600,
            color: '#64748b',
          }}
        >
          {japaneseTitle}
        </div>
      </div>
    </div>
    <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>
      {subtitle}
    </div>
    <div
      style={{
        fontSize: '20px',
        lineHeight: 1.25,
        fontWeight: 800,
        color: '#1e293b',
        wordBreak: 'break-word',
      }}
    >
      {value}
    </div>
  </div>
);

const BilingualHeading = ({ title, japaneseTitle, icon, color = '#1e293b' }) => (
  <div>
    <div style={{ fontWeight: 800, color }}>
      {icon ? `${icon} ` : ''}
      {title}
    </div>
    <div
      lang="ja"
      style={{ marginTop: '1px', fontSize: '11px', color: '#64748b' }}
    >
      {japaneseTitle}
    </div>
  </div>
);

const EmptyChart = ({ message = 'Tidak ada data untuk filter yang dipilih.' }) => (
  <div
    style={{
      height: '250px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '24px',
      textAlign: 'center',
      color: '#64748b',
      fontSize: '13px',
    }}
  >
    {message}
  </div>
);

const SectionDivider = ({
  title,
  japaneseTitle,
  badge,
  accent,
  background,
  border,
}) => (
  <div
    style={{
      margin: '18px 0 12px',
      padding: '14px 16px',
      borderRadius: '12px',
      border: `2px solid ${border}`,
      borderLeft: `8px solid ${accent}`,
      background,
      boxShadow: '0 4px 14px rgba(15, 23, 42, 0.06)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '12px',
      flexWrap: 'wrap',
    }}
  >
    <BilingualHeading
      title={title}
      japaneseTitle={japaneseTitle}
      color={accent}
    />
    <span
      style={{
        padding: '6px 10px',
        borderRadius: '999px',
        backgroundColor: '#fff',
        border: `1px solid ${border}`,
        color: accent,
        fontSize: '11px',
        fontWeight: 800,
        letterSpacing: '0.08em',
      }}
    >
      {badge}
    </span>
  </div>
);

const PanelReferenceInfo = () => (
  <div
    style={{
      marginTop: '12px',
      paddingTop: '12px',
      borderTop: '1px solid #e2e8f0',
    }}
  >
    <div
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        gap: '10px',
        flexWrap: 'wrap',
        marginBottom: '10px',
      }}
    >
      <div>
        <div style={{ fontSize: '13px', fontWeight: 800, color: '#1e293b' }}>
          Informasi Panel
        </div>
        <div style={{ marginTop: '2px', fontSize: '11px', color: '#64748b' }}>
          Referensi unit dan equipment panel.
        </div>
      </div>
      <span
        style={{
          padding: '5px 9px',
          borderRadius: '999px',
          backgroundColor: '#eff6ff',
          color: '#1d4ed8',
          border: '1px solid #bfdbfe',
          fontSize: '11px',
          fontWeight: 700,
        }}
      >
        {PANEL_REFERENCE_INFO.length} panel referensi
      </span>
    </div>

    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
        gap: '8px',
      }}
    >
      {PANEL_REFERENCE_INFO.map((item) => (
        <div
          key={item.panel}
          style={{
            padding: '10px',
            borderRadius: '8px',
            border: '1px solid #e2e8f0',
            backgroundColor: '#f8fafc',
            minHeight: '92px',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              gap: '8px',
              marginBottom: '6px',
            }}
          >
            <strong style={{ fontSize: '12px', color: '#0f172a' }}>
              {item.panel}
            </strong>
            <span
              style={{
                padding: '2px 6px',
                borderRadius: '5px',
                backgroundColor: '#e0f2fe',
                color: '#0369a1',
                fontSize: '10px',
                fontWeight: 800,
              }}
            >
              {item.unit}
            </span>
          </div>
          <div style={{ fontSize: '11px', lineHeight: 1.45, color: '#475569' }}>
            {item.equipment}
          </div>
        </div>
      ))}
    </div>
  </div>
);

const MonthlyChartCard = ({
  title,
  japaneseTitle,
  data,
  sourceText,
  large = false,
  highlightPartialFebruary2026 = false,
}) => (
  <div
    style={{
      backgroundColor: '#fff',
      border: '1px solid #e2e8f0',
      borderRadius: '9px',
      padding: '12px',
      minWidth: 0,
    }}
  >
    <BilingualHeading title={title} japaneseTitle={japaneseTitle} />
    <div style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 8px' }}>
      {sourceText}
    </div>

    {highlightPartialFebruary2026 &&
      data.some((item) => item.month === 2 && item.year === 2026) && (
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            marginBottom: '7px',
            padding: '5px 8px',
            borderRadius: '6px',
            backgroundColor: '#fff7ed',
            color: '#c2410c',
            fontSize: '11px',
          }}
        >
          <span
            style={{
              width: '10px',
              height: '10px',
              borderRadius: '2px',
              backgroundColor: PARTIAL_MONTH_BAR_COLOR,
            }}
          />
          Februari 2026 merupakan data parsial karena pengambilan data tidak dimulai
          dari awal bulan.
        </div>
      )}

    {data.length ? (
      <div style={{ width: '100%', height: large ? '320px' : '280px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{ top: 28, right: 18, left: 8, bottom: 8 }}
          >
            <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
            <XAxis dataKey="period" tick={{ fontSize: 11 }} interval={0} />
            <YAxis
              tick={{ fontSize: 11 }}
              tickFormatter={formatNumber}
              label={{
                value: 'kWh',
                angle: -90,
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontWeight: 700 },
              }}
            />
            <Tooltip
              formatter={(value) => [`${formatDecimal(value)} kWh`, 'Konsumsi']}
              labelFormatter={(label) => `Bulan: ${label}`}
              contentStyle={{
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
              }}
            />
            <Bar
              dataKey="kwh"
              fill={DEFAULT_MONTHLY_BAR_COLOR}
              radius={[4, 4, 0, 0]}
              name="Konsumsi (kWh)"
            >
              {data.map((item) => (
                <Cell
                  key={item.key}
                  fill={
                    highlightPartialFebruary2026 &&
                    item.month === 2 &&
                    item.year === 2026
                      ? PARTIAL_MONTH_BAR_COLOR
                      : DEFAULT_MONTHLY_BAR_COLOR
                  }
                />
              ))}
              <LabelList
                dataKey="kwh"
                position="top"
                formatter={formatNumber}
                fill="#334155"
                fontSize={10}
                fontWeight="bold"
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    ) : (
      <EmptyChart />
    )}
  </div>
);

const ParetoChartCard = ({
  title,
  japaneseTitle,
  data,
  periodText,
  isPartialFebruary2026 = false,
  footerContent = null,
}) => (
  <div
    style={{
      backgroundColor: '#fff',
      border: '1px solid #e2e8f0',
      borderRadius: '9px',
      padding: '12px',
      minWidth: 0,
    }}
  >
    <BilingualHeading title={title} japaneseTitle={japaneseTitle} />
    <div style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 8px' }}>
      {periodText}
    </div>

    {isPartialFebruary2026 && (
      <div
        style={{
          marginBottom: '7px',
          padding: '6px 8px',
          borderRadius: '6px',
          backgroundColor: '#fff7ed',
          color: '#c2410c',
          fontSize: '11px',
        }}
      >
        Batang oranye menandai Februari 2026 sebagai data parsial, bukan konsumsi
        satu bulan penuh.
      </div>
    )}

    {data.length ? (
      <div style={{ width: '100%', height: '330px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            data={data}
            margin={{ top: 28, right: 20, left: 8, bottom: 8 }}
          >
            <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
            <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} />
            <YAxis
              yAxisId="left"
              tick={{ fontSize: 11 }}
              tickFormatter={formatNumber}
              label={{
                value: 'kWh',
                angle: -90,
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontWeight: 700 },
              }}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              domain={[0, 100]}
              tick={{ fontSize: 11 }}
              tickFormatter={(value) => `${value}%`}
            />
            <Tooltip
              formatter={(value, name) =>
                name === 'Kumulatif (%)'
                  ? [`${formatDecimal(value)}%`, name]
                  : [`${formatDecimal(value)} kWh`, name]
              }
              contentStyle={{
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
              }}
            />
            <Legend verticalAlign="top" height={28} />
            <Bar
              yAxisId="left"
              dataKey="value"
              name="Konsumsi (kWh)"
              fill={isPartialFebruary2026 ? PARTIAL_MONTH_BAR_COLOR : PARETO_BAR_COLOR}
              radius={[4, 4, 0, 0]}
            >
              <LabelList
                dataKey="value"
                position="top"
                formatter={formatNumber}
                fill="#334155"
                fontSize={10}
                fontWeight="bold"
              />
            </Bar>
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="cumulativePercent"
              name="Kumulatif (%)"
              stroke={PARETO_LINE_COLOR}
              strokeWidth={2.5}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    ) : (
      <EmptyChart message="Data belum tersedia untuk membuat Pareto." />
    )}
    {footerContent}
  </div>
);

const DailyChartCard = ({
  title,
  japaneseTitle,
  data,
  sourceText,
  chartKey,
  large = false,
}) => {
  const gradientShift1 = `gradientShift1-${chartKey}`;
  const gradientShift2 = `gradientShift2-${chartKey}`;

  return (
    <div
      style={{
        backgroundColor: '#fff',
        border: '1px solid #e2e8f0',
        borderRadius: '9px',
        padding: '12px',
        minWidth: 0,
      }}
    >
      <BilingualHeading title={title} japaneseTitle={japaneseTitle} />
      <div style={{ fontSize: '11px', color: '#94a3b8', margin: '4px 0 8px' }}>
        {sourceText}
      </div>

      {data.length ? (
        <div style={{ width: '100%', height: large ? '340px' : '300px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 28, right: 18, left: 8, bottom: 5 }}
            >
              <defs>
                <linearGradient id={gradientShift1} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#14b8a6" stopOpacity={1} />
                  <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.55} />
                </linearGradient>
                <linearGradient id={gradientShift2} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f46e5" stopOpacity={1} />
                  <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.55} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="4 4" stroke="#e2e8f0" />
              <XAxis
                dataKey="dateKey"
                tick={{ fontSize: 11 }}
                tickFormatter={(value) => {
                  const [, month, day] = String(value).split('-');
                  return `${day}/${month}`;
                }}
              />
              <YAxis
                tick={{ fontSize: 11 }}
                tickFormatter={formatNumber}
                label={{
                  value: 'kWh',
                  angle: -90,
                  position: 'insideLeft',
                  style: { textAnchor: 'middle', fontWeight: 700 },
                }}
              />
              <Tooltip
                formatter={(value, name) => [
                  `${formatDecimal(value)} kWh`,
                  name,
                ]}
                labelFormatter={(_, payload) =>
                  payload?.[0]?.payload?.date || '-'
                }
                contentStyle={{
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                }}
              />
              <Legend verticalAlign="top" height={28} />
              <Bar
                dataKey="shift1"
                fill={`url(#${gradientShift1})`}
                name="Shift 1"
                radius={[4, 4, 0, 0]}
              />
              <Bar
                dataKey="shift2"
                fill={`url(#${gradientShift2})`}
                name="Shift 2"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <EmptyChart />
      )}
    </div>
  );
};

const FilterSelect = ({ label, japaneseLabel, children }) => (
  <label
    style={{
      display: 'flex',
      flexDirection: 'column',
      gap: '3px',
      fontSize: '11px',
      color: '#64748b',
    }}
  >
    <span>
      {label}
      <span lang="ja" style={{ marginLeft: '5px', color: '#94a3b8' }}>
        {japaneseLabel}
      </span>
    </span>
    {children}
  </label>
);

const selectStyle = {
  padding: '7px 10px',
  borderRadius: '7px',
  border: '1px solid #cbd5e1',
  backgroundColor: '#fff',
  fontSize: '13px',
  minWidth: '120px',
};

const MainDashboardListrik = () => {
  const requestControllerRef = useRef(null);
  const initialSelectionDoneRef = useRef(false);
  const firstFetchRef = useRef(true);

  const [kubShiftlyRaw, setKubShiftlyRaw] = useState([]);
  const [kubMonthlyRaw, setKubMonthlyRaw] = useState([]);
  const [compressorShiftlyRaw, setCompressorShiftlyRaw] = useState([]);
  const [compressorMonthlyRaw, setCompressorMonthlyRaw] = useState([]);
  const [productionShiftlyRaw, setProductionShiftlyRaw] = useState([]);
  const [productionMonthlyRaw, setProductionMonthlyRaw] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [lastFetchedAt, setLastFetchedAt] = useState(null);

  const now = new Date();
  const currentMonthNumber = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const [selectedLine, setSelectedLine] = useState(KUBIKAL_PRIMARY_LINE);
  const [monthlyMonth, setMonthlyMonth] = useState(currentMonthNumber);
  const [monthlyYear, setMonthlyYear] = useState(currentYear);
  const [shiftMonth, setShiftMonth] = useState(currentMonthNumber);
  const [shiftYear, setShiftYear] = useState(currentYear);
  const [showKubikal, setShowKubikal] = useState(true);
  const [showCompressor, setShowCompressor] = useState(true);
  const [showProduction, setShowProduction] = useState(true);

  const fetchData = useCallback(async (initialLoad = false) => {
    requestControllerRef.current?.abort();
    const controller = new AbortController();
    requestControllerRef.current = controller;

    if (initialLoad) setLoading(true);
    else setRefreshing(true);
    setError('');

    const requestConfig = {
      signal: controller.signal,
      timeout: 20000,
      params: { timestamp: Date.now() },
      headers: { 'Cache-Control': 'no-cache' },
    };

    const shiftRange = getMonthDateRange(shiftYear, shiftMonth);

    const requestDefinitions = [
      {
        id: 'kub-shiftly',
        type: 'kubShiftly',
        label: KUB_SHIFTLY_API_URL,
        promise: axios.get(KUB_SHIFTLY_API_URL, requestConfig),
      },
      {
        id: 'kub-monthly',
        type: 'kubMonthly',
        label: KUB_MONTHLY_API_URL,
        promise: axios.get(KUB_MONTHLY_API_URL, requestConfig),
      },
      ...COMPRESSORS.flatMap((compressor) => [
        {
          id: `${compressor.key}-shiftly`,
          type: 'compressorShiftly',
          label: compressor.shiftly,
          compressor,
          promise: axios.get(compressor.shiftly, requestConfig),
        },
        {
          id: `${compressor.key}-monthly`,
          type: 'compressorMonthly',
          label: compressor.monthly,
          compressor,
          promise: axios.get(compressor.monthly, requestConfig),
        },
      ]),
      ...PRODUCTION_LINES.flatMap((line) => {
        const shiftlyUrl = `${API_ROOT}/reports/shiftly/${line.lineTable}_shiftly/range?startDate=${shiftRange.startDate}&endDate=${shiftRange.endDate}`;
        const monthlyUrl = `${API_ROOT}/reports/monthly/${line.lineTable}_monthly/year/${monthlyYear}`;

        return [
          {
            id: `${line.key}-shiftly`,
            type: 'productionShiftly',
            label: shiftlyUrl,
            productionLine: line,
            promise: axios.get(shiftlyUrl, requestConfig),
          },
          {
            id: `${line.key}-monthly`,
            type: 'productionMonthly',
            label: monthlyUrl,
            productionLine: line,
            promise: axios.get(monthlyUrl, requestConfig),
          },
        ];
      }),
    ];

    try {
      const settled = await Promise.allSettled(
        requestDefinitions.map((definition) => definition.promise)
      );

      if (controller.signal.aborted) return;

      const nextKubShiftly = [];
      const nextKubMonthly = [];
      const nextCompressorShiftly = [];
      const nextCompressorMonthly = [];
      const nextProductionShiftly = [];
      const nextProductionMonthly = [];
      const failedEndpoints = [];

      settled.forEach((result, index) => {
        const definition = requestDefinitions[index];

        if (result.status === 'rejected') {
          const reason = result.reason;
          if (
            axios.isCancel(reason) ||
            reason?.name === 'CanceledError' ||
            reason?.name === 'AbortError'
          ) {
            return;
          }
          failedEndpoints.push(definition.label);
          return;
        }

        try {
          const records = extractApiRecords(result.value, definition.label);

          if (definition.type === 'kubShiftly') {
            nextKubShiftly.push(
              ...records.filter((item) => item?.line_table && item?.shift_date)
            );
          } else if (definition.type === 'kubMonthly') {
            nextKubMonthly.push(
              ...records.filter((item) => item?.line_table && item?.month && item?.year)
            );
          } else if (definition.type === 'compressorShiftly') {
            nextCompressorShiftly.push(
              ...normalizeRecords(records, definition.compressor).filter(
                (item) => item?.shift_date
              )
            );
          } else if (definition.type === 'compressorMonthly') {
            nextCompressorMonthly.push(
              ...normalizeRecords(records, definition.compressor).filter(
                (item) => item?.month && item?.year
              )
            );
          } else if (definition.type === 'productionShiftly') {
            nextProductionShiftly.push(
              ...normalizeRecords(records, definition.productionLine).filter(
                (item) => item?.shift_date
              )
            );
          } else if (definition.type === 'productionMonthly') {
            nextProductionMonthly.push(
              ...normalizeRecords(records, definition.productionLine).filter(
                (item) => item?.month && item?.year
              )
            );
          }
        } catch (parseError) {
          console.error(parseError);
          failedEndpoints.push(definition.label);
        }
      });

      const cleanKubShiftly = dedupeShiftlyRecords(nextKubShiftly);
      const cleanKubMonthly = dedupeMonthlyRecords(nextKubMonthly);
      const cleanCompressorShiftly = dedupeShiftlyRecords(nextCompressorShiftly);
      const cleanCompressorMonthly = dedupeMonthlyRecords(nextCompressorMonthly);
      const cleanProductionShiftly = dedupeShiftlyRecords(nextProductionShiftly);
      const cleanProductionMonthly = dedupeMonthlyRecords(nextProductionMonthly);

      const totalRecordCount =
        cleanKubShiftly.length +
        cleanKubMonthly.length +
        cleanCompressorShiftly.length +
        cleanCompressorMonthly.length +
        cleanProductionShiftly.length +
        cleanProductionMonthly.length;

      if (!totalRecordCount && !controller.signal.aborted) {
        throw new Error('Seluruh endpoint dashboard gagal memberikan data.');
      }

      setKubShiftlyRaw(cleanKubShiftly);
      setKubMonthlyRaw(cleanKubMonthly);
      setCompressorShiftlyRaw(cleanCompressorShiftly);
      setCompressorMonthlyRaw(cleanCompressorMonthly);
      setProductionShiftlyRaw(cleanProductionShiftly);
      setProductionMonthlyRaw(cleanProductionMonthly);
      setLastFetchedAt(new Date());

      if (failedEndpoints.length) {
        const preview = failedEndpoints.slice(0, 8).join(', ');
        const suffix =
          failedEndpoints.length > 8
            ? `, dan ${failedEndpoints.length - 8} endpoint lainnya`
            : '';
        setError(
          `${failedEndpoints.length} endpoint gagal dimuat: ${preview}${suffix}`
        );
      }

      if (!initialSelectionDoneRef.current) {
        const preferredLineExists = [...nextKubShiftly, ...nextKubMonthly].some(
          (item) => item.line_table === KUBIKAL_PRIMARY_LINE
        );
        const firstKubRecord = nextKubShiftly[0] || nextKubMonthly[0];
        setSelectedLine(
          preferredLineExists
            ? KUBIKAL_PRIMARY_LINE
            : firstKubRecord?.line_table || KUBIKAL_PRIMARY_LINE
        );

        const latestMonthly = getLatestMonthlyRecord([
          ...cleanKubMonthly,
          ...cleanCompressorMonthly,
          ...cleanProductionMonthly,
        ]);
        const latestShift = getLatestShiftRecord([
          ...cleanKubShiftly,
          ...cleanCompressorShiftly,
          ...cleanProductionShiftly,
        ]);

        setMonthlyMonth(
          getMonthNumber(latestMonthly?.month || latestMonthly?.month_name) ||
            currentMonthNumber
        );
        setMonthlyYear(toNumber(latestMonthly?.year) || currentYear);
        setShiftMonth(
          getMonthNumber(latestShift?.month || latestShift?.month_name) ||
            currentMonthNumber
        );
        setShiftYear(toNumber(latestShift?.year) || currentYear);
        initialSelectionDoneRef.current = true;
      }
    } catch (err) {
      if (
        axios.isCancel(err) ||
        err?.name === 'CanceledError' ||
        err?.name === 'AbortError'
      ) {
        return;
      }

      console.error('Gagal memuat dashboard energi gabungan:', err);
      setError(
        err?.response?.data?.message ||
          err?.message ||
          'Gagal memuat data dashboard.'
      );
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, [
    currentMonthNumber,
    currentYear,
    monthlyYear,
    shiftMonth,
    shiftYear,
  ]);

  useEffect(() => {
    fetchData(firstFetchRef.current);
    firstFetchRef.current = false;

    const intervalId = window.setInterval(() => {
      fetchData(false);
    }, REFRESH_INTERVAL_MS);

    return () => {
      window.clearInterval(intervalId);
      requestControllerRef.current?.abort();
    };
  }, [fetchData]);

  const lineOptions = useMemo(() => {
    const map = new Map();

    [...kubShiftlyRaw, ...kubMonthlyRaw].forEach((item) => {
      if (!map.has(item.line_table)) {
        map.set(
          item.line_table,
          formatLineLabel(item.line_table, item.line_name)
        );
      }
    });

    return [...map.entries()]
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label, 'id-ID'));
  }, [kubShiftlyRaw, kubMonthlyRaw]);

  const selectedLineLabel =
    lineOptions.find((item) => item.value === selectedLine)?.label || 'Kubikal';

  const monthlyYearOptions = useMemo(
    () =>
      [
        ...new Set(
          [...kubMonthlyRaw, ...compressorMonthlyRaw, ...productionMonthlyRaw]
            .map((item) => toNumber(item.year))
            .filter(Boolean)
        ),
      ].sort((a, b) => b - a),
    [kubMonthlyRaw, compressorMonthlyRaw, productionMonthlyRaw]
  );

  const shiftYearOptions = useMemo(
    () =>
      [
        ...new Set(
          [...kubShiftlyRaw, ...compressorShiftlyRaw, ...productionShiftlyRaw]
            .map((item) => toNumber(item.year))
            .filter(Boolean)
        ),
      ].sort((a, b) => b - a),
    [kubShiftlyRaw, compressorShiftlyRaw, productionShiftlyRaw]
  );

  const monthlyMonthOptions = useMemo(() => {
    const available = new Set(
      [...kubMonthlyRaw, ...compressorMonthlyRaw, ...productionMonthlyRaw]
        .filter((item) => toNumber(item.year) === toNumber(monthlyYear))
        .map((item) => getMonthNumber(item.month || item.month_name))
        .filter(Boolean)
    );
    return MONTHS.map((name, index) => ({ name, number: index + 1 })).filter(
      (item) => available.has(item.number)
    );
  }, [
    kubMonthlyRaw,
    compressorMonthlyRaw,
    productionMonthlyRaw,
    monthlyYear,
  ]);

  const shiftMonthOptions = useMemo(() => {
    const available = new Set(
      [...kubShiftlyRaw, ...compressorShiftlyRaw, ...productionShiftlyRaw]
        .filter((item) => toNumber(item.year) === toNumber(shiftYear))
        .map((item) => getMonthNumber(item.month || item.month_name))
        .filter(Boolean)
    );
    return MONTHS.map((name, index) => ({ name, number: index + 1 })).filter(
      (item) => available.has(item.number)
    );
  }, [
    kubShiftlyRaw,
    compressorShiftlyRaw,
    productionShiftlyRaw,
    shiftYear,
  ]);

  useEffect(() => {
    if (
      monthlyMonthOptions.length &&
      !monthlyMonthOptions.some((item) => item.number === monthlyMonth)
    ) {
      setMonthlyMonth(monthlyMonthOptions[monthlyMonthOptions.length - 1].number);
    }
  }, [monthlyMonthOptions, monthlyMonth]);

  useEffect(() => {
    if (
      shiftMonthOptions.length &&
      !shiftMonthOptions.some((item) => item.number === shiftMonth)
    ) {
      setShiftMonth(shiftMonthOptions[shiftMonthOptions.length - 1].number);
    }
  }, [shiftMonthOptions, shiftMonth]);

  const selectedKubShiftlyRecords = useMemo(
    () => kubShiftlyRaw.filter((item) => item.line_table === selectedLine),
    [kubShiftlyRaw, selectedLine]
  );

  const selectedKubMonthlyRecords = useMemo(
    () => kubMonthlyRaw.filter((item) => item.line_table === selectedLine),
    [kubMonthlyRaw, selectedLine]
  );

  const kubDailyData = useMemo(
    () => buildDailyData(selectedKubShiftlyRecords, shiftMonth, shiftYear),
    [selectedKubShiftlyRecords, shiftMonth, shiftYear]
  );

  const kubMonthlyData = useMemo(
    () => buildMonthlyData(selectedKubMonthlyRecords, monthlyYear, monthlyMonth),
    [selectedKubMonthlyRecords, monthlyYear, monthlyMonth]
  );

  const compressorDailyData = useMemo(() => {
    const result = {};
    COMPRESSORS.forEach((compressor) => {
      result[compressor.key] = buildDailyData(
        compressorShiftlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        shiftMonth,
        shiftYear
      );
    });
    return result;
  }, [compressorShiftlyRaw, shiftMonth, shiftYear]);

  const compressorMonthlyData = useMemo(() => {
    const result = {};
    COMPRESSORS.forEach((compressor) => {
      result[compressor.key] = buildMonthlyData(
        compressorMonthlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        monthlyYear,
        monthlyMonth
      );
    });
    return result;
  }, [compressorMonthlyRaw, monthlyYear, monthlyMonth]);

  const totalCompressorDailyData = useMemo(
    () => buildDailyData(compressorShiftlyRaw, shiftMonth, shiftYear),
    [compressorShiftlyRaw, shiftMonth, shiftYear]
  );

  const totalCompressorMonthlyData = useMemo(
    () => buildMonthlyData(compressorMonthlyRaw, monthlyYear, monthlyMonth),
    [compressorMonthlyRaw, monthlyYear, monthlyMonth]
  );

  const productionDailyData = useMemo(
    () => buildDailyData(productionShiftlyRaw, shiftMonth, shiftYear),
    [productionShiftlyRaw, shiftMonth, shiftYear]
  );

  const productionMonthlyData = useMemo(
    () => buildMonthlyData(productionMonthlyRaw, monthlyYear, monthlyMonth),
    [productionMonthlyRaw, monthlyYear, monthlyMonth]
  );

  const monthlyProductionPareto = useMemo(
    () =>
      buildParetoRows(
        PRODUCTION_LINES.map((line) => ({
          key: line.key,
          name: line.label,
          value: sumMonthlyPeriod(
            productionMonthlyRaw.filter((item) => item.source_key === line.key),
            monthlyMonth,
            monthlyYear
          ),
        }))
      ),
    [productionMonthlyRaw, monthlyMonth, monthlyYear]
  );

  const shiftlyProductionPareto = useMemo(
    () =>
      buildParetoRows(
        PRODUCTION_LINES.map((line) => ({
          key: line.key,
          name: line.label,
          value: buildDailyData(
            productionShiftlyRaw.filter((item) => item.source_key === line.key),
            shiftMonth,
            shiftYear
          ).reduce((sum, item) => sum + item.total, 0),
        }))
      ),
    [productionShiftlyRaw, shiftMonth, shiftYear]
  );

  const monthlyCompressorPareto = useMemo(() => {
    const ranked = COMPRESSORS.map((compressor) => ({
      key: compressor.key,
      name: compressor.label,
      value: sumMonthlyPeriod(
        compressorMonthlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        monthlyMonth,
        monthlyYear
      ),
    }))
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value);

    const total = ranked.reduce((sum, item) => sum + item.value, 0);
    let cumulative = 0;

    return ranked.map((item) => {
      cumulative += item.value;
      return {
        ...item,
        value: Number(item.value.toFixed(2)),
        cumulativePercent: total
          ? Number(((cumulative / total) * 100).toFixed(2))
          : 0,
      };
    });
  }, [compressorMonthlyRaw, monthlyMonth, monthlyYear]);

  const shiftlyCompressorPareto = useMemo(() => {
    const ranked = COMPRESSORS.map((compressor) => ({
      key: compressor.key,
      name: compressor.label,
      value: (compressorDailyData[compressor.key] || []).reduce(
        (sum, item) => sum + item.total,
        0
      ),
    }))
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value);

    const total = ranked.reduce((sum, item) => sum + item.value, 0);
    let cumulative = 0;

    return ranked.map((item) => {
      cumulative += item.value;
      return {
        ...item,
        value: Number(item.value.toFixed(2)),
        cumulativePercent: total
          ? Number(((cumulative / total) * 100).toFixed(2))
          : 0,
      };
    });
  }, [compressorDailyData]);

  const metrics = useMemo(() => {
    const totalShift1 = kubDailyData.reduce(
      (sum, item) => sum + item.shift1,
      0
    );
    const totalShift2 = kubDailyData.reduce(
      (sum, item) => sum + item.shift2,
      0
    );
    const totalKwh = totalShift1 + totalShift2;
    const daysCount = kubDailyData.length;
    const avgDaily = daysCount ? totalKwh / daysCount : 0;
    const peakValue = kubDailyData.length
      ? Math.max(
          ...kubDailyData.flatMap((item) => [item.shift1, item.shift2])
        )
      : 0;

    return {
      totalShift1,
      totalShift2,
      totalKwh,
      avgDaily,
      peakValue,
      totalCost: totalKwh * COST_PER_KWH,
      totalCo2: totalKwh * CO2_EMISSION_FACTOR,
      daysCount,
    };
  }, [kubDailyData]);

  const energyBalance = useMemo(() => {
    const kubikalRecords = kubMonthlyRaw.filter(
      (item) => item.line_table === KUBIKAL_PRIMARY_LINE
    );
    const baseRecords = kubikalRecords.length
      ? kubikalRecords
      : selectedKubMonthlyRecords;

    const kubikal = sumMonthlyPeriod(baseRecords, monthlyMonth, monthlyYear);
    const compressorValues = COMPRESSORS.map((compressor) => ({
      key: compressor.key,
      name: compressor.label,
      value: sumMonthlyPeriod(
        compressorMonthlyRaw.filter(
          (item) => item.source_key === compressor.key
        ),
        monthlyMonth,
        monthlyYear
      ),
    }));
    const compressorTotal = compressorValues.reduce(
      (sum, item) => sum + item.value,
      0
    );
    const productionTotal = sumMonthlyPeriod(
      productionMonthlyRaw,
      monthlyMonth,
      monthlyYear
    );
    const componentTotal = compressorTotal + productionTotal;
    const variance = kubikal - componentTotal;
    const variancePercent = kubikal ? (variance / kubikal) * 100 : 0;

    return {
      kubikal,
      compressorValues,
      compressorTotal,
      productionTotal,
      componentTotal,
      variance,
      variancePercent,
      data: [
        {
          name: 'Line Produksi / WH Otics',
          value: Number(productionTotal.toFixed(2)),
          signedValue: Number(productionTotal.toFixed(2)),
        },
        ...compressorValues.map((item) => ({
          name: item.name,
          value: Number(item.value.toFixed(2)),
          signedValue: Number(item.value.toFixed(2)),
        })),
        ...(Math.abs(variance) >= 0.01
          ? [
              {
                name:
                  variance >= 0
                    ? 'Selisih belum teralokasi (+)'
                    : 'Kelebihan komponen (-)',
                value: Number(Math.abs(variance).toFixed(2)),
                signedValue: Number(variance.toFixed(2)),
                isVariance: true,
              },
            ]
          : []),
      ].filter((item) => item.value > 0),
    };
  }, [
    kubMonthlyRaw,
    selectedKubMonthlyRecords,
    compressorMonthlyRaw,
    productionMonthlyRaw,
    monthlyMonth,
    monthlyYear,
  ]);

  const latestApiUpdate = useMemo(() => {
    const timestamps = [
      ...kubShiftlyRaw,
      ...kubMonthlyRaw,
      ...compressorShiftlyRaw,
      ...compressorMonthlyRaw,
      ...productionShiftlyRaw,
      ...productionMonthlyRaw,
    ]
      .map((item) =>
        new Date(String(item.updated_at || item.created_at || '').replace(' ', 'T'))
      )
      .filter((date) => !Number.isNaN(date.getTime()));

    if (!timestamps.length) return null;
    return new Date(Math.max(...timestamps.map((date) => date.getTime())));
  }, [
    kubShiftlyRaw,
    kubMonthlyRaw,
    compressorShiftlyRaw,
    compressorMonthlyRaw,
    productionShiftlyRaw,
    productionMonthlyRaw,
  ]);

  const exportToExcel = () => {
    const workbook = XLSX.utils.book_new();

    const appendSheet = (name, rows) => {
      const worksheet = XLSX.utils.json_to_sheet(rows);
      worksheet['!cols'] = Array.from({ length: 15 }, () => ({ wch: 18 }));
      XLSX.utils.book_append_sheet(workbook, worksheet, name.slice(0, 31));
    };

    const shiftRows = (records) =>
      records
        .filter(
          (item) =>
            getMonthNumber(item.month || item.month_name) === shiftMonth &&
            toNumber(item.year) === toNumber(shiftYear)
        )
        .map((item) => ({
          Tanggal: item.shift_date,
          Hari: item.day_name,
          Shift: item.shift,
          Line: item.line_name,
          'Mulai Shift': item.shift_start_datetime,
          'Akhir Shift': item.shift_end_datetime,
          'Start Meter': toNumber(item.start_kwh),
          'End Meter': toNumber(item.end_kwh),
          'Energi (kWh)': Number(toShiftlyKwh(item.total_kwh).toFixed(2)),
        }));

    const monthlyRows = (records) =>
      records
        .filter(
          (item) =>
            toNumber(item.year) === toNumber(monthlyYear) &&
            getMonthNumber(item.month || item.month_name) <= monthlyMonth
        )
        .map((item) => ({
          Tahun: item.year,
          Bulan: item.month_name || MONTHS[getMonthNumber(item.month) - 1],
          Line: item.line_name,
          'Tanggal Awal': item.month_start_date,
          'Tanggal Akhir': item.month_end_date,
          'Start Meter': toNumber(item.start_kwh),
          'End Meter': toNumber(item.end_kwh),
          'Energi (kWh)': Number(toMonthlyKwh(item.total_kwh).toFixed(2)),
        }));

    appendSheet('Kubikal Shiftly', shiftRows(selectedKubShiftlyRecords));
    appendSheet('Kubikal Monthly', monthlyRows(selectedKubMonthlyRecords));

    COMPRESSORS.forEach((compressor) => {
      appendSheet(
        `${compressor.label} Shiftly`,
        shiftRows(
          compressorShiftlyRaw.filter(
            (item) => item.source_key === compressor.key
          )
        )
      );
      appendSheet(
        `${compressor.label} Monthly`,
        monthlyRows(
          compressorMonthlyRaw.filter(
            (item) => item.source_key === compressor.key
          )
        )
      );
    });

    appendSheet('Line Produksi Shiftly', shiftRows(productionShiftlyRaw));
    appendSheet('Line Produksi Monthly', monthlyRows(productionMonthlyRaw));

    appendSheet('Neraca Energi', [
      {
        Periode: `${MONTHS[monthlyMonth - 1]} ${monthlyYear}`,
        'Kubikal (kWh)': Number(energyBalance.kubikal.toFixed(2)),
        'Line Produksi / WH Otics (kWh)': Number(
          energyBalance.productionTotal.toFixed(2)
        ),
        'Comp 19 (kWh)': Number(
          (energyBalance.compressorValues[0]?.value || 0).toFixed(2)
        ),
        'Comp 20 (kWh)': Number(
          (energyBalance.compressorValues[1]?.value || 0).toFixed(2)
        ),
        'Comp 21 (kWh)': Number(
          (energyBalance.compressorValues[2]?.value || 0).toFixed(2)
        ),
        'Comp 24 (kWh)': Number(
          (energyBalance.compressorValues[3]?.value || 0).toFixed(2)
        ),
        'Comp + Line Produksi (kWh)': Number(
          energyBalance.componentTotal.toFixed(2)
        ),
        'Selisih Kubikal - Komponen (kWh)': Number(
          energyBalance.variance.toFixed(2)
        ),
        'Selisih (%)': Number(energyBalance.variancePercent.toFixed(2)),
      },
    ]);

    XLSX.writeFile(
      workbook,
      `Energy_Gabungan_${MONTHS[monthlyMonth - 1]}_${monthlyYear}.xlsx`
    );
  };

  if (loading) {
    return (
      <Nais_Layout>
        <Container fluid className="p-1">
          <div style={{ padding: '24px', fontSize: '14px', color: '#475569' }}>
            Memuat dashboard Kubikal, Compressor, dan Line Produksi...
          </div>
        </Container>
      </Nais_Layout>
    );
  }

  return (
    <Nais_Layout>
      <Container fluid className="p-1">
        <div
          style={{
            padding: '14px',
            fontFamily: 'Segoe UI, Arial, sans-serif',
            minHeight: '100%',
            background: '#f8fafc',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              gap: '12px',
              flexWrap: 'wrap',
              marginBottom: '12px',
            }}
          >
            <div>
              <h2
                style={{
                  color: '#0f5fa8',
                  margin: 0,
                  fontSize: '21px',
                  fontWeight: 800,
                }}
              >
                ⚡ Otics Indonesia Energy Dashboard — {selectedLineLabel}
              </h2>
              <div
                lang="ja"
                style={{ marginTop: '2px', fontSize: '12px', color: '#64748b' }}
              >
                オティックス・インドネシア エネルギーダッシュボード
              </div>
              <p style={{ margin: '4px 0 0', fontSize: '13px', color: '#64748b' }}>
                Dashboard gabungan Kubikal, Compressor, dan seluruh Line Produksi PM 200 / PM 220
              </p>
              <div style={{ marginTop: '5px', fontSize: '12px', color: '#94a3b8' }}>
                API diperbarui:{' '}
                {latestApiUpdate ? latestApiUpdate.toLocaleString('id-ID') : '-'}
                {' · '}Dashboard mengambil data:{' '}
                {lastFetchedAt ? lastFetchedAt.toLocaleString('id-ID') : '-'}
              </div>
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'flex-end',
                gap: '8px',
                flexWrap: 'wrap',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '6px',
                  border: '1px solid #cbd5e1',
                  borderRadius: '8px',
                  backgroundColor: '#fff',
                }}
              >
                <span style={{ fontSize: '11px', color: '#64748b', padding: '0 3px' }}>
                  Show / Hide
                </span>
                <button
                  type="button"
                  onClick={() => setShowKubikal((current) => !current)}
                  style={{
                    padding: '6px 9px',
                    border: showKubikal ? '1px solid #2563eb' : '1px solid #cbd5e1',
                    borderRadius: '6px',
                    backgroundColor: showKubikal ? '#dbeafe' : '#f8fafc',
                    color: showKubikal ? '#1d4ed8' : '#64748b',
                    cursor: 'pointer',
                    fontSize: '12px',
                    fontWeight: 700,
                  }}
                >
                  {showKubikal ? '✓ ' : ''}Kubikal
                </button>
                <button
                  type="button"
                  onClick={() => setShowCompressor((current) => !current)}
                  style={{
                    padding: '6px 9px',
                    border: showCompressor
                      ? '1px solid #ea580c'
                      : '1px solid #cbd5e1',
                    borderRadius: '6px',
                    backgroundColor: showCompressor ? '#ffedd5' : '#f8fafc',
                    color: showCompressor ? '#c2410c' : '#64748b',
                    cursor: 'pointer',
                    fontSize: '12px',
                    fontWeight: 700,
                  }}
                >
                  {showCompressor ? '✓ ' : ''}Compressor
                </button>
                <button
                  type="button"
                  onClick={() => setShowProduction((current) => !current)}
                  style={{
                    padding: '6px 9px',
                    border: showProduction
                      ? '1px solid #16a34a'
                      : '1px solid #cbd5e1',
                    borderRadius: '6px',
                    backgroundColor: showProduction ? '#dcfce7' : '#f8fafc',
                    color: showProduction ? '#15803d' : '#64748b',
                    cursor: 'pointer',
                    fontSize: '12px',
                    fontWeight: 700,
                  }}
                >
                  {showProduction ? '✓ ' : ''}Line Produksi
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowKubikal(true);
                    setShowCompressor(true);
                    setShowProduction(true);
                  }}
                  style={{
                    padding: '6px 8px',
                    border: '1px solid #cbd5e1',
                    borderRadius: '6px',
                    backgroundColor: '#fff',
                    color: '#475569',
                    cursor: 'pointer',
                    fontSize: '12px',
                  }}
                >
                  Semua
                </button>
              </div>

              {showKubikal && (
              <FilterSelect label="Sumber Kubikal" japaneseLabel="キュービカル">
                <select
                  value={selectedLine}
                  onChange={(event) => setSelectedLine(event.target.value)}
                  style={selectStyle}
                >
                  {lineOptions.map((line) => (
                    <option key={line.value} value={line.value}>
                      {line.label}
                    </option>
                  ))}
                </select>
              </FilterSelect>
              )}

              <button
                type="button"
                onClick={() => fetchData(false)}
                disabled={refreshing}
                style={{
                  padding: '8px 11px',
                  border: 'none',
                  borderRadius: '7px',
                  backgroundColor: '#2563eb',
                  color: '#fff',
                  cursor: refreshing ? 'not-allowed' : 'pointer',
                  opacity: refreshing ? 0.65 : 1,
                  fontSize: '13px',
                  fontWeight: 600,
                }}
              >
                {refreshing ? 'Memperbarui...' : '↻ Refresh'}
              </button>

              <button
                type="button"
                onClick={exportToExcel}
                style={{
                  padding: '8px 11px',
                  border: 'none',
                  borderRadius: '7px',
                  backgroundColor: '#16a34a',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: 600,
                }}
              >
                📊 Export Excel
              </button>
            </div>
          </div>

          {error && (
            <div
              style={{
                padding: '10px 12px',
                marginBottom: '12px',
                borderRadius: '7px',
                border: '1px solid #fed7aa',
                backgroundColor: '#fff7ed',
                color: '#c2410c',
                fontSize: '13px',
              }}
            >
              {error}
            </div>
          )}

          {showKubikal && (
          <>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(165px, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <SummaryCard
              icon="⚡"
              title="Total Energy"
              japaneseTitle="全エネルギー"
              subtitle={`${MONTHS[shiftMonth - 1]} ${shiftYear}`}
              value={`${formatDecimal(metrics.totalKwh)} kWh`}
              accent="#0284c7"
            />
            <SummaryCard
              icon="💰"
              title="Estimated Cost"
              japaneseTitle="推定コスト"
              subtitle={`Tarif ${formatCurrency(COST_PER_KWH)}/kWh`}
              value={formatCurrency(metrics.totalCost)}
              accent="#d97706"
            />
            <SummaryCard
              icon="📈"
              title="Daily Average"
              japaneseTitle="1日平均"
              subtitle={`${metrics.daysCount} hari tercatat`}
              value={`${formatDecimal(metrics.avgDaily)} kWh`}
              accent="#16a34a"
            />
            <SummaryCard
              icon="☀️"
              title="Shift 1 Total"
              japaneseTitle="シフト1合計"
              subtitle="SHIFT 1"
              value={`${formatDecimal(metrics.totalShift1)} kWh`}
              accent="#0891b2"
            />
            <SummaryCard
              icon="🌙"
              title="Shift 2 Total"
              japaneseTitle="シフト2合計"
              subtitle="SHIFT 2"
              value={`${formatDecimal(metrics.totalShift2)} kWh`}
              accent="#4f46e5"
            />
            <SummaryCard
              icon="⬆️"
              title="Peak Shift"
              japaneseTitle="最大シフト"
              subtitle="Nilai shift tertinggi"
              value={`${formatDecimal(metrics.peakValue)} kWh`}
              accent="#dc2626"
            />
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                padding: '13px',
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
            >
              <BilingualHeading
                icon="🔥"
                title="CO₂ Emissions Summary"
                japaneseTitle="CO₂排出量概要"
                color="#dc2626"
              />
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '8px',
                  textAlign: 'center',
                  marginTop: '9px',
                }}
              >
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Monthly</div>
                  <strong>{formatDecimal(metrics.totalCo2)} kg</strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Daily Avg</div>
                  <strong>
                    {formatDecimal(
                      metrics.daysCount ? metrics.totalCo2 / metrics.daysCount : 0
                    )}{' '}
                    kg
                  </strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Projection</div>
                  <strong>{formatDecimal(metrics.totalCo2 * 12)} kg</strong>
                </div>
              </div>
            </div>

            <div
              style={{
                padding: '13px',
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
              }}
            >
              <BilingualHeading
                icon="💰"
                title="Cost Analysis"
                japaneseTitle="コスト分析"
                color="#d97706"
              />
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '8px',
                  textAlign: 'center',
                  marginTop: '9px',
                }}
              >
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Monthly</div>
                  <strong>{formatCurrency(metrics.totalCost)}</strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Daily Avg</div>
                  <strong>
                    {formatCurrency(
                      metrics.daysCount ? metrics.totalCost / metrics.daysCount : 0
                    )}
                  </strong>
                </div>
                <div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Per kWh</div>
                  <strong>{formatCurrency(COST_PER_KWH)}</strong>
                </div>
              </div>
            </div>
          </div>
          </>
          )}

          <SectionDivider
            title="MONTHLY — Konsumsi Energi Bulanan"
            japaneseTitle="月間エネルギー消費セクション"
            badge="MONTHLY DATA"
            accent="#0f5fa8"
            background="linear-gradient(135deg, #eff6ff 0%, #f8fbff 100%)"
            border="#93c5fd"
          />

          <div
            style={{
              backgroundColor: '#eef6ff',
              border: '1px solid #bfdbfe',
              borderRadius: '9px',
              padding: '12px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-end',
                gap: '10px',
                flexWrap: 'wrap',
              }}
            >
              <BilingualHeading
                title="Filter Bulanan"
                japaneseTitle="月間フィルター"
                color="#0f5fa8"
              />
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <FilterSelect label="Bulan" japaneseLabel="月">
                  <select
                    value={monthlyMonth}
                    onChange={(event) => setMonthlyMonth(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {monthlyMonthOptions.length ? (
                      monthlyMonthOptions.map((month) => (
                        <option key={month.number} value={month.number}>
                          {month.name}
                        </option>
                      ))
                    ) : (
                      <option value={monthlyMonth}>{MONTHS[monthlyMonth - 1]}</option>
                    )}
                  </select>
                </FilterSelect>
                <FilterSelect label="Tahun" japaneseLabel="年">
                  <select
                    value={monthlyYear}
                    onChange={(event) => setMonthlyYear(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {monthlyYearOptions.length ? (
                      monthlyYearOptions.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))
                    ) : (
                      <option value={monthlyYear}>{monthlyYear}</option>
                    )}
                  </select>
                </FilterSelect>
              </div>
            </div>
          </div>

          <div style={{ marginBottom: '12px' }}>
            <div style={{ marginBottom: '8px' }}>
              <BilingualHeading
                title="Tren Konsumsi Energi Bulanan"
                japaneseTitle="月間エネルギー消費傾向"
                color="#0f5fa8"
              />
              <div style={{ marginTop: '3px', fontSize: '12px', color: '#64748b' }}>
                Menampilkan Januari sampai {MONTHS[monthlyMonth - 1]} {monthlyYear}
              </div>
            </div>

            {showKubikal && (
              <MonthlyChartCard
                title={`Kubikal — ${selectedLineLabel}`}
                japaneseTitle="キュービカル月間エネルギー"
                data={kubMonthlyData}
                sourceText={KUB_MONTHLY_API_URL}
                large
              />
            )}

            {showProduction && (
              <div style={{ marginTop: '10px' }}>
                <MonthlyChartCard
                  title={`Total Line Produksi — ${PRODUCTION_LINES.length} Line`}
                  japaneseTitle="生産ライン月間エネルギー合計"
                  data={productionMonthlyData}
                  sourceText={`${PRODUCTION_ENDPOINT_SUMMARY} · endpoint monthly`}
                  large
                />
              </div>
            )}

            {showCompressor && (
              <div style={{ marginTop: '10px' }}>
                <MonthlyChartCard
                  title={`Total Comp — ${COMPRESSORS.length} Panel`}
                  japaneseTitle="コンプレッサー月間エネルギー合計"
                  data={totalCompressorMonthlyData}
                  sourceText={`${COMPRESSORS.length} endpoint compressor monthly`}
                  large
                  highlightPartialFebruary2026
                />
              </div>
            )}

            {showCompressor && (
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))',
                  gap: '10px',
                  marginTop: '10px',
                }}
              >
                {COMPRESSORS.map((compressor) => (
                  <MonthlyChartCard
                    key={compressor.key}
                    title={`Monthly ${compressor.label}`}
                    japaneseTitle={`${compressor.japaneseLabel} 月間エネルギー`}
                    data={compressorMonthlyData[compressor.key] || []}
                    sourceText={compressor.monthly}
                    highlightPartialFebruary2026
                  />
                ))}
              </div>
            )}

            {showCompressor && (
              <div style={{ marginTop: '10px' }}>
                <ParetoChartCard
                  title="Pareto Monthly Compressor"
                  japaneseTitle="コンプレッサー月間パレート分析"
                  data={monthlyCompressorPareto}
                  periodText={`Periode ${MONTHS[monthlyMonth - 1]} ${monthlyYear}`}
                  isPartialFebruary2026={
                    monthlyMonth === 2 && monthlyYear === 2026
                  }
                  footerContent={<PanelReferenceInfo />}
                />
              </div>
            )}

            {showProduction && (
              <div style={{ marginTop: '10px' }}>
                <ParetoChartCard
                  title="Pareto Monthly Line Produksi"
                  japaneseTitle="生産ライン月間パレート分析"
                  data={monthlyProductionPareto}
                  periodText={`Periode ${MONTHS[monthlyMonth - 1]} ${monthlyYear} · Top 15 + Lainnya`}
                />
              </div>
            )}
          </div>

          {showKubikal && showCompressor && showProduction && (
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))',
                gap: '10px',
                marginBottom: '12px',
              }}
            >
              <div
                style={{
                  backgroundColor: '#fff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '9px',
                  padding: '12px',
                  minWidth: 0,
                }}
              >
                <BilingualHeading
                  title="Komposisi dan Selisih Energi Kubikal"
                  japaneseTitle="キュービカル電力構成と差異"
                  color="#0f5fa8"
                />
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>
                  Line Produksi / WH Otics + Compressor + Selisih · {MONTHS[monthlyMonth - 1]} {monthlyYear}
                </div>
                <div style={{ width: '100%', height: '330px' }}>
                  {energyBalance.data.length ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={energyBalance.data}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="46%"
                          outerRadius={105}
                          label={({ name, percent }) =>
                            `${name} ${(percent * 100).toFixed(1)}%`
                          }
                        >
                          {energyBalance.data.map((entry, index) => (
                            <Cell
                              key={`${entry.name}-${index}`}
                              fill={PIE_COLORS[index % PIE_COLORS.length]}
                            />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value, name, item) => {
                            const signedValue = item?.payload?.signedValue ?? value;
                            return [`${formatDecimal(signedValue)} kWh`, name];
                          }}
                        />
                        <Legend verticalAlign="bottom" />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <EmptyChart message="Data komponen monthly belum tersedia untuk membuat pie chart." />
                  )}
                </div>
                <div
                  style={{
                    marginTop: '6px',
                    padding: '7px 9px',
                    borderRadius: '7px',
                    backgroundColor: '#f8fafc',
                    color: '#64748b',
                    fontSize: '11px',
                    lineHeight: 1.5,
                  }}
                >
                  Irisan selisih menggunakan nilai absolut agar dapat divisualkan pada
                  pie chart. Tanda (+) berarti energi Kubikal belum teralokasi, sedangkan
                  tanda (-) berarti total komponen melebihi Kubikal.
                </div>
              </div>

              <div
                style={{
                  backgroundColor: '#fff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '9px',
                  padding: '14px',
                }}
              >
                <BilingualHeading
                  title="Validasi Neraca Energi"
                  japaneseTitle="エネルギーバランス検証"
                />
                <div
                  style={{
                    marginTop: '12px',
                    padding: '10px',
                    borderRadius: '7px',
                    backgroundColor: '#f8fafc',
                    fontSize: '13px',
                    lineHeight: 1.7,
                  }}
                >
                  <div>
                    Kubikal: <strong>{formatDecimal(energyBalance.kubikal)} kWh</strong>
                  </div>
                  <div>
                    Line Produksi / WH Otics:{' '}
                    <strong>{formatDecimal(energyBalance.productionTotal)} kWh</strong>
                  </div>
                  {energyBalance.compressorValues.map((item) => (
                    <div key={item.key}>
                      {item.name}: <strong>{formatDecimal(item.value)} kWh</strong>
                    </div>
                  ))}
                  <div
                    style={{
                      borderTop: '1px solid #cbd5e1',
                      marginTop: '8px',
                      paddingTop: '8px',
                    }}
                  >
                    Total Compressor:{' '}
                    <strong>{formatDecimal(energyBalance.compressorTotal)} kWh</strong>
                  </div>
                  <div style={{ fontSize: '15px' }}>
                    Compressor + Line Produksi:{' '}
                    <strong>{formatDecimal(energyBalance.componentTotal)} kWh</strong>
                  </div>
                  <div
                    style={{
                      marginTop: '8px',
                      color:
                        Math.abs(energyBalance.variance) < 0.01
                          ? '#15803d'
                          : '#b45309',
                    }}
                  >
                    Selisih terhadap Kubikal:{' '}
                    <strong>
                      {formatDecimal(energyBalance.variance)} kWh (
                      {formatDecimal(energyBalance.variancePercent)}%)
                    </strong>
                  </div>
                </div>
                <div
                  style={{
                    marginTop: '10px',
                    fontSize: '12px',
                    lineHeight: 1.6,
                    color: '#475569',
                  }}
                >
                  Kubikal = Comp 19 + Comp 20 + Comp 21 + Comp 24 + seluruh Line
                  Produksi. Nilai Line Produksi berasal langsung dari endpoint PM 200
                  dan PM 220, bukan hasil pengurangan Kubikal.
                </div>
              </div>
            </div>
          )}

          <SectionDivider
            title="SHIFTLY — Konsumsi Energi Harian per Shift"
            japaneseTitle="シフト別日間エネルギー消費セクション"
            badge="SHIFTLY DATA"
            accent="#15803d"
            background="linear-gradient(135deg, #f0fdf4 0%, #f8fffb 100%)"
            border="#86efac"
          />

          <div
            style={{
              backgroundColor: '#f0fdf4',
              border: '1px solid #bbf7d0',
              borderRadius: '9px',
              padding: '12px',
              marginBottom: '12px',
            }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-end',
                gap: '10px',
                flexWrap: 'wrap',
              }}
            >
              <BilingualHeading
                title="Filter Shiftly"
                japaneseTitle="シフトフィルター"
                color="#15803d"
              />
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                <FilterSelect label="Bulan" japaneseLabel="月">
                  <select
                    value={shiftMonth}
                    onChange={(event) => setShiftMonth(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {shiftMonthOptions.length ? (
                      shiftMonthOptions.map((month) => (
                        <option key={month.number} value={month.number}>
                          {month.name}
                        </option>
                      ))
                    ) : (
                      <option value={shiftMonth}>{MONTHS[shiftMonth - 1]}</option>
                    )}
                  </select>
                </FilterSelect>
                <FilterSelect label="Tahun" japaneseLabel="年">
                  <select
                    value={shiftYear}
                    onChange={(event) => setShiftYear(Number(event.target.value))}
                    style={selectStyle}
                  >
                    {shiftYearOptions.length ? (
                      shiftYearOptions.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))
                    ) : (
                      <option value={shiftYear}>{shiftYear}</option>
                    )}
                  </select>
                </FilterSelect>
              </div>
            </div>
          </div>

          <div>
            <div style={{ marginBottom: '8px' }}>
              <BilingualHeading
                title="Konsumsi Energi Harian per Shift"
                japaneseTitle="シフト別日間エネルギー消費量"
                color="#15803d"
              />
              <div style={{ marginTop: '3px', fontSize: '12px', color: '#64748b' }}>
                Periode {MONTHS[shiftMonth - 1]} {shiftYear}
              </div>
            </div>

            {showKubikal && (
              <DailyChartCard
                title={`Kubikal — ${selectedLineLabel}`}
                japaneseTitle="キュービカル シフト別エネルギー"
                data={kubDailyData}
                sourceText={KUB_SHIFTLY_API_URL}
                chartKey="kubikal"
                large
              />
            )}

            {showProduction && (
              <div style={{ marginTop: '10px' }}>
                <DailyChartCard
                  title={`Total Line Produksi — ${PRODUCTION_LINES.length} Line`}
                  japaneseTitle="生産ラインシフト別エネルギー合計"
                  data={productionDailyData}
                  sourceText={`${PRODUCTION_ENDPOINT_SUMMARY} · endpoint shiftly`}
                  chartKey="production-total"
                  large
                />
              </div>
            )}

            {showCompressor && (
              <div style={{ marginTop: '10px' }}>
                <DailyChartCard
                  title={`Total Comp — ${COMPRESSORS.length} Panel`}
                  japaneseTitle="コンプレッサーシフト別エネルギー合計"
                  data={totalCompressorDailyData}
                  sourceText={`${COMPRESSORS.length} endpoint compressor shiftly`}
                  chartKey="compressor-total"
                  large
                />
              </div>
            )}

            {showCompressor && (
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))',
                  gap: '10px',
                  marginTop: '10px',
                }}
              >
                {COMPRESSORS.map((compressor) => (
                  <DailyChartCard
                    key={compressor.key}
                    title={`Shiftly ${compressor.label}`}
                    japaneseTitle={`${compressor.japaneseLabel} シフト別エネルギー`}
                    data={compressorDailyData[compressor.key] || []}
                    sourceText={compressor.shiftly}
                    chartKey={compressor.key}
                  />
                ))}
              </div>
            )}

            {showCompressor && (
              <div style={{ marginTop: '10px' }}>
                <ParetoChartCard
                  title="Pareto Shiftly Compressor"
                  japaneseTitle="コンプレッサーシフト別パレート分析"
                  data={shiftlyCompressorPareto}
                  periodText={`Periode ${MONTHS[shiftMonth - 1]} ${shiftYear}`}
                />
              </div>
            )}

            {showProduction && (
              <div style={{ marginTop: '10px' }}>
                <ParetoChartCard
                  title="Pareto Shiftly Line Produksi"
                  japaneseTitle="生産ラインシフト別パレート分析"
                  data={shiftlyProductionPareto}
                  periodText={`Periode ${MONTHS[shiftMonth - 1]} ${shiftYear} · Top 15 + Lainnya`}
                />
              </div>
            )}
          </div>
        </div>
      </Container>
    </Nais_Layout>
  );
};

export default MainDashboardListrik;
