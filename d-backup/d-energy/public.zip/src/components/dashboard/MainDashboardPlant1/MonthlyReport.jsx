import React, { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
} from 'recharts';

const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92; // kg per kWh
const API_BASE_URL = 'http://172.27.6.191:4000';

const MONTH_ORDER = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const numberFormatter = new Intl.NumberFormat('id-ID');
const currencyFormatter = new Intl.NumberFormat('id-ID', {
  style: 'currency',
  currency: 'IDR',
  maximumFractionDigits: 0,
});

const formatNumber = (value) => numberFormatter.format(Number(value) || 0);
const formatCurrency = (value) => currencyFormatter.format(Number(value) || 0);

const sortByMonthYear = (a, b) => {
  const yearDiff = Number(a.year) - Number(b.year);
  if (yearDiff !== 0) return yearDiff;
  return MONTH_ORDER.indexOf(a.month) - MONTH_ORDER.indexOf(b.month);
};

const MonthlyReport = () => {
  const [monthlyData, setMonthlyData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const controller = new AbortController();

    const fetchData = async () => {
      setLoading(true);
      setError('');

      try {
        const response = await axios.get(`${API_BASE_URL}/api/pm-monthly-kub-kwh`, {
          signal: controller.signal,
          timeout: 15000,
        });

        if (!response?.data || response.data.success !== true || !Array.isArray(response.data.data)) {
          throw new Error('Format respons API tidak valid.');
        }

        const grouped = response.data.data.reduce((acc, item) => {
          const month = item?.month || '-';
          const year = String(item?.year || '-');
          const key = `${month}-${year}`;
          const totalWh = Number(item?.total_wh ?? 0);

          if (!acc[key]) {
            acc[key] = { month, year, totalWh: 0 };
          }

          acc[key].totalWh += Number.isFinite(totalWh) ? totalWh : 0;
          return acc;
        }, {});

        const formatted = Object.values(grouped)
          .map((item) => {
            const kwh = Math.round(item.totalWh / 1000);
            const cost = Math.round(kwh * COST_PER_KWH);
            const co2Kg = Math.round(kwh * CO2_EMISSION_FACTOR);

            return {
              period: `${item.month} ${item.year}`,
              month: item.month,
              year: item.year,
              kwh,
              cost,
              co2Kg,
            };
          })
          .sort(sortByMonthYear);

        setMonthlyData(formatted);
      } catch (err) {
        if (axios.isCancel(err) || err?.name === 'CanceledError' || err?.name === 'AbortError') {
          return;
        }

        const message =
          err?.response?.data?.message ||
          err?.message ||
          'Gagal memuat data dari server.';

        setError(message);
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    };

    fetchData();
    return () => controller.abort();
  }, []);

  const totals = useMemo(() => {
    return monthlyData.reduce(
      (acc, item) => {
        acc.kwh += item.kwh;
        acc.cost += item.cost;
        acc.co2Kg += item.co2Kg;
        return acc;
      },
      { kwh: 0, cost: 0, co2Kg: 0 }
    );
  }, [monthlyData]);

  if (loading) return <div style={{ padding: '24px' }}>Memuat data...</div>;
  if (error) return <div style={{ padding: '24px', color: '#e74c3c' }}>{error}</div>;
  if (!monthlyData.length) return <div style={{ padding: '24px' }}>Data tidak tersedia.</div>;

  return (
    <div style={{ padding: '20px', fontFamily: 'Segoe UI, Arial, sans-serif', backgroundColor: '#ffffff' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', gap: '12px', flexWrap: 'wrap' }}>
        <h2 style={{ color: '#3498db', margin: 0, fontSize: '24px' }}>Laporan Konsumsi Energi Bulanan</h2>
        <div style={{ backgroundColor: '#e3f2fd', color: '#0d47a1', padding: '6px 12px', borderRadius: '6px', fontSize: '16px', fontWeight: 600 }}>
          Total: {formatNumber(totals.kwh)} kWh
        </div>
      </div>

      <div style={{ width: '100%', height: '420px', marginBottom: '28px' }}>
        <ResponsiveContainer>
          <BarChart data={monthlyData} margin={{ top: 20, right: 16, left: 8, bottom: 24 }}>
            <CartesianGrid strokeDasharray="4 4" stroke="#eee" />
            <XAxis
              dataKey="period"
              tick={{ fontSize: 12 }}
              angle={-20}
              textAnchor="end"
              interval={0}
              height={60}
            />
            <YAxis
              tick={{ fontSize: 12 }}
              tickFormatter={formatNumber}
              label={{
                value: 'kWh',
                angle: -90,
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontWeight: 'bold' },
              }}
            />
            <Tooltip
              formatter={(value, name) => {
                if (name === 'Konsumsi (kWh)') return [`${formatNumber(value)} kWh`, name];
                if (name === 'Biaya (Rp)') return [formatCurrency(value), name];
                if (name === 'CO₂ (kg)') return [`${formatNumber(value)} kg`, name];
                return [formatNumber(value), name];
              }}
              labelFormatter={(label) => `Periode: ${label}`}
              contentStyle={{ borderRadius: '8px', border: '1px solid #ddd' }}
            />
            <Legend />
            <Bar dataKey="kwh" fill="#3498db" radius={[4, 4, 0, 0]} name="Konsumsi (kWh)">
              <LabelList
                dataKey="kwh"
                position="top"
                formatter={formatNumber}
                fill="#333"
                fontSize={11}
                fontWeight="bold"
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default MonthlyReport;