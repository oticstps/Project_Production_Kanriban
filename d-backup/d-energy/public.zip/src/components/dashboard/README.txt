RunningMachine RECHARTS PRO

Isi:
- RunningMachine_RECHARTS_PRO.js
- common-rail-9-layout.png

Dependency yang digunakan:
- react
- recharts
- Tailwind CSS (mengikuti project sebelumnya)

Pastikan kedua file berada di folder yang sama karena component menggunakan:
import commonRailLayout from "./common-rail-9-layout.png";

Recharts yang digunakan:
PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
BarChart, Bar, CartesianGrid, XAxis, YAxis.
