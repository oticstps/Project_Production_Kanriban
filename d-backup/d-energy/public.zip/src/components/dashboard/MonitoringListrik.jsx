import React, { useEffect, useMemo, useState } from "react";
import * as mqtt from "mqtt";
import Layout from "../layout/Layout";

/*
  MonitoringListrik.jsx
  React JS + Vite + Tailwind

  Fitur:
  - Light theme
  - Tampilan lebih padat
  - Identitas panel tetap jelas
  - PM220 dan PM200 sejajar
  - Hijau jika data live
  - Orange jika data tidak live tetapi update terakhir masih kurang dari 1 jam
  - Merah jika data lebih dari atau sama dengan 1 jam
  - Abu-abu jika belum ada data
  - Nilai Wh otomatis menjadi kWh / MWh / GWh
  - Chart rolling 1 jam
  - MQTT over WebSocket
*/

const MQTT_URL =
  import.meta.env.VITE_MQTT_URL || "ws://192.168.137.241:9001/mqtt";

const MQTT_USERNAME = import.meta.env.VITE_MQTT_USERNAME || "";
const MQTT_PASSWORD = import.meta.env.VITE_MQTT_PASSWORD || "";

const ONE_HOUR_MS = 60 * 60 * 1000;
const STALE_MS = 2 * 60 * 1000;
const RED_ALERT_MS = ONE_HOUR_MS;
const MAX_POINTS = 240;

const PANELS = [
  ...Array.from({ length: 12 }, (_, i) => ({
    id: `cr${i + 1}`,
    label: `CR ${i + 1}`,
    meters: ["pm_220", "pm_200"],
  })),

  { id: "chsaa", label: "CHSAA", meters: ["pm_220", "pm_200"] },
  { id: "chsab", label: "CHSAB", meters: ["pm_220", "pm_200"] },
  { id: "chsac", label: "CHSAC", meters: ["pm_220", "pm_200"] },
  { id: "chab", label: "CHAB", meters: ["pm_220", "pm_200"] },
  { id: "chcd", label: "CHCD", meters: ["pm_220", "pm_200"] },
  { id: "chef", label: "CHEF", meters: ["pm_220", "pm_200"] },

  { id: "cc1", label: "CC 1", meters: ["pm_220", "pm_200"] },
  { id: "cc234", label: "CC 234", meters: ["pm_220", "pm_200"] },

  { id: "bs1", label: "BS 1", meters: ["pm_220", "pm_200"] },
  { id: "bs2", label: "BS 2", meters: ["pm_220", "pm_200"] },

  { id: "ret", label: "RET", meters: ["pm_220", "pm_200"] },
  { id: "ra", label: "RA", meters: ["pm_220", "pm_200"] },

  { id: "conn", label: "CONN", meters: ["pm_200"] },
  { id: "hla", label: "HLA", meters: ["pm_200"] },
];

const TOPICS = PANELS.flatMap((panel) =>
  panel.meters.map((meter) => `${meter}_${panel.id}`)
);

const METER_NAME = {
  pm_220: "PM220",
  pm_200: "PM200",
};

function getMqttConnect() {
  if (typeof mqtt.connect === "function") return mqtt.connect;
  if (typeof mqtt.default?.connect === "function") return mqtt.default.connect;
  if (typeof mqtt.default === "function") return mqtt.default;
  return null;
}

function parseTopic(topic) {
  const match = String(topic).match(/^(pm_220|pm_200)_(.+)$/);

  if (!match) return null;

  return {
    meter: match[1],
    panel: match[2],
  };
}

function parsePayload(message) {
  let text = "";

  try {
    if (typeof message === "string") {
      text = message;
    } else if (message instanceof ArrayBuffer) {
      text = new TextDecoder().decode(message);
    } else if (message instanceof Uint8Array) {
      text = new TextDecoder().decode(message);
    } else if (message?.toString) {
      text = message.toString();
    }
  } catch {
    text = "";
  }

  const clean = String(text).trim();

  if (!clean) return null;

  try {
    const json = JSON.parse(clean);

    if (typeof json === "number") return json;
    if (json?.value !== undefined) return Number(json.value);
    if (json?.payload !== undefined) return Number(json.payload);
    if (json?.data !== undefined) return Number(json.data);
  } catch {
    // Payload bukan JSON.
  }

  const value = Number(clean);

  return Number.isFinite(value) ? value : null;
}

function formatEnergy(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) {
    return "-";
  }

  const num = Number(value);
  const abs = Math.abs(num);

  if (abs >= 1_000_000_000) {
    return `${(num / 1_000_000_000).toFixed(2)} GWh`;
  }

  if (abs >= 1_000_000) {
    return `${(num / 1_000_000).toFixed(2)} MWh`;
  }

  if (abs >= 1_000) {
    return `${(num / 1_000).toFixed(2)} kWh`;
  }

  return `${num.toFixed(0)} Wh`;
}

function formatNumber(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) {
    return "-";
  }

  return new Intl.NumberFormat("id-ID", {
    maximumFractionDigits: 0,
  }).format(Number(value));
}

function shortTime(timestamp) {
  if (!timestamp) return "-";

  return new Intl.DateTimeFormat("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(new Date(timestamp));
}

function ageText(timestamp, now) {
  if (!timestamp) return "no data";

  const sec = Math.max(0, Math.floor((now - timestamp) / 1000));

  if (sec < 60) return `${sec}s`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m`;

  return "1h+";
}

function getReadingState(reading, now) {
  const hasData = Boolean(reading?.updatedAt);

  if (!hasData) {
    return {
      hasData: false,
      live: false,
      redAlert: false,
      stale: false,
      age: null,
      status: "empty",
    };
  }

  const age = now - reading.updatedAt;
  const live = age <= STALE_MS;

  // Sudah ditukar:
  // Orange/stale = tidak live, tetapi masih kurang dari 1 jam.
  // Merah/redAlert = tidak live dan sudah 1 jam atau lebih.
  const redAlert = !live && age >= RED_ALERT_MS;
  const stale = !live && age < RED_ALERT_MS;

  return {
    hasData,
    live,
    redAlert,
    stale,
    age,
    status: live ? "live" : redAlert ? "red" : stale ? "stale" : "empty",
  };
}

function Sparkline({ history = [], now, status = "empty" }) {
  const width = 120;
  const height = 18;
  const start = now - ONE_HOUR_MS;

  const data = history
    .filter((item) => item.time >= start)
    .slice(-MAX_POINTS);

  const lineColor =
    status === "live"
      ? "text-emerald-500"
      : status === "red"
      ? "text-red-500"
      : status === "stale"
      ? "text-orange-500"
      : "text-slate-400";

  const fillColor =
    status === "live"
      ? "fill-emerald-500"
      : status === "red"
      ? "fill-red-500"
      : status === "stale"
      ? "fill-orange-500"
      : "fill-slate-400";

  if (data.length < 2) {
    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="h-3.5 w-full">
        <line
          x1="3"
          y1="9"
          x2={width - 3}
          y2="9"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeOpacity="0.25"
          className="text-slate-400"
        />
      </svg>
    );
  }

  const values = data.map((item) => Number(item.value)).filter(Number.isFinite);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;

  const points = data
    .map((item) => {
      const xRatio = Math.min(1, Math.max(0, (item.time - start) / ONE_HOUR_MS));
      const yRatio = (Number(item.value) - min) / range;

      const x = 3 + xRatio * (width - 6);
      const y = height - 3 - yRatio * (height - 6);

      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  const last = data[data.length - 1];
  const lastXRatio = Math.min(1, Math.max(0, (last.time - start) / ONE_HOUR_MS));
  const lastYRatio = (Number(last.value) - min) / range;

  const lastX = 3 + lastXRatio * (width - 6);
  const lastY = height - 3 - lastYRatio * (height - 6);

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-3.5 w-full overflow-visible">
      <polyline
        points={points}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={lineColor}
      />

      <circle cx={lastX} cy={lastY} r="1.8" className={fillColor} />
    </svg>
  );
}

function SummaryBox({ label, value, sub, active }) {
  return (
    <div
      className={[
        "min-w-0 rounded-md border px-1.5 py-0.5 shadow-sm transition-all duration-300",
        active
          ? "border-emerald-400 bg-emerald-100 text-emerald-950 shadow-[0_0_10px_rgba(16,185,129,0.25)]"
          : "border-slate-200 bg-white text-slate-700",
      ].join(" ")}
    >
      <div className="truncate text-[8px] font-black uppercase tracking-wide text-slate-500">
        {label}
      </div>

      <div className="truncate text-xs font-black leading-tight">{value}</div>

      <div className="truncate text-[8px] font-medium text-slate-400">{sub}</div>
    </div>
  );
}

function MeterBox({ topic, reading, now, single = false }) {
  const meta = parseTopic(topic);
  const state = getReadingState(reading, now);

  return (
    <div
      title={`${topic} | ${formatEnergy(reading?.value)} | ${
        reading?.updatedAt ? shortTime(reading.updatedAt) : "no data"
      }`}
      className={[
        single ? "col-span-2" : "",
        "min-w-0 overflow-hidden rounded-md border px-1 py-0.5 transition-all duration-300",
        state.live
          ? "border-emerald-500 bg-emerald-100 shadow-[0_0_12px_rgba(16,185,129,0.45)]"
          : state.redAlert
          ? "border-red-500 bg-red-100 shadow-[0_0_12px_rgba(239,68,68,0.35)]"
          : state.stale
          ? "border-orange-300 bg-orange-50"
          : "border-slate-200 bg-slate-50",
      ].join(" ")}
    >
      <div className="flex min-w-0 items-center justify-between gap-1">
        <div className="flex min-w-0 items-center gap-1">
          <span
            className={[
              "h-1.5 w-1.5 shrink-0 rounded-full",
              state.live
                ? "bg-emerald-500 shadow-[0_0_7px_rgba(16,185,129,1)]"
                : state.redAlert
                ? "bg-red-500 shadow-[0_0_7px_rgba(239,68,68,0.8)]"
                : state.stale
                ? "bg-orange-500"
                : "bg-slate-300",
            ].join(" ")}
          />

          <span
            className={[
              "truncate text-[8px] font-black leading-none",
              state.live
                ? "text-emerald-950"
                : state.redAlert
                ? "text-red-900"
                : state.stale
                ? "text-orange-800"
                : "text-slate-500",
            ].join(" ")}
          >
            {METER_NAME[meta?.meter] || topic}
          </span>
        </div>

        <span
          className={[
            "shrink-0 text-[7px] font-bold",
            state.live
              ? "text-emerald-700"
              : state.redAlert
              ? "text-red-700"
              : state.stale
              ? "text-orange-700"
              : "text-slate-400",
          ].join(" ")}
        >
          {ageText(reading?.updatedAt, now)}
        </span>
      </div>

      <div
        className={[
          "mt-0.5 min-w-0 truncate text-center text-[10px] font-black tabular-nums leading-none",
          state.live
            ? "text-emerald-700"
            : state.redAlert
            ? "text-red-700"
            : state.stale
            ? "text-orange-700"
            : "text-slate-500",
        ].join(" ")}
      >
        {formatEnergy(reading?.value)}
      </div>

      <div className="mt-0.5 min-w-0 overflow-hidden">
        <Sparkline
          history={reading?.history || []}
          now={now}
          status={state.status}
        />
      </div>
    </div>
  );
}

function PanelCard({ panel, readings, now }) {
  const topics = panel.meters.map((meter) => `${meter}_${panel.id}`);

  const liveCount = topics.filter((topic) => {
    const reading = readings[topic];

    return reading?.updatedAt && now - reading.updatedAt <= STALE_MS;
  }).length;

  const hasData = topics.some((topic) => readings[topic]?.updatedAt);

  const lastUpdate = Math.max(
    ...topics.map((topic) => readings[topic]?.updatedAt || 0)
  );

  const latestAge = lastUpdate ? now - lastUpdate : null;

  // Sudah ditukar:
  // Orange/stale = tidak live, tetapi masih kurang dari 1 jam.
  // Merah/redAlert = tidak live dan sudah 1 jam atau lebih.
  const redAlert = hasData && liveCount === 0 && latestAge >= RED_ALERT_MS;
  const stale = hasData && liveCount === 0 && latestAge < RED_ALERT_MS;

  return (
    <div
      className={[
        "min-h-0 overflow-hidden rounded-md border bg-white transition-all duration-300",
        liveCount > 0
          ? "border-emerald-500 shadow-[0_0_14px_rgba(16,185,129,0.32)]"
          : redAlert
          ? "border-red-500 shadow-[0_0_14px_rgba(239,68,68,0.32)]"
          : stale
          ? "border-orange-300 shadow-sm"
          : "border-slate-200 shadow-sm",
      ].join(" ")}
    >
      <div
        className={[
          "flex items-center justify-between gap-1 border-b px-1.5 py-0.5",
          liveCount > 0
            ? "border-emerald-200 bg-emerald-100"
            : redAlert
            ? "border-red-200 bg-red-100"
            : stale
            ? "border-orange-100 bg-orange-50"
            : "border-slate-100 bg-slate-50",
        ].join(" ")}
      >
        <div className="min-w-0">
          <h3
            className={[
              "truncate text-[10px] font-black leading-none",
              liveCount > 0
                ? "text-emerald-950"
                : redAlert
                ? "text-red-900"
                : stale
                ? "text-orange-800"
                : "text-slate-700",
            ].join(" ")}
          >
            {panel.label}
          </h3>

          <div className="mt-0.5 truncate text-[7px] font-semibold text-slate-500">
            {lastUpdate ? shortTime(lastUpdate) : "no update"}
          </div>
        </div>

        <span
          className={[
            "shrink-0 rounded-full px-1 py-0.5 text-[8px] font-black leading-none",
            liveCount > 0
              ? "bg-emerald-600 text-white shadow-[0_0_8px_rgba(16,185,129,0.75)]"
              : redAlert
              ? "bg-red-600 text-white shadow-[0_0_8px_rgba(239,68,68,0.65)]"
              : stale
              ? "bg-orange-500 text-white"
              : "bg-slate-200 text-slate-500",
          ].join(" ")}
        >
          {liveCount}/{topics.length}
        </span>
      </div>

      <div className="grid min-w-0 grid-cols-2 gap-0.5 p-0.5">
        {topics.map((topic) => (
          <MeterBox
            key={topic}
            topic={topic}
            reading={readings[topic]}
            now={now}
            single={topics.length === 1}
          />
        ))}
      </div>
    </div>
  );
}

export default function MonitoringListrik() {
  const [status, setStatus] = useState("offline");
  const [statusText, setStatusText] = useState("Belum terkoneksi");
  const [readings, setReadings] = useState({});
  const [lastMessage, setLastMessage] = useState(null);
  const [messageCount, setMessageCount] = useState(0);
  const [now, setNow] = useState(Date.now());

  const activeTopics = useMemo(() => {
    return TOPICS.filter((topic) => {
      const reading = readings[topic];

      return reading?.updatedAt && now - reading.updatedAt <= STALE_MS;
    }).length;
  }, [readings, now]);

  const activePanels = useMemo(() => {
    return PANELS.filter((panel) =>
      panel.meters.some((meter) => {
        const reading = readings[`${meter}_${panel.id}`];

        return reading?.updatedAt && now - reading.updatedAt <= STALE_MS;
      })
    ).length;
  }, [readings, now]);

  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const connectFn = getMqttConnect();

    if (!connectFn) {
      setStatus("error");
      setStatusText("MQTT connect function tidak ditemukan");
      return;
    }

    const options = {
      clientId: `monitoring_listrik_${Date.now()}_${Math.random()
        .toString(16)
        .slice(2)}`,
      clean: true,
      keepalive: 60,
      reconnectPeriod: 2000,
      connectTimeout: 8000,
      protocolVersion: 4,
    };

    if (MQTT_USERNAME) options.username = MQTT_USERNAME;
    if (MQTT_PASSWORD) options.password = MQTT_PASSWORD;

    let client;

    try {
      client = connectFn(MQTT_URL, options);
    } catch (error) {
      setStatus("error");
      setStatusText(error?.message || "Gagal membuat koneksi MQTT");
      return;
    }

    client.on("connect", () => {
      setStatus("online");
      setStatusText("Terhubung ke MQTT broker");

      client.subscribe(TOPICS, { qos: 0 }, (err) => {
        if (err) {
          setStatus("error");
          setStatusText(`Gagal subscribe: ${err.message}`);
        } else {
          setStatusText(`Subscribe ${TOPICS.length} topic aktif`);
        }
      });
    });

    client.on("reconnect", () => {
      setStatus("reconnecting");
      setStatusText("Mencoba reconnect...");
    });

    client.on("close", () => {
      setStatus("offline");
      setStatusText("Koneksi tertutup");
    });

    client.on("offline", () => {
      setStatus("offline");
      setStatusText("MQTT offline");
    });

    client.on("error", (err) => {
      setStatus("error");
      setStatusText(err?.message || "MQTT error");
    });

    client.on("message", (topic, message) => {
      const meta = parseTopic(topic);

      if (!meta) return;

      const value = parsePayload(message);

      if (value === null || Number.isNaN(value)) return;

      const timestamp = Date.now();
      const cutoff = timestamp - ONE_HOUR_MS;

      setReadings((prev) => {
        const old = prev[topic];

        const history = [
          ...(old?.history || []),
          {
            time: timestamp,
            value,
          },
        ]
          .filter((item) => item.time >= cutoff)
          .slice(-MAX_POINTS);

        return {
          ...prev,
          [topic]: {
            topic,
            panel: meta.panel,
            meter: meta.meter,
            value,
            previousValue: old?.value ?? null,
            updatedAt: timestamp,
            history,
          },
        };
      });

      setLastMessage({
        topic,
        value,
        time: timestamp,
      });

      setMessageCount((count) => count + 1);
    });

    return () => {
      try {
        client.end(true);
      } catch {
        // ignore cleanup error
      }
    };
  }, []);

  const statusClass =
    status === "online"
      ? "bg-emerald-600 text-white shadow-[0_0_10px_rgba(16,185,129,0.8)]"
      : status === "reconnecting"
      ? "bg-orange-500 text-white"
      : status === "error"
      ? "bg-rose-600 text-white"
      : "bg-slate-300 text-slate-700";

  return (
    <>
      {/* <Layout> */}
      <div className="h-screen overflow-hidden bg-slate-100 text-slate-800">
        <div className="flex h-full flex-col gap-1 p-1">
          <header className="shrink-0 rounded-lg border border-slate-200 bg-white px-2 py-1 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <div className="flex min-w-0 items-center justify-end gap-1 text-[8px]">
                <span
                  className={`rounded-full px-1.5 py-0.5 font-black uppercase ${statusClass}`}
                >
                  {status}
                </span>

                <span className="max-w-[280px] truncate rounded-full bg-slate-100 px-1.5 py-0.5 font-semibold text-slate-500">
                  {statusText}
                </span>

                <span className="hidden max-w-[220px] truncate rounded-full bg-slate-100 px-1.5 py-0.5 font-semibold text-slate-500 xl:block">
                  {MQTT_URL}
                </span>
              </div>
            </div>
          </header>

          <section className="grid shrink-0 grid-cols-6 gap-1">
            <SummaryBox
              label="Panel"
              value={`${activePanels}/${PANELS.length}`}
              sub="live"
              active={activePanels > 0}
            />

            <SummaryBox
              label="Topic"
              value={`${activeTopics}/${TOPICS.length}`}
              sub="aktif"
              active={activeTopics > 0}
            />

            <SummaryBox
              label="Pesan"
              value={formatNumber(messageCount)}
              sub="total"
              active={messageCount > 0}
            />

            <SummaryBox
              label="Last"
              value={lastMessage?.topic || "-"}
              sub={lastMessage ? formatEnergy(lastMessage.value) : "waiting"}
              active={Boolean(lastMessage)}
            />

            <SummaryBox
              label="Update"
              value={lastMessage ? shortTime(lastMessage.time) : "-"}
              sub="last"
              active={Boolean(lastMessage)}
            />

            <SummaryBox
              label="Jam"
              value={shortTime(now)}
              sub="local"
              active={status === "online"}
            />
          </section>

          <main
            className="grid min-h-0 flex-1 gap-1 overflow-hidden"
            style={{
              gridTemplateColumns: "repeat(6, minmax(0, 1fr))",
              gridTemplateRows: `repeat(${Math.ceil(
                PANELS.length / 6
              )}, minmax(0, 1fr))`,
            }}
          >
            {PANELS.map((panel) => (
              <PanelCard
                key={panel.id}
                panel={panel}
                readings={readings}
                now={now}
              />
            ))}
          </main>
        </div>
      </div>
      {/* </Layout> */}
    </>
  );
}