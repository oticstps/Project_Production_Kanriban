import React, { useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import Layout from "../layout/Layout";

const API_BASE_URL = "http://172.27.6.191:4000/api/plts-p1-hourly";

const ACCEPTED_EXTENSIONS = [
  ".xlsx",
  ".xls",
  ".csv",
  ".txt",
  ".tsv",
  ".xlsb",
  ".ods",
];

function ConverterExelP1Hourly() {
  const fileInputRef = useRef(null);

  const [selectedFile, setSelectedFile] = useState(null);
  const [workbookData, setWorkbookData] = useState(null);
  const [sheetNames, setSheetNames] = useState([]);
  const [selectedSheet, setSelectedSheet] = useState("");
  const [jsonData, setJsonData] = useState([]);
  const [rawJsonText, setRawJsonText] = useState("");
  const [rangePreview, setRangePreview] = useState([]);
  const [fileInfo, setFileInfo] = useState(null);
  const [headerMode, setHeaderMode] = useState("auto");

  const [dateCustom, setDateCustom] = useState("");
  const [monitoringDate, setMonitoringDate] = useState("");
  const [monitoringRows, setMonitoringRows] = useState([]);

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isFetchingMonitoring, setIsFetchingMonitoring] = useState(false);
  const [error, setError] = useState("");
  const [importResult, setImportResult] = useState(null);

  const prettyJson = useMemo(() => {
    try {
      return JSON.stringify(jsonData, null, 2);
    } catch {
      return "[]";
    }
  }, [jsonData]);

  const resetAll = () => {
    setSelectedFile(null);
    setWorkbookData(null);
    setSheetNames([]);
    setSelectedSheet("");
    setJsonData([]);
    setRawJsonText("");
    setRangePreview([]);
    setFileInfo(null);
    setHeaderMode("auto");
    setError("");
    setImportResult(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const getExtension = (fileName = "") => {
    const lastDot = fileName.lastIndexOf(".");
    if (lastDot === -1) return "";
    return fileName.slice(lastDot).toLowerCase();
  };

  const isAcceptedFile = (file) => {
    const ext = getExtension(file?.name || "");
    return ACCEPTED_EXTENSIONS.includes(ext);
  };

  const normalizeKey = (key, index) => {
    if (key === undefined || key === null || String(key).trim() === "") {
      return `column_${index + 1}`;
    }

    return String(key)
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "_")
      .replace(/[^\w]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
  };

  const normalizeObjectKey = (key) => {
    return String(key || "")
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "_")
      .replace(/[^\w]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^_+|_+$/g, "");
  };

  const getValueByPossibleKeys = (row, possibleKeys) => {
    const normalizedRow = {};

    Object.keys(row || {}).forEach((key) => {
      normalizedRow[normalizeObjectKey(key)] = row[key];
    });

    for (const key of possibleKeys) {
      const normalizedKey = normalizeObjectKey(key);

      if (
        normalizedRow[normalizedKey] !== undefined &&
        normalizedRow[normalizedKey] !== null &&
        normalizedRow[normalizedKey] !== ""
      ) {
        return normalizedRow[normalizedKey];
      }
    }

    return "";
  };

  const normalizeTimeForBackend = (value) => {
    if (value === undefined || value === null || value === "") return "";

    if (typeof value === "number") {
      const fraction = value >= 1 ? value % 1 : value;
      const totalMinutes = Math.round(fraction * 24 * 60);
      const hour = Math.floor(totalMinutes / 60) % 24;
      const minute = totalMinutes % 60;

      return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
    }

    const text = String(value).trim();

    if (!text) return "";

    const decimalNumber = Number(text);

    if (!Number.isNaN(decimalNumber) && text.includes(".")) {
      const fraction = decimalNumber >= 1 ? decimalNumber % 1 : decimalNumber;
      const totalMinutes = Math.round(fraction * 24 * 60);
      const hour = Math.floor(totalMinutes / 60) % 24;
      const minute = totalMinutes % 60;

      return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
    }

    const match = text.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);

    if (!match) return "";

    const hour = Number(match[1]);
    const minute = Number(match[2]);

    if (hour < 0 || hour > 23) return "";
    if (minute < 0 || minute > 59) return "";

    return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
  };

  const isValidTimeValue = (value) => {
    return /^\d{2}:\d{2}$/.test(String(value || ""));
  };

  const normalizeRowForBackend = (row) => {
    const rawTime = getValueByPossibleKeys(row, [
      "x",
      "time",
      "jam",
      "energy_time",
      "column_1",
    ]);

    return {
      x: normalizeTimeForBackend(rawTime),

      production_kwh: getValueByPossibleKeys(row, [
        "pv_power",
        "pv power",
        "production",
        "production_kwh",
        "production kwh",
        "produksi",
        "column_2",
      ]),

      inverter1_kwh: getValueByPossibleKeys(row, [
        "inverter1",
        "inverter_1",
        "inverter 1",
        "inverter1_kwh",
        "inverter 1 kwh",
        "column_3",
      ]),

      inverter2_kwh: getValueByPossibleKeys(row, [
        "inverter2",
        "inverter_2",
        "inverter 2",
        "inverter2_kwh",
        "inverter 2 kwh",
        "column_4",
      ]),
    };
  };

  const prepareDataForBackend = () => {
    if (!Array.isArray(jsonData)) return [];

    return jsonData
      .filter((row) => row && typeof row === "object" && !Array.isArray(row))
      .map((row) => normalizeRowForBackend(row))
      .filter((row) => isValidTimeValue(row.x));
  };

  const readWorkbookSafely = async (file) => {
    const buffer = await file.arrayBuffer();

    return XLSX.read(buffer, {
      type: "array",
      raw: true,
      codepage: 65001,
      cellDates: false,
      cellText: true,
      WTF: false,
    });
  };

  const convertSheetToJson = (workbook, sheetName, mode = "auto") => {
    const worksheet = workbook.Sheets[sheetName];

    if (!worksheet) {
      throw new Error(`Sheet "${sheetName}" tidak ditemukan.`);
    }

    const previewRows = XLSX.utils.sheet_to_json(worksheet, {
      header: 1,
      defval: "",
      raw: true,
      blankrows: false,
    });

    setRangePreview(previewRows.slice(0, 10));

    let result = [];

    if (mode === "array") {
      result = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: "",
        raw: true,
        blankrows: false,
      });
    } else if (mode === "custom-header") {
      const rows = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: "",
        raw: true,
        blankrows: false,
      });

      if (rows.length === 0) {
        result = [];
      } else {
        const headers = rows[0].map((item, index) => normalizeKey(item, index));

        result = rows.slice(1).map((row) => {
          const obj = {};

          headers.forEach((header, index) => {
            obj[header] = row[index] ?? "";
          });

          return obj;
        });
      }
    } else {
      result = XLSX.utils.sheet_to_json(worksheet, {
        defval: "",
        raw: true,
        blankrows: false,
      });
    }

    setJsonData(result);
    setRawJsonText(JSON.stringify(result, null, 2));
    setImportResult(null);
  };

  const parseFile = async (file) => {
    if (!file) return;

    setIsLoading(true);
    setError("");
    setImportResult(null);

    try {
      if (!isAcceptedFile(file)) {
        throw new Error(
          "Format file tidak didukung. Gunakan file .xlsx, .xls, .csv, .txt, .tsv, .xlsb, atau .ods."
        );
      }

      const ext = getExtension(file.name);
      const workbook = await readWorkbookSafely(file);
      const names = workbook.SheetNames || [];

      if (names.length === 0) {
        throw new Error("File tidak memiliki sheet atau data yang bisa dibaca.");
      }

      setSelectedFile(file);
      setWorkbookData(workbook);
      setSheetNames(names);
      setSelectedSheet(names[0]);

      setFileInfo({
        name: file.name,
        size: file.size,
        type: file.type || ext || "unknown",
        lastModified: file.lastModified
          ? new Date(file.lastModified).toLocaleString("id-ID")
          : "-",
      });

      convertSheetToJson(workbook, names[0], headerMode);
    } catch (err) {
      console.error("Gagal membaca file:", err);
      setError(err.message || "Terjadi kesalahan saat membaca file.");
      setWorkbookData(null);
      setSheetNames([]);
      setSelectedSheet("");
      setJsonData([]);
      setRawJsonText("");
      setRangePreview([]);
      setFileInfo(null);
      setImportResult(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = async (event) => {
    const file = event.target.files?.[0];
    await parseFile(file);
  };

  const handleDrop = async (event) => {
    event.preventDefault();
    event.stopPropagation();

    const file = event.dataTransfer.files?.[0];
    await parseFile(file);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleSheetChange = (event) => {
    const newSheet = event.target.value;
    setSelectedSheet(newSheet);

    if (workbookData && newSheet) {
      try {
        convertSheetToJson(workbookData, newSheet, headerMode);
      } catch (err) {
        setError(err.message || "Gagal mengubah sheet.");
      }
    }
  };

  const handleHeaderModeChange = (event) => {
    const newMode = event.target.value;
    setHeaderMode(newMode);

    if (workbookData && selectedSheet) {
      try {
        convertSheetToJson(workbookData, selectedSheet, newMode);
      } catch (err) {
        setError(err.message || "Gagal mengubah mode header.");
      }
    }
  };

  const handleSaveToDatabase = async () => {
    try {
      setIsSaving(true);
      setError("");
      setImportResult(null);

      if (!dateCustom) {
        throw new Error("Tanggal data wajib dipilih terlebih dahulu.");
      }

      if (!Array.isArray(jsonData) || jsonData.length === 0) {
        throw new Error("Tidak ada data JSON untuk disimpan.");
      }

      if (headerMode === "array") {
        throw new Error(
          "Mode Array 2D tidak bisa langsung disimpan. Gunakan Auto Object atau Baris Pertama Jadi Header."
        );
      }

      const payloadData = prepareDataForBackend();

      if (payloadData.length === 0) {
        throw new Error(
          "Tidak ada data valid. Pastikan file memiliki kolom x, Pv Power, Inverter1, dan Inverter2."
        );
      }

      const response = await fetch(`${API_BASE_URL}/bulk`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          date_custom: dateCustom,
          data: payloadData,
        }),
      });

      const responseText = await response.text();

      let result = {};
      try {
        result = responseText ? JSON.parse(responseText) : {};
      } catch {
        throw new Error(responseText || "Response backend bukan JSON valid.");
      }

      if (!response.ok) {
        throw new Error(result.message || "Gagal menyimpan data ke database.");
      }

      setImportResult(result.result);

      alert(
        `Import selesai. Berhasil: ${result.result.successCount}, Gagal: ${result.result.failedCount}`
      );

      setMonitoringDate(dateCustom);
      await fetchMonitoringByDate(dateCustom);
    } catch (err) {
      console.error("Gagal simpan ke database:", err);
      setError(err.message || "Gagal simpan ke database.");
    } finally {
      setIsSaving(false);
    }
  };

  const fetchMonitoringByDate = async (targetDate = monitoringDate) => {
    try {
      setIsFetchingMonitoring(true);
      setError("");

      if (!targetDate) {
        throw new Error("Pilih tanggal monitoring terlebih dahulu.");
      }

      const response = await fetch(`${API_BASE_URL}?date=${targetDate}`);
      const responseText = await response.text();

      let result = {};
      try {
        result = responseText ? JSON.parse(responseText) : {};
      } catch {
        throw new Error(responseText || "Response backend bukan JSON valid.");
      }

      if (!response.ok) {
        throw new Error(result.message || "Gagal mengambil data monitoring.");
      }

      setMonitoringRows(Array.isArray(result.data) ? result.data : []);
    } catch (err) {
      console.error("Gagal mengambil monitoring:", err);
      setError(err.message || "Gagal mengambil data monitoring.");
      setMonitoringRows([]);
    } finally {
      setIsFetchingMonitoring(false);
    }
  };

  const renderTablePreview = () => {
    if (!Array.isArray(jsonData) || jsonData.length === 0) {
      return <div style={styles.emptyBox}>Tidak ada data untuk ditampilkan.</div>;
    }

    if (headerMode === "array") {
      return (
        <div style={styles.tableWrapper}>
          <table style={styles.table}>
            <tbody>
              {jsonData.slice(0, 10).map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {Array.isArray(row) &&
                    row.map((cell, cellIndex) => (
                      <td key={cellIndex} style={styles.td}>
                        {String(cell)}
                      </td>
                    ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    const firstRow = jsonData[0] || {};
    const columns = Object.keys(firstRow);

    return (
      <div style={styles.tableWrapper}>
        <table style={styles.table}>
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col} style={styles.th}>
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {jsonData.slice(0, 10).map((row, rowIndex) => (
              <tr key={rowIndex}>
                {columns.map((col) => (
                  <td key={`${rowIndex}-${col}`} style={styles.td}>
                    {String(row[col] ?? "")}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const renderMonitoringTable = () => {
    if (!Array.isArray(monitoringRows) || monitoringRows.length === 0) {
      return (
        <div style={styles.emptyBox}>
          Belum ada data monitoring. Pilih tanggal lalu klik Tampilkan Monitoring.
        </div>
      );
    }

    return (
      <div style={styles.tableWrapper}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>x</th>
              <th style={styles.th}>Pv Power</th>
              <th style={styles.th}>Inverter1</th>
              <th style={styles.th}>Inverter2</th>
            </tr>
          </thead>
          <tbody>
            {monitoringRows.map((row) => (
              <tr key={row.energy_date}>
                <td style={styles.td}>{row.x}</td>
                <td style={styles.td}>{row.production_kwh}</td>
                <td style={styles.td}>{row.inverter1_kwh}</td>
                <td style={styles.td}>{row.inverter2_kwh}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <Layout>
      <div style={styles.page}>
        <div style={styles.container}>
          <div style={styles.header}>
            <h1 style={styles.title}>Import PLTS P1 Hourly</h1>
            <p style={styles.subtitle}>
              Upload file Excel dengan kolom x, Pv Power, Inverter1, dan
              Inverter2. Tanggal diinput manual melalui date_custom.
            </p>
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Tanggal Data</h3>

            <div style={styles.controlRow}>
              <div style={styles.controlGroup}>
                <label style={styles.label}>date_custom</label>
                <input
                  type="date"
                  value={dateCustom}
                  onChange={(event) => setDateCustom(event.target.value)}
                  style={styles.input}
                />
              </div>
            </div>
          </div>

          <div
            style={styles.dropZone}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
          >
            <p style={styles.dropText}>Drag & drop file ke sini atau pilih manual</p>

            <button
              type="button"
              style={styles.primaryButton}
              onClick={() => fileInputRef.current?.click()}
            >
              Pilih File
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_EXTENSIONS.join(",")}
              onChange={handleFileChange}
              style={{ display: "none" }}
            />

            <p style={styles.supportText}>
              Format didukung: {ACCEPTED_EXTENSIONS.join(", ")}
            </p>
          </div>

          {isLoading && <div style={styles.infoBox}>Sedang membaca file...</div>}

          {isSaving && (
            <div style={styles.infoBox}>Sedang menyimpan data ke database...</div>
          )}

          {isFetchingMonitoring && (
            <div style={styles.infoBox}>Sedang mengambil data monitoring...</div>
          )}

          {error && <div style={styles.errorBox}>{error}</div>}

          {importResult && (
            <div style={styles.successBox}>
              Import selesai. Berhasil:{" "}
              <strong>{importResult.successCount}</strong>, Gagal:{" "}
              <strong>{importResult.failedCount}</strong>
            </div>
          )}

          {fileInfo && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Informasi File</h3>
              <div style={styles.infoGrid}>
                <div>
                  <strong>Nama:</strong> {fileInfo.name}
                </div>
                <div>
                  <strong>Ukuran:</strong> {(fileInfo.size / 1024).toFixed(2)} KB
                </div>
                <div>
                  <strong>Tipe:</strong> {fileInfo.type}
                </div>
                <div>
                  <strong>Last Modified:</strong> {fileInfo.lastModified}
                </div>
              </div>
            </div>
          )}

          {sheetNames.length > 0 && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Pengaturan Konversi</h3>

              <div style={styles.controlRow}>
                <div style={styles.controlGroup}>
                  <label style={styles.label}>Pilih Sheet</label>
                  <select
                    value={selectedSheet}
                    onChange={handleSheetChange}
                    style={styles.select}
                  >
                    {sheetNames.map((sheet) => (
                      <option key={sheet} value={sheet}>
                        {sheet}
                      </option>
                    ))}
                  </select>
                </div>

                <div style={styles.controlGroup}>
                  <label style={styles.label}>Mode Header</label>
                  <select
                    value={headerMode}
                    onChange={handleHeaderModeChange}
                    style={styles.select}
                  >
                    <option value="auto">Auto Object</option>
                    <option value="custom-header">Baris Pertama Jadi Header</option>
                    <option value="array">Array 2D</option>
                  </select>
                </div>
              </div>

              <div style={styles.buttonRow}>
                <button
                  type="button"
                  style={styles.saveButton}
                  onClick={handleSaveToDatabase}
                  disabled={isSaving}
                >
                  {isSaving ? "Menyimpan..." : "Simpan ke Database"}
                </button>

                <button
                  type="button"
                  style={styles.dangerButton}
                  onClick={resetAll}
                >
                  Reset
                </button>
              </div>
            </div>
          )}

          {rangePreview.length > 0 && (
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Preview Raw Sheet</h3>
              <div style={styles.tableWrapper}>
                <table style={styles.table}>
                  <tbody>
                    {rangePreview.map((row, rowIndex) => (
                      <tr key={rowIndex}>
                        {row.map((cell, cellIndex) => (
                          <td key={cellIndex} style={styles.td}>
                            {String(cell)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Preview Hasil JSON</h3>
            {renderTablePreview()}
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>Monitoring Per 5 Menit</h3>

            <div style={styles.controlRow}>
              <div style={styles.controlGroup}>
                <label style={styles.label}>Pilih Tanggal Monitoring</label>
                <input
                  type="date"
                  value={monitoringDate}
                  onChange={(event) => setMonitoringDate(event.target.value)}
                  style={styles.input}
                />
              </div>
            </div>

            <div style={styles.buttonRow}>
              <button
                type="button"
                style={styles.primaryButton}
                onClick={() => fetchMonitoringByDate()}
                disabled={isFetchingMonitoring}
              >
                {isFetchingMonitoring
                  ? "Mengambil Data..."
                  : "Tampilkan Monitoring"}
              </button>
            </div>

            <div style={{ marginTop: "16px" }}>{renderMonitoringTable()}</div>
          </div>

          <div style={styles.card}>
            <h3 style={styles.cardTitle}>JSON Output</h3>
            <textarea
              value={rawJsonText}
              readOnly
              style={styles.textarea}
              placeholder="Hasil JSON akan tampil di sini..."
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f5f7fb",
    padding: "24px",
    boxSizing: "border-box",
    fontFamily: "Arial, sans-serif",
  },
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
  },
  header: {
    marginBottom: "24px",
  },
  title: {
    margin: 0,
    fontSize: "28px",
    color: "#1f2937",
  },
  subtitle: {
    marginTop: "8px",
    color: "#6b7280",
    fontSize: "14px",
  },
  dropZone: {
    backgroundColor: "#ffffff",
    border: "2px dashed #cbd5e1",
    borderRadius: "12px",
    padding: "32px",
    textAlign: "center",
    marginBottom: "20px",
  },
  dropText: {
    marginBottom: "12px",
    color: "#334155",
    fontSize: "16px",
  },
  supportText: {
    marginTop: "12px",
    fontSize: "12px",
    color: "#64748b",
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: "12px",
    padding: "20px",
    marginBottom: "20px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
  },
  cardTitle: {
    marginTop: 0,
    marginBottom: "16px",
    fontSize: "18px",
    color: "#111827",
  },
  infoGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: "12px",
    color: "#374151",
    fontSize: "14px",
  },
  controlRow: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
    gap: "16px",
    marginBottom: "16px",
  },
  controlGroup: {
    display: "flex",
    flexDirection: "column",
  },
  label: {
    marginBottom: "8px",
    fontSize: "14px",
    fontWeight: "bold",
    color: "#374151",
  },
  input: {
    padding: "10px 12px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    fontSize: "14px",
    outline: "none",
  },
  select: {
    padding: "10px 12px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    fontSize: "14px",
    outline: "none",
  },
  buttonRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: "10px",
  },
  primaryButton: {
    backgroundColor: "#2563eb",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 18px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
  },
  saveButton: {
    backgroundColor: "#2563eb",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
  },
  dangerButton: {
    backgroundColor: "#dc2626",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    padding: "10px 16px",
    cursor: "pointer",
    fontSize: "14px",
  },
  infoBox: {
    backgroundColor: "#e0f2fe",
    color: "#075985",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  successBox: {
    backgroundColor: "#dcfce7",
    color: "#166534",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  errorBox: {
    backgroundColor: "#fee2e2",
    color: "#991b1b",
    padding: "12px 16px",
    borderRadius: "8px",
    marginBottom: "16px",
  },
  emptyBox: {
    padding: "20px",
    border: "1px dashed #cbd5e1",
    borderRadius: "8px",
    color: "#6b7280",
    textAlign: "center",
  },
  tableWrapper: {
    overflowX: "auto",
    border: "1px solid #e5e7eb",
    borderRadius: "8px",
    maxHeight: "520px",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: "13px",
  },
  th: {
    backgroundColor: "#f8fafc",
    borderBottom: "1px solid #e5e7eb",
    padding: "10px",
    textAlign: "left",
    whiteSpace: "nowrap",
    position: "sticky",
    top: 0,
    zIndex: 1,
  },
  td: {
    borderBottom: "1px solid #f1f5f9",
    padding: "10px",
    verticalAlign: "top",
    whiteSpace: "nowrap",
  },
  textarea: {
    width: "100%",
    minHeight: "360px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
    padding: "12px",
    boxSizing: "border-box",
    fontFamily: "monospace",
    fontSize: "13px",
    resize: "vertical",
    outline: "none",
  },
};

export default ConverterExelP1Hourly;