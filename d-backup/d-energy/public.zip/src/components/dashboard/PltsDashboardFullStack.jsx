import React, { useEffect, useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import Layout from '../layout/Layout';

const API_BASE_URL = '/api';
const BASE_ELECTRICITY_RATE_PER_KWH = 2165;
const PLTS_REDUCTION_PERCENTAGE = 0.30;
const PLTS_REDUCTION_RATE_PER_KWH = BASE_ELECTRICITY_RATE_PER_KWH * PLTS_REDUCTION_PERCENTAGE; // 649.5
const PLTS_REDUCED_RATE_PER_KWH = BASE_ELECTRICITY_RATE_PER_KWH - PLTS_REDUCTION_RATE_PER_KWH; // 1515.5
const CO2_REDUCTION_KG_PER_KWH = 0.85;

// Target bulanan untuk gauge. Silakan sesuaikan dengan target perusahaan.
const TARGET_P1_MONTHLY_KWH = 15000;
const TARGET_TOTAL_CO2_MONTHLY_KG = 10000;

const MONTH_OPTIONS = [
  { value: '01', label: 'Januari', japanese: '1月' },
  { value: '02', label: 'Februari', japanese: '2月' },
  { value: '03', label: 'Maret', japanese: '3月' },
  { value: '04', label: 'April', japanese: '4月' },
  { value: '05', label: 'Mei', japanese: '5月' },
  { value: '06', label: 'Juni', japanese: '6月' },
  { value: '07', label: 'Juli', japanese: '7月' },
  { value: '08', label: 'Agustus', japanese: '8月' },
  { value: '09', label: 'September', japanese: '9月' },
  { value: '10', label: 'Oktober', japanese: '10月' },
  { value: '11', label: 'November', japanese: '11月' },
  { value: '12', label: 'Desember', japanese: '12月' },
];

function getDateOnly(value) {
  if (!value) return '';
  if (typeof value === 'string') return value.slice(0, 10);

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return date.toISOString().slice(0, 10);
}

function formatDate(value) {
  const dateOnly = getDateOnly(value);
  if (!dateOnly) return '-';

  const [year, month, day] = dateOnly.split('-');
  const date = new Date(Number(year), Number(month) - 1, Number(day));

  return date.toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
  });
}

function getDateTimeOnly(value) {
  if (!value) return '';

  if (typeof value === 'string') {
    return value.replace('T', ' ').slice(0, 19);
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return '';

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hour = String(date.getHours()).padStart(2, '0');
  const minute = String(date.getMinutes()).padStart(2, '0');
  const second = String(date.getSeconds()).padStart(2, '0');

  return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
}

function formatHour(value) {
  const dateTimeOnly = getDateTimeOnly(value);

  if (!dateTimeOnly) return '-';

  return dateTimeOnly.slice(11, 16);
}

function formatDateHour(value) {
  const dateOnly = getDateOnly(value);
  const hourOnly = formatHour(value);

  if (!dateOnly || !hourOnly || hourOnly === '-') return '-';

  const [, month, day] = dateOnly.split('-');

  return `${day}/${month} ${hourOnly}`;
}

function toNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function normalizeP1(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateOnly(item.energy_date),
    date_label: formatDate(item.energy_date),
    plts_production_kwh: toNumber(item.plts_production_kwh ?? item.production_kwh),
    inverter1_kwh: toNumber(item.inverter1_kwh),
    inverter2_kwh: toNumber(item.inverter2_kwh),
  }));
}

function normalizeP2(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateOnly(item.energy_date),
    date_label: formatDate(item.energy_date),
    purchased_from_grid_kwh: toNumber(item.purchased_from_grid_kwh),
    plts_production_kwh: toNumber(item.plts_production_kwh ?? item.generated_by_pv_kwh),
    fed_to_grid_kwh: toNumber(item.fed_to_grid_kwh),
    consumed_by_appliances_kwh: toNumber(item.consumed_by_appliances_kwh),
  }));
}

function normalizeP1Hourly(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateTimeOnly(item.energy_date),
    date_custom: getDateOnly(item.date_custom ?? item.energy_date),
    time_label: formatHour(item.energy_date),
    datetime_label: formatDateHour(item.energy_date),
    plts_production_kwh: toNumber(item.plts_production_kwh ?? item.production_kwh),
    inverter1_kwh: toNumber(item.inverter1_kwh),
    inverter2_kwh: toNumber(item.inverter2_kwh),
  }));
}

function normalizeP2Hourly(rows = []) {
  return rows.map((item) => ({
    energy_date: getDateTimeOnly(item.energy_date),
    date_custom: getDateOnly(item.date_custom ?? item.energy_date),
    time_label: formatHour(item.energy_date),
    datetime_label: formatDateHour(item.energy_date),
    purchased_from_grid_kwh: toNumber(item.purchased_from_grid_kwh),
    plts_production_kwh: toNumber(item.plts_production_kwh ?? item.generated_by_pv_kwh ?? item.production_kwh),
    fed_to_grid_kwh: toNumber(item.fed_to_grid_kwh),
    consumed_by_appliances_kwh: toNumber(item.consumed_by_appliances_kwh),
  }));
}

function sumBy(data, key) {
  return data.reduce((total, item) => total + toNumber(item[key]), 0);
}

function maxBy(data, key) {
  return data.reduce((max, item) => Math.max(max, toNumber(item[key])), 0);
}

function formatNumber(value) {
  return new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(toNumber(value));
}

function formatCurrency(value) {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(toNumber(value));
}

function formatRupiahPlain(value) {
  return `Rp ${formatNumber(value)}`;
}

function formatCo2(valueKg) {
  const kg = toNumber(valueKg);

  if (kg >= 1000) {
    return `${formatNumber(kg / 1000)} ton`;
  }

  return `${formatNumber(kg)} kg`;
}

function formatPercent(value) {
  return `${formatNumber(value)}%`;
}

function filterByDate(data, startDate, endDate) {
  return data.filter((item) => {
    if (!item.energy_date) return false;
    if (startDate && item.energy_date < startDate) return false;
    if (endDate && item.energy_date > endDate) return false;
    return true;
  });
}

function filterHourlyBySingleDate(data, selectedDate) {
  return data.filter((item) => {
    if (!item.date_custom) return false;
    if (!selectedDate) return false;
    return item.date_custom === selectedDate;
  });
}

function getMinDate(...datasets) {
  const dates = datasets.flat().map((item) => item.energy_date).filter(Boolean).sort();
  return dates[0] || '';
}

function getMaxDate(...datasets) {
  const dates = datasets.flat().map((item) => item.energy_date).filter(Boolean).sort();
  return dates[dates.length - 1] || '';
}

function getTodayDateString() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getCurrentMonthStart() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}-01`;
}

function getCurrentYear() {
  return String(new Date().getFullYear());
}

function getCurrentMonth() {
  return String(new Date().getMonth() + 1).padStart(2, '0');
}

function getMonthStartDate(year, month) {
  return `${year}-${month}-01`;
}

function getMonthEndDate(year, month) {
  const today = getTodayDateString();
  const currentYear = getCurrentYear();
  const currentMonth = getCurrentMonth();

  if (String(year) === currentYear && String(month) === currentMonth) {
    return today;
  }

  const lastDate = new Date(Number(year), Number(month), 0).getDate();
  return `${year}-${month}-${String(lastDate).padStart(2, '0')}`;
}

function createYearOptions(...datasets) {
  const years = datasets
    .flat()
    .map((item) => String(item.energy_date || '').slice(0, 4))
    .filter(Boolean);

  years.push(getCurrentYear());

  return [...new Set(years)].sort((a, b) => Number(b) - Number(a));
}

function buildPvComparisonData(p1Rows = [], p2Rows = []) {
  const p2Map = new Map(
    p2Rows.map((item) => [
      item.energy_date,
      item.plts_production_kwh,
    ])
  );

  return p1Rows.map((p1Item) => {
    const p1Production = toNumber(p1Item.plts_production_kwh);
    const p2Production = toNumber(p2Map.get(p1Item.energy_date));

    return {
      energy_date: p1Item.energy_date,
      date_label: p1Item.date_label,
      plant1_plts_production_kwh: p1Production,
      plant2_plts_production_kwh: p2Production,
      difference_kwh: p1Production - p2Production,
    };
  });
}

function buildCo2AnalysisData(pvComparisonRows = []) {
  return pvComparisonRows.map((item) => {
    const plant1Co2Reduced = toNumber(item.plant1_plts_production_kwh) * CO2_REDUCTION_KG_PER_KWH;
    const plant2Co2Reduced = toNumber(item.plant2_plts_production_kwh) * CO2_REDUCTION_KG_PER_KWH;

    return {
      ...item,
      plant1_co2_reduced_kg: plant1Co2Reduced,
      plant2_co2_reduced_kg: plant2Co2Reduced,
      total_co2_reduced_kg: plant1Co2Reduced + plant2Co2Reduced,
    };
  });
}

function StatCard({ label, japaneseLabel, value, unit }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm sm:px-4 sm:py-3">
      <p className="truncate text-[10px] font-semibold uppercase tracking-wide text-slate-500 sm:text-xs">{label}</p>
      {japaneseLabel && <p className="mt-0.5 truncate text-[10px] font-medium text-slate-400">{japaneseLabel}</p>}
      <div className="mt-1 flex items-end gap-1">
        <span className="truncate text-lg font-black text-slate-900 sm:text-xl">{value}</span>
        {unit && <span className="mb-0.5 text-[10px] font-semibold text-slate-500 sm:text-xs">{unit}</span>}
      </div>
    </div>
  );
}

function GaugeCard({ title, japaneseTitle, value = 0, max = 100, unit = '%', color = '#10b981', subtitle = '', reverse = false }) {
  const safeValue = toNumber(value);
  const safeMax = toNumber(max) > 0 ? toNumber(max) : 100;
  const percent = clamp((safeValue / safeMax) * 100, 0, 100);
  const displayPercent = unit === '%' ? safeValue : percent;
  const gaugePercent = unit === '%' ? clamp(safeValue, 0, 100) : percent;
  const statusText = reverse
    ? gaugePercent <= 40
      ? 'Good / 良好'
      : gaugePercent <= 70
        ? 'Watch / 注意'
        : 'High / 高い'
    : gaugePercent >= 80
      ? 'Good / 良好'
      : gaugePercent >= 50
        ? 'Progress / 進行中'
        : 'Low / 低い';

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-3 shadow-sm sm:p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="truncate text-sm font-black text-slate-800">{title}</h3>
          {japaneseTitle && <p className="truncate text-[11px] font-semibold text-slate-400">{japaneseTitle}</p>}
        </div>
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600">{statusText}</span>
      </div>

      <div className="mt-3 flex items-center justify-center">
        <div
          className="relative flex h-32 w-32 items-center justify-center rounded-full sm:h-36 sm:w-36"
          style={{
            background: `conic-gradient(${color} ${gaugePercent}%, #e5e7eb ${gaugePercent}% 100%)`,
          }}
        >
          <div className="flex h-22 w-22 flex-col items-center justify-center rounded-full bg-white shadow-inner sm:h-24 sm:w-24">
            <span className="text-2xl font-black text-slate-900">{formatNumber(displayPercent)}</span>
            <span className="text-xs font-bold text-slate-500">{unit === '%' ? '%' : '達成率'}</span>
          </div>
        </div>
      </div>

      <div className="mt-3 text-center">
        <p className="text-xs font-bold text-slate-700">
          {unit === '%' ? `${formatNumber(safeValue)}%` : `${formatNumber(safeValue)} / ${formatNumber(safeMax)} ${unit}`}
        </p>
        {subtitle && <p className="mt-1 text-[11px] leading-relaxed text-slate-500">{subtitle}</p>}
      </div>
    </div>
  );
}

function PlantPanel({ title, japaneseTitle, subtitle, japaneseSubtitle, badge, children }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-md shadow-slate-200/70 sm:p-4">
      <div className="mb-3 flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
        <div className="min-w-0">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">{title}</p>
          <p className="mt-0.5 text-[11px] font-semibold text-slate-400">{japaneseTitle}</p>
          <h2 className="mt-1 truncate text-lg font-black text-slate-950 sm:text-xl">{subtitle}</h2>
          <p className="mt-0.5 text-xs text-slate-500">{japaneseSubtitle}</p>
        </div>
        <div className="shrink-0 rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700 sm:text-xs">
          {badge}
        </div>
      </div>
      {children}
    </section>
  );
}

function ChartCard({ title, japaneseTitle, description, children }) {
  return (
    <div className="mt-3 rounded-2xl border border-slate-100 bg-slate-50 p-3">
      <div className="mb-2">
        <h3 className="text-sm font-black text-slate-900 sm:text-base">{title}</h3>
        {japaneseTitle && <p className="text-[11px] font-semibold text-emerald-700">{japaneseTitle}</p>}
        {description && <p className="text-[11px] text-slate-500 sm:text-xs">{description}</p>}
      </div>
      {children}
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="flex h-full items-center justify-center rounded-xl border border-dashed border-slate-300 bg-white px-4 text-center text-xs text-slate-500">
      Tidak ada data pada rentang tanggal ini
      <br />
      選択した日付範囲にデータがありません
    </div>
  );
}

function LoadingBox() {
  return (
    <div className="flex min-h-[260px] items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white text-sm text-slate-500">
      Memuat data dashboard... / ダッシュボードデータを読み込み中...
    </div>
  );
}

function ErrorBox({ message }) {
  return (
    <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700">
      <p className="font-bold">Gagal memuat data / データの読み込みに失敗しました</p>
      <p className="mt-1 text-sm">{message}</p>
    </div>
  );
}

export default function App() {
  const [p1Data, setP1Data] = useState([]);
  const [p2Data, setP2Data] = useState([]);
  const [p1HourlyData, setP1HourlyData] = useState([]);
  const [p2HourlyData, setP2HourlyData] = useState([]);
  const [hourlyDate, setHourlyDate] = useState(getTodayDateString());
  const [hourlyLoading, setHourlyLoading] = useState(false);
  const [hourlyError, setHourlyError] = useState('');
  const [selectedYear, setSelectedYear] = useState(getCurrentYear());
  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  const [startDate, setStartDate] = useState(getCurrentMonthStart());
  const [endDate, setEndDate] = useState(getTodayDateString());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        setLoading(true);
        setError('');

        const [p1Response, p2Response] = await Promise.all([
          fetch(`${API_BASE_URL}/plts-p1-daily-full-stack`),
          fetch(`${API_BASE_URL}/plts-p2-daily-full-stack`),
        ]);

        if (!p1Response.ok) {
          throw new Error('Endpoint P1 tidak dapat diakses');
        }

        if (!p2Response.ok) {
          throw new Error('Endpoint P2 tidak dapat diakses');
        }

        const p1Json = await p1Response.json();
        const p2Json = await p2Response.json();

        const normalizedP1 = normalizeP1(p1Json.data || []);
        const normalizedP2 = normalizeP2(p2Json.data || []);

        setP1Data(normalizedP1);
        setP2Data(normalizedP2);

        const currentYear = getCurrentYear();
        const currentMonth = getCurrentMonth();
        const currentMonthStart = getMonthStartDate(currentYear, currentMonth);
        const currentMonthEnd = getMonthEndDate(currentYear, currentMonth);

        setSelectedYear(currentYear);
        setSelectedMonth(currentMonth);
        setStartDate(currentMonthStart);
        setEndDate(currentMonthEnd);
        setHourlyDate(currentMonthEnd);
      } catch (err) {
        setError(err.message || 'Terjadi kesalahan saat mengambil data');
      } finally {
        setLoading(false);
      }
    }

    fetchDashboardData();
  }, []);

  useEffect(() => {
    async function fetchHourlyData() {
      try {
        setHourlyLoading(true);
        setHourlyError('');

        const selectedDate = hourlyDate || getTodayDateString();

        const [p1HourlyResponse, p2HourlyResponse] = await Promise.all([
          fetch(`${API_BASE_URL}/plts-p1-hourly-full-stack?date=${selectedDate}&limit=2000&order=ASC`),
          fetch(`${API_BASE_URL}/plts-p2-hourly-full-stack?date=${selectedDate}&limit=2000&order=ASC`),
        ]);

        if (!p1HourlyResponse.ok) {
          throw new Error('Endpoint hourly P1 tidak dapat diakses');
        }

        if (!p2HourlyResponse.ok) {
          throw new Error('Endpoint hourly P2 tidak dapat diakses');
        }

        const p1HourlyJson = await p1HourlyResponse.json();
        const p2HourlyJson = await p2HourlyResponse.json();

        setP1HourlyData(normalizeP1Hourly(p1HourlyJson.data || []));
        setP2HourlyData(normalizeP2Hourly(p2HourlyJson.data || []));
      } catch (err) {
        setP1HourlyData([]);
        setP2HourlyData([]);
        setHourlyError(err.message || 'Terjadi kesalahan saat mengambil data hourly');
      } finally {
        setHourlyLoading(false);
      }
    }

    fetchHourlyData();
  }, [hourlyDate]);


  const minAvailableDate = useMemo(() => getMinDate(p1Data, p2Data), [p1Data, p2Data]);
  const maxAvailableDate = useMemo(() => getMaxDate(p1Data, p2Data), [p1Data, p2Data]);
  const yearOptions = useMemo(() => createYearOptions(p1Data, p2Data), [p1Data, p2Data]);

  const filteredP1Data = useMemo(() => {
    return filterByDate(p1Data, startDate, endDate);
  }, [p1Data, startDate, endDate]);

  const filteredP2Data = useMemo(() => {
    return filterByDate(p2Data, startDate, endDate);
  }, [p2Data, startDate, endDate]);

  const filteredP1HourlyData = useMemo(() => {
    return filterHourlyBySingleDate(p1HourlyData, hourlyDate);
  }, [p1HourlyData, hourlyDate]);

  const filteredP2HourlyData = useMemo(() => {
    return filterHourlyBySingleDate(p2HourlyData, hourlyDate);
  }, [p2HourlyData, hourlyDate]);

  const p1Summary = useMemo(() => {
    const totalProduction = sumBy(filteredP1Data, 'plts_production_kwh');

    return {
      totalProduction,
      inverter1: sumBy(filteredP1Data, 'inverter1_kwh'),
      inverter2: sumBy(filteredP1Data, 'inverter2_kwh'),
      peakProduction: maxBy(filteredP1Data, 'plts_production_kwh'),
      pltsReducedValue: totalProduction * PLTS_REDUCED_RATE_PER_KWH,
      estimatedSaving: totalProduction * PLTS_REDUCTION_RATE_PER_KWH,
      co2Reduced: totalProduction * CO2_REDUCTION_KG_PER_KWH,
    };
  }, [filteredP1Data]);

  const p2Summary = useMemo(() => {
    const totalConsumption = sumBy(filteredP2Data, 'consumed_by_appliances_kwh');
    const purchasedGrid = sumBy(filteredP2Data, 'purchased_from_grid_kwh');
    const generatedPv = sumBy(filteredP2Data, 'plts_production_kwh');

    return {
      totalConsumption,
      generatedPv,
      purchasedGrid,
      fedGrid: sumBy(filteredP2Data, 'fed_to_grid_kwh'),
      consumptionCost: totalConsumption * BASE_ELECTRICITY_RATE_PER_KWH,
      gridCost: purchasedGrid * BASE_ELECTRICITY_RATE_PER_KWH,
      co2Reduced: generatedPv * CO2_REDUCTION_KG_PER_KWH,
      pvContribution: totalConsumption > 0 ? (generatedPv / totalConsumption) * 100 : 0,
      gridDependency: totalConsumption > 0 ? (purchasedGrid / totalConsumption) * 100 : 0,
    };
  }, [filteredP2Data]);

  const p1HourlySummary = useMemo(() => {
    return {
      totalProduction: sumBy(filteredP1HourlyData, 'plts_production_kwh'),
      inverter1: sumBy(filteredP1HourlyData, 'inverter1_kwh'),
      inverter2: sumBy(filteredP1HourlyData, 'inverter2_kwh'),
      peakProduction: maxBy(filteredP1HourlyData, 'plts_production_kwh'),
    };
  }, [filteredP1HourlyData]);

  const p2HourlySummary = useMemo(() => {
    return {
      generatedPv: sumBy(filteredP2HourlyData, 'plts_production_kwh'),
      purchasedGrid: sumBy(filteredP2HourlyData, 'purchased_from_grid_kwh'),
      fedGrid: sumBy(filteredP2HourlyData, 'fed_to_grid_kwh'),
      totalConsumption: sumBy(filteredP2HourlyData, 'consumed_by_appliances_kwh'),
      peakPv: maxBy(filteredP2HourlyData, 'plts_production_kwh'),
    };
  }, [filteredP2HourlyData]);

  const pvComparisonData = useMemo(() => {
    return buildPvComparisonData(filteredP1Data, filteredP2Data);
  }, [filteredP1Data, filteredP2Data]);

  const pvComparisonSummary = useMemo(() => {
    const plant1Total = sumBy(pvComparisonData, 'plant1_plts_production_kwh');
    const plant2Total = sumBy(pvComparisonData, 'plant2_plts_production_kwh');

    return {
      plant1Total,
      plant2Total,
      difference: plant1Total - plant2Total,
    };
  }, [pvComparisonData]);

  const co2AnalysisData = useMemo(() => {
    return buildCo2AnalysisData(pvComparisonData);
  }, [pvComparisonData]);

  const co2Summary = useMemo(() => {
    const plant1Co2Reduced = sumBy(co2AnalysisData, 'plant1_co2_reduced_kg');
    const plant2Co2Reduced = sumBy(co2AnalysisData, 'plant2_co2_reduced_kg');
    const totalCo2Reduced = plant1Co2Reduced + plant2Co2Reduced;
    const totalPvGenerated = pvComparisonSummary.plant1Total + pvComparisonSummary.plant2Total;
    const estimatedSaving = totalPvGenerated * PLTS_REDUCTION_RATE_PER_KWH;
    const pltsReducedCost = totalPvGenerated * PLTS_REDUCED_RATE_PER_KWH;
    const totalDays = co2AnalysisData.length;
    const plant1Contribution = totalCo2Reduced > 0 ? (plant1Co2Reduced / totalCo2Reduced) * 100 : 0;
    const plant2Contribution = totalCo2Reduced > 0 ? (plant2Co2Reduced / totalCo2Reduced) * 100 : 0;

    return {
      plant1Co2Reduced,
      plant2Co2Reduced,
      totalCo2Reduced,
      totalPvGenerated,
      estimatedSaving,
      pltsReducedCost,
      averageCo2PerDay: totalDays > 0 ? totalCo2Reduced / totalDays : 0,
      plant1Contribution,
      plant2Contribution,
      achievementPercent: TARGET_TOTAL_CO2_MONTHLY_KG > 0 ? (totalCo2Reduced / TARGET_TOTAL_CO2_MONTHLY_KG) * 100 : 0,
    };
  }, [co2AnalysisData, pvComparisonSummary]);

  const gaugeSummary = useMemo(() => {
    return {
      p1ProductionAchievement: TARGET_P1_MONTHLY_KWH > 0 ? (p1Summary.totalProduction / TARGET_P1_MONTHLY_KWH) * 100 : 0,
      p1Co2Achievement: TARGET_TOTAL_CO2_MONTHLY_KG > 0 ? (p1Summary.co2Reduced / TARGET_TOTAL_CO2_MONTHLY_KG) * 100 : 0,
      p2PvContribution: p2Summary.pvContribution,
      p2GridDependency: p2Summary.gridDependency,
    };
  }, [p1Summary, p2Summary]);

  function applyMonthFilter(year, month) {
    const monthStart = getMonthStartDate(year, month);
    const monthEnd = getMonthEndDate(year, month);

    setSelectedYear(year);
    setSelectedMonth(month);
    setStartDate(monthStart);
    setEndDate(monthEnd);
    setHourlyDate(monthEnd);
  }

  function resetFilter() {
    const currentYear = getCurrentYear();
    const currentMonth = getCurrentMonth();
    applyMonthFilter(currentYear, currentMonth);
  }

  return (
    <Layout>
      <main className="min-h-screen bg-gradient-to-br from-slate-50 via-stone-50 to-emerald-50 p-3 text-slate-900 sm:p-4 lg:p-5">
        <div className="mx-auto max-w-[1700px]">
          <header className="mb-4 rounded-2xl border border-slate-200 bg-white/85 p-4 shadow-sm backdrop-blur sm:p-5">
            <div className="min-w-0">
                <p className="text-xs font-bold uppercase tracking-[0.25em] text-emerald-600">PLTS Monitoring</p>
                <h1 className="mt-1 text-xl font-extrabold tracking-tight text-slate-700 sm:text-2xl">
                  Dashboard Harian Plant 1 & Plant 2
                </h1>
                <p className="mt-1 text-xs text-slate-600 sm:text-sm">
                  2分割表示：左側はPlant 1、右側はPlant 2。日別の発電量・消費量・電力料金・CO2削減量を監視します。
                </p>
                <p className="mt-1 text-xs text-slate-500 sm:text-sm">
                  Dashboard dilengkapi gauge, analisa CO2 reduction, filter tahun dan bulan, serta bar chart perbandingan PV.
                </p>
            </div>
          </header>

          {loading && <LoadingBox />}
          {!loading && error && <ErrorBox message={error} />}

          {!loading && !error && (
            <>
              <section className="mb-4 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-md shadow-slate-200/70 sm:p-4">
                <div className="mb-3 grid gap-3 border-b border-slate-100 pb-3 xl:grid-cols-[1fr_auto] xl:items-end">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">Hourly PV Production</p>
                    <p className="mt-0.5 text-[11px] font-semibold text-slate-400">時間別PV発電量</p>
                    <h2 className="mt-1 text-lg font-black text-slate-800 sm:text-xl">
                      Produksi Hourly Plant 1 dan Plant 2
                    </h2>
                    <p className="mt-0.5 text-xs text-slate-500">
                      Bar chart hourly dibatasi hanya satu hari. Plant 1 menggunakan production_kwh, Plant 2 menggunakan generated_by_pv_kwh.
                    </p>
                  </div>

                  <div className="grid gap-2 xl:min-w-[620px]">
                    <label className="block rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                      <span className="text-[11px] font-bold uppercase text-slate-500">Tanggal Hourly / 日付</span>
                      <input
                        type="date"
                        value={hourlyDate}
                        min={startDate || minAvailableDate}
                        max={endDate || maxAvailableDate}
                        onChange={(event) => setHourlyDate(event.target.value)}
                        className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                      />
                      <p className="mt-1 text-[11px] font-medium text-slate-500">
                        Menampilkan data hourly khusus tanggal {hourlyDate || '-'}.
                      </p>
                    </label>

                    <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
                      <StatCard
                        label="Hourly P1"
                        japaneseLabel="P1時間別総発電量"
                        value={formatNumber(p1HourlySummary.totalProduction)}
                        unit="kWh"
                      />
                      <StatCard
                        label="Peak P1"
                        japaneseLabel="P1最大発電量"
                        value={formatNumber(p1HourlySummary.peakProduction)}
                        unit="kWh"
                      />
                      <StatCard
                        label="Hourly P2 PV"
                        japaneseLabel="P2時間別PV発電量"
                        value={formatNumber(p2HourlySummary.generatedPv)}
                        unit="kWh"
                      />
                      <StatCard
                        label="Peak P2 PV"
                        japaneseLabel="P2最大PV発電量"
                        value={formatNumber(p2HourlySummary.peakPv)}
                        unit="kWh"
                      />
                    </div>

                    {hourlyLoading && (
                      <p className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-500">
                        Memuat data hourly... / 時間別データを読み込み中...
                      </p>
                    )}

                    {hourlyError && (
                      <p className="rounded-xl bg-red-50 px-3 py-2 text-xs font-semibold text-red-700">
                        {hourlyError}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                  <ChartCard
                    title="Plant 1 - Hourly PV Production"
                    japaneseTitle="Plant 1 時間別発電量"
                    description="Bar chart produksi hourly Plant 1 khusus satu hari"
                  >
                    <div className="h-[260px] sm:h-[320px]">
                      {filteredP1HourlyData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={filteredP1HourlyData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="datetime_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plts_production_kwh"
                              name="Plant 1 Hourly Production / P1時間別発電量"
                              fill="#10b981"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard
                    title="Plant 2 - Hourly PV Production"
                    japaneseTitle="Plant 2 時間別PV発電量"
                    description="Bar chart PV hourly Plant 2 khusus satu hari"
                  >
                    <div className="h-[260px] sm:h-[320px]">
                      {filteredP2HourlyData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={filteredP2HourlyData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="datetime_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plts_production_kwh"
                              name="Plant 2 Hourly PV / P2時間別PV発電量"
                              fill="#6366f1"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>
                </div>
              </section>


              <section className="mb-4 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-md shadow-slate-200/70 sm:p-4">
                <div className="mb-3 grid gap-3 border-b border-slate-100 pb-3 xl:grid-cols-[1fr_auto] xl:items-end">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">PV Comparison</p>
                    <p className="mt-0.5 text-[11px] font-semibold text-slate-400">PV比較</p>
                    <h2 className="mt-1 text-lg font-black text-slate-800 sm:text-xl">
                      Perbandingan Plant 1 plts_production_kwh vs Plant 2 plts_production_kwh
                    </h2>
                    <p className="mt-0.5 text-xs text-slate-500">
                      Bar chart dipisah kiri dan kanan sesuai plant. Plant 1は左側、Plant 2は右側に表示します。
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <StatCard label="Total P1" japaneseLabel="P1総発電量" value={formatNumber(pvComparisonSummary.plant1Total)} unit="kWh" />
                    <StatCard label="Total P2 PV" japaneseLabel="P2 PV総発電量" value={formatNumber(pvComparisonSummary.plant2Total)} unit="kWh" />
                    <StatCard label="Selisih" japaneseLabel="差分" value={formatNumber(pvComparisonSummary.difference)} unit="kWh" />
                  </div>
                </div>

                <div className="mb-3 grid gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
                  <div className="rounded-xl bg-white px-3 py-2 shadow-sm ring-1 ring-slate-200 sm:col-span-3">
                    <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Harga listrik & PLTS reduce / 電力単価</p>
                    <p className="mt-0.5 text-sm font-black text-slate-950">
                      Tarif konvensional <span className="font-semibold text-slate-500">(base)</span> {formatRupiahPlain(BASE_ELECTRICITY_RATE_PER_KWH)} / kWh
                    </p>
                    <p className="mt-0.5 text-xs font-bold text-amber-700">
                      Reduce 30%: {formatRupiahPlain(PLTS_REDUCTION_RATE_PER_KWH)} / kWh
                    </p>
                    <p className="mt-0.5 text-xs font-bold text-emerald-700">
                      Harga PLTS setelah reduce: {formatRupiahPlain(PLTS_REDUCED_RATE_PER_KWH)} / kWh
                    </p>
                  </div>

                  <label className="block">
                    <span className="text-[11px] font-bold uppercase text-slate-500">Tahun / 年</span>
                    <select
                      value={selectedYear}
                      onChange={(event) => applyMonthFilter(event.target.value, selectedMonth)}
                      className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                    >
                      {yearOptions.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="block">
                    <span className="text-[11px] font-bold uppercase text-slate-500">Bulan / 月</span>
                    <select
                      value={selectedMonth}
                      onChange={(event) => applyMonthFilter(selectedYear, event.target.value)}
                      className="mt-1 w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                    >
                      {MONTH_OPTIONS.map((month) => (
                        <option key={month.value} value={month.value}>
                          {month.label} / {month.japanese}
                        </option>
                      ))}
                    </select>
                  </label>

                  <button
                    type="button"
                    onClick={resetFilter}
                    className="rounded-xl bg-slate-950 px-3 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-slate-800"
                  >
                    Bulan Ini / 今月
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                  <ChartCard
                    title="Plant 1 - plts_production_kwh"
                    japaneseTitle="Plant 1 発電量"
                    description="Bar chart khusus produksi harian Plant 1"
                  >
                    <div className="h-[240px] sm:h-[300px]">
                      {pvComparisonData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={pvComparisonData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="date_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plant1_plts_production_kwh"
                              name="Plant 1 plts_production_kwh / P1発電量"
                              fill="#10b981"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard
                    title="Plant 2 - plts_production_kwh"
                    japaneseTitle="Plant 2 PV発電量"
                    description="Bar chart khusus PV harian Plant 2"
                  >
                    <div className="h-[240px] sm:h-[300px]">
                      {pvComparisonData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={pvComparisonData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="date_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar
                              dataKey="plant2_plts_production_kwh"
                              name="Plant 2 plts_production_kwh / P2 PV発電量"
                              fill="#6366f1"
                              radius={[6, 6, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>
                </div>
              </section>

              <section className="mb-4 rounded-2xl border border-emerald-100 bg-white/95 p-3 shadow-md shadow-emerald-100/70 sm:p-4">
                <div className="mb-3 grid gap-3 border-b border-emerald-50 pb-3 xl:grid-cols-[1fr_auto] xl:items-end">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">CO2 Reduction Analysis</p>
                    <p className="mt-0.5 text-[11px] font-semibold text-slate-400">CO2削減分析</p>
                    <h2 className="mt-1 text-lg font-black text-slate-800 sm:text-xl">
                      Analisa Pengurangan Emisi dari Produksi PV
                    </h2>
                    <p className="mt-0.5 text-xs text-slate-500">
                      Estimasi CO2 dihitung dari total PV Plant 1 dan Plant 2 dengan faktor {CO2_REDUCTION_KG_PER_KWH} kg CO2/kWh. Saving dihitung dari nilai reduce 30%, yaitu {formatRupiahPlain(PLTS_REDUCTION_RATE_PER_KWH)} per kWh. Harga PLTS setelah reduce adalah {formatRupiahPlain(PLTS_REDUCED_RATE_PER_KWH)} per kWh.
                    </p>
                  </div>

                  <div className="rounded-xl border border-emerald-100 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
                    <p className="font-black">Rumus / 計算式</p>
                    <p className="mt-0.5 font-semibold">CO2 = PV kWh × {CO2_REDUCTION_KG_PER_KWH} kg CO2/kWh</p>
                    <p className="mt-0.5 font-semibold">Saving = PV kWh × {formatRupiahPlain(PLTS_REDUCTION_RATE_PER_KWH)} / kWh</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 lg:grid-cols-5">
                  <StatCard label="Total PV" japaneseLabel="PV総発電量" value={formatNumber(co2Summary.totalPvGenerated)} unit="kWh" />
                  <StatCard label="CO2 Reduce" japaneseLabel="CO2削減量" value={formatCo2(co2Summary.totalCo2Reduced)} />
                  <StatCard label="Avg CO2/Hari" japaneseLabel="日平均CO2削減" value={formatCo2(co2Summary.averageCo2PerDay)} />
                  <StatCard label="Biaya PLTS Reduce" japaneseLabel="太陽光発電料金" value={formatCurrency(co2Summary.pltsReducedCost)} />
                  <StatCard label="Estimasi Saving 30%" japaneseLabel="推定削減金額" value={formatCurrency(co2Summary.estimatedSaving)} />
                </div>

                <div className="mt-3 grid grid-cols-1 gap-3 lg:grid-cols-[1.2fr_0.8fr]">
                  <ChartCard
                    title="Daily CO2 Reduction"
                    japaneseTitle="日別CO2削減量"
                    description="P1 plts_production_kwh dan P2 plts_production_kwh dikonversi ke estimasi CO2 reduction"
                  >
                    <div className="h-[240px] sm:h-[300px]">
                      {co2AnalysisData.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={co2AnalysisData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="date_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar dataKey="plant1_co2_reduced_kg" name="P1 CO2削減 / P1 CO2 Reduce" stackId="co2" fill="#10b981" radius={[6, 6, 0, 0]} />
                            <Bar dataKey="plant2_co2_reduced_kg" name="P2 CO2削減 / P2 CO2 Reduce" stackId="co2" fill="#6366f1" radius={[6, 6, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard
                    title="Insight Kontribusi"
                    japaneseTitle="貢献度インサイト"
                    description="Komposisi kontribusi CO2 reduction berdasarkan plant"
                  >
                    <div className="space-y-3 rounded-xl bg-white p-3">
                      <div>
                        <div className="mb-1 flex items-center justify-between text-xs font-bold text-slate-600">
                          <span>Plant 1 / プラント1</span>
                          <span>{formatPercent(co2Summary.plant1Contribution)}</span>
                        </div>
                        <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                          <div className="h-full rounded-full bg-emerald-500" style={{ width: `${co2Summary.plant1Contribution}%` }} />
                        </div>
                        <p className="mt-1 text-[11px] text-slate-500">{formatCo2(co2Summary.plant1Co2Reduced)} dari plts_production_kwh</p>
                      </div>

                      <div>
                        <div className="mb-1 flex items-center justify-between text-xs font-bold text-slate-600">
                          <span>Plant 2 / プラント2</span>
                          <span>{formatPercent(co2Summary.plant2Contribution)}</span>
                        </div>
                        <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                          <div className="h-full rounded-full bg-indigo-500" style={{ width: `${co2Summary.plant2Contribution}%` }} />
                        </div>
                        <p className="mt-1 text-[11px] text-slate-500">{formatCo2(co2Summary.plant2Co2Reduced)} dari plts_production_kwh</p>
                      </div>

                      <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">
                        <p className="font-black text-slate-800">Catatan / 注記</p>
                        <p className="mt-1">
                          Nilai CO2 reduction adalah estimasi. Ubah konstanta CO2_REDUCTION_KG_PER_KWH bila perusahaan memakai faktor emisi resmi yang berbeda.
                        </p>
                      </div>
                    </div>
                  </ChartCard>
                </div>
              </section>
              <section className="mb-4 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-md shadow-slate-200/70 sm:p-4">
                <div className="mb-3 border-b border-slate-100 pb-3">
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-600">Main Gauge Indicator</p>
                  <p className="mt-0.5 text-[11px] font-semibold text-slate-400">主要ゲージ指標</p>
                  <h2 className="mt-1 text-lg font-black text-slate-800 sm:text-xl">Ringkasan Performa Bulanan</h2>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Gauge membantu membaca capaian produksi, kontribusi PV, ketergantungan grid, dan CO2 reduction secara cepat.
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
                  <GaugeCard
                    title="P1 Production"
                    japaneseTitle="P1発電達成率"
                    value={p1Summary.totalProduction}
                    max={TARGET_P1_MONTHLY_KWH}
                    unit="kWh"
                    color="#10b981"
                    subtitle={`Target bulanan ${formatNumber(TARGET_P1_MONTHLY_KWH)} kWh`}
                  />

                  <GaugeCard
                    title="CO2 Reduction"
                    japaneseTitle="CO2削減達成率"
                    value={co2Summary.totalCo2Reduced}
                    max={TARGET_TOTAL_CO2_MONTHLY_KG}
                    unit="kg"
                    color="#0ea5e9"
                    subtitle={`Target bulanan ${formatCo2(TARGET_TOTAL_CO2_MONTHLY_KG)}`}
                  />

                  <GaugeCard
                    title="P2 PV Contribution"
                    japaneseTitle="P2 PV寄与率"
                    value={gaugeSummary.p2PvContribution}
                    max={100}
                    unit="%"
                    color="#f59e0b"
                    subtitle="PV terhadap total konsumsi Plant 2"
                  />

                  <GaugeCard
                    title="Grid Dependency"
                    japaneseTitle="系統依存率"
                    value={gaugeSummary.p2GridDependency}
                    max={100}
                    unit="%"
                    color="#6366f1"
                    subtitle="Semakin kecil semakin baik / 低いほど良い"
                    reverse
                  />
                </div>
              </section>
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                <PlantPanel
                  title="Plant 1"
                  japaneseTitle="プラント1"
                  subtitle="P1 - Produksi Harian"
                  japaneseSubtitle="日別発電量"
                  badge={`${filteredP1Data.length} data`}
                >
                  <div className="grid grid-cols-2 gap-2 xl:grid-cols-4">
                    <StatCard label="Total Produksi" japaneseLabel="総発電量" value={formatNumber(p1Summary.totalProduction)} unit="kWh" />
                    <StatCard label="Peak Harian" japaneseLabel="日最大発電量" value={formatNumber(p1Summary.peakProduction)} unit="kWh" />
                    <StatCard label="Biaya PLTS P1" japaneseLabel="太陽光発電料金" value={formatCurrency(p1Summary.pltsReducedValue)} />
                    <StatCard label="Saving 30% P1" japaneseLabel="推定削減金額" value={formatCurrency(p1Summary.estimatedSaving)} />
                    <StatCard label="Inverter 1" japaneseLabel="インバータ1" value={formatNumber(p1Summary.inverter1)} unit="kWh" />
                    <StatCard label="Inverter 2" japaneseLabel="インバータ2" value={formatNumber(p1Summary.inverter2)} unit="kWh" />
                    <StatCard label="CO2 Reduce" japaneseLabel="CO2削減量" value={formatCo2(p1Summary.co2Reduced)} />
                  </div>

                  <ChartCard
                    title="Chart kWh Harian P1"
                    japaneseTitle="P1 日別発電量チャート"
                    description="plts_production_kwh, inverter1_kwh, inverter2_kwh"
                  >
                    <div className="h-[240px] sm:h-[280px] xl:h-[300px]">
                      {filteredP1Data.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <ComposedChart data={filteredP1Data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <defs>
                              <linearGradient id="p1Production" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                                <stop offset="95%" stopColor="#10b981" stopOpacity={0.02} />
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="date_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Area
                              type="monotone"
                              dataKey="plts_production_kwh"
                              name="Produksi / 発電量"
                              stroke="#10b981"
                              fill="url(#p1Production)"
                              strokeWidth={3}
                            />
                            <Line
                              type="monotone"
                              dataKey="inverter1_kwh"
                              name="Inverter 1 / インバータ1"
                              stroke="#6366f1"
                              strokeWidth={2}
                              dot={false}
                            />
                            <Line
                              type="monotone"
                              dataKey="inverter2_kwh"
                              name="Inverter 2 / インバータ2"
                              stroke="#f59e0b"
                              strokeWidth={2}
                              dot={false}
                            />
                          </ComposedChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard title="Perbandingan Inverter P1" japaneseTitle="P1 インバータ比較">
                    <div className="h-[190px] sm:h-[220px]">
                      {filteredP1Data.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={filteredP1Data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="date_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar dataKey="inverter1_kwh" name="Inverter 1 / インバータ1" fill="#6366f1" radius={[6, 6, 0, 0]} />
                            <Bar dataKey="inverter2_kwh" name="Inverter 2 / インバータ2" fill="#f59e0b" radius={[6, 6, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>
                </PlantPanel>

                <PlantPanel
                  title="Plant 2"
                  japaneseTitle="プラント2"
                  subtitle="P2 - Konsumsi Harian"
                  japaneseSubtitle="日別消費電力量"
                  badge={`${filteredP2Data.length} data`}
                >
                  <div className="grid grid-cols-2 gap-2 xl:grid-cols-3">
                    <StatCard label="Total Konsumsi" japaneseLabel="総消費電力量" value={formatNumber(p2Summary.totalConsumption)} unit="kWh" />
                    <StatCard label="PV Generate" japaneseLabel="PV発電量" value={formatNumber(p2Summary.generatedPv)} unit="kWh" />
                    <StatCard label="Estimasi Biaya Aktual" japaneseLabel="推定電気料金" value={formatCurrency(p2Summary.consumptionCost)} />
                    <StatCard label="Beli Grid" japaneseLabel="系統から購入" value={formatNumber(p2Summary.purchasedGrid)} unit="kWh" />
                    <StatCard label="Biaya Grid" japaneseLabel="購入電力量料金" value={formatCurrency(p2Summary.gridCost)} />
                    <StatCard label="CO2 Reduce" japaneseLabel="CO2削減量" value={formatCo2(p2Summary.co2Reduced)} />
                  </div>

                  <ChartCard
                    title="Chart Konsumsi Harian P2"
                    japaneseTitle="P2 日別消費電力量チャート"
                    description="consumed_by_appliances_kwh, plts_production_kwh, purchased_from_grid_kwh"
                  >
                    <div className="h-[240px] sm:h-[280px] xl:h-[300px]">
                      {filteredP2Data.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <ComposedChart data={filteredP2Data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <defs>
                              <linearGradient id="p2Consumption" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#f97316" stopOpacity={0.35} />
                                <stop offset="95%" stopColor="#f97316" stopOpacity={0.02} />
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="date_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Area
                              type="monotone"
                              dataKey="consumed_by_appliances_kwh"
                              name="Konsumsi / 消費電力量"
                              stroke="#f97316"
                              fill="url(#p2Consumption)"
                              strokeWidth={3}
                            />
                            <Line
                              type="monotone"
                              dataKey="plts_production_kwh"
                              name="PV Generate / PV発電量"
                              stroke="#10b981"
                              strokeWidth={2}
                              dot={false}
                            />
                            <Line
                              type="monotone"
                              dataKey="purchased_from_grid_kwh"
                              name="Beli Grid / 系統購入"
                              stroke="#0f172a"
                              strokeWidth={2}
                              dot={false}
                            />
                          </ComposedChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>

                  <ChartCard title="Distribusi Energi P2" japaneseTitle="P2 エネルギー内訳">
                    <div className="h-[190px] sm:h-[220px]">
                      {filteredP2Data.length === 0 ? (
                        <EmptyChart />
                      ) : (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={filteredP2Data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                            <XAxis dataKey="date_label" tick={{ fontSize: 10 }} stroke="#64748b" interval="preserveStartEnd" />
                            <YAxis tick={{ fontSize: 10 }} stroke="#64748b" />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                            <Bar dataKey="purchased_from_grid_kwh" name="Beli Grid / 系統購入" fill="#0f172a" radius={[6, 6, 0, 0]} />
                            <Bar dataKey="plts_production_kwh" name="PV Generate / PV発電量" fill="#10b981" radius={[6, 6, 0, 0]} />
                            <Bar dataKey="fed_to_grid_kwh" name="Kirim Grid / 系統送電" fill="#06b6d4" radius={[6, 6, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </ChartCard>
                </PlantPanel>
              </div>
            </>
          )}
        </div>
      </main>
    </Layout>
  );
}
