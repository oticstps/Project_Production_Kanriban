import React, { useEffect, useMemo, useState } from "react";
import Layout from "../layout/Layout";

// const API_URL = "http://172.27.63.180:4000/api/full-texts";
const API_URL = "http://172.27.6.191:4000/api/full-texts";




function PLTS() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const fetchData = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError("");

      const response = await fetch(API_URL, {
        headers: {
          Accept: "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const result = await response.json();

      if (!result.success || !Array.isArray(result.data)) {
        throw new Error("Format data API tidak sesuai");
      }

      setRows(result.data);
    } catch (err) {
      setError(err.message || "Gagal mengambil data");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(() => fetchData(true), 30000);
    return () => clearInterval(interval);
  }, []);

  const latest = useMemo(() => {
    if (!rows.length) return null;
    return rows[0];
  }, [rows]);

  const parseNumber = (value) => {
    if (value === null || value === undefined || value === "") return 0;
    const num = Number(value);
    return Number.isNaN(num) ? 0 : num;
  };

  const formatNumber = (value, digits = 3) => {
    return parseNumber(value).toLocaleString("id-ID", {
      minimumFractionDigits: 0,
      maximumFractionDigits: digits,
    });
  };

  const formatDateTime = (value) => {
    if (!value) return "-";
    const date = new Date(value.replace(" ", "T"));
    if (Number.isNaN(date.getTime())) return value;

    return date.toLocaleString("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  const cards = latest
    ? [
        {
          title: "Yield Today",
          value: formatNumber(latest.area1_value),
          unit: "kWh",
        },
        {
          title: "Supply from Grid Today",
          value: formatNumber(latest.area2_value),
          unit: "MWh",
        },
        {
          title: "Total Yield",
          value: formatNumber(latest.area3_value),
          unit: "MWh",
        },
        {
          title: "Inverter Rated Power",
          value: formatNumber(latest.area4_value),
          unit: "kW",
        },
      ]
    : [];

  return (
    <>
      <Layout>
        <div className="min-h-screen bg-slate-100 p-4 md:p-6">
          <div className="mx-auto max-w-7xl">
            <div className="mb-6 rounded-2xl bg-white p-6 shadow-sm">
              <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                <div>
                  <h1 className="text-xl font-bold text-slate-800">
                    Dashboard Monitoring PLTS PLAN 2
                  </h1>
                  <p className="text-xs text-slate-500">
                    Monitoring data PLTS secara real-time
                  </p>
                </div>

                <button
                  onClick={() => fetchData(true)}
                  className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700"
                >
                  {refreshing ? "Refreshing..." : "Refresh"}
                </button>
              </div>
            </div>

            {loading && (
              <div className="rounded-xl bg-white p-8 text-center shadow-sm">
                <p className="text-slate-700">Loading data...</p>
              </div>
            )}

            {!loading && error && (
              <div className="rounded-xl bg-red-50 p-6 text-red-700 shadow-sm">
                {error}
              </div>
            )}

            {!loading && !error && latest && (
              <>
                <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-6">
                  {cards.map((card, index) => (
                    <div key={index} className="rounded-lg bg-white p-4 shadow-sm">
                      <p className="text-xs text-slate-500">{card.title}</p>
                      <div className="mt-2 flex items-end gap-1">
                        <span className="text-lg font-bold text-slate-800">
                          {card.value}
                        </span>
                        <span className="text-sm text-slate-500">{card.unit}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="rounded-lg bg-white p-6 shadow-sm">
                  <h2 className="mb-4 text-lg font-semibold text-slate-800">
                    Riwayat Data
                  </h2>

                  <div className="overflow-x-auto">
                    <table className="min-w-full text-xs">
                      <thead>
                        <tr className="border-b text-left text-slate-500">
                          <th className="px-2 py-3">ID</th>
                          <th className="px-2 py-3">Waktu</th>
                          <th className="px-2 py-3">Yield Today</th>
                          <th className="px-2 py-3">Supply from Grid</th>
                          <th className="px-2 py-3">Total Yield</th>
                          <th className="px-2 py-3">Inverter Rated Power</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rows.slice(0, 5).map((item) => (  // Membatasi 5 record terbaru
                          <tr key={item.id} className="border-b last:border-0">
                            <td className="px-2 py-3">{item.id}</td>
                            <td className="px-2 py-3">{formatDateTime(item.created_at)}</td>
                            <td className="px-2 py-3">{formatNumber(item.area1_value)} kWh</td>
                            <td className="px-2 py-3">{formatNumber(item.area2_value)} MWh</td>
                            <td className="px-2 py-3">{formatNumber(item.area3_value)} MWh</td>
                            <td className="px-2 py-3">{formatNumber(item.area4_value)} kW</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </Layout>
    </>
  );
}

export default PLTS;