import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import * as XLSX from 'xlsx';
import Layout from '../layout/Layout';

// Konstanta biaya dan emisi
const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92; // kg per kWh

// Palet warna untuk panel (digunakan saat mode all lines)
const PANEL_COLORS = [
  '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEEAD',
  '#D4A5A5', '#9B59B6', '#3498DB', '#E67E22', '#2ECC71',
  '#F1C40F', '#E74C3C', '#1ABC9C', '#34495E', '#7F8C8D'
];

const CompShiftly = () => {
  const [shiftData, setShiftData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFetching, setIsFetching] = useState(false); // indikator loading halus
  const [error, setError] = useState(null);
  const [availableLines, setAvailableLines] = useState([]);
  const [displayMode, setDisplayMode] = useState('single'); // 'single' atau 'all'

  // State filter
  const now = new Date();
  const currentMonth = now.toLocaleString('en-US', { month: 'long' });
  const currentYear = now.getFullYear();

  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [selectedLine, setSelectedLine] = useState('kubikal_1');

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const years = [2024, 2025, 2026];

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsFetching(true); // mulai indikator halus
        const response = await axios.get('/api/pm-shiftly-kwh');
        if (!response.data?.success) throw new Error('Invalid API response');

        let rawData = response.data.data || [];

        // Ambil daftar line_name unik
        const lines = [...new Set(rawData.map(item => item.line_name))];
        setAvailableLines(lines);

        // Filter bulan & tahun
        rawData = rawData.filter(item => 
          item.month_name === selectedMonth && parseInt(item.year) === selectedYear
        );

        // Filter line jika dipilih
        if (selectedLine !== 'semua') {
          rawData = rawData.filter(item => item.line_name === selectedLine);
        }

        // Transformasi data berdasarkan mode
        if (selectedLine === 'semua') {
          // Mode all lines: kelompokkan per hari dan per panel
          const byDatePanel = {};
          rawData.forEach((item) => {
            const dateKey = `${item.day_name} ${item.day} ${item.month_name.slice(0, 3)}`;
            if (!byDatePanel[dateKey]) {
              byDatePanel[dateKey] = { date: dateKey };
            }
            const panel = item.line_name;
            const kwh = parseFloat(item.total_kwh) / 1000;
            byDatePanel[dateKey][panel] = (byDatePanel[dateKey][panel] || 0) + kwh;
          });

          // Urutkan berdasarkan tanggal (terbaru di kanan)
          const sortedDates = Object.keys(byDatePanel).sort((a, b) => {
            const dateA = new Date(a.replace(/(\w+) (\d+) (\w+)/, '$3 $2, $1'));
            const dateB = new Date(b.replace(/(\w+) (\d+) (\w+)/, '$3 $2, $1'));
            return dateA - dateB;
          }).reverse();

          const chartData = sortedDates.map(dateKey => byDatePanel[dateKey]);
          setShiftData(chartData);
          setDisplayMode('all');
        } else {
          // Mode single line: kelompokkan per hari dan shift
          const groupedByDate = {};
          rawData.forEach((item) => {
            const dateKey = `${item.day_name} ${item.day} ${item.month_name.slice(0, 3)}`;
            const shiftKey = item.shift === 'shift_1' ? 'shift1' : 'shift2';

            if (!groupedByDate[dateKey]) {
              groupedByDate[dateKey] = {
                date: dateKey,
                shift1: 0,
                shift2: 0,
                records: [],
              };
            }

            const kwh = parseFloat(item.total_kwh) / 1000;
            groupedByDate[dateKey][shiftKey] += kwh;

            groupedByDate[dateKey].records.push({
              ...item,
              kwh: Math.round(kwh),
              cost: Math.round(kwh * COST_PER_KWH),
              co2Kg: Math.round(kwh * CO2_EMISSION_FACTOR),
            });
          });

          // Urutkan tanggal
          const sortedDates = Object.keys(groupedByDate).sort((a, b) => {
            const dateA = new Date(a.replace(/(\w+) (\d+) (\w+)/, '$3 $2, $1'));
            const dateB = new Date(b.replace(/(\w+) (\d+) (\w+)/, '$3 $2, $1'));
            return dateA - dateB;
          }).reverse();

          const chartData = sortedDates.map(dateKey => ({
            date: dateKey,
            shift1: Math.round(groupedByDate[dateKey].shift1),
            shift2: Math.round(groupedByDate[dateKey].shift2),
            records: groupedByDate[dateKey].records,
          }));

          setShiftData(chartData);
          setDisplayMode('single');
        }
      } catch (err) {
        console.error(err);
        setError('Gagal memuat data dari server.');
      } finally {
        setLoading(false);
        setIsFetching(false);
      }
    };

    fetchData();
  }, [selectedMonth, selectedYear, selectedLine]);

  // Export ke Excel (disesuaikan dengan mode)
  const exportToExcel = () => {
    const exportData = [];
    
    if (displayMode === 'single') {
      shiftData.forEach(day => {
        day.records.forEach(record => {
          exportData.push({
            'Date': day.date,
            'Shift': record.shift === 'shift_1' ? 'Shift 1' : 'Shift 2',
            'Line': record.line_name,
            'Energy (kWh)': record.kwh,
            'Cost (IDR)': record.cost,
            'CO2 (kg)': record.co2Kg,
            'Month': selectedMonth,
            'Year': selectedYear
          });
        });
      });
    } else {
      // Mode all: setiap baris adalah hari + panel
      shiftData.forEach(day => {
        Object.keys(day).forEach(key => {
          if (key !== 'date' && typeof day[key] === 'number') {
            exportData.push({
              'Date': day.date,
              'Line': key,
              'Energy (kWh)': Math.round(day[key]),
              'Cost (IDR)': Math.round(day[key] * COST_PER_KWH),
              'CO2 (kg)': Math.round(day[key] * CO2_EMISSION_FACTOR),
              'Month': selectedMonth,
              'Year': selectedYear
            });
          }
        });
      });
    }

    const totalKwh = displayMode === 'single'
      ? shiftData.reduce((sum, item) => sum + item.shift1 + item.shift2, 0)
      : shiftData.reduce((sum, day) => {
          let total = 0;
          Object.keys(day).forEach(key => {
            if (key !== 'date') total += day[key];
          });
          return sum + total;
        }, 0);

    exportData.push({}, {
      'Date': 'TOTAL',
      'Line': '-',
      'Energy (kWh)': Math.round(totalKwh),
      'Cost (IDR)': Math.round(totalKwh * COST_PER_KWH),
      'CO2 (kg)': Math.round(totalKwh * CO2_EMISSION_FACTOR),
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Energy Report');
    ws['!cols'] = [
      { wch: 15 }, { wch: 15 }, { wch: 15 },
      { wch: 15 }, { wch: 18 }, { wch: 10 }, { wch: 8 }
    ];
    XLSX.writeFile(wb, `Energy_${selectedLine}_${selectedMonth}_${selectedYear}.xlsx`);
  };

  if (loading) return <div style={{ padding: 24 }}>Memuat data...</div>;
  if (error) return <div style={{ padding: 24, color: '#e74c3c' }}>{error}</div>;

  // Statistik (hanya untuk mode single, untuk all lines kita hitung total per hari)
  let totalKwh = 0, totalShift1 = 0, totalShift2 = 0, daysCount = 0, avgDaily = 0, peakValue = 0, totalCost = 0, totalCo2 = 0;

  if (displayMode === 'single') {
    totalKwh = shiftData.reduce((sum, item) => sum + item.shift1 + item.shift2, 0);
    totalShift1 = shiftData.reduce((sum, item) => sum + item.shift1, 0);
    totalShift2 = shiftData.reduce((sum, item) => sum + item.shift2, 0);
    daysCount = shiftData.length;
    avgDaily = daysCount ? Math.round(totalKwh / daysCount) : 0;
    peakValue = Math.max(...shiftData.map(d => Math.max(d.shift1, d.shift2)), 0);
    totalCost = Math.round(totalKwh * COST_PER_KWH);
    totalCo2 = Math.round(totalKwh * CO2_EMISSION_FACTOR);
  } else {
    // Hitung total dari semua panel
    totalKwh = shiftData.reduce((sum, day) => {
      let dayTotal = 0;
      Object.keys(day).forEach(key => {
        if (key !== 'date') dayTotal += day[key];
      });
      return sum + dayTotal;
    }, 0);
    daysCount = shiftData.length;
    avgDaily = daysCount ? Math.round(totalKwh / daysCount) : 0;
    peakValue = Math.max(...shiftData.map(day => {
      return Math.max(...Object.keys(day).filter(k => k !== 'date').map(k => day[k]));
    }), 0);
    totalCost = Math.round(totalKwh * COST_PER_KWH);
    totalCo2 = Math.round(totalKwh * CO2_EMISSION_FACTOR);
    // Untuk shift1/shift2 tidak relevan di mode all, kita set 0 agar tidak muncul di stat
    totalShift1 = 0;
    totalShift2 = 0;
  }

  const formatNumber = (num) => num.toLocaleString('id-ID');
  const formatCurrency = (num) => `Rp ${num.toLocaleString('id-ID')}`;




  const panelDescriptions = {
    "kubikal_1": 'Sumber Utama Otics 1',
    "panel_24": 'Compressor 7, Compressor 10',
    "panel_19": 'Compressor 5',
    "panel_21": 'Compressor 8, Compressor 9',
    "panel_20": 'Compressor 6, Compressor 9, Bebicon',

    "panel_16": 'sub Kubikal',

    "panel_17": 'sub Kubikal',

  };




  const getDisplayTitle = () => {
    if (selectedLine === 'semua') return 'Semua Panel';
    return selectedLine;
  };




  return (
    <Layout>
      <div style={{ padding: 20, fontFamily: 'Segoe UI, sans-serif', background: '#fff' }}>
        {/* Header dengan indikator fetching */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <h1 style={{ color: '#3498db', margin: 0 }}>⚡ Otics Indonesia Energy Dashboard</h1>
            {isFetching && (
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 14, color: '#666' }}>
                <span className="spinner" style={{ width: 16, height: 16, border: '2px solid #ccc', borderTopColor: '#3498db', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></span>
                <span>Memperbarui...</span>
              </div>
            )}
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <button onClick={exportToExcel} style={{ padding: '8px 16px', background: '#27ae60', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}>
              📊 Export Excel
            </button>
            <select value={selectedLine} onChange={(e) => setSelectedLine(e.target.value)} style={{ padding: 6, borderRadius: 6, border: '1px solid #ddd' }}>
              <option value="semua">Semua Panel</option>
              {availableLines.map(line => <option key={line} value={line}>{line}</option>)}
            </select>
            <select value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} style={{ padding: 6, borderRadius: 6, border: '1px solid #ddd' }}>
              {months.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
            <select value={selectedYear} onChange={(e) => setSelectedYear(parseInt(e.target.value))} style={{ padding: 6, borderRadius: 6, border: '1px solid #ddd' }}>
              {years.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        </div>














        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 15, fontWeight: 600, color: "#2c3e50", marginBottom: 4 }}>
            📊 Menampilkan data untuk:{" "}
            <strong style={{ color: "#2980b9", backgroundColor: "#e8f4fd", padding: "4px 12px", borderRadius: 20 }}>
              {getDisplayTitle()}
            </strong>
          </div>
          
          {selectedLine !== 'semua' && panelDescriptions[selectedLine] && (
            <div style={{ 
              marginTop: 8, 
              padding: "12px 16px", 
              backgroundColor: "#f8f9fa", 
              borderRadius: 8,
              borderLeft: "4px solid #3498db",
              display: "flex",
              flexWrap: "wrap",
              alignItems: "center",
              gap: "8px 16px"
            }}>
              <span style={{ fontWeight: 600, color: "#34495e" }}>⚙️ Kompresor terhubung:</span>
              {panelDescriptions[selectedLine].split(',').map((item, idx) => {
                const trimmed = item.trim();
                // Pisahkan jika ada keterangan tambahan seperti "Bebicon"
                const isCompressor = trimmed.toLowerCase().includes('compressor');
                return (
                  <span
                    key={idx}
                    style={{
                      backgroundColor: isCompressor ? "#d4edda" : "#fff3cd",
                      color: isCompressor ? "#155724" : "#856404",
                      padding: "4px 12px",
                      borderRadius: 20,
                      fontSize: 13,
                      fontWeight: 500,
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 4,
                      boxShadow: "0 2px 4px rgba(0,0,0,0.05)"
                    }}
                  >
                    {isCompressor ? "🔧" : "📦"} {trimmed}
                  </span>
                );
              })}
            </div>
          )}
        </div>







        {/* Kartu statistik (hanya tampilkan yang relevan) */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px,1fr))', gap: 16, marginBottom: 24, background: '#e3f2fd', padding: 16, borderRadius: 8 }}>
          {[
            { label: 'Total Energy', value: `${formatNumber(totalKwh)} kWh`, icon: '⚡', color: '#3498db' },
            { label: 'Cost', value: formatCurrency(totalCost), icon: '💰', color: '#f39c12' },
            { label: 'Avg Daily', value: `${formatNumber(avgDaily)} kWh`, icon: '📈', color: '#27ae60' },
            ...(displayMode === 'single' ? [
              { label: 'Shift 1 Total', value: `${formatNumber(totalShift1)} kWh`, icon: '⏱️', color: '#3498db' },
              { label: 'Shift 2 Total', value: `${formatNumber(totalShift2)} kWh`, icon: '⏱️', color: '#7f8c8d' },
            ] : []),
            { label: 'Peak Value', value: `${formatNumber(peakValue)} kWh`, icon: '⬆️', color: '#e74c3c' },
          ].map((stat, idx) => (
            <div key={idx} style={{ background: '#fff', padding: 16, borderRadius: 8, textAlign: 'center', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, color: stat.color }}>
                <span style={{ fontSize: 20 }}>{stat.icon}</span>
                <span style={{ fontWeight: 'bold' }}>{stat.label}</span>
              </div>
              <div style={{ fontSize: 20, fontWeight: 'bold', marginTop: 8 }}>{stat.value}</div>
            </div>
          ))}
        </div>

        {/* Analisis CO2 & Biaya */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 30, background: '#e3f2fd', padding: 20, borderRadius: 8 }}>
          <div style={{ background: '#fff', padding: 20, borderRadius: 8 }}>
            <h3 style={{ color: '#e74c3c' }}>🔥 CO2 Emissions</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>Monthly: <strong>{formatNumber(totalCo2)} kg</strong></div>
              <div>Daily Avg: <strong>{(totalCo2 / daysCount || 0).toFixed(2)} kg</strong></div>
              <div>Yearly: <strong>{formatNumber(Math.round(totalCo2 * 12))} kg</strong></div>
            </div>
          </div>
          <div style={{ background: '#fff', padding: 20, borderRadius: 8 }}>
            <h3 style={{ color: '#f39c12' }}>💰 Cost Analysis</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>Monthly: <strong>{formatCurrency(totalCost)}</strong></div>
              <div>Daily Avg: <strong>{daysCount ? formatCurrency(Math.round(totalCost / daysCount)) : 'Rp 0'}</strong></div>
              <div>Per kWh: <strong>Rp {COST_PER_KWH.toFixed(3)}</strong></div>
            </div>
          </div>
        </div>







        {/* Grafik */}
        <div style={{ width: '100%', height: 400, border: '1px solid #ddd', borderRadius: 8 }}>
          <ResponsiveContainer>
            <BarChart data={shiftData} margin={{ top: 40, right: 30, left: 20, bottom: 20 }}>
              <CartesianGrid strokeDasharray="4 4" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }} 
                tickFormatter={(v) => v.split(' ').slice(1,3).join('-')} 
              />
              <YAxis tickFormatter={formatNumber} label={{ value: 'kWh', angle: -90, position: 'insideLeft' }} />
              <Tooltip 
                formatter={(value, name) => {
                  if (displayMode === 'all') {
                    return [`${formatNumber(value)} kWh`, name];
                  }
                  return [`${formatNumber(value)} kWh`, name === 'shift1' ? 'Shift 1' : 'Shift 2'];
                }} 
                labelFormatter={(label) => `Tanggal: ${label}`}
              />
              <Legend 
                verticalAlign="top" 
                content={({ payload }) => {
                  if (displayMode === 'single') {
                    return (
                      <div style={{ display: 'flex', justifyContent: 'center', gap: 24 }}>
                        <span><span style={{ color: '#2edace' }}>●</span> Shift 1: {formatNumber(totalShift1)} kWh</span>
                        <span><span style={{ color: '#172fe5' }}>●</span> Shift 2: {formatNumber(totalShift2)} kWh</span>
                      </div>
                    );
                  } else {
                    // Tampilkan legenda untuk setiap panel (maksimal 10 agar tidak terlalu penuh)
                    const panels = availableLines.slice(0, 10);
                    return (
                      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '8px 16px', fontSize: 12 }}>
                        {panels.map((panel, idx) => (
                          <span key={panel}>
                            <span style={{ color: PANEL_COLORS[idx % PANEL_COLORS.length] }}>●</span> {panel}
                          </span>
                        ))}
                        {availableLines.length > 10 && <span>...dan lainnya</span>}
                      </div>
                    );
                  }
                }}
              />
              {displayMode === 'single' ? (
                <>
                  <Bar dataKey="shift1" fill="url(#grad1)" radius={[4,4,0,0]} />
                  <Bar dataKey="shift2" fill="url(#grad2)" radius={[4,4,0,0]} />
                </>
              ) : (
                // Render stacked bar untuk setiap panel
                availableLines.map((panel, idx) => (
                  <Bar 
                    key={panel} 
                    dataKey={panel} 
                    stackId="a" 
                    fill={PANEL_COLORS[idx % PANEL_COLORS.length]} 
                    radius={[4,4,0,0]} 
                  />
                ))
              )}
              <defs>
                <linearGradient id="grad1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2edace" stopOpacity={1} />
                  <stop offset="95%" stopColor="#2edace" stopOpacity={0.6} />
                </linearGradient>
                <linearGradient id="grad2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#172fe5" stopOpacity={1} />
                  <stop offset="95%" stopColor="#172fe5" stopOpacity={0.6} />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* CSS untuk spinner */}
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>


      {/* Warning Analisa Data */}
      <div
          style={{
            marginBottom: 16,
            padding: "12px 16px",
            backgroundColor: "#fff3cd",
            border: "1px solid #ffeeba",
            borderRadius: 6,
            color: "#856404",
            fontSize: 16,
            fontWeight: 500
          }}
        >
          ⚠️ Panel 19 dan Panel 24 sedang dalam proses analisa karakteristik data.
      </div>
    </Layout>
  );
};

export default CompShiftly;