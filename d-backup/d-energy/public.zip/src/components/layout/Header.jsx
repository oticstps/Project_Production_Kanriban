import { useState, useEffect } from 'react';
import { Bell, Search, User, Menu, LogOut } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import Button from '../common/Button';
import { useNavigate } from 'react-router-dom';
import oiImage from '../../assets/oi.jpg';

const Header = ({ onSidebarToggle }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  // 🔹 State untuk Date Time
  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setDateTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  // Format tanggal & jam
  const formattedDate = dateTime.toLocaleDateString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const formattedTime = dateTime.toLocaleTimeString('id-ID');

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">

          {/* Mobile menu button */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={onSidebarToggle}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              aria-label="Toggle sidebar"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>

          {/* Logo */}
          <div className="flex items-center space-x-3 flex-1 lg:flex-none">
            <img
              src={oiImage}
              alt="TPS Logo"
              className="w-8 h-8 rounded-lg object-cover"
            />
            <h1 className="text-xl font-bold text-gray-800 hidden sm:block">
              Otics Indonesia Monitoring System
            </h1>
          </div>

          {/* 🔹 Date Time + User */}
          <div className="flex items-center space-x-6">



            {user && (
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>

                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-gray-700">
                      {user.name || user.username}
                    </span>
                    <span className="text-xs text-gray-500">
                      {user.username}
                    </span>
                  </div>
                </div>

                <Button
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                  className="flex items-center space-x-1 text-sm"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            )}


            {/* Date Time */}
            <div className="hidden md:flex flex-col text-right">
              <span className="text-sm font-semibold text-blue-700">
                {formattedTime}
              </span>
              <span className="text-xs text-gray-500">
                {formattedDate}
              </span>
            </div>



          </div>

        </div>
      </div>
    </header>
  );
};

export default Header;