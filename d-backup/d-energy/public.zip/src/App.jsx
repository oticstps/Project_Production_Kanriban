import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';


import ProtectedRoute from './components/common/ProtectedRoute';
import GuestRoute from './components/common/GuestRoute';
import LoginForm from './components/auth/LoginForm';
import RegisterForm from './components/auth/RegisterForm';
import Dashboard from './components/dashboard/Dashboard';
import ReportMonthlyEnergyListrik from './components/dashboard/ReportMonthlyEnergyListrik';
import Kubikal1ActivePower from './components/dashboard/Kubikal1ActivePower';
import MainDashboardKwh from './components/dashboard/MainDashboardListrik';
import EnergyElectrialPlant2 from './components/dashboard/EnergyElectrialPlant2';
import Lora from './components/custom/Lora/Lora';
import Smile from './components/dashboard/MainDashboardEnergyListrikNipon/Smile';
import LayoutListrikOtics1 from './components/dashboard/LayoutListrikOtics1';
import GetPosisitionImg from './components/dashboard/GetPosisitionImg';
import PanelComp from './components/dashboard/PanelComp';
// import PanelCompressor from './components/dashboard/PanelCompressor';
import CompShiftly from './components/dashboard/CompShiftly';
import PLTS_P1 from './components/dashboard/PLTS_P1';
import LineProd_no_panel from './components/dashboard/LineProd_no_panel';
import PLTS from './components/dashboard/PLTS';
import ConvertExelP1 from './components/dashboard/ConverterExelP1';
import ConvertExelP2 from './components/dashboard/ConverterExelP2';
import PLTSCommon from './components/dashboard/PLTSCommon';
import ConvertExelP1Hourly from './components/dashboard/ConvertExelHourlyP1';
import ConvertExelP2Hourly from './components/dashboard/ConvertExelHourlyP2';
import PLTSCommonDashboard from './components/dashboard/PLTSCommonDashboard';
import MonitoringListrik from './components/dashboard/MonitoringListrik';
import PLTSV1 from './components/dashboard/PLTSV1';
import MonitoringDaily from './components/dashboard/MonitoringDaily';
import MesinIMC_10 from './components/dashboard/MesinIMC_10';
import RunningMachine from './components/dashboard/RunningMachine';
import IMC from './components/dashboard/IMC';



function App() {
  const { loading, user } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>


        <Route path="/kwh" element={<MainDashboardKwh />} />
        <Route path="/kubikal1" element={<Kubikal1ActivePower />} />
        <Route path="/listrik" element={<ReportMonthlyEnergyListrik />} />
        <Route path="/MesinIMC_10" element={<MesinIMC_10 />} />
        <Route path="/imc" element={<IMC />} />
        

        <Route path="/plant2" element={<EnergyElectrialPlant2 />} />
        <Route path="/lora" element={<Lora />} />
        <Route path="/smile" element={<Smile />} />
        <Route path="/layoutotics1" element={<LayoutListrikOtics1 />} />
        <Route path="/GetPosisitionImg" element={<GetPosisitionImg />} />


        {/* <Route path="/comp" element={<PanelCompressor />} /> */}
        <Route path="/compShiftly" element={<CompShiftly />} />
        <Route path="/plts_p1" element={<PLTS_P1 />} />
        <Route path="/line" element={<LineProd_no_panel />} />
        <Route path="/plts" element={<PLTS />} />
        <Route path="/convert_exel_p1" element={<ConvertExelP1 />} />
        <Route path="/convert_exel_p2" element={<ConvertExelP2 />} />
        <Route path="/convert_exel_p1_hourly" element={<ConvertExelP1Hourly />} />
        <Route path="/convert_exel_p2_hourly" element={<ConvertExelP2Hourly />} />
        <Route path="/plts_common" element={<PLTSCommon />} />
        <Route path="/plts_common_dashboard" element={<PLTSCommonDashboard />} />
        <Route path="/monitoring-listrik" element={<MonitoringListrik />} />
        <Route path="/pltsv1" element={<PLTSV1  />} />


        <Route path="daily" element={< MonitoringDaily />}/>
        <Route path="RunningMachine" element={<RunningMachine/>} />



        <Route 
          path="/" 
          element={user ? <Navigate to="/kwh" replace /> : <Navigate to="/kwh" replace />} 
        />


        <Route 
          path="/login" 
          element={
            <GuestRoute>
              <LoginForm />
            </GuestRoute>
          } 
        />


        <Route 
          path="/register_tps_core_engine_member" 
          element={
            <GuestRoute>
              <RegisterForm />
            </GuestRoute>
          } 
        />


   
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;