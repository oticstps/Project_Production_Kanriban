import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'



// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://172.27.6.191:4000',
        changeOrigin: true,
        secure: false
      }
    },
    host: true,
    port: 3000,
    open: false
  },

  
})