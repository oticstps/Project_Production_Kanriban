// Jika ingin menghapus seluruh data rekap terlebih dahulu:
// TRUNCATE TABLE tb_kub_panel_16_wh_monthly;
// TRUNCATE TABLE tb_kub_panel_17_wh_monthly;

const pool = require("../database");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
    {
        pm_type: "DA_01",
        source_table: "tb_kub_panel_16_wh",
        target_table: "tb_kub_panel_16_wh_monthly",
        line_name: "Panel_16"
    },
    {
        pm_type: "DA_01",
        source_table: "tb_kub_panel_17_wh",
        target_table: "tb_kub_panel_17_wh_monthly",
        line_name: "Panel_17"
    }
];

const monthNames = [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember"
];

/**
 * Mengamankan nama tabel agar tidak dapat disisipi SQL injection.
 */
function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Invalid table name: ${identifier}`);
    }

    return `\`${identifier}\``;
}

/**
 * Mengambil nilai WH pertama dan terakhir dalam satu bulan.
 */
async function getMonthlyData(
    connection,
    tableName,
    monthStart,
    nextMonthStart
) {
    const safeTable = escapeIdentifier(tableName);

    const startTimeString = monthStart.format("YYYY-MM-DD HH:mm:ss");
    const endTimeString = nextMonthStart.format("YYYY-MM-DD HH:mm:ss");

    /*
     * Mengambil data valid pertama pada bulan tersebut.
     * REGEXP digunakan karena kolom wh bertipe VARCHAR.
     */
    const [startRows] = await connection.query(
        `
        SELECT
            DATE_FORMAT(date_time, '%Y-%m-%d %H:%i:%s') AS date_time,
            CAST(TRIM(wh) AS DECIMAL(15,3)) AS value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND wh IS NOT NULL
          AND TRIM(wh) <> ''
          AND TRIM(wh) REGEXP '^[+-]?[0-9]+([.][0-9]+)?$'
        ORDER BY date_time ASC, idPrimary ASC
        LIMIT 1
        `,
        [startTimeString, endTimeString]
    );

    /*
     * Mengambil data valid terakhir pada bulan tersebut.
     */
    const [endRows] = await connection.query(
        `
        SELECT
            DATE_FORMAT(date_time, '%Y-%m-%d %H:%i:%s') AS date_time,
            CAST(TRIM(wh) AS DECIMAL(15,3)) AS value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND wh IS NOT NULL
          AND TRIM(wh) <> ''
          AND TRIM(wh) REGEXP '^[+-]?[0-9]+([.][0-9]+)?$'
        ORDER BY date_time DESC, idPrimary DESC
        LIMIT 1
        `,
        [startTimeString, endTimeString]
    );

    if (!startRows.length || !endRows.length) {
        return null;
    }

    const startValue = Number(startRows[0].value);
    const endValue = Number(endRows[0].value);

    if (!Number.isFinite(startValue) || !Number.isFinite(endValue)) {
        return null;
    }

    const totalValue = Number((endValue - startValue).toFixed(3));

    /*
     * Total 0 atau negatif tidak dimasukkan.
     * Nilai negatif dapat terjadi karena meter reset atau data tidak berurutan.
     */
    if (totalValue <= 0) {
        return null;
    }

    return {
        monthStartDatetime: startRows[0].date_time,
        monthEndDatetime: endRows[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

/**
 * Insert atau update data rekap bulanan.
 */
async function upsertMonthlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(
        `
        INSERT INTO ${safeTargetTable} (
            pm_type,
            line_table,
            line_name,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            month_start_date,
            month_end_date,
            month_start_datetime,
            month_end_datetime,
            created_at,
            updated_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW()
        )
        ON DUPLICATE KEY UPDATE
            line_name = VALUES(line_name),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            month_name = VALUES(month_name),
            month_start_date = VALUES(month_start_date),
            month_end_date = VALUES(month_end_date),
            month_start_datetime = VALUES(month_start_datetime),
            month_end_datetime = VALUES(month_end_datetime),
            updated_at = NOW()
        `,
        [
            line.pm_type,
            line.source_table,
            line.line_name,
            data.start_kwh,
            data.end_kwh,
            data.total_kwh,
            data.year,
            data.month,
            data.month_name,
            data.month_start_date,
            data.month_end_date,
            data.month_start_datetime,
            data.month_end_datetime
        ]
    );

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | ` +
        `${data.month_name} ${data.year} | ` +
        `${data.total_kwh} kWh`
    );
}

/**
 * Mengambil daftar tahun dan bulan yang tersedia pada tabel sumber.
 */
async function getAvailableMonths(connection, sourceTable) {
    const safeSourceTable = escapeIdentifier(sourceTable);

    const [rows] = await connection.query(`
        SELECT DISTINCT
            YEAR(date_time) AS year,
            MONTH(date_time) AS month
        FROM ${safeSourceTable}
        WHERE date_time IS NOT NULL
          AND wh IS NOT NULL
          AND TRIM(wh) <> ''
          AND TRIM(wh) REGEXP '^[+-]?[0-9]+([.][0-9]+)?$'
        ORDER BY year ASC, month ASC
    `);

    return rows.map((row) => ({
        year: Number(row.year),
        month: Number(row.month)
    }));
}

/**
 * Memproses seluruh bulan pada satu tabel sumber.
 */
async function processLine(connection, line) {
    console.log(
        `\n🔍 Proses Monthly: ${line.source_table} -> ${line.target_table}`
    );

    const availableMonths = await getAvailableMonths(
        connection,
        line.source_table
    );

    if (!availableMonths.length) {
        console.log(
            `⚠️ Tidak ada data WH valid pada tabel sumber: ${line.source_table}`
        );
        return;
    }

    for (const period of availableMonths) {
        const year = period.year;
        const month = period.month;

        const monthStart = moment.tz(
            `${year}-${String(month).padStart(2, "0")}-01 00:00:00`,
            "YYYY-MM-DD HH:mm:ss",
            "Asia/Jakarta"
        );

        const nextMonthStart = monthStart.clone().add(1, "month");

        const monthStartDate = monthStart.format("YYYY-MM-DD");
        const monthEndDate = monthStart
            .clone()
            .endOf("month")
            .format("YYYY-MM-DD");

        const monthlyData = await getMonthlyData(
            connection,
            line.source_table,
            monthStart,
            nextMonthStart
        );

        if (!monthlyData) {
            console.log(
                `⚠️ Skip: ${line.target_table} | ` +
                `${monthNames[month - 1]} ${year} | ` +
                `data kosong, tidak valid, 0, atau negatif`
            );
            continue;
        }

        await upsertMonthlyToTable(connection, line, {
            start_kwh: monthlyData.startValue,
            end_kwh: monthlyData.endValue,
            total_kwh: monthlyData.totalValue,
            year,
            month,
            month_name: monthNames[month - 1],
            month_start_date: monthStartDate,
            month_end_date: monthEndDate,
            month_start_datetime: monthlyData.monthStartDatetime,
            month_end_datetime: monthlyData.monthEndDatetime
        });
    }
}

/**
 * Fungsi utama rekap bulanan.
 */
async function rekapMonthly() {
    const connection = await pool.getConnection();

    try {
        console.log("🚀 Mulai rekap monthly...");
        console.log(
            "🔐 Mode UPSERT aktif apabila UNIQUE KEY sudah tersedia."
        );

        for (const line of lineTables) {
            try {
                await processLine(connection, line);
            } catch (lineError) {
                console.error(
                    `❌ Error pada line ${line.source_table} -> ` +
                    `${line.target_table}:`,
                    lineError
                );
            }
        }

        console.log("\n🎉 Rekap monthly selesai.");
    } catch (error) {
        console.error("❌ Error utama rekap monthly:", error);
        throw error;
    } finally {
        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

rekapMonthly()
    .then(() => {
        console.log("✅ Program selesai.");
        process.exit(0);
    })
    .catch((error) => {
        console.error("❌ Program gagal:", error);
        process.exit(1);
    });