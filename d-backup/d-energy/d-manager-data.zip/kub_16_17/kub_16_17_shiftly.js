// ============================================================
// REKAP DATA WH PER SHIFT
// ============================================================
//
// Tabel sumber:
// - tb_kub_panel_16_wh
// - tb_kub_panel_17_wh
//
// Tabel tujuan:
// - tb_kub_panel_16_wh_shiftly
// - tb_kub_panel_17_wh_shiftly
//
// Untuk mengosongkan tabel tujuan secara manual:
//
// TRUNCATE TABLE tb_kub_panel_16_wh_shiftly;
// TRUNCATE TABLE tb_kub_panel_17_wh_shiftly;
//
// ============================================================

const pool = require("../database");
const moment = require("moment-timezone");

require("moment/locale/id");

moment.tz.setDefault("Asia/Jakarta");
moment.locale("id");

// ============================================================
// KONFIGURASI
// ============================================================

const lineTables = [
    {
        pm_type: "DA_01",
        source_table: "tb_kub_panel_16_wh",
        target_table: "tb_kub_panel_16_wh_shiftly",
        line_name: "Panel_16"
    },
    {
        pm_type: "DA_01",
        source_table: "tb_kub_panel_17_wh",
        target_table: "tb_kub_panel_17_wh_shiftly",
        line_name: "Panel_17"
    }
];

/*
 * Gunakan:
 *
 * 1     apabila nilai pada kolom wh sudah dalam satuan kWh.
 * 1000  apabila nilai pada kolom wh masih dalam satuan Wh
 *       dan perlu dikonversi menjadi kWh.
 */
const WH_TO_KWH_DIVISOR = 1;

// ============================================================
// FUNGSI BANTU
// ============================================================

function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Nama tabel tidak valid: ${identifier}`);
    }

    return `\`${identifier}\``;
}

function formatDateTime(value) {
    return moment(value).format("YYYY-MM-DD HH:mm:ss");
}

/**
 * Mengubah nilai varchar menjadi angka.
 *
 * Format yang didukung:
 * - 1234
 * - 1234.56
 * - 1234,56
 * - 1.234,56
 * - 1,234.56
 */
function parseNumericValue(value) {
    if (value === null || value === undefined) {
        return null;
    }

    let normalizedValue = String(value)
        .trim()
        .replace(/\s+/g, "");

    if (!normalizedValue) {
        return null;
    }

    const hasComma = normalizedValue.includes(",");
    const hasDot = normalizedValue.includes(".");

    if (hasComma && hasDot) {
        const lastCommaPosition = normalizedValue.lastIndexOf(",");
        const lastDotPosition = normalizedValue.lastIndexOf(".");

        if (lastCommaPosition > lastDotPosition) {
            // Format Indonesia: 1.234,56
            normalizedValue = normalizedValue
                .replace(/\./g, "")
                .replace(",", ".");
        } else {
            // Format internasional: 1,234.56
            normalizedValue = normalizedValue.replace(/,/g, "");
        }
    } else if (hasComma) {
        // Contoh: 1234,56
        normalizedValue = normalizedValue.replace(",", ".");
    }

    const numericValue = Number(normalizedValue);

    if (!Number.isFinite(numericValue)) {
        return null;
    }

    return numericValue;
}

function convertWhToKwh(value) {
    const numericValue = parseNumericValue(value);

    if (numericValue === null) {
        return null;
    }

    return Number(
        (numericValue / WH_TO_KWH_DIVISOR).toFixed(3)
    );
}

// ============================================================
// MENGAMBIL DATA AWAL DAN AKHIR SHIFT
// ============================================================

async function getShiftData(
    connection,
    tableName,
    startTime,
    endTime
) {
    const safeTable = escapeIdentifier(tableName);

    const startTimeString = startTime.format(
        "YYYY-MM-DD HH:mm:ss"
    );

    const endTimeString = endTime.format(
        "YYYY-MM-DD HH:mm:ss"
    );

    /*
     * Mengambil beberapa data awal untuk mengantisipasi jika
     * baris pertama memiliki nilai WH yang kosong atau tidak valid.
     */
    const [startRows] = await connection.query(
        `
        SELECT
            date_time,
            wh
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND wh IS NOT NULL
          AND TRIM(wh) <> ''
        ORDER BY date_time ASC
        LIMIT 20
        `,
        [
            startTimeString,
            endTimeString
        ]
    );

    /*
     * Mengambil beberapa data akhir untuk mengantisipasi jika
     * baris terakhir memiliki nilai WH yang kosong atau tidak valid.
     */
    const [endRows] = await connection.query(
        `
        SELECT
            date_time,
            wh
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND wh IS NOT NULL
          AND TRIM(wh) <> ''
        ORDER BY date_time DESC
        LIMIT 20
        `,
        [
            startTimeString,
            endTimeString
        ]
    );

    if (!startRows.length || !endRows.length) {
        return null;
    }

    let validStartRow = null;
    let startValue = null;

    for (const row of startRows) {
        const parsedValue = convertWhToKwh(row.wh);

        if (parsedValue !== null) {
            validStartRow = row;
            startValue = parsedValue;
            break;
        }
    }

    let validEndRow = null;
    let endValue = null;

    for (const row of endRows) {
        const parsedValue = convertWhToKwh(row.wh);

        if (parsedValue !== null) {
            validEndRow = row;
            endValue = parsedValue;
            break;
        }
    }

    if (
        !validStartRow ||
        !validEndRow ||
        startValue === null ||
        endValue === null
    ) {
        return null;
    }

    const totalValue = Number(
        (endValue - startValue).toFixed(3)
    );

    /*
     * Data tidak disimpan apabila:
     * - hasil pengurangan 0;
     * - nilai akhir lebih kecil daripada nilai awal;
     * - meter mengalami reset.
     */
    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: formatDateTime(
            validStartRow.date_time
        ),
        endDatetime: formatDateTime(
            validEndRow.date_time
        ),
        startValue,
        endValue,
        totalValue
    };
}

// ============================================================
// INSERT ATAU UPDATE DATA SHIFTLY
// ============================================================

async function upsertShiftlyToTable(
    connection,
    line,
    data
) {
    const safeTargetTable = escapeIdentifier(
        line.target_table
    );

    const [result] = await connection.query(
        `
        INSERT INTO ${safeTargetTable} (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, NOW(), NOW()
        )
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_table = VALUES(line_table),
            line_name = VALUES(line_name),
            shift_start_datetime =
                VALUES(shift_start_datetime),
            shift_end_datetime =
                VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
        `,
        [
            line.pm_type,
            line.source_table,
            line.line_name,
            data.shift,
            data.shift_date,
            data.shift_start_datetime,
            data.shift_end_datetime,
            data.start_kwh,
            data.end_kwh,
            data.total_kwh,
            data.year,
            data.month,
            data.month_name,
            data.day,
            data.day_name
        ]
    );

    let action = "Tidak Berubah";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ` +
        `${line.target_table} | ` +
        `${data.shift} | ` +
        `${data.shift_date} | ` +
        `${data.total_kwh} kWh`
    );
}

// ============================================================
// MENGAMBIL SEMUA TANGGAL YANG TERSEDIA
// ============================================================

async function getAvailableDates(
    connection,
    sourceTable
) {
    const safeSourceTable = escapeIdentifier(
        sourceTable
    );

    const [rows] = await connection.query(
        `
        SELECT DISTINCT
            DATE_FORMAT(
                date_time,
                '%Y-%m-%d'
            ) AS shift_date
        FROM ${safeSourceTable}
        WHERE date_time IS NOT NULL
        ORDER BY shift_date ASC
        `
    );

    return rows
        .map((row) => row.shift_date)
        .filter(Boolean);
}

// ============================================================
// MEMPROSES SATU PANEL
// ============================================================

async function processLine(
    connection,
    line
) {
    console.log(
        `\n🔍 Proses Shiftly: ` +
        `${line.source_table} -> ` +
        `${line.target_table}`
    );

    const availableDates = await getAvailableDates(
        connection,
        line.source_table
    );

    if (!availableDates.length) {
        console.log(
            `⚠️ Tidak ada data tanggal pada tabel sumber: ` +
            `${line.source_table}`
        );

        return;
    }

    console.log(
        `📅 Jumlah tanggal ditemukan: ` +
        `${availableDates.length}`
    );

    for (const shiftDate of availableDates) {
        const dateObj = moment(
            shiftDate,
            "YYYY-MM-DD",
            true
        );

        if (!dateObj.isValid()) {
            console.log(
                `⚠️ Format tanggal tidak valid: ${shiftDate}`
            );

            continue;
        }

        const year = Number(
            dateObj.format("YYYY")
        );

        const month = Number(
            dateObj.format("M")
        );

        const day = Number(
            dateObj.format("D")
        );

        const monthName = dateObj.format("MMMM");
        const dayName = dateObj.format("dddd");

        // ====================================================
        // SHIFT 1: 07:10 sampai sebelum 19:50
        // ====================================================

        const shift1Start = moment(
            shiftDate,
            "YYYY-MM-DD"
        ).set({
            hour: 7,
            minute: 10,
            second: 0,
            millisecond: 0
        });

        const shift1End = moment(
            shiftDate,
            "YYYY-MM-DD"
        ).set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        // ====================================================
        // SHIFT 2: 19:50 sampai sebelum 07:10 hari berikutnya
        // ====================================================

        const shift2Start = moment(
            shiftDate,
            "YYYY-MM-DD"
        ).set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        const shift2End = moment(
            shiftDate,
            "YYYY-MM-DD"
        )
            .add(1, "day")
            .set({
                hour: 7,
                minute: 10,
                second: 0,
                millisecond: 0
            });

        // ====================================================
        // PROSES SHIFT 1
        // ====================================================

        const shift1Data = await getShiftData(
            connection,
            line.source_table,
            shift1Start,
            shift1End
        );

        if (shift1Data) {
            await upsertShiftlyToTable(
                connection,
                line,
                {
                    shift: "shift_1",
                    shift_date: shiftDate,
                    shift_start_datetime:
                        shift1Data.startDatetime,
                    shift_end_datetime:
                        shift1Data.endDatetime,
                    start_kwh:
                        shift1Data.startValue,
                    end_kwh:
                        shift1Data.endValue,
                    total_kwh:
                        shift1Data.totalValue,
                    year,
                    month,
                    month_name: monthName,
                    day,
                    day_name: dayName
                }
            );
        } else {
            console.log(
                `⚠️ Skip: ` +
                `${line.target_table} | ` +
                `shift_1 | ` +
                `${shiftDate} | ` +
                `data kosong, tidak valid, 0, atau negatif`
            );
        }

        // ====================================================
        // PROSES SHIFT 2
        // ====================================================

        const shift2Data = await getShiftData(
            connection,
            line.source_table,
            shift2Start,
            shift2End
        );

        if (shift2Data) {
            await upsertShiftlyToTable(
                connection,
                line,
                {
                    shift: "shift_2",
                    shift_date: shiftDate,
                    shift_start_datetime:
                        shift2Data.startDatetime,
                    shift_end_datetime:
                        shift2Data.endDatetime,
                    start_kwh:
                        shift2Data.startValue,
                    end_kwh:
                        shift2Data.endValue,
                    total_kwh:
                        shift2Data.totalValue,
                    year,
                    month,
                    month_name: monthName,
                    day,
                    day_name: dayName
                }
            );
        } else {
            console.log(
                `⚠️ Skip: ` +
                `${line.target_table} | ` +
                `shift_2 | ` +
                `${shiftDate} | ` +
                `data kosong, tidak valid, 0, atau negatif`
            );
        }
    }
}

// ============================================================
// PROGRAM UTAMA
// ============================================================

async function rekapShiftly() {
    let connection;

    try {
        connection = await pool.getConnection();

        console.log("========================================");
        console.log("🚀 MULAI REKAP DATA WH SHIFTLY");
        console.log("========================================");

        console.log(
            "🔐 Mode UPSERT aktif. Data tidak akan " +
            "double apabila UNIQUE KEY sudah benar."
        );

        console.log(
            `⚙️ Pembagi konversi WH ke KWH: ` +
            `${WH_TO_KWH_DIVISOR}`
        );

        for (const line of lineTables) {
            try {
                await processLine(
                    connection,
                    line
                );
            } catch (lineError) {
                console.error(
                    `❌ Error pada line ` +
                    `${line.source_table} -> ` +
                    `${line.target_table}:`,
                    lineError
                );
            }
        }

        console.log("\n========================================");
        console.log("🎉 REKAP DATA SHIFTLY SELESAI");
        console.log("========================================");
    } catch (error) {
        console.error(
            "❌ Error utama rekap shiftly:",
            error
        );

        throw error;
    } finally {
        if (connection) {
            connection.release();

            console.log(
                "🔚 Koneksi database dilepas."
            );
        }
    }
}

// ============================================================
// MENJALANKAN PROGRAM
// ============================================================

rekapShiftly()
    .then(() => {
        console.log("✅ Program selesai.");
        process.exit(0);
    })
    .catch((error) => {
        console.error(
            "❌ Program gagal:",
            error
        );

        process.exit(1);
    });