// ======================================================
// REKAP MONTHLY KUB PANEL 16 & PANEL 17 WH
// ======================================================

// TRUNCATE TABLE tb_kub_panel_16_wh_monthly;
// TRUNCATE TABLE tb_kub_panel_17_wh_monthly;


const pool = require("../database");
const moment = require("moment-timezone");


const TIMEZONE = "Asia/Jakarta";
const DATE_TIME_FORMAT = "YYYY-MM-DD HH:mm:ss";

const JOB_LOCK_NAME =
    "rekap_monthly_kub_panel_wh";


moment.tz.setDefault(TIMEZONE);
moment.locale("id");



/**
 * Konfigurasi panel
 */
const lineTables = [

    {
        pm_type: "DA_01",

        source_table:
            "tb_kub_panel_16_wh",

        target_table:
            "tb_kub_panel_16_wh_monthly",

        line_name:
            "Panel_16",


        /*
         * 1    = jika wh sudah kWh
         * 1000 = jika wh masih Wh
         */
        wh_divisor: 1
    },


    {
        pm_type: "DA_01",

        source_table:
            "tb_kub_panel_17_wh",

        target_table:
            "tb_kub_panel_17_wh_monthly",

        line_name:
            "Panel_17",


        wh_divisor: 1
    }

];



const IDENTIFIER_PATTERN =
    /^[A-Za-z0-9_]+$/;



/**
 * Validasi nama tabel
 */
function validateIdentifier(
    identifier,
    fieldName
){

    if(
        !IDENTIFIER_PATTERN.test(identifier)
    ){

        throw new Error(
            `${fieldName} tidak valid : ${identifier}`
        );

    }

}



/**
 * Escape nama tabel
 */
function escapeIdentifier(
    identifier
){

    validateIdentifier(
        identifier,
        "identifier"
    );


    return `\`${identifier}\``;

}




/**
 * Validasi konfigurasi
 */
function validateConfiguration(){


    if(
        !Array.isArray(lineTables) ||
        lineTables.length === 0
    ){

        throw new Error(
            "lineTables kosong"
        );

    }



    for(
        const line of lineTables
    ){


        validateIdentifier(
            line.source_table,
            "source_table"
        );


        validateIdentifier(
            line.target_table,
            "target_table"
        );



        if(
            !line.pm_type ||
            !line.line_name
        ){

            throw new Error(
                "pm_type atau line_name kosong"
            );

        }


    }


}






/**
 * Convert nilai WH menjadi angka
 */
function parseWH(
    value,
    divisor
){

    if(
        value === null ||
        value === undefined
    ){

        return null;

    }



    const number =
        Number.parseFloat(
            String(value)
            .replace(",",".")
            .trim()
        );



    if(
        !Number.isFinite(number)
    ){

        return null;

    }



    return number / divisor;

}






/**
 * Ambil nilai awal dan akhir bulan
 */
async function getMonthlyData(
    connection,
    line,
    startTime,
    endTime
){


    const table =
        escapeIdentifier(
            line.source_table
        );



    const params = [

        startTime.format(
            DATE_TIME_FORMAT
        ),

        endTime.format(
            DATE_TIME_FORMAT
        )

    ];





    // nilai awal bulan

    const [
        startRows
    ] =
    await connection.query(`


        SELECT

            date_time,
            wh


        FROM ${table}


        WHERE date_time >= ?
        AND date_time < ?

        AND wh IS NOT NULL


        ORDER BY

            date_time ASC,
            idPrimary ASC


        LIMIT 1


    `,
    params);





    // nilai akhir bulan


    const [
        endRows
    ] =
    await connection.query(`


        SELECT

            date_time,
            wh


        FROM ${table}


        WHERE date_time >= ?
        AND date_time < ?


        AND wh IS NOT NULL


        ORDER BY

            date_time DESC,
            idPrimary DESC


        LIMIT 1


    `,
    params);






    if(
        startRows.length === 0 ||
        endRows.length === 0
    ){

        return null;

    }






    const startKwh =
        parseWH(
            startRows[0].wh,
            line.wh_divisor
        );



    const endKwh =
        parseWH(
            endRows[0].wh,
            line.wh_divisor
        );





    if(
        !Number.isFinite(startKwh) ||
        !Number.isFinite(endKwh)
    ){

        return null;

    }





    const totalKwh =
        endKwh - startKwh;




    if(
        totalKwh <= 0
    ){

        return null;

    }




    return {


        startDatetime:
            startRows[0].date_time,


        endDatetime:
            endRows[0].date_time,


        startKwh,

        endKwh,

        totalKwh


    };

}







/**
 * Insert atau update monthly
 */
async function upsertMonthly(
    connection,
    line,
    data
){


    const table =
        escapeIdentifier(
            line.target_table
        );




    const [
        existing
    ] =
    await connection.query(`


        SELECT 1


        FROM ${table}


        WHERE pm_type = ?

        AND line_table = ?

        AND line_name = ?

        AND year = ?

        AND month = ?


        LIMIT 1


    `,
    [

        line.pm_type,

        line.source_table,

        line.line_name,

        data.year,

        data.month

    ]);







    if(
        existing.length > 0
    ){



        await connection.query(`


            UPDATE ${table}


            SET


                start_kwh = ?,

                end_kwh = ?,

                total_kwh = ?,


                month_name = ?,


                month_start_date = ?,

                month_end_date = ?,


                month_start_datetime = ?,

                month_end_datetime = ?,


                updated_at = NOW()



            WHERE pm_type = ?

            AND line_table = ?

            AND line_name = ?

            AND year = ?

            AND month = ?



        `,
        [


            data.start_kwh,

            data.end_kwh,

            data.total_kwh,


            data.month_name,


            data.month_start_date,

            data.month_end_date,


            data.month_start_datetime,

            data.month_end_datetime,



            line.pm_type,

            line.source_table,

            line.line_name,

            data.year,

            data.month


        ]);





        console.log(
            `🔄 UPDATE ${line.line_name} ${data.year}-${data.month}`
        );



    }

    else
    {




        await connection.query(`


            INSERT INTO ${table}


            (

                pm_type,

                line_table,

                line_name,


                start_kwh,

                end_kwh,

                total_kwh,


                year,

                month,

                month_name,


                month_start_date,

                month_end_date,


                month_start_datetime,

                month_end_datetime,


                created_at,

                updated_at


            )


            VALUES

            (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())


        `,
        [


            line.pm_type,

            line.source_table,

            line.line_name,


            data.start_kwh,

            data.end_kwh,

            data.total_kwh,


            data.year,

            data.month,

            data.month_name,


            data.month_start_date,

            data.month_end_date,


            data.month_start_datetime,

            data.month_end_datetime


        ]);





        console.log(
            `✅ INSERT ${line.line_name} ${data.year}-${data.month}`
        );


    }


}









/**
 * MySQL Lock
 */
async function acquireLock(
    connection
){


    const [
        rows
    ] =
    await connection.query(

        "SELECT GET_LOCK(?,0) acquired",

        [
            JOB_LOCK_NAME
        ]

    );



    return Number(
        rows[0].acquired
    ) === 1;


}






async function releaseLock(
    connection
){


    await connection.query(

        "SELECT RELEASE_LOCK(?)",

        [
            JOB_LOCK_NAME
        ]

    );


}








/**
 * MAIN PROCESS
 */
async function rekapMonthly(){


    validateConfiguration();



    const connection =
        await pool.getConnection();



    let locked = false;



    try{


        locked =
            await acquireLock(
                connection
            );



        if(!locked){


            console.log(
                "⚠️ Job masih berjalan"
            );


            return;

        }





        console.log(

            "🚀 START REKAP MONTHLY "

            +

            moment()
            .format(
                "YYYY-MM-DD HH:mm:ss"
            )

        );






        for(
            const line of lineTables
        ){




            const source =
                escapeIdentifier(
                    line.source_table
                );




            const [
                months
            ] =
            await connection.query(`


                SELECT DISTINCT


                    YEAR(date_time)
                    year_num,


                    MONTH(date_time)
                    month_num



                FROM ${source}


                ORDER BY

                    year_num,

                    month_num



            `);






            for(
                const m of months
            ){



                const year =
                    Number(
                        m.year_num
                    );



                const month =
                    Number(
                        m.month_num
                    );




                const start =
                    moment.tz(

                        `${year}-${String(month).padStart(2,"0")}-01 00:00:00`,

                        DATE_TIME_FORMAT,

                        TIMEZONE

                    );




                const end =
                    start
                    .clone()
                    .add(
                        1,
                        "month"
                    );







                const result =
                    await getMonthlyData(

                        connection,

                        line,

                        start,

                        end

                    );






                if(!result){


                    console.log(

                        `⚠️ Skip ${line.line_name} ${year}-${month}`

                    );


                    continue;

                }







                await upsertMonthly(

                    connection,

                    line,

                    {


                        year,

                        month,


                        month_name:
                            start.format(
                                "MMMM"
                            ),


                        month_start_date:
                            start.format(
                                "YYYY-MM-DD"
                            ),


                        month_end_date:
                            end.clone()
                            .subtract(
                                1,
                                "day"
                            )
                            .format(
                                "YYYY-MM-DD"
                            ),



                        month_start_datetime:
                            result.startDatetime,



                        month_end_datetime:
                            result.endDatetime,



                        start_kwh:
                            result.startKwh,



                        end_kwh:
                            result.endKwh,



                        total_kwh:
                            result.totalKwh


                    }

                );



            }


        }





        console.log(
            "🎉 REKAP MONTHLY SELESAI"
        );



    }
    finally{


        if(locked){

            await releaseLock(
                connection
            );

        }



        connection.release();


    }


}








// ======================================================
// SCHEDULER HARIAN 07:40 WIB
// ======================================================

const SCHEDULE_HOUR = 7;
const SCHEDULE_MINUTE = 40;

let scheduleTimer = null;
let isShuttingDown = false;


/**
 * Jalankan job tanpa menghentikan scheduler ketika terjadi error.
 */
async function runJobSafely(){

    try{

        await rekapMonthly();

    }
    catch(error){

        console.error(
            "❌ ERROR REKAP : ",
            error
        );

    }

}


/**
 * Hitung jadwal 07:40 WIB berikutnya.
 */
function getNextRunTime(){

    const now = moment.tz(TIMEZONE);

    let nextRun = now
        .clone()
        .hour(SCHEDULE_HOUR)
        .minute(SCHEDULE_MINUTE)
        .second(0)
        .millisecond(0);

    if(
        nextRun.isSameOrBefore(now)
    ){

        nextRun.add(1, "day");

    }

    return nextRun;

}


/**
 * Jadwalkan eksekusi berikutnya secara rekursif.
 */
function scheduleNextRun(){

    if(isShuttingDown){
        return;
    }

    const now = moment.tz(TIMEZONE);
    const nextRun = getNextRunTime();
    const delayMs = nextRun.diff(now);

    console.log(
        `⏰ Jadwal berikutnya: ${nextRun.format("YYYY-MM-DD HH:mm:ss")} WIB`
    );

    scheduleTimer = setTimeout(
        async () => {

            await runJobSafely();
            scheduleNextRun();

        },
        delayMs
    );

}


/**
 * Tutup koneksi database dengan aman saat aplikasi dihentikan.
 */
async function shutdown(signal){

    if(isShuttingDown){
        return;
    }

    isShuttingDown = true;

    console.log(
        `
🛑 Menerima ${signal}, menghentikan scheduler...`
    );

    if(scheduleTimer){
        clearTimeout(scheduleTimer);
        scheduleTimer = null;
    }

    try{

        if(
            typeof pool.end === "function"
        ){

            await pool.end();

        }

        console.log(
            "✅ Koneksi database ditutup"
        );

        process.exit(0);

    }
    catch(error){

        console.error(
            "❌ Gagal menutup koneksi database:",
            error
        );

        process.exit(1);

    }

}


async function main(){

    console.log(
        "🚀 Scheduler rekap monthly aktif"
    );

    // Jalankan sekali saat program pertama kali dinyalakan.
    await runJobSafely();

    // Setelah itu, ulangi setiap hari pukul 07:40 WIB.
    scheduleNextRun();

}


process.on(
    "SIGINT",
    () => shutdown("SIGINT")
);

process.on(
    "SIGTERM",
    () => shutdown("SIGTERM")
);


main().catch(
    async error => {

        console.error(
            "❌ ERROR FATAL : ",
            error
        );

        await shutdown("ERROR FATAL");

    }
);
