// TRUNCATE TABLE tb_comp_19_shiftly;
// TRUNCATE TABLE tb_comp_20_shiftly;
// TRUNCATE TABLE tb_comp_21_shiftly;
// TRUNCATE TABLE tb_comp_24_shiftly;






"use strict";

const pool = require("../database");
const moment = require("moment-timezone");
require("moment/locale/id");

const TIMEZONE = "Asia/Jakarta";
const LOCK_NAME = "rekap_comp_shiftly_v4";
const REQUIRED_UNIQUE_COLUMNS = [
    "line_table",
    "line_name",
    "shift_date",
    "shift"
];

moment.tz.setDefault(TIMEZONE);
moment.locale("id");

function envInteger(name, defaultValue, minimum = 0) {
    const rawValue = process.env[name];

    if (rawValue === undefined || rawValue === "") {
        return defaultValue;
    }

    const parsedValue = Number(rawValue);

    if (!Number.isInteger(parsedValue) || parsedValue < minimum) {
        throw new Error(
            `${name} harus berupa bilangan bulat minimal ${minimum}. Nilai diterima: ${rawValue}`
        );
    }

    return parsedValue;
}

function envBoolean(name, defaultValue) {
    const rawValue = process.env[name];

    if (rawValue === undefined || rawValue === "") {
        return defaultValue;
    }

    const normalized = String(rawValue).trim().toLowerCase();

    if (["true", "1", "yes", "y"].includes(normalized)) {
        return true;
    }

    if (["false", "0", "no", "n"].includes(normalized)) {
        return false;
    }

    throw new Error(`${name} harus bernilai true atau false.`);
}

/**
 * Pengaturan aman untuk eksekusi berkala.
 *
 * LOOKBACK_DAYS:
 *   Setelah backfill pertama, program hanya mengecek ulang beberapa hari
 *   terakhir agar data terlambat masih dapat memperbarui hasil rekap.
 *
 * SHIFT_GRACE_MINUTES:
 *   Shift baru diproses setelah waktu akhir shift ditambah masa tunggu.
 *   Ini mencegah data shift aktif/parsial masuk ke tabel tujuan.
 *
 * BOUNDARY_TOLERANCE_MINUTES:
 *   Pembacaan pertama dan terakhir wajib berada dekat batas awal/akhir shift.
 *
 * AUTO_BACKFILL_EMPTY_PANEL:
 *   Jika suatu panel belum pernah masuk tabel tujuan, seluruh riwayat panel
 *   tersebut diproses satu kali. Setelah itu hanya LOOKBACK_DAYS yang diproses.
 *
 * ALLOW_ZERO_TOTAL:
 *   false = total pemakaian 0 dilewati, mengikuti perilaku program lama.
 *   true  = total pemakaian 0 dianggap valid dan tetap disimpan.
 */
const SETTINGS = Object.freeze({
    lookbackDays: envInteger("LOOKBACK_DAYS", 3, 1),
    shiftGraceMinutes: envInteger("SHIFT_GRACE_MINUTES", 20, 0),
    boundaryToleranceMinutes: envInteger(
        "BOUNDARY_TOLERANCE_MINUTES",
        30,
        0
    ),
    minimumSamples: envInteger("MINIMUM_SAMPLES", 2, 2),
    autoBackfillEmptyPanel: envBoolean("AUTO_BACKFILL_EMPTY_PANEL", true),
    forceBackfillAll: envBoolean("BACKFILL_ALL", false),
    allowZeroTotal: envBoolean("ALLOW_ZERO_TOTAL", false),
    lockWaitSeconds: envInteger("LOCK_WAIT_SECONDS", 0, 0)
});

/**
 * value_divisor:
 * - 1000 = kolom wh benar-benar dalam Wh dan dikonversi ke kWh.
 * - 1    = kolom wh sebenarnya sudah menyimpan nilai kWh.
 */
const lineTables = Object.freeze([
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_19",
        target_table: "tb_comp_19_shiftly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_20",
        target_table: "tb_comp_20_shiftly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_21",
        target_table: "tb_comp_21_shiftly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_24",
        target_table: "tb_comp_24_shiftly",
        value_divisor: 1000
    }
]);

function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Identifier tidak valid: ${identifier}`);
    }

    return `\`${identifier}\``;
}

function normalizePanel(panel) {
    return String(panel ?? "").trim();
}

function parseWhAsBigInt(value, fieldName) {
    const normalized = String(value ?? "").trim();

    if (!/^-?\d+$/.test(normalized)) {
        throw new Error(`${fieldName} bukan bilangan bulat yang valid: ${value}`);
    }

    return BigInt(normalized);
}

/**
 * Membagi nilai integer secara aman tanpa kehilangan presisi BIGINT,
 * kemudian mengembalikan string DECIMAL dengan tiga angka di belakang koma.
 */
function divideBigIntToFixed(value, divisor, decimalPlaces = 3) {
    const divisorBigInt = BigInt(divisor);

    if (divisorBigInt <= 0n) {
        throw new Error(`value_divisor harus lebih besar dari 0: ${divisor}`);
    }

    const scale = 10n ** BigInt(decimalPlaces);
    const isNegative = value < 0n;
    const absoluteValue = isNegative ? -value : value;

    // Pembulatan half-up ke tiga angka desimal.
    const scaledValue =
        (absoluteValue * scale + divisorBigInt / 2n) / divisorBigInt;

    const wholePart = scaledValue / scale;
    const fractionPart = String(scaledValue % scale).padStart(
        decimalPlaces,
        "0"
    );

    return `${isNegative ? "-" : ""}${wholePart}.${fractionPart}`;
}

async function acquireProgramLock(connection) {
    const [rows] = await connection.query(
        "SELECT GET_LOCK(?, ?) AS acquired",
        [LOCK_NAME, SETTINGS.lockWaitSeconds]
    );

    return Number(rows[0]?.acquired) === 1;
}

async function releaseProgramLock(connection) {
    try {
        await connection.query("SELECT RELEASE_LOCK(?)", [LOCK_NAME]);
    } catch (error) {
        console.error(`⚠️ Gagal melepas database lock: ${error.message}`);
    }
}

async function getTableColumns(connection, tableName) {
    const [rows] = await connection.query(
        `
            SELECT COLUMN_NAME
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
        `,
        [tableName]
    );

    return new Set(rows.map((row) => row.COLUMN_NAME));
}

async function assertRequiredColumns(
    connection,
    tableName,
    requiredColumns,
    tableRole
) {
    const columns = await getTableColumns(connection, tableName);

    if (!columns.size) {
        throw new Error(`${tableRole} tidak ditemukan: ${tableName}`);
    }

    const missingColumns = requiredColumns.filter(
        (columnName) => !columns.has(columnName)
    );

    if (missingColumns.length) {
        throw new Error(
            `${tableRole} ${tableName} tidak memiliki kolom: ${missingColumns.join(
                ", "
            )}`
        );
    }
}

async function assertUniqueKey(connection, targetTable) {
    const [rows] = await connection.query(
        `
            SELECT
                INDEX_NAME,
                GROUP_CONCAT(
                    COLUMN_NAME
                    ORDER BY SEQ_IN_INDEX
                    SEPARATOR ','
                ) AS index_columns
            FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
              AND NON_UNIQUE = 0
            GROUP BY INDEX_NAME
        `,
        [targetTable]
    );

    const requiredSignature = REQUIRED_UNIQUE_COLUMNS.join(",");
    const uniqueKeyExists = rows.some(
        (row) => String(row.index_columns).toLowerCase() === requiredSignature
    );

    if (!uniqueKeyExists) {
        throw new Error(
            `UNIQUE KEY (${requiredSignature}) belum tersedia pada ${targetTable}. ` +
                "Jalankan setup_comp_shiftly_safe.sql terlebih dahulu."
        );
    }
}

async function validateLineConfiguration(connection, line) {
    await assertRequiredColumns(
        connection,
        line.source_table,
        ["idPrimary", "panel", "wh", "date_time"],
        "Tabel sumber"
    );

    await assertRequiredColumns(
        connection,
        line.target_table,
        [
            "idPrimary",
            "pm_type",
            "line_table",
            "line_name",
            "shift",
            "shift_date",
            "shift_start_datetime",
            "shift_end_datetime",
            "start_kwh",
            "end_kwh",
            "total_kwh",
            "year",
            "month",
            "month_name",
            "day",
            "day_name",
            "created_at",
            "updated_at"
        ],
        "Tabel tujuan"
    );

    await assertUniqueKey(connection, line.target_table);
}

/**
 * Mengambil panel mentah untuk query sumber, serta nama panel yang sudah
 * dirapikan untuk disimpan sebagai line_name.
 *
 * Dua nilai panel yang hanya berbeda spasi ditolak agar tidak saling
 * menimpa pada UNIQUE KEY tabel tujuan.
 */
async function getAvailablePanels(connection, sourceTable) {
    const safeSourceTable = escapeIdentifier(sourceTable);

    const [rows] = await connection.query(`
        SELECT DISTINCT panel
        FROM ${safeSourceTable}
        WHERE panel IS NOT NULL
          AND TRIM(panel) <> ''
        ORDER BY panel ASC
    `);

    const normalizedPanelMap = new Map();

    for (const row of rows) {
        const sourcePanel = String(row.panel);
        const lineName = normalizePanel(sourcePanel);

        if (normalizedPanelMap.has(lineName)) {
            const previousPanel = normalizedPanelMap.get(lineName).sourcePanel;

            throw new Error(
                `Panel tidak konsisten pada ${sourceTable}: ` +
                    `"${previousPanel}" dan "${sourcePanel}" menjadi line_name ` +
                    `yang sama setelah TRIM, yaitu "${lineName}".`
            );
        }

        normalizedPanelMap.set(lineName, { sourcePanel, lineName });
    }

    return Array.from(normalizedPanelMap.values());
}

async function targetHasPanelData(connection, line, lineName) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [rows] = await connection.query(
        `
            SELECT idPrimary
            FROM ${safeTargetTable}
            WHERE line_table = ?
              AND line_name = ?
            LIMIT 1
        `,
        [line.source_table, lineName]
    );

    return rows.length > 0;
}

async function getAvailableDates(
    connection,
    sourceTable,
    sourcePanel,
    processAllDates
) {
    const safeSourceTable = escapeIdentifier(sourceTable);
    const parameters = [sourcePanel];
    let dateFilter = "";

    if (!processAllDates) {
        const minimumDate = moment
            .tz(TIMEZONE)
            .subtract(SETTINGS.lookbackDays, "days")
            .startOf("day")
            .format("YYYY-MM-DD HH:mm:ss");

        dateFilter = "AND date_time >= ?";
        parameters.push(minimumDate);
    }

    const [rows] = await connection.query(
        `
            SELECT DISTINCT DATE_FORMAT(date_time, '%Y-%m-%d') AS shift_date
            FROM ${safeSourceTable}
            WHERE date_time IS NOT NULL
              AND panel = ?
              ${dateFilter}
            ORDER BY shift_date ASC
        `,
        parameters
    );

    return rows.map((row) => row.shift_date);
}

function buildShiftWindows(shiftDate) {
    const dateObject = moment.tz(shiftDate, "YYYY-MM-DD", TIMEZONE);

    return [
        {
            shift: "shift_1",
            start: dateObject.clone().set({
                hour: 7,
                minute: 10,
                second: 0,
                millisecond: 0
            }),
            end: dateObject.clone().set({
                hour: 19,
                minute: 50,
                second: 0,
                millisecond: 0
            })
        },
        {
            shift: "shift_2",
            start: dateObject.clone().set({
                hour: 19,
                minute: 50,
                second: 0,
                millisecond: 0
            }),
            end: dateObject.clone().add(1, "day").set({
                hour: 7,
                minute: 10,
                second: 0,
                millisecond: 0
            })
        }
    ];
}

function getDateMetadata(shiftDate) {
    const dateObject = moment.tz(shiftDate, "YYYY-MM-DD", TIMEZONE);

    return {
        year: Number(dateObject.format("YYYY")),
        month: Number(dateObject.format("M")),
        month_name: dateObject.format("MMMM"),
        day: Number(dateObject.format("D")),
        day_name: dateObject.format("dddd")
    };
}

function isShiftReady(shiftEnd, currentTime) {
    const readyAt = shiftEnd
        .clone()
        .add(SETTINGS.shiftGraceMinutes, "minutes");

    return !currentTime.isBefore(readyAt);
}

async function getShiftData(
    connection,
    line,
    sourcePanel,
    shiftStart,
    shiftEnd
) {
    const safeSourceTable = escapeIdentifier(line.source_table);
    const startTime = shiftStart.format("YYYY-MM-DD HH:mm:ss");
    const endTime = shiftEnd.format("YYYY-MM-DD HH:mm:ss");
    const queryParameters = [sourcePanel, startTime, endTime];

    const [countRows] = await connection.query(
        `
            SELECT COUNT(*) AS sample_count
            FROM ${safeSourceTable}
            WHERE panel = ?
              AND date_time >= ?
              AND date_time <= ?
              AND wh IS NOT NULL
        `,
        queryParameters
    );

    const sampleCount = Number(countRows[0]?.sample_count || 0);

    if (sampleCount < SETTINGS.minimumSamples) {
        return {
            valid: false,
            reason:
                `jumlah sampel ${sampleCount}, minimal ` +
                `${SETTINGS.minimumSamples}`
        };
    }

    const [startRows] = await connection.query(
        `
            SELECT
                idPrimary,
                wh,
                DATE_FORMAT(date_time, '%Y-%m-%d %H:%i:%s') AS reading_time
            FROM ${safeSourceTable}
            WHERE panel = ?
              AND date_time >= ?
              AND date_time <= ?
              AND wh IS NOT NULL
            ORDER BY date_time ASC, idPrimary ASC
            LIMIT 1
        `,
        queryParameters
    );

    const [endRows] = await connection.query(
        `
            SELECT
                idPrimary,
                wh,
                DATE_FORMAT(date_time, '%Y-%m-%d %H:%i:%s') AS reading_time
            FROM ${safeSourceTable}
            WHERE panel = ?
              AND date_time >= ?
              AND date_time <= ?
              AND wh IS NOT NULL
            ORDER BY date_time DESC, idPrimary DESC
            LIMIT 1
        `,
        queryParameters
    );

    if (!startRows.length || !endRows.length) {
        return { valid: false, reason: "nilai awal atau akhir tidak ditemukan" };
    }

    const firstReadingTime = moment.tz(
        startRows[0].reading_time,
        "YYYY-MM-DD HH:mm:ss",
        TIMEZONE
    );
    const lastReadingTime = moment.tz(
        endRows[0].reading_time,
        "YYYY-MM-DD HH:mm:ss",
        TIMEZONE
    );

    if (!firstReadingTime.isValid() || !lastReadingTime.isValid()) {
        return { valid: false, reason: "format waktu pembacaan tidak valid" };
    }

    if (!lastReadingTime.isAfter(firstReadingTime)) {
        return {
            valid: false,
            reason: "waktu pembacaan akhir tidak lebih besar dari awal"
        };
    }

    const startGapMinutes = firstReadingTime.diff(
        shiftStart,
        "minutes",
        true
    );
    const endGapMinutes = shiftEnd.diff(lastReadingTime, "minutes", true);

    if (
        startGapMinutes < 0 ||
        startGapMinutes > SETTINGS.boundaryToleranceMinutes
    ) {
        return {
            valid: false,
            reason:
                `pembacaan awal berjarak ${startGapMinutes.toFixed(1)} menit ` +
                `dari awal shift; toleransi maksimal ` +
                `${SETTINGS.boundaryToleranceMinutes} menit`
        };
    }

    if (
        endGapMinutes < 0 ||
        endGapMinutes > SETTINGS.boundaryToleranceMinutes
    ) {
        return {
            valid: false,
            reason:
                `pembacaan akhir berjarak ${endGapMinutes.toFixed(1)} menit ` +
                `dari akhir shift; toleransi maksimal ` +
                `${SETTINGS.boundaryToleranceMinutes} menit`
        };
    }

    let rawStartWh;
    let rawEndWh;

    try {
        rawStartWh = parseWhAsBigInt(startRows[0].wh, "start wh");
        rawEndWh = parseWhAsBigInt(endRows[0].wh, "end wh");
    } catch (error) {
        return { valid: false, reason: error.message };
    }

    const rawTotalWh = rawEndWh - rawStartWh;

    if (rawTotalWh < 0n) {
        return {
            valid: false,
            reason: "nilai meter turun/reset sehingga total menjadi negatif"
        };
    }

    if (rawTotalWh === 0n && !SETTINGS.allowZeroTotal) {
        return {
            valid: false,
            reason: "total pemakaian 0 dan ALLOW_ZERO_TOTAL=false"
        };
    }

    return {
        valid: true,
        sampleCount,
        startDatetime: startRows[0].reading_time,
        endDatetime: endRows[0].reading_time,
        startKwh: divideBigIntToFixed(
            rawStartWh,
            line.value_divisor,
            3
        ),
        endKwh: divideBigIntToFixed(rawEndWh, line.value_divisor, 3),
        totalKwh: divideBigIntToFixed(
            rawTotalWh,
            line.value_divisor,
            3
        )
    };
}

/**
 * UPSERT bersifat atomic. UNIQUE KEY mencegah baris ganda, sedangkan nilai
 * yang sama persis tidak mengubah updated_at.
 */
async function upsertShiftlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(
        `
            INSERT INTO ${safeTargetTable} (
                pm_type,
                line_table,
                line_name,
                shift,
                shift_date,
                shift_start_datetime,
                shift_end_datetime,
                start_kwh,
                end_kwh,
                total_kwh,
                year,
                month,
                month_name,
                day,
                day_name,
                created_at,
                updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ON DUPLICATE KEY UPDATE
                updated_at = IF(
                    NOT (pm_type <=> VALUES(pm_type))
                    OR NOT (shift_start_datetime <=> VALUES(shift_start_datetime))
                    OR NOT (shift_end_datetime <=> VALUES(shift_end_datetime))
                    OR NOT (start_kwh <=> VALUES(start_kwh))
                    OR NOT (end_kwh <=> VALUES(end_kwh))
                    OR NOT (total_kwh <=> VALUES(total_kwh))
                    OR NOT (year <=> VALUES(year))
                    OR NOT (month <=> VALUES(month))
                    OR NOT (month_name <=> VALUES(month_name))
                    OR NOT (day <=> VALUES(day))
                    OR NOT (day_name <=> VALUES(day_name)),
                    NOW(),
                    updated_at
                ),
                pm_type = VALUES(pm_type),
                shift_start_datetime = VALUES(shift_start_datetime),
                shift_end_datetime = VALUES(shift_end_datetime),
                start_kwh = VALUES(start_kwh),
                end_kwh = VALUES(end_kwh),
                total_kwh = VALUES(total_kwh),
                year = VALUES(year),
                month = VALUES(month),
                month_name = VALUES(month_name),
                day = VALUES(day),
                day_name = VALUES(day_name)
        `,
        [
            line.pm_type,
            line.source_table,
            data.line_name,
            data.shift,
            data.shift_date,
            data.shift_start_datetime,
            data.shift_end_datetime,
            data.start_kwh,
            data.end_kwh,
            data.total_kwh,
            data.year,
            data.month,
            data.month_name,
            data.day,
            data.day_name
        ]
    );

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | panel=${data.line_name} | ` +
            `${data.shift} | ${data.shift_date} | ${data.total_kwh} kWh | ` +
            `${data.sample_count} sampel`
    );
}

async function processShift(
    connection,
    line,
    panel,
    shiftDate,
    shiftWindow,
    currentTime,
    dateMetadata
) {
    if (!isShiftReady(shiftWindow.end, currentTime)) {
        const readyAt = shiftWindow.end
            .clone()
            .add(SETTINGS.shiftGraceMinutes, "minutes")
            .format("YYYY-MM-DD HH:mm:ss");

        console.log(
            `⏳ Belum diproses: ${line.target_table} | panel=${panel.lineName} | ` +
                `${shiftWindow.shift} | ${shiftDate} | siap setelah ${readyAt}`
        );
        return;
    }

    const shiftData = await getShiftData(
        connection,
        line,
        panel.sourcePanel,
        shiftWindow.start,
        shiftWindow.end
    );

    if (!shiftData.valid) {
        console.log(
            `⚠️ Skip: ${line.target_table} | panel=${panel.lineName} | ` +
                `${shiftWindow.shift} | ${shiftDate} | ${shiftData.reason}`
        );
        return;
    }

    await upsertShiftlyToTable(connection, line, {
        line_name: panel.lineName,
        shift: shiftWindow.shift,
        shift_date: shiftDate,
        shift_start_datetime: shiftData.startDatetime,
        shift_end_datetime: shiftData.endDatetime,
        start_kwh: shiftData.startKwh,
        end_kwh: shiftData.endKwh,
        total_kwh: shiftData.totalKwh,
        sample_count: shiftData.sampleCount,
        ...dateMetadata
    });
}

async function processLine(connection, line, currentTime) {
    console.log(`\n🔍 Validasi: ${line.source_table} -> ${line.target_table}`);
    await validateLineConfiguration(connection, line);

    const panels = await getAvailablePanels(connection, line.source_table);

    if (!panels.length) {
        console.log(`⚠️ Tidak ada panel pada tabel sumber: ${line.source_table}`);
        return;
    }

    for (const panel of panels) {
        const panelAlreadyHasTargetData = await targetHasPanelData(
            connection,
            line,
            panel.lineName
        );

        const processAllDates =
            SETTINGS.forceBackfillAll ||
            (SETTINGS.autoBackfillEmptyPanel && !panelAlreadyHasTargetData);

        console.log(
            `\n📌 Panel: ${panel.lineName} | mode=` +
                `${processAllDates ? "BACKFILL" : `LOOKBACK ${SETTINGS.lookbackDays} hari`}`
        );

        const availableDates = await getAvailableDates(
            connection,
            line.source_table,
            panel.sourcePanel,
            processAllDates
        );

        if (!availableDates.length) {
            console.log(
                `⚠️ Tidak ada tanggal yang perlu diproses untuk panel ` +
                    `${panel.lineName} pada ${line.source_table}`
            );
            continue;
        }

        for (const shiftDate of availableDates) {
            const dateMetadata = getDateMetadata(shiftDate);
            const shiftWindows = buildShiftWindows(shiftDate);

            for (const shiftWindow of shiftWindows) {
                await processShift(
                    connection,
                    line,
                    panel,
                    shiftDate,
                    shiftWindow,
                    currentTime,
                    dateMetadata
                );
            }
        }
    }
}

async function rekapShiftly() {
    const connection = await pool.getConnection();
    let lockAcquired = false;
    let failedLineCount = 0;

    try {
        lockAcquired = await acquireProgramLock(connection);

        if (!lockAcquired) {
            console.log(
                "⏭️ Program tidak dijalankan karena proses sebelumnya masih aktif. " +
                    "Ini mencegah dua proses berjalan bersamaan."
            );
            return;
        }

        const currentTime = moment.tz(TIMEZONE);

        console.log("🚀 Mulai rekap shiftly compressor...");
        console.log(`🕒 Waktu server aplikasi: ${currentTime.format("YYYY-MM-DD HH:mm:ss Z")}`);
        console.log("🔐 Database advisory lock aktif.");
        console.log("🔐 UPSERT + pemeriksaan UNIQUE KEY aktif.");
        console.log(
            `🛡️ Shift grace=${SETTINGS.shiftGraceMinutes} menit, ` +
                `boundary tolerance=${SETTINGS.boundaryToleranceMinutes} menit, ` +
                `lookback=${SETTINGS.lookbackDays} hari.`
        );

        for (const line of lineTables) {
            try {
                await processLine(connection, line, currentTime);
            } catch (lineError) {
                failedLineCount += 1;
                console.error(
                    `❌ Error pada ${line.source_table} -> ${line.target_table}:`,
                    lineError.message
                );
            }
        }

        if (failedLineCount > 0) {
            throw new Error(
                `${failedLineCount} tabel gagal diproses. Periksa log error di atas.`
            );
        }

        console.log("\n🎉 Rekap shiftly compressor selesai tanpa error.");
    } finally {
        if (lockAcquired) {
            await releaseProgramLock(connection);
        }

        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

rekapShiftly()
    .then(() => {
        console.log("✅ Program selesai.");
        process.exit(0);
    })
    .catch((error) => {
        console.error("❌ Program gagal:", error.message);
        process.exit(1);
    });
