// TRUNCATE TABLE tb_comp_19_monthly;
// TRUNCATE TABLE tb_comp_20_monthly;
// TRUNCATE TABLE tb_comp_21_monthly;
// TRUNCATE TABLE tb_comp_24_monthly;









"use strict";

const pool = require("../database");
const moment = require("moment-timezone");
require("moment/locale/id");

const TIMEZONE = "Asia/Jakarta";
const LOCK_NAME = "rekap_comp_monthly_v1";
const REQUIRED_UNIQUE_COLUMNS = [
    "line_table",
    "line_name",
    "year",
    "month"
];

moment.tz.setDefault(TIMEZONE);
moment.locale("id");

function envInteger(name, defaultValue, minimum = 0) {
    const rawValue = process.env[name];

    if (rawValue === undefined || rawValue === "") {
        return defaultValue;
    }

    const parsedValue = Number(rawValue);

    if (!Number.isInteger(parsedValue) || parsedValue < minimum) {
        throw new Error(
            `${name} harus berupa bilangan bulat minimal ${minimum}. ` +
                `Nilai diterima: ${rawValue}`
        );
    }

    return parsedValue;
}

function envBoolean(name, defaultValue) {
    const rawValue = process.env[name];

    if (rawValue === undefined || rawValue === "") {
        return defaultValue;
    }

    const normalized = String(rawValue).trim().toLowerCase();

    if (["true", "1", "yes", "y"].includes(normalized)) {
        return true;
    }

    if (["false", "0", "no", "n"].includes(normalized)) {
        return false;
    }

    throw new Error(`${name} harus bernilai true atau false.`);
}

/**
 * Pengaturan aman untuk program yang boleh dipanggil setiap 4 jam.
 *
 * LOOKBACK_MONTHS:
 *   Setelah backfill pertama, program mengecek ulang beberapa bulan terakhir.
 *   Data yang terlambat masuk masih dapat memperbarui hasil bulan tersebut.
 *
 * MONTH_GRACE_MINUTES:
 *   Bulan baru diproses setelah masuk bulan berikutnya dan melewati masa tunggu.
 *   Bulan berjalan tidak pernah disimpan sebagai hasil bulanan parsial.
 *
 * BOUNDARY_TOLERANCE_HOURS:
 *   Pembacaan awal dan akhir harus berada cukup dekat dengan batas bulan.
 *   Jika data terlalu jauh dari batas, bulan dilewati agar total tidak menyesatkan.
 *
 * AUTO_BACKFILL_EMPTY_PANEL:
 *   Panel yang belum pernah masuk tabel monthly akan diproses dari riwayat awal.
 *
 * BACKFILL_ALL=true:
 *   Paksa semua bulan historis diperiksa kembali pada satu kali eksekusi.
 *
 * ALLOW_ZERO_TOTAL:
 *   false = total 0 dilewati. true = total 0 tetap disimpan.
 */
const SETTINGS = Object.freeze({
    lookbackMonths: envInteger("LOOKBACK_MONTHS", 3, 1),
    monthGraceMinutes: envInteger("MONTH_GRACE_MINUTES", 60, 0),
    boundaryToleranceHours: envInteger(
        "BOUNDARY_TOLERANCE_HOURS",
        6,
        0
    ),
    minimumSamples: envInteger("MINIMUM_SAMPLES", 2, 2),
    autoBackfillEmptyPanel: envBoolean("AUTO_BACKFILL_EMPTY_PANEL", true),
    forceBackfillAll: envBoolean("BACKFILL_ALL", false),
    allowZeroTotal: envBoolean("ALLOW_ZERO_TOTAL", false),
    lockWaitSeconds: envInteger("LOCK_WAIT_SECONDS", 0, 0)
});

/**
 * value_divisor:
 * - 1000 = kolom wh benar-benar dalam Wh dan dikonversi menjadi kWh.
 * - 1    = kolom wh sebenarnya sudah menyimpan nilai kWh.
 */
const lineTables = Object.freeze([
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_19",
        target_table: "tb_comp_19_monthly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_20",
        target_table: "tb_comp_20_monthly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_21",
        target_table: "tb_comp_21_monthly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_24",
        target_table: "tb_comp_24_monthly",
        value_divisor: 1000
    }
]);

function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Identifier tidak valid: ${identifier}`);
    }

    return `\`${identifier}\``;
}

function normalizePanel(panel) {
    return String(panel ?? "").trim();
}

function parseWhAsBigInt(value, fieldName) {
    const normalized = String(value ?? "").trim();

    if (!/^-?\d+$/.test(normalized)) {
        throw new Error(`${fieldName} bukan bilangan bulat valid: ${value}`);
    }

    return BigInt(normalized);
}

/**
 * Membagi BIGINT secara aman tanpa mengubahnya menjadi Number agar presisi
 * meter tidak hilang. Hasil berupa string DECIMAL tiga angka di belakang koma.
 */
function divideBigIntToFixed(value, divisor, decimalPlaces = 3) {
    const divisorBigInt = BigInt(divisor);

    if (divisorBigInt <= 0n) {
        throw new Error(`value_divisor harus lebih besar dari 0: ${divisor}`);
    }

    const scale = 10n ** BigInt(decimalPlaces);
    const isNegative = value < 0n;
    const absoluteValue = isNegative ? -value : value;
    const scaledValue =
        (absoluteValue * scale + divisorBigInt / 2n) / divisorBigInt;
    const wholePart = scaledValue / scale;
    const fractionPart = String(scaledValue % scale).padStart(
        decimalPlaces,
        "0"
    );

    return `${isNegative ? "-" : ""}${wholePart}.${fractionPart}`;
}

async function acquireProgramLock(connection) {
    const [rows] = await connection.query(
        "SELECT GET_LOCK(?, ?) AS acquired",
        [LOCK_NAME, SETTINGS.lockWaitSeconds]
    );

    return Number(rows[0]?.acquired) === 1;
}

async function releaseProgramLock(connection) {
    try {
        await connection.query("SELECT RELEASE_LOCK(?)", [LOCK_NAME]);
    } catch (error) {
        console.error(`⚠️ Gagal melepas database lock: ${error.message}`);
    }
}

async function getTableColumns(connection, tableName) {
    const [rows] = await connection.query(
        `
            SELECT COLUMN_NAME
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
        `,
        [tableName]
    );

    return new Set(rows.map((row) => row.COLUMN_NAME));
}

async function assertRequiredColumns(
    connection,
    tableName,
    requiredColumns,
    tableRole
) {
    const columns = await getTableColumns(connection, tableName);

    if (!columns.size) {
        throw new Error(`${tableRole} tidak ditemukan: ${tableName}`);
    }

    const missingColumns = requiredColumns.filter(
        (columnName) => !columns.has(columnName)
    );

    if (missingColumns.length) {
        throw new Error(
            `${tableRole} ${tableName} tidak memiliki kolom: ` +
                missingColumns.join(", ")
        );
    }
}

async function assertUniqueKey(connection, targetTable) {
    const [rows] = await connection.query(
        `
            SELECT
                INDEX_NAME,
                GROUP_CONCAT(
                    COLUMN_NAME
                    ORDER BY SEQ_IN_INDEX
                    SEPARATOR ','
                ) AS index_columns
            FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
              AND NON_UNIQUE = 0
            GROUP BY INDEX_NAME
        `,
        [targetTable]
    );

    const requiredSignature = REQUIRED_UNIQUE_COLUMNS.join(",");
    const uniqueKeyExists = rows.some(
        (row) => String(row.index_columns).toLowerCase() === requiredSignature
    );

    if (!uniqueKeyExists) {
        throw new Error(
            `UNIQUE KEY (${requiredSignature}) belum tersedia pada ` +
                `${targetTable}. Jalankan setup_comp_monthly_safe.sql.`
        );
    }
}

async function validateLineConfiguration(connection, line) {
    await assertRequiredColumns(
        connection,
        line.source_table,
        ["idPrimary", "panel", "wh", "date_time"],
        "Tabel sumber"
    );

    await assertRequiredColumns(
        connection,
        line.target_table,
        [
            "idPrimary",
            "pm_type",
            "line_table",
            "line_name",
            "year",
            "month",
            "month_name",
            "month_start_date",
            "month_end_date",
            "month_start_datetime",
            "month_end_datetime",
            "start_kwh",
            "end_kwh",
            "total_kwh",
            "created_at",
            "updated_at"
        ],
        "Tabel tujuan"
    );

    await assertUniqueKey(connection, line.target_table);
}

/**
 * Mengambil nilai panel mentah untuk filter sumber dan nama panel yang sudah
 * dirapikan untuk line_name. Panel yang hanya berbeda spasi ditolak agar tidak
 * bertabrakan pada UNIQUE KEY.
 */
async function getAvailablePanels(connection, sourceTable) {
    const safeSourceTable = escapeIdentifier(sourceTable);

    const [rows] = await connection.query(`
        SELECT DISTINCT panel
        FROM ${safeSourceTable}
        WHERE panel IS NOT NULL
          AND TRIM(panel) <> ''
        ORDER BY panel ASC
    `);

    const normalizedPanelMap = new Map();

    for (const row of rows) {
        const sourcePanel = String(row.panel);
        const lineName = normalizePanel(sourcePanel);

        if (normalizedPanelMap.has(lineName)) {
            const previousPanel = normalizedPanelMap.get(lineName).sourcePanel;

            throw new Error(
                `Panel tidak konsisten pada ${sourceTable}: ` +
                    `"${previousPanel}" dan "${sourcePanel}" menjadi ` +
                    `line_name yang sama setelah TRIM: "${lineName}".`
            );
        }

        normalizedPanelMap.set(lineName, { sourcePanel, lineName });
    }

    return Array.from(normalizedPanelMap.values());
}

async function targetHasPanelData(connection, line, lineName) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [rows] = await connection.query(
        `
            SELECT idPrimary
            FROM ${safeTargetTable}
            WHERE line_table = ?
              AND line_name = ?
            LIMIT 1
        `,
        [line.source_table, lineName]
    );

    return rows.length > 0;
}

async function getAvailableMonths(
    connection,
    sourceTable,
    sourcePanel,
    processAllMonths
) {
    const safeSourceTable = escapeIdentifier(sourceTable);
    const parameters = [sourcePanel];
    let dateFilter = "";

    if (!processAllMonths) {
        const minimumDate = moment
            .tz(TIMEZONE)
            .startOf("month")
            .subtract(SETTINGS.lookbackMonths - 1, "months")
            .format("YYYY-MM-DD HH:mm:ss");

        dateFilter = "AND date_time >= ?";
        parameters.push(minimumDate);
    }

    const [rows] = await connection.query(
        `
            SELECT DISTINCT
                DATE_FORMAT(date_time, '%Y-%m-01') AS month_start_date
            FROM ${safeSourceTable}
            WHERE date_time IS NOT NULL
              AND panel = ?
              ${dateFilter}
            ORDER BY month_start_date ASC
        `,
        parameters
    );

    return rows.map((row) => row.month_start_date);
}

function buildMonthWindow(monthStartDate) {
    const start = moment.tz(monthStartDate, "YYYY-MM-DD", TIMEZONE).startOf(
        "month"
    );
    const endExclusive = start.clone().add(1, "month");

    return {
        start,
        endExclusive,
        monthStartDate: start.format("YYYY-MM-DD"),
        monthEndDate: endExclusive.clone().subtract(1, "day").format("YYYY-MM-DD"),
        year: Number(start.format("YYYY")),
        month: Number(start.format("M")),
        monthName: start.format("MMMM")
    };
}

function isMonthReady(monthEndExclusive, currentTime) {
    const readyAt = monthEndExclusive
        .clone()
        .add(SETTINGS.monthGraceMinutes, "minutes");

    return !currentTime.isBefore(readyAt);
}

/**
 * Mengambil seluruh pembacaan satu bulan untuk:
 * - menentukan pembacaan awal dan akhir,
 * - memastikan jumlah sampel cukup,
 * - mendeteksi nilai meter negatif,
 * - mendeteksi meter turun/reset di tengah bulan.
 *
 * Batas akhir dibuat inklusif agar pembacaan tepat pukul 00:00 pada awal
 * bulan berikutnya dapat menjadi nilai akhir bulan sebelumnya.
 */
async function getMonthlyData(
    connection,
    line,
    sourcePanel,
    monthStart,
    monthEndExclusive
) {
    const safeSourceTable = escapeIdentifier(line.source_table);
    const startTime = monthStart.format("YYYY-MM-DD HH:mm:ss");
    const endTime = monthEndExclusive.format("YYYY-MM-DD HH:mm:ss");

    const [rows] = await connection.query(
        `
            SELECT
                idPrimary,
                wh,
                DATE_FORMAT(date_time, '%Y-%m-%d %H:%i:%s') AS reading_time
            FROM ${safeSourceTable}
            WHERE panel = ?
              AND date_time >= ?
              AND date_time <= ?
              AND wh IS NOT NULL
            ORDER BY date_time ASC, idPrimary ASC
        `,
        [sourcePanel, startTime, endTime]
    );

    if (rows.length < SETTINGS.minimumSamples) {
        return {
            valid: false,
            reason:
                `jumlah sampel ${rows.length}, minimal ` +
                `${SETTINGS.minimumSamples}`
        };
    }

    let firstWh = null;
    let lastWh = null;
    let previousWh = null;
    let firstReadingTime = null;
    let lastReadingTime = null;

    for (const row of rows) {
        let currentWh;

        try {
            currentWh = parseWhAsBigInt(row.wh, `wh idPrimary=${row.idPrimary}`);
        } catch (error) {
            return { valid: false, reason: error.message };
        }

        if (currentWh < 0n) {
            return {
                valid: false,
                reason: `nilai wh negatif pada idPrimary=${row.idPrimary}`
            };
        }

        if (previousWh !== null && currentWh < previousWh) {
            return {
                valid: false,
                reason:
                    `meter turun/reset di tengah bulan pada ` +
                    `idPrimary=${row.idPrimary}`
            };
        }

        if (firstWh === null) {
            firstWh = currentWh;
            firstReadingTime = row.reading_time;
        }

        lastWh = currentWh;
        lastReadingTime = row.reading_time;
        previousWh = currentWh;
    }

    const firstMoment = moment.tz(
        firstReadingTime,
        "YYYY-MM-DD HH:mm:ss",
        TIMEZONE
    );
    const lastMoment = moment.tz(
        lastReadingTime,
        "YYYY-MM-DD HH:mm:ss",
        TIMEZONE
    );

    if (!firstMoment.isValid() || !lastMoment.isValid()) {
        return { valid: false, reason: "format waktu pembacaan tidak valid" };
    }

    if (!lastMoment.isAfter(firstMoment)) {
        return {
            valid: false,
            reason: "waktu pembacaan akhir tidak lebih besar dari awal"
        };
    }

    const startGapHours = firstMoment.diff(monthStart, "hours", true);
    const endGapHours = monthEndExclusive.diff(lastMoment, "hours", true);

    if (
        startGapHours < 0 ||
        startGapHours > SETTINGS.boundaryToleranceHours
    ) {
        return {
            valid: false,
            reason:
                `pembacaan awal berjarak ${startGapHours.toFixed(2)} jam ` +
                `dari awal bulan; toleransi maksimal ` +
                `${SETTINGS.boundaryToleranceHours} jam`
        };
    }

    if (endGapHours < 0 || endGapHours > SETTINGS.boundaryToleranceHours) {
        return {
            valid: false,
            reason:
                `pembacaan akhir berjarak ${endGapHours.toFixed(2)} jam ` +
                `dari akhir bulan; toleransi maksimal ` +
                `${SETTINGS.boundaryToleranceHours} jam`
        };
    }

    const totalWh = lastWh - firstWh;

    if (totalWh < 0n) {
        return {
            valid: false,
            reason: "nilai akhir lebih kecil dari nilai awal"
        };
    }

    if (totalWh === 0n && !SETTINGS.allowZeroTotal) {
        return {
            valid: false,
            reason: "total pemakaian 0 dan ALLOW_ZERO_TOTAL=false"
        };
    }

    return {
        valid: true,
        sampleCount: rows.length,
        startDatetime: firstReadingTime,
        endDatetime: lastReadingTime,
        startKwh: divideBigIntToFixed(firstWh, line.value_divisor, 3),
        endKwh: divideBigIntToFixed(lastWh, line.value_divisor, 3),
        totalKwh: divideBigIntToFixed(totalWh, line.value_divisor, 3)
    };
}

/**
 * UPSERT atomic:
 * UNIQUE KEY mencegah data bulanan ganda. Jika hasil sama persis, updated_at
 * tidak berubah. Jika data sumber terlambat masuk dan hasil berubah, baris lama
 * diperbarui tanpa membuat baris baru.
 */
async function upsertMonthlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(
        `
            INSERT INTO ${safeTargetTable} (
                pm_type,
                line_table,
                line_name,
                year,
                month,
                month_name,
                month_start_date,
                month_end_date,
                month_start_datetime,
                month_end_datetime,
                start_kwh,
                end_kwh,
                total_kwh,
                created_at,
                updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ON DUPLICATE KEY UPDATE
                updated_at = IF(
                    NOT (pm_type <=> VALUES(pm_type))
                    OR NOT (month_name <=> VALUES(month_name))
                    OR NOT (month_start_date <=> VALUES(month_start_date))
                    OR NOT (month_end_date <=> VALUES(month_end_date))
                    OR NOT (
                        month_start_datetime <=> VALUES(month_start_datetime)
                    )
                    OR NOT (
                        month_end_datetime <=> VALUES(month_end_datetime)
                    )
                    OR NOT (start_kwh <=> VALUES(start_kwh))
                    OR NOT (end_kwh <=> VALUES(end_kwh))
                    OR NOT (total_kwh <=> VALUES(total_kwh)),
                    NOW(),
                    updated_at
                ),
                pm_type = VALUES(pm_type),
                month_name = VALUES(month_name),
                month_start_date = VALUES(month_start_date),
                month_end_date = VALUES(month_end_date),
                month_start_datetime = VALUES(month_start_datetime),
                month_end_datetime = VALUES(month_end_datetime),
                start_kwh = VALUES(start_kwh),
                end_kwh = VALUES(end_kwh),
                total_kwh = VALUES(total_kwh)
        `,
        [
            line.pm_type,
            line.source_table,
            data.line_name,
            data.year,
            data.month,
            data.month_name,
            data.month_start_date,
            data.month_end_date,
            data.month_start_datetime,
            data.month_end_datetime,
            data.start_kwh,
            data.end_kwh,
            data.total_kwh
        ]
    );

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | panel=${data.line_name} | ` +
            `${data.year}-${String(data.month).padStart(2, "0")} | ` +
            `${data.total_kwh} kWh | ${data.sample_count} sampel`
    );
}

async function processMonth(
    connection,
    line,
    panel,
    monthStartDate,
    currentTime
) {
    const monthWindow = buildMonthWindow(monthStartDate);

    if (!isMonthReady(monthWindow.endExclusive, currentTime)) {
        const readyAt = monthWindow.endExclusive
            .clone()
            .add(SETTINGS.monthGraceMinutes, "minutes")
            .format("YYYY-MM-DD HH:mm:ss");

        console.log(
            `⏳ Belum diproses: ${line.target_table} | ` +
                `panel=${panel.lineName} | ${monthWindow.year}-` +
                `${String(monthWindow.month).padStart(2, "0")} | ` +
                `bulan belum selesai, siap setelah ${readyAt}`
        );
        return;
    }

    const monthlyData = await getMonthlyData(
        connection,
        line,
        panel.sourcePanel,
        monthWindow.start,
        monthWindow.endExclusive
    );

    if (!monthlyData.valid) {
        console.log(
            `⚠️ Skip: ${line.target_table} | panel=${panel.lineName} | ` +
                `${monthWindow.year}-` +
                `${String(monthWindow.month).padStart(2, "0")} | ` +
                monthlyData.reason
        );
        return;
    }

    await upsertMonthlyToTable(connection, line, {
        line_name: panel.lineName,
        year: monthWindow.year,
        month: monthWindow.month,
        month_name: monthWindow.monthName,
        month_start_date: monthWindow.monthStartDate,
        month_end_date: monthWindow.monthEndDate,
        month_start_datetime: monthlyData.startDatetime,
        month_end_datetime: monthlyData.endDatetime,
        start_kwh: monthlyData.startKwh,
        end_kwh: monthlyData.endKwh,
        total_kwh: monthlyData.totalKwh,
        sample_count: monthlyData.sampleCount
    });
}

async function processLine(connection, line, currentTime) {
    console.log(`\n🔍 Validasi: ${line.source_table} -> ${line.target_table}`);
    await validateLineConfiguration(connection, line);

    const panels = await getAvailablePanels(connection, line.source_table);

    if (!panels.length) {
        console.log(`⚠️ Tidak ada panel pada tabel sumber: ${line.source_table}`);
        return;
    }

    for (const panel of panels) {
        const panelAlreadyHasTargetData = await targetHasPanelData(
            connection,
            line,
            panel.lineName
        );

        const processAllMonths =
            SETTINGS.forceBackfillAll ||
            (SETTINGS.autoBackfillEmptyPanel && !panelAlreadyHasTargetData);

        console.log(
            `\n📌 Panel: ${panel.lineName} | mode=` +
                `${
                    processAllMonths
                        ? "BACKFILL"
                        : `LOOKBACK ${SETTINGS.lookbackMonths} bulan`
                }`
        );

        const availableMonths = await getAvailableMonths(
            connection,
            line.source_table,
            panel.sourcePanel,
            processAllMonths
        );

        if (!availableMonths.length) {
            console.log(
                `⚠️ Tidak ada bulan yang perlu diproses untuk panel ` +
                    `${panel.lineName} pada ${line.source_table}`
            );
            continue;
        }

        for (const monthStartDate of availableMonths) {
            await processMonth(
                connection,
                line,
                panel,
                monthStartDate,
                currentTime
            );
        }
    }
}

async function rekapMonthly() {
    const connection = await pool.getConnection();
    let lockAcquired = false;
    let failedLineCount = 0;

    try {
        lockAcquired = await acquireProgramLock(connection);

        if (!lockAcquired) {
            console.log(
                "⏭️ Program monthly tidak dijalankan karena proses sebelumnya " +
                    "masih aktif. Ini mencegah dua proses berjalan bersamaan."
            );
            return;
        }

        const currentTime = moment.tz(TIMEZONE);

        console.log("🚀 Mulai rekap monthly compressor...");
        console.log(
            `🕒 Waktu aplikasi: ${currentTime.format(
                "YYYY-MM-DD HH:mm:ss Z"
            )}`
        );
        console.log("🔐 Database advisory lock aktif.");
        console.log("🔐 UPSERT + pemeriksaan UNIQUE KEY aktif.");
        console.log("🛡️ Bulan berjalan tidak disimpan sebagai data parsial.");
        console.log(
            `🛡️ Grace=${SETTINGS.monthGraceMinutes} menit, ` +
                `boundary tolerance=${SETTINGS.boundaryToleranceHours} jam, ` +
                `lookback=${SETTINGS.lookbackMonths} bulan.`
        );

        for (const line of lineTables) {
            try {
                await processLine(connection, line, currentTime);
            } catch (lineError) {
                failedLineCount += 1;
                console.error(
                    `❌ Error pada ${line.source_table} -> ` +
                        `${line.target_table}:`,
                    lineError.message
                );
            }
        }

        if (failedLineCount > 0) {
            throw new Error(
                `${failedLineCount} tabel gagal diproses. ` +
                    "Periksa log error di atas."
            );
        }

        console.log("\n🎉 Rekap monthly compressor selesai tanpa error.");
    } finally {
        if (lockAcquired) {
            await releaseProgramLock(connection);
        }

        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

rekapMonthly()
    .then(() => {
        console.log("✅ Program selesai.");
        process.exit(0);
    })
    .catch((error) => {
        console.error("❌ Program gagal:", error.message);
        process.exit(1);
    });
