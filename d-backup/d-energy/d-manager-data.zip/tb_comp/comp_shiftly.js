// TRUNCATE TABLE tb_comp_19_shiftly;
// TRUNCATE TABLE tb_comp_20_shiftly;
// TRUNCATE TABLE tb_comp_21_shiftly;
// TRUNCATE TABLE tb_comp_24_shiftly;


// TRUNCATE TABLE tb_comp_19_monthly;
// TRUNCATE TABLE tb_comp_20_monthly;
// TRUNCATE TABLE tb_comp_21_monthly;
// TRUNCATE TABLE tb_comp_24_monthly;




const pool = require("../database");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

const panelTablesShiftly = [
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_19",
    target_table: "tb_comp_19_shiftly",
    line_name: "PANEL 19",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_20",
    target_table: "tb_comp_20_shiftly",
    line_name: "PANEL 20",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_21",
    target_table: "tb_comp_21_shiftly",
    line_name: "PANEL 21",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_24",
    target_table: "tb_comp_24_shiftly",
    line_name: "PANEL 24",
  },
];

// Fungsi untuk mengkonversi string ke number
function toNumber(value) {
  if (value === null || value === undefined) return NaN;
  return parseFloat(String(value).replace(/,/g, "").trim());
}

// Fungsi untuk mendapatkan tanggal-tanggal unik
async function getDistinctDates(connection, tableName) {
  const [rows] = await connection.query(`
    SELECT DISTINCT DATE(date_time) AS period_date
    FROM ${tableName}
    WHERE date_time IS NOT NULL
    ORDER BY period_date ASC
  `);

  return rows.map((row) => moment(row.period_date).format("YYYY-MM-DD"));
}

// Fungsi untuk mengambil data range dalam periode tertentu
async function getRangeData(connection, tableName, startTime, endTime) {
  const [startRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time ASC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  const [endRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time DESC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  if (!startRow.length || !endRow.length) {
    return null;
  }

  const startValue = toNumber(startRow[0].wh_value);
  const endValue = toNumber(endRow[0].wh_value);

  if (Number.isNaN(startValue) || Number.isNaN(endValue)) {
    return null;
  }

  const totalValue = endValue - startValue;

  // Abaikan jika totalValue <= 0
  if (totalValue <= 0) {
    return null;
  }

  return {
    startDatetime: moment(startRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    endDatetime: moment(endRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    startValue,
    endValue,
    totalValue,
  };
}

// Fungsi untuk menyimpan data shiftly ke dalam tabel
async function upsertShiftlyToTable(connection, line, data) {
  await connection.query(
    `
    INSERT INTO ${line.target_table} (
      pm_type,
      line_table,
      line_name,
      shift,
      shift_date,
      shift_start_datetime,
      shift_end_datetime,
      start_kwh,
      end_kwh,
      total_kwh,
      year,
      month,
      month_name,
      day,
      day_name,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      line_name = VALUES(line_name),
      shift_start_datetime = VALUES(shift_start_datetime),
      shift_end_datetime = VALUES(shift_end_datetime),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      year = VALUES(year),
      month = VALUES(month),
      month_name = VALUES(month_name),
      day = VALUES(day),
      day_name = VALUES(day_name),
      updated_at = NOW()
    `,
    [
      line.pm_type,
      line.source_table,
      line.line_name,
      data.shift,
      data.shift_date,
      data.shift_start_datetime,
      data.shift_end_datetime,
      data.start_kwh,
      data.end_kwh,
      data.total_kwh,
      data.year,
      data.month,
      data.month_name,
      data.day,
      data.day_name,
    ]
  );

  console.log(
    `✅ Upsert: ${line.target_table} | ${data.shift} | ${data.shift_date} | ${data.total_kwh.toFixed(3)} kWh`
  );
}

// Fungsi utama untuk menjalankan proses rekap shiftly
async function rekapShiftly() {
  const connection = await pool.getConnection();

  try {
    for (const line of panelTablesShiftly) {
      console.log(`\n🔍 Proses Shiftly: ${line.source_table} -> ${line.target_table}`);

      const dates = await getDistinctDates(connection, line.source_table);

      // Proses Shiftly untuk setiap tanggal
      for (const dateStr of dates) {
        const dateObj = moment(dateStr);
        const dayName = dateObj.format("dddd");
        const monthName = dateObj.format("MMMM");

        // Shift 1
        const shift1Start = dateObj.clone().set({ hour: 7, minute: 0, second: 0 });
        const shift1End = dateObj.clone().set({ hour: 19, minute: 0, second: 0 });

        const shift1Data = await getRangeData(connection, line.source_table, shift1Start, shift1End);
        if (shift1Data) {
          await upsertShiftlyToTable(connection, line, {
            shift: "shift_1",
            shift_date: dateStr,
            shift_start_datetime: shift1Data.startDatetime,
            shift_end_datetime: shift1Data.endDatetime,
            start_kwh: shift1Data.startValue,
            end_kwh: shift1Data.endValue,
            total_kwh: shift1Data.totalValue,
            year: dateObj.year(),
            month: dateObj.month() + 1,
            month_name: monthName,
            day: dateObj.date(),
            day_name: dayName,
          });
        } else {
          console.log(`⚠️ Skip shift_1: ${line.target_table} | ${dateStr} | invalid / 0 / negatif`);
        }

        // Shift 2
        const shift2Start = dateObj.clone().set({ hour: 19, minute: 0, second: 0 });
        const shift2End = dateObj.clone().add(1, "day").set({ hour: 7, minute: 0, second: 0 });

        const shift2Data = await getRangeData(connection, line.source_table, shift2Start, shift2End);
        if (shift2Data) {
          await upsertShiftlyToTable(connection, line, {
            shift: "shift_2",
            shift_date: dateStr,
            shift_start_datetime: shift2Data.startDatetime,
            shift_end_datetime: shift2Data.endDatetime,
            start_kwh: shift2Data.startValue,
            end_kwh: shift2Data.endValue,
            total_kwh: shift2Data.totalValue,
            year: dateObj.year(),
            month: dateObj.month() + 1,
            month_name: monthName,
            day: dateObj.date(),
            day_name: dayName,
          });
        } else {
          console.log(`⚠️ Skip shift_2: ${line.target_table} | ${dateStr} | invalid / 0 / negatif`);
        }
      }
    }

    console.log("\n🎉 Rekap shiftly selesai.");
  } catch (err) {
    console.error("❌ Error rekap shiftly:", err);
  } finally {
    connection.release();
  }
}

// Menjalankan fungsi rekap shiftly
rekapShiftly();