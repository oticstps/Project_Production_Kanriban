REKAP MONTHLY COMPRESSOR
========================

Tabel sumber:
- tb_comp_19
- tb_comp_20
- tb_comp_21
- tb_comp_24

Tabel tujuan:
- tb_comp_19_monthly
- tb_comp_20_monthly
- tb_comp_21_monthly
- tb_comp_24_monthly

CARA HITUNG
-----------
Program membaca meter kumulatif pada kolom wh untuk setiap panel:

    total_kwh = (wh_akhir_bulan - wh_awal_bulan) / 1000

Pembacaan awal adalah data pertama di dekat awal bulan. Pembacaan akhir adalah
pembacaan terakhir di dekat akhir bulan atau tepat pukul 00:00 bulan berikutnya.

KEAMANAN DATA
-------------
1. Bulan berjalan tidak dimasukkan. Bulan diproses setelah berakhir + grace.
2. UNIQUE KEY mencegah data ganda:
   (line_table, line_name, year, month)
3. ON DUPLICATE KEY UPDATE memperbarui baris lama tanpa insert ganda.
4. Database GET_LOCK mencegah dua proses monthly berjalan bersamaan.
5. Meter negatif atau turun/reset di tengah bulan akan dilewati.
6. Pembacaan yang terlalu jauh dari batas awal/akhir bulan akan dilewati.
7. Jika hasil tidak berubah, updated_at tidak diubah.
8. Data terlambat dapat memperbarui hasil karena beberapa bulan terakhir dicek ulang.

PERSIAPAN
---------
1. Letakkan rekap_comp_monthly.js satu folder dengan database.js.
2. Pastikan package tersedia:

   npm install mysql2 moment-timezone moment

3. Backup database.
4. Jalankan setup_comp_monthly_safe.sql satu kali.
5. Jalankan program:

   node rekap_comp_monthly.js

MENJALANKAN SETIAP 4 JAM
------------------------
Program aman dipanggil oleh Task Scheduler, cron, atau PM2 setiap 4 jam.
Tidak perlu menambahkan setInterval ke dalam file JavaScript.

Contoh cron:

   0 */4 * * * cd /lokasi/program && /usr/bin/node rekap_comp_monthly.js >> monthly.log 2>&1

PENGATURAN ENV OPSIONAL
-----------------------
LOOKBACK_MONTHS=3
- Jumlah bulan terakhir yang dicek ulang setelah backfill awal.

MONTH_GRACE_MINUTES=60
- Masa tunggu setelah pukul 00:00 pada awal bulan berikutnya.

BOUNDARY_TOLERANCE_HOURS=6
- Maksimal jarak pembacaan awal/akhir terhadap batas bulan.

MINIMUM_SAMPLES=2
- Minimal jumlah pembacaan dalam satu bulan.

AUTO_BACKFILL_EMPTY_PANEL=true
- Panel yang tabel tujuannya masih kosong diproses dari riwayat awal.

BACKFILL_ALL=false
- Ubah menjadi true untuk memeriksa ulang semua bulan historis satu kali.

ALLOW_ZERO_TOTAL=false
- Ubah menjadi true bila pemakaian 0 dianggap data yang valid.

LOCK_WAIT_SECONDS=0
- Waktu tunggu database lock. Nilai 0 berarti langsung skip bila proses lain aktif.

CONTOH BACKFILL SELURUH DATA
----------------------------
Windows CMD:

   set BACKFILL_ALL=true && node rekap_comp_monthly.js

Linux:

   BACKFILL_ALL=true node rekap_comp_monthly.js

CATATAN SATUAN
--------------
Konfigurasi default value_divisor adalah 1000 karena kolom sumber bernama wh.
Jika nilai pada kolom wh sebenarnya sudah kWh, ubah value_divisor pada empat
konfigurasi tabel di rekap_comp_monthly.js dari 1000 menjadi 1.
