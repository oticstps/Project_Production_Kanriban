const pool = require("../database");
const moment = require("moment-timezone");
require("moment/locale/id");

moment.tz.setDefault("Asia/Jakarta");
moment.locale("id");

/**
 * Daftar tabel compressor yang akan direkap per shift.
 *
 * value_divisor:
 * - 1000 = sumber `wh` benar-benar dalam satuan Wh, lalu dikonversi ke kWh.
 * - 1    = nilai pada kolom `wh` sebenarnya sudah berupa kWh.
 */
const lineTables = [
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_19",
        target_table: "tb_comp_19_shiftly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_20",
        target_table: "tb_comp_20_shiftly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_21",
        target_table: "tb_comp_21_shiftly",
        value_divisor: 1000
    },
    {
        pm_type: "COMPRESSOR",
        source_table: "tb_comp_24",
        target_table: "tb_comp_24_shiftly",
        value_divisor: 1000
    }
];

/**
 * Pengaman identifier untuk query tabel dinamis.
 */
function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Invalid identifier: ${identifier}`);
    }

    return `\`${identifier}\``;
}

function formatDateTime(value) {
    return moment(value).format("YYYY-MM-DD HH:mm:ss");
}

function normalizePanel(panel) {
    return String(panel ?? "").trim();
}

/**
 * Mengambil seluruh panel yang tersedia pada tabel sumber.
 */
async function getAvailablePanels(connection, sourceTable) {
    const safeSourceTable = escapeIdentifier(sourceTable);

    const [rows] = await connection.query(`
        SELECT DISTINCT TRIM(panel) AS panel
        FROM ${safeSourceTable}
        WHERE panel IS NOT NULL
          AND TRIM(panel) <> ''
        ORDER BY panel ASC
    `);

    return rows
        .map((row) => normalizePanel(row.panel))
        .filter(Boolean);
}

/**
 * Mengambil seluruh tanggal yang tersedia untuk satu panel.
 */
async function getAvailableDates(connection, sourceTable, panel) {
    const safeSourceTable = escapeIdentifier(sourceTable);

    const [rows] = await connection.query(`
        SELECT DISTINCT DATE_FORMAT(date_time, '%Y-%m-%d') AS shift_date
        FROM ${safeSourceTable}
        WHERE date_time IS NOT NULL
          AND panel = ?
        ORDER BY shift_date ASC
    `, [panel]);

    return rows.map((row) => row.shift_date);
}

/**
 * Mengambil nilai awal dan akhir meter dalam satu rentang shift
 * untuk satu panel tertentu.
 */
async function getShiftData(
    connection,
    tableName,
    panel,
    startTime,
    endTime,
    valueDivisor
) {
    const safeTable = escapeIdentifier(tableName);

    const startTimeString = startTime.format("YYYY-MM-DD HH:mm:ss");
    const endTimeString = endTime.format("YYYY-MM-DD HH:mm:ss");

    const [startRows] = await connection.query(`
        SELECT idPrimary, panel, wh, date_time
        FROM ${safeTable}
        WHERE panel = ?
          AND date_time >= ?
          AND date_time < ?
          AND wh IS NOT NULL
        ORDER BY date_time ASC, idPrimary ASC
        LIMIT 1
    `, [panel, startTimeString, endTimeString]);

    const [endRows] = await connection.query(`
        SELECT idPrimary, panel, wh, date_time
        FROM ${safeTable}
        WHERE panel = ?
          AND date_time >= ?
          AND date_time < ?
          AND wh IS NOT NULL
        ORDER BY date_time DESC, idPrimary DESC
        LIMIT 1
    `, [panel, startTimeString, endTimeString]);

    if (!startRows.length || !endRows.length) {
        return null;
    }

    const rawStartWh = Number(startRows[0].wh);
    const rawEndWh = Number(endRows[0].wh);
    const divisor = Number(valueDivisor) || 1;

    if (!Number.isFinite(rawStartWh) || !Number.isFinite(rawEndWh)) {
        return null;
    }

    const startKwh = Number((rawStartWh / divisor).toFixed(3));
    const endKwh = Number((rawEndWh / divisor).toFixed(3));
    const totalKwh = Number(((rawEndWh - rawStartWh) / divisor).toFixed(3));

    // Abaikan meter turun/reset, total negatif, atau tidak ada pemakaian.
    if (totalKwh <= 0) {
        return null;
    }

    return {
        startDatetime: formatDateTime(startRows[0].date_time),
        endDatetime: formatDateTime(endRows[0].date_time),
        startKwh,
        endKwh,
        totalKwh
    };
}

/**
 * Insert/update hasil rekap shift.
 *
 * UNIQUE KEY yang disarankan:
 * (line_table, line_name, shift_date, shift)
 */
async function upsertShiftlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(`
        INSERT INTO ${safeTargetTable} (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            shift_start_datetime = VALUES(shift_start_datetime),
            shift_end_datetime = VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        data.line_name,
        data.shift,
        data.shift_date,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name
    ]);

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | panel=${data.line_name} | ` +
        `${data.shift} | ${data.shift_date} | ${data.total_kwh} kWh`
    );
}

async function processShift(
    connection,
    line,
    panel,
    shiftDate,
    shift,
    shiftStart,
    shiftEnd,
    dateMetadata
) {
    const shiftData = await getShiftData(
        connection,
        line.source_table,
        panel,
        shiftStart,
        shiftEnd,
        line.value_divisor
    );

    if (!shiftData) {
        console.log(
            `⚠️ Skip: ${line.target_table} | panel=${panel} | ${shift} | ` +
            `${shiftDate} | data kosong / total 0 / negatif / meter reset`
        );
        return;
    }

    await upsertShiftlyToTable(connection, line, {
        line_name: panel,
        shift,
        shift_date: shiftDate,
        shift_start_datetime: shiftData.startDatetime,
        shift_end_datetime: shiftData.endDatetime,
        start_kwh: shiftData.startKwh,
        end_kwh: shiftData.endKwh,
        total_kwh: shiftData.totalKwh,
        ...dateMetadata
    });
}

/**
 * Memproses satu tabel compressor.
 */
async function processLine(connection, line) {
    console.log(`\n🔍 Proses Shiftly: ${line.source_table} -> ${line.target_table}`);

    const panels = await getAvailablePanels(connection, line.source_table);

    if (!panels.length) {
        console.log(`⚠️ Tidak ada panel pada tabel sumber: ${line.source_table}`);
        return;
    }

    for (const panel of panels) {
        console.log(`\n📌 Panel: ${panel}`);

        const availableDates = await getAvailableDates(
            connection,
            line.source_table,
            panel
        );

        if (!availableDates.length) {
            console.log(
                `⚠️ Tidak ada tanggal untuk panel ${panel} pada ${line.source_table}`
            );
            continue;
        }

        for (const shiftDate of availableDates) {
            const dateObj = moment.tz(shiftDate, "YYYY-MM-DD", "Asia/Jakarta");

            const dateMetadata = {
                year: Number(dateObj.format("YYYY")),
                month: Number(dateObj.format("M")),
                month_name: dateObj.format("MMMM"),
                day: Number(dateObj.format("D")),
                day_name: dateObj.format("dddd")
            };

            // Shift 1: 07:10 sampai 19:50 pada tanggal yang sama.
            const shift1Start = dateObj.clone().set({
                hour: 7,
                minute: 10,
                second: 0,
                millisecond: 0
            });

            const shift1End = dateObj.clone().set({
                hour: 19,
                minute: 50,
                second: 0,
                millisecond: 0
            });

            // Shift 2: 19:50 sampai 07:10 hari berikutnya.
            const shift2Start = dateObj.clone().set({
                hour: 19,
                minute: 50,
                second: 0,
                millisecond: 0
            });

            const shift2End = dateObj.clone().add(1, "day").set({
                hour: 7,
                minute: 10,
                second: 0,
                millisecond: 0
            });

            await processShift(
                connection,
                line,
                panel,
                shiftDate,
                "shift_1",
                shift1Start,
                shift1End,
                dateMetadata
            );

            await processShift(
                connection,
                line,
                panel,
                shiftDate,
                "shift_2",
                shift2Start,
                shift2End,
                dateMetadata
            );
        }
    }
}

async function rekapShiftly() {
    const connection = await pool.getConnection();

    try {
        console.log("🚀 Mulai rekap shiftly compressor...");
        console.log("🔐 Mode UPSERT aktif.");

        for (const line of lineTables) {
            try {
                await processLine(connection, line);
            } catch (lineError) {
                console.error(
                    `❌ Error pada ${line.source_table} -> ${line.target_table}:`,
                    lineError.message
                );
            }
        }

        console.log("\n🎉 Rekap shiftly compressor selesai.");
    } catch (error) {
        console.error("❌ Error utama rekap shiftly compressor:", error);
        process.exitCode = 1;
    } finally {
        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

rekapShiftly()
    .then(() => {
        console.log("✅ Program selesai.");
        process.exit(process.exitCode || 0);
    })
    .catch((error) => {
        console.error("❌ Program gagal:", error);
        process.exit(1);
    });
