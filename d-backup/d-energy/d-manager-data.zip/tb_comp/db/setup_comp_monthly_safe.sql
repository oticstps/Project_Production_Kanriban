-- ============================================================
-- SETUP REKAP BULANAN COMPRESSOR
-- Dipakai oleh: rekap_comp_monthly.js
--
-- Perlindungan data ganda:
-- UNIQUE KEY (line_table, line_name, year, month)
-- ============================================================

CREATE TABLE IF NOT EXISTS tb_comp_19_monthly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) NULL,
    line_table VARCHAR(100) NULL,
    line_name VARCHAR(100) NULL,
    year INT(11) NULL,
    month INT(11) NULL,
    month_name VARCHAR(20) NULL,
    month_start_date DATE NULL,
    month_end_date DATE NULL,
    month_start_datetime DATETIME NULL,
    month_end_datetime DATETIME NULL,
    start_kwh DECIMAL(20,3) NULL,
    end_kwh DECIMAL(20,3) NULL,
    total_kwh DECIMAL(20,3) NULL,
    created_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uniq_comp19_monthly_line_panel_year_month
        (line_table, line_name, year, month),
    KEY idx_comp19_monthly_year_month (year, month),
    KEY idx_comp19_monthly_panel (line_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS tb_comp_20_monthly LIKE tb_comp_19_monthly;
CREATE TABLE IF NOT EXISTS tb_comp_21_monthly LIKE tb_comp_19_monthly;
CREATE TABLE IF NOT EXISTS tb_comp_24_monthly LIKE tb_comp_19_monthly;

-- Nama index dari CREATE TABLE ... LIKE akan ikut tersalin. Nama index boleh sama
-- pada tabel yang berbeda. Program memeriksa susunan kolom index, bukan namanya.

-- ============================================================
-- CEK DATA GANDA YANG SUDAH TERLANJUR ADA.
-- Semua SELECT berikut harus menghasilkan 0 baris.
-- ============================================================

SELECT line_table, line_name, year, month, COUNT(*) AS jumlah
FROM tb_comp_19_monthly
GROUP BY line_table, line_name, year, month
HAVING COUNT(*) > 1;

SELECT line_table, line_name, year, month, COUNT(*) AS jumlah
FROM tb_comp_20_monthly
GROUP BY line_table, line_name, year, month
HAVING COUNT(*) > 1;

SELECT line_table, line_name, year, month, COUNT(*) AS jumlah
FROM tb_comp_21_monthly
GROUP BY line_table, line_name, year, month
HAVING COUNT(*) > 1;

SELECT line_table, line_name, year, month, COUNT(*) AS jumlah
FROM tb_comp_24_monthly
GROUP BY line_table, line_name, year, month
HAVING COUNT(*) > 1;

-- ============================================================
-- PROCEDURE SEMENTARA:
-- Menambahkan UNIQUE KEY pada tabel lama apabila belum tersedia.
-- Jika tabel lama masih memiliki data ganda, ALTER akan gagal dengan aman.
-- Tidak ada data yang dihapus otomatis.
-- ============================================================

DROP PROCEDURE IF EXISTS ensure_comp_monthly_unique;

DELIMITER $$

CREATE PROCEDURE ensure_comp_monthly_unique(
    IN p_table_name VARCHAR(64),
    IN p_index_name VARCHAR(64)
)
BEGIN
    DECLARE v_index_exists INT DEFAULT 0;

    SELECT COUNT(*)
    INTO v_index_exists
    FROM (
        SELECT
            INDEX_NAME,
            GROUP_CONCAT(
                COLUMN_NAME
                ORDER BY SEQ_IN_INDEX
                SEPARATOR ','
            ) AS index_columns
        FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table_name
          AND NON_UNIQUE = 0
        GROUP BY INDEX_NAME
    ) AS unique_indexes
    WHERE unique_indexes.index_columns = 'line_table,line_name,year,month';

    IF v_index_exists = 0 THEN
        SET @alter_unique_sql = CONCAT(
            'ALTER TABLE `',
            REPLACE(p_table_name, '`', '``'),
            '` ADD UNIQUE KEY `',
            REPLACE(p_index_name, '`', '``'),
            '` (line_table, line_name, year, month)'
        );

        PREPARE alter_unique_statement FROM @alter_unique_sql;
        EXECUTE alter_unique_statement;
        DEALLOCATE PREPARE alter_unique_statement;
    END IF;
END$$

DELIMITER ;

CALL ensure_comp_monthly_unique(
    'tb_comp_19_monthly',
    'uniq_comp19_monthly_line_panel_year_month'
);
CALL ensure_comp_monthly_unique(
    'tb_comp_20_monthly',
    'uniq_comp20_monthly_line_panel_year_month'
);
CALL ensure_comp_monthly_unique(
    'tb_comp_21_monthly',
    'uniq_comp21_monthly_line_panel_year_month'
);
CALL ensure_comp_monthly_unique(
    'tb_comp_24_monthly',
    'uniq_comp24_monthly_line_panel_year_month'
);

DROP PROCEDURE ensure_comp_monthly_unique;

-- ============================================================
-- INDEX SUMBER
-- Program shiftly aman sebelumnya sudah membuat index ini. Jalankan ALTER
-- berikut hanya apabila index tersebut belum tersedia pada tabel sumber.
-- ============================================================

-- CREATE INDEX idx_comp19_panel_datetime_id
-- ON tb_comp_19 (panel, date_time, idPrimary);
--
-- CREATE INDEX idx_comp20_panel_datetime_id
-- ON tb_comp_20 (panel, date_time, idPrimary);
--
-- CREATE INDEX idx_comp21_panel_datetime_id
-- ON tb_comp_21 (panel, date_time, idPrimary);
--
-- CREATE INDEX idx_comp24_panel_datetime_id
-- ON tb_comp_24 (panel, date_time, idPrimary);
