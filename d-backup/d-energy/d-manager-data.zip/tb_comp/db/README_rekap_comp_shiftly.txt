REKAP COMPRESSOR SHIFTLY - MODE AMAN EKSEKUSI 4 JAM
===================================================

ISI FILE
--------
1. rekap_comp_shiftly.js
2. setup_comp_shiftly_safe.sql

LANGKAH PEMAKAIAN
-----------------
1. Backup database terlebih dahulu.
2. Jalankan bagian pengecekan data double pada setup_comp_shiftly_safe.sql.
3. Pastikan semua query pengecekan menghasilkan 0 baris.
4. Tambahkan UNIQUE KEY dan index sumber dari file SQL tersebut.
5. Letakkan rekap_comp_shiftly.js satu folder dengan database.js.
6. Jalankan:

   node rekap_comp_shiftly.js

PERLINDUNGAN YANG AKTIF
-----------------------
- UNIQUE KEY mencegah satu panel/tanggal/shift tersimpan lebih dari sekali.
- ON DUPLICATE KEY UPDATE memperbarui baris lama, bukan menambah baris baru.
- GET_LOCK mencegah dua instance program berjalan bersamaan.
- Shift aktif tidak diproses.
- Shift baru diproses 20 menit setelah waktu akhir shift.
- Pembacaan awal dan akhir harus maksimal 30 menit dari batas shift.
- Minimal tersedia 2 sampel.
- Meter turun/reset atau total negatif dilewati.
- Total 0 dilewati secara default.
- Setelah backfill awal, hanya 3 hari terakhir yang dicek ulang.
- BIGINT wh dihitung tanpa kehilangan presisi JavaScript Number.

PENGATURAN ENVIRONMENT OPSIONAL
-------------------------------
LOOKBACK_DAYS=3
SHIFT_GRACE_MINUTES=20
BOUNDARY_TOLERANCE_MINUTES=30
MINIMUM_SAMPLES=2
ALLOW_ZERO_TOTAL=false
AUTO_BACKFILL_EMPTY_PANEL=true
BACKFILL_ALL=false
LOCK_WAIT_SECONDS=0

Contoh Windows CMD:

set LOOKBACK_DAYS=3
set SHIFT_GRACE_MINUTES=20
node rekap_comp_shiftly.js

Contoh PowerShell:

$env:LOOKBACK_DAYS="3"
$env:SHIFT_GRACE_MINUTES="20"
node .\rekap_comp_shiftly.js

CATATAN PENTING
---------------
- Jangan memakai setInterval di dalam file jika program sudah dipanggil oleh
  Windows Task Scheduler, cron, PM2, atau scheduler lain setiap 4 jam.
- value_divisor saat ini 1000. Artinya kolom wh dianggap dalam Wh.
  Jika kolom wh sebenarnya sudah kWh, ubah value_divisor menjadi 1.
- BACKFILL_ALL=true hanya digunakan ketika ingin memproses ulang seluruh
  riwayat. Setelah selesai, kembalikan menjadi false.
