const pool = require("../database");
const moment = require("moment-timezone");
require("moment/locale/id");

const TIMEZONE = "Asia/Jakarta";
moment.tz.setDefault(TIMEZONE);

// Mendukung database.js yang mengekspor mysql2 biasa maupun mysql2/promise.
const db = typeof pool.promise === "function" ? pool.promise() : pool;

const lineTables = [
    {
        pm_type: "DA_01",
        source_power_meter: "DA_01",
        source_table: "tb_kub1_total_kwh",
        target_table: "tb_kub1_total_kwh_shiftly",
        line_name: "kubikal_1",
    },
];

/*
 * Pembagian shift:
 * SHIFT 1: 07:10:00 sampai sebelum 19:50:00
 * SHIFT 2: 19:50:00 sampai sebelum 07:10:00 hari berikutnya
 *
 * Untuk SHIFT 2, shift_date mengikuti tanggal saat shift dimulai.
 * Contoh:
 * 4 Agustus 19:50 sampai 5 Agustus 07:10
 * disimpan dengan shift_date = 2026-08-04.
 */

// Jumlah shift terbaru yang diperbarui setiap siklus (default 60).
// Bisa diubah lewat env: LATEST_SHIFTS_LIMIT=60 node file.js
const parsedShiftLimit = Number.parseInt(
    process.env.LATEST_SHIFTS_LIMIT || "60",
    10
);
const LATEST_SHIFTS_LIMIT =
    Number.isFinite(parsedShiftLimit) && parsedShiftLimit > 0
        ? parsedShiftLimit
        : 60;

// Ada 2 shift per hari, ditambah cadangan 2 hari kalau ada hari yang datanya kosong.
const LOOKBACK_DAYS = Math.ceil(LATEST_SHIFTS_LIMIT / 2) + 2;

// Sinkronisasi langsung saat program dimulai, lalu setiap 5 jam.
const SYNC_INTERVAL_HOURS = Math.max(
    1,
    Number.parseInt(process.env.SYNC_INTERVAL_HOURS || "5", 10)
);
const SYNC_INTERVAL_MS = SYNC_INTERVAL_HOURS * 60 * 60 * 1000;

const args = new Set(process.argv.slice(2));
const RUN_ONCE = args.has("--once");
const FORCE_FULL_SYNC = args.has("--full");

let syncIsRunning = false;
let intervalId = null;

function quoteIdentifier(identifier) {
    if (!/^[A-Za-z0-9_]+$/.test(identifier)) {
        throw new Error(`Identifier SQL tidak valid: ${identifier}`);
    }

    return `\`${identifier}\``;
}

function roundTo3(value) {
    return Math.round((value + Number.EPSILON) * 1000) / 1000;
}

function buildSourceConditions(config, alias = "") {
    const prefix = alias ? `${alias}.` : "";

    const conditions = [
        `${prefix}\`date_time\` IS NOT NULL`,
        `${prefix}\`value\` IS NOT NULL`,
        `TRIM(${prefix}\`value\`) REGEXP '^[0-9]+([.][0-9]+)?$'`,
    ];

    const params = [];

    if (config.source_power_meter) {
        conditions.push(`${prefix}\`power_meter\` = ?`);
        params.push(config.source_power_meter);
    }

    return { conditions, params };
}

/*
 * Sinkronisasi penuh hanya dilakukan saat:
 * 1. program dipanggil dengan --full; atau
 * 2. belum ada satu pun data untuk konfigurasi ini di tabel tujuan.
 *
 * Setelah sinkronisasi awal, setiap siklus hanya memperbarui
 * LATEST_SHIFTS_LIMIT shift terbaru.
 */
async function shouldRunFullSync(connection, config) {
    if (FORCE_FULL_SYNC) {
        return true;
    }

    const targetTable = quoteIdentifier(config.target_table);

    const sql = `
        SELECT COUNT(*) AS total
        FROM ${targetTable}
        WHERE \`pm_type\` = ?
          AND \`line_table\` = ?
          AND \`line_name\` = ?
    `;

    const [[row]] = await connection.query(sql, [
        config.pm_type,
        config.source_table,
        config.line_name,
    ]);

    return Number(row.total || 0) === 0;
}

/*
 * Untuk mode incremental, cari waktu data valid paling baru.
 * Query rekap kemudian dibatasi beberapa hari ke belakang agar tetap ringan.
 */
async function getLatestSourceDatetime(connection, config) {
    const sourceTable = quoteIdentifier(config.source_table);
    const { conditions, params } = buildSourceConditions(config);

    const sql = `
        SELECT MAX(\`date_time\`) AS latest_datetime
        FROM ${sourceTable}
        WHERE ${conditions.join("\n          AND ")}
    `;

    const [[row]] = await connection.query(sql, params);
    return row.latest_datetime || null;
}

/*
 * Mengambil nilai Wh pertama dan terakhir untuk setiap shift.
 *
 * Tidak ada konversi menjadi kWh:
 * start_kwh = nilai Wh pertama dalam shift
 * end_kwh   = nilai Wh terakhir dalam shift
 * total_kwh = end_wh - start_wh
 *
 * Nama kolom tetap mengikuti struktur tabel tujuan.
 */
async function getShiftSourceData(connection, config, fullSync) {
    const sourceTable = quoteIdentifier(config.source_table);
    const { conditions, params } = buildSourceConditions(config);

    let description = "seluruh shift dari data paling awal";

    if (!fullSync) {
        const latestDatetime = await getLatestSourceDatetime(
            connection,
            config
        );

        if (!latestDatetime) {
            return {
                rows: [],
                description: "tidak ada data sumber yang valid",
            };
        }

        /*
         * Ada 2 shift per hari, jadi rentang hari dihitung dari
         * LATEST_SHIFTS_LIMIT (lihat LOOKBACK_DAYS).
         * LIMIT tetap memastikan hanya shift terbaru sebanyak itu yang diproses.
         */
        const rangeStart = moment(latestDatetime)
            .tz(TIMEZONE)
            .subtract(LOOKBACK_DAYS, "days")
            .startOf("day")
            .format("YYYY-MM-DD HH:mm:ss");

        const rangeEnd = moment(latestDatetime)
            .tz(TIMEZONE)
            .add(1, "day")
            .endOf("day")
            .format("YYYY-MM-DD HH:mm:ss");

        conditions.push("`date_time` >= ?");
        conditions.push("`date_time` <= ?");
        params.push(rangeStart, rangeEnd);

        description = `${LATEST_SHIFTS_LIMIT} shift terbaru`;
    }

    const direction = fullSync ? "ASC" : "DESC";
    const limitClause = fullSync ? "" : `LIMIT ${LATEST_SHIFTS_LIMIT}`;

    /*
     * start_key dan end_key memilih id berdasarkan urutan date_time + id.
     * Cara ini tidak bergantung pada GROUP_CONCAT yang dapat terpotong
     * apabila data per shift sangat banyak.
     */
    const sql = `
        SELECT
            grouped.\`shift\`,
            grouped.\`shift_date\`,
            start_row.\`date_time\` AS actual_start_datetime,
            end_row.\`date_time\` AS actual_end_datetime,
            CAST(TRIM(start_row.\`value\`) AS DECIMAL(20,3)) AS start_wh,
            CAST(TRIM(end_row.\`value\`) AS DECIMAL(20,3)) AS end_wh,
            grouped.reading_count
        FROM (
            SELECT
                mapped.\`shift\`,
                mapped.\`shift_order\`,
                mapped.\`shift_date\`,
                MIN(
                    CONCAT(
                        DATE_FORMAT(
                            mapped.\`date_time\`,
                            '%Y%m%d%H%i%s%f'
                        ),
                        '|',
                        LPAD(mapped.\`idPrimary\`, 12, '0')
                    )
                ) AS start_key,
                MAX(
                    CONCAT(
                        DATE_FORMAT(
                            mapped.\`date_time\`,
                            '%Y%m%d%H%i%s%f'
                        ),
                        '|',
                        LPAD(mapped.\`idPrimary\`, 12, '0')
                    )
                ) AS end_key,
                COUNT(*) AS reading_count
            FROM (
                SELECT
                    \`idPrimary\`,
                    \`date_time\`,
                    CASE
                        WHEN TIME(\`date_time\`) >= '07:10:00'
                         AND TIME(\`date_time\`) < '19:50:00'
                            THEN 'SHIFT 1'
                        ELSE 'SHIFT 2'
                    END AS \`shift\`,
                    CASE
                        WHEN TIME(\`date_time\`) >= '07:10:00'
                         AND TIME(\`date_time\`) < '19:50:00'
                            THEN 1
                        ELSE 2
                    END AS \`shift_order\`,
                    CASE
                        WHEN TIME(\`date_time\`) < '07:10:00'
                            THEN DATE(
                                DATE_SUB(\`date_time\`, INTERVAL 1 DAY)
                            )
                        ELSE DATE(\`date_time\`)
                    END AS \`shift_date\`
                FROM ${sourceTable}
                WHERE ${conditions.join("\n                  AND ")}
            ) AS mapped
            GROUP BY
                mapped.\`shift_date\`,
                mapped.\`shift\`,
                mapped.\`shift_order\`
            ORDER BY
                mapped.\`shift_date\` ${direction},
                mapped.\`shift_order\` ${direction}
            ${limitClause}
        ) AS grouped
        INNER JOIN ${sourceTable} AS start_row
            ON start_row.\`idPrimary\` = CAST(
                SUBSTRING_INDEX(grouped.start_key, '|', -1)
                AS UNSIGNED
            )
        INNER JOIN ${sourceTable} AS end_row
            ON end_row.\`idPrimary\` = CAST(
                SUBSTRING_INDEX(grouped.end_key, '|', -1)
                AS UNSIGNED
            )
        ORDER BY
            grouped.\`shift_date\` ${direction},
            grouped.\`shift_order\` ${direction}
    `;

    const [rows] = await connection.query(sql, params);

    return {
        rows: fullSync ? rows : rows.reverse(),
        description,
    };
}

function getShiftMetadata(shiftDate, shift) {
    const date = moment.tz(shiftDate, "YYYY-MM-DD", TIMEZONE);

    let shiftStart;
    let shiftEnd;

    if (shift === "SHIFT 1") {
        shiftStart = date
            .clone()
            .hour(7)
            .minute(10)
            .second(0)
            .millisecond(0);

        shiftEnd = date
            .clone()
            .hour(19)
            .minute(50)
            .second(0)
            .millisecond(0);
    } else {
        shiftStart = date
            .clone()
            .hour(19)
            .minute(50)
            .second(0)
            .millisecond(0);

        shiftEnd = date
            .clone()
            .add(1, "day")
            .hour(7)
            .minute(10)
            .second(0)
            .millisecond(0);
    }

    return {
        year: date.year(),
        month: date.month() + 1,
        monthName: date.locale("id").format("MMMM"),
        day: date.date(),
        dayName: date.locale("id").format("dddd"),
        shiftStartDatetime: shiftStart.format("YYYY-MM-DD HH:mm:ss"),
        shiftEndDatetime: shiftEnd.format("YYYY-MM-DD HH:mm:ss"),
    };
}

async function replaceShiftRow(connection, config, sourceRow) {
    const targetTable = quoteIdentifier(config.target_table);

    const shiftDate = moment(sourceRow.shift_date)
        .tz(TIMEZONE)
        .format("YYYY-MM-DD");

    const shift = sourceRow.shift;
    const startWh = Number(sourceRow.start_wh);
    const endWh = Number(sourceRow.end_wh);

    if (
        !["SHIFT 1", "SHIFT 2"].includes(shift) ||
        !Number.isFinite(startWh) ||
        !Number.isFinite(endWh)
    ) {
        throw new Error(
            `Data shift tidak valid: ${JSON.stringify(sourceRow)}`
        );
    }

    const startValue = roundTo3(startWh);
    const endValue = roundTo3(endWh);
    const totalValue = roundTo3(endWh - startWh);
    const metadata = getShiftMetadata(shiftDate, shift);

    if (totalValue < 0) {
        console.warn(
            `[PERINGATAN] ${config.line_name} ${shiftDate} ${shift}: ` +
                `total bernilai negatif (${totalValue} Wh). ` +
                "Kemungkinan meter mengalami reset atau nilai menurun."
        );
    }

    if (Number(sourceRow.reading_count) < 2) {
        console.warn(
            `[PERINGATAN] ${config.line_name} ${shiftDate} ${shift}: ` +
                "hanya memiliki satu data pembacaan."
        );
    }

    /*
     * Hapus data shift yang sama sebelum insert agar proses idempotent,
     * meskipun tabel belum mempunyai UNIQUE KEY.
     */
    const deleteSql = `
        DELETE FROM ${targetTable}
        WHERE \`pm_type\` = ?
          AND \`line_table\` = ?
          AND \`line_name\` = ?
          AND \`shift\` = ?
          AND \`shift_date\` = ?
    `;

    await connection.query(deleteSql, [
        config.pm_type,
        config.source_table,
        config.line_name,
        shift,
        shiftDate,
    ]);

    const insertSql = `
        INSERT INTO ${targetTable} (
            \`pm_type\`,
            \`line_table\`,
            \`line_name\`,
            \`shift\`,
            \`shift_date\`,
            \`shift_start_datetime\`,
            \`shift_end_datetime\`,
            \`start_kwh\`,
            \`end_kwh\`,
            \`total_kwh\`,
            \`year\`,
            \`month\`,
            \`month_name\`,
            \`day\`,
            \`day_name\`,
            \`created_at\`,
            \`updated_at\`
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW()
        )
    `;

    await connection.query(insertSql, [
        config.pm_type,
        config.source_table,
        config.line_name,
        shift,
        shiftDate,
        metadata.shiftStartDatetime,
        metadata.shiftEndDatetime,
        startValue,
        endValue,
        totalValue,
        metadata.year,
        metadata.month,
        metadata.monthName,
        metadata.day,
        metadata.dayName,
    ]);

    return {
        shift,
        shiftDate,
        startValue,
        endValue,
        totalValue,
        readingCount: Number(sourceRow.reading_count),
        actualStartDatetime: moment(sourceRow.actual_start_datetime)
            .tz(TIMEZONE)
            .format("YYYY-MM-DD HH:mm:ss"),
        actualEndDatetime: moment(sourceRow.actual_end_datetime)
            .tz(TIMEZONE)
            .format("YYYY-MM-DD HH:mm:ss"),
    };
}

async function deleteConfiguredTargetRows(connection, config) {
    const targetTable = quoteIdentifier(config.target_table);

    await connection.query(
        `
            DELETE FROM ${targetTable}
            WHERE \`pm_type\` = ?
              AND \`line_table\` = ?
              AND \`line_name\` = ?
        `,
        [
            config.pm_type,
            config.source_table,
            config.line_name,
        ]
    );
}

async function syncLineShiftly(config) {
    const connection = await db.getConnection();

    try {
        await connection.query("SET time_zone = '+07:00'");

        const fullSync = await shouldRunFullSync(connection, config);

        console.log(
            fullSync
                ? `[MODE] ${config.line_name}: sinkronisasi seluruh shift dari awal.`
                : `[MODE] ${config.line_name}: memperbarui ${LATEST_SHIFTS_LIMIT} shift terbaru.`
        );

        const { rows, description } = await getShiftSourceData(
            connection,
            config,
            fullSync
        );

        if (rows.length === 0) {
            console.log(
                `[INFO] Tidak ada data valid untuk ${config.source_table} ` +
                    `(${description}).`
            );
            return;
        }

        await connection.beginTransaction();

        /*
         * --full berarti benar-benar membangun ulang data konfigurasi ini.
         * Sinkronisasi awal karena tabel kosong tidak memerlukan penghapusan.
         */
        if (FORCE_FULL_SYNC) {
            await deleteConfiguredTargetRows(connection, config);
        }

        const results = [];

        for (const row of rows) {
            results.push(
                await replaceShiftRow(connection, config, row)
            );
        }

        await connection.commit();

        for (const result of results) {
            console.log(
                `[OK] ${result.shiftDate} ${result.shift} | ` +
                    `awal=${result.startValue.toFixed(3)} Wh | ` +
                    `akhir=${result.endValue.toFixed(3)} Wh | ` +
                    `total=${result.totalValue.toFixed(3)} Wh | ` +
                    `pembacaan=${result.readingCount} | ` +
                    `aktual=${result.actualStartDatetime} s.d. ` +
                    `${result.actualEndDatetime}`
            );
        }

        console.log(
            `[INFO] ${config.line_name}: ${results.length} shift diproses.`
        );
    } catch (error) {
        try {
            await connection.rollback();
        } catch (_) {
            // Abaikan apabila transaksi belum dimulai.
        }

        throw error;
    } finally {
        connection.release();
    }
}

async function runSync() {
    if (syncIsRunning) {
        console.log(
            "[INFO] Proses sebelumnya masih berjalan; siklus ini dilewati."
        );
        return true;
    }

    syncIsRunning = true;

    console.log(
        `\n[START] Sync shift kubikal 1 pada ${moment().format(
            "YYYY-MM-DD HH:mm:ss"
        )}`
    );

    try {
        for (const config of lineTables) {
            await syncLineShiftly(config);
        }

        console.log(
            `[DONE] Sinkronisasi selesai pada ${moment().format(
                "YYYY-MM-DD HH:mm:ss"
            )}`
        );

        return true;
    } catch (error) {
        console.error("[ERROR] Sinkronisasi gagal:", error);
        return false;
    } finally {
        syncIsRunning = false;
    }
}

async function closeDatabase() {
    if (typeof db.end === "function") {
        await db.end();
    }
}

async function shutdown(signal) {
    console.log(`\n[INFO] Menerima ${signal}, menutup aplikasi...`);

    if (intervalId) {
        clearInterval(intervalId);
    }

    try {
        await closeDatabase();
    } catch (error) {
        console.error("[ERROR] Gagal menutup database:", error);
    }

    process.exit(0);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

(async () => {
    const success = await runSync();

    if (RUN_ONCE) {
        await closeDatabase();

        if (!success) {
            process.exitCode = 1;
        }

        return;
    }

    intervalId = setInterval(() => {
        runSync().catch((error) => {
            console.error("[ERROR] Kesalahan interval:", error);
        });
    }, SYNC_INTERVAL_MS);

    console.log(
        `[INFO] Sinkronisasi berikutnya setiap ` +
            `${SYNC_INTERVAL_HOURS} jam.`
    );
})().catch(async (error) => {
    console.error("[FATAL] Program gagal dijalankan:", error);

    try {
        await closeDatabase();
    } catch (_) {
        // Abaikan.
    }

    process.exitCode = 1;
});