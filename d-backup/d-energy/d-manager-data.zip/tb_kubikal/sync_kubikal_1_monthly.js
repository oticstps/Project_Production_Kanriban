const pool = require("../database");
const moment = require("moment-timezone");
require("moment/locale/id");

const TIMEZONE = "Asia/Jakarta";
moment.tz.setDefault(TIMEZONE);

// Mendukung database.js yang mengekspor mysql2 biasa maupun mysql2/promise.
const db = typeof pool.promise === "function" ? pool.promise() : pool;

const lineTables = [
    {
        pm_type: "DA_01",
        source_power_meter: "DA_01",
        source_table: "tb_kub1_total_kwh",
        target_table: "tb_kub1_total_kwh_monthly",
        line_name: "kubikal_1",
    },
];

// Setelah data awal lengkap, hanya 5 bulan terbaru yang diperbarui.
const LATEST_MONTHS_LIMIT = 5;

// Default sinkronisasi ulang setiap 5 jam.
// Bisa diubah, misalnya: set SYNC_INTERVAL_HOURS=3
const SYNC_INTERVAL_HOURS = Math.max(
    1,
    Number.parseInt(process.env.SYNC_INTERVAL_HOURS || "5", 10)
);
const SYNC_INTERVAL_MS = SYNC_INTERVAL_HOURS * 60 * 60 * 1000;

const args = new Set(process.argv.slice(2));
const RUN_ONCE = args.has("--once");
const FORCE_FULL_SYNC = args.has("--full");

let syncIsRunning = false;
let intervalId = null;

function quoteIdentifier(identifier) {
    if (!/^[A-Za-z0-9_]+$/.test(identifier)) {
        throw new Error(`Identifier SQL tidak valid: ${identifier}`);
    }

    return `\`${identifier}\``;
}

function roundTo3(value) {
    return Math.round((value + Number.EPSILON) * 1000) / 1000;
}

function getLatestMonthsRange() {
    const from = moment()
        .subtract(LATEST_MONTHS_LIMIT - 1, "month")
        .startOf("month");

    const until = moment().add(1, "month").startOf("month");

    return {
        from: from.format("YYYY-MM-DD HH:mm:ss"),
        until: until.format("YYYY-MM-DD HH:mm:ss"),
        description:
            `${LATEST_MONTHS_LIMIT} bulan terbaru: ` +
            `${from.format("YYYY-MM")} s.d. ${moment().format("YYYY-MM")}`,
    };
}

function buildSourceConditions(config, alias = "") {
    const prefix = alias ? `${alias}.` : "";
    const conditions = [
        `${prefix}\`date_time\` IS NOT NULL`,
        `${prefix}\`value\` IS NOT NULL`,
        `TRIM(${prefix}\`value\`) REGEXP '^[0-9]+([.][0-9]+)?$'`,
    ];
    const params = [];

    if (config.source_power_meter) {
        conditions.push(`${prefix}\`power_meter\` = ?`);
        params.push(config.source_power_meter);
    }

    return { conditions, params };
}

/**
 * Menentukan apakah rekap seluruh riwayat perlu dijalankan.
 *
 * Full sync dilakukan apabila:
 * - dipanggil dengan --full; atau
 * - tabel tujuan belum memiliki bulan yang lengkap dibanding sumber.
 *
 * Dengan demikian, jika proses pertama sebelumnya terputus di tengah jalan,
 * program tetap melanjutkan kembali dari seluruh riwayat pada start berikutnya.
 */
async function needsFullSync(connection, config) {
    if (FORCE_FULL_SYNC) {
        return true;
    }

    const sourceTable = quoteIdentifier(config.source_table);
    const targetTable = quoteIdentifier(config.target_table);
    const { conditions, params } = buildSourceConditions(config);

    const sourceSql = `
        SELECT
            COUNT(DISTINCT DATE_FORMAT(\`date_time\`, '%Y-%m')) AS source_months,
            MIN(DATE_FORMAT(\`date_time\`, '%Y-%m')) AS source_first_month,
            MAX(DATE_FORMAT(\`date_time\`, '%Y-%m')) AS source_last_month
        FROM ${sourceTable}
        WHERE ${conditions.join("\n          AND ")}
    `;

    const targetSql = `
        SELECT
            COUNT(DISTINCT CONCAT(\`year\`, '-', LPAD(\`month\`, 2, '0'))) AS target_months,
            MIN(CONCAT(\`year\`, '-', LPAD(\`month\`, 2, '0'))) AS target_first_month,
            MAX(CONCAT(\`year\`, '-', LPAD(\`month\`, 2, '0'))) AS target_last_month
        FROM ${targetTable}
        WHERE \`pm_type\` = ?
          AND \`line_table\` = ?
          AND \`line_name\` = ?
    `;

    const [[sourceStats]] = await connection.query(sourceSql, params);
    const [[targetStats]] = await connection.query(targetSql, [
        config.pm_type,
        config.source_table,
        config.line_name,
    ]);

    const sourceMonths = Number(sourceStats.source_months || 0);
    const targetMonths = Number(targetStats.target_months || 0);

    if (sourceMonths === 0) {
        return false;
    }

    return (
        targetMonths < sourceMonths ||
        targetStats.target_first_month !== sourceStats.source_first_month ||
        targetStats.target_last_month !== sourceStats.source_last_month
    );
}


async function getMonthlySourceData(connection, config, fullSync) {
    const sourceTable = quoteIdentifier(config.source_table);
    const { conditions, params } = buildSourceConditions(config);

    let description = "seluruh riwayat dari bulan paling awal";

    if (!fullSync) {
        const range = getLatestMonthsRange();
        conditions.push("`date_time` >= ?");
        conditions.push("`date_time` < ?");
        params.push(range.from, range.until);
        description = range.description;
    }

    const direction = fullSync ? "ASC" : "DESC";
    const limitClause = fullSync ? "" : `LIMIT ${LATEST_MONTHS_LIMIT}`;

    const sql = `
        SELECT
            YEAR(\`date_time\`) AS \`year\`,
            MONTH(\`date_time\`) AS \`month\`,

            CAST(
                SUBSTRING_INDEX(
                    GROUP_CONCAT(
                        TRIM(\`value\`)
                        ORDER BY \`date_time\` ASC, \`idPrimary\` ASC
                        SEPARATOR ','
                    ),
                    ',',
                    1
                ) AS DECIMAL(20,3)
            ) AS \`start_wh\`,

            CAST(
                SUBSTRING_INDEX(
                    GROUP_CONCAT(
                        TRIM(\`value\`)
                        ORDER BY \`date_time\` DESC, \`idPrimary\` DESC
                        SEPARATOR ','
                    ),
                    ',',
                    1
                ) AS DECIMAL(20,3)
            ) AS \`end_wh\`,

            SUBSTRING_INDEX(
                GROUP_CONCAT(
                    DATE_FORMAT(\`date_time\`, '%Y-%m-%d %H:%i:%s')
                    ORDER BY \`date_time\` ASC, \`idPrimary\` ASC
                    SEPARATOR ','
                ),
                ',',
                1
            ) AS \`start_datetime\`,

            SUBSTRING_INDEX(
                GROUP_CONCAT(
                    DATE_FORMAT(\`date_time\`, '%Y-%m-%d %H:%i:%s')
                    ORDER BY \`date_time\` DESC, \`idPrimary\` DESC
                    SEPARATOR ','
                ),
                ',',
                1
            ) AS \`end_datetime\`,

            COUNT(*) AS \`reading_count\`
        FROM ${sourceTable}
        WHERE ${conditions.join("\n          AND ")}
        GROUP BY YEAR(\`date_time\`), MONTH(\`date_time\`)
        ORDER BY YEAR(\`date_time\`) ${direction}, MONTH(\`date_time\`) ${direction}
        ${limitClause}
    `;

    const [rows] = await connection.query(sql, params);

    return {
        rows: fullSync ? rows : rows.reverse(),
        description,
    };
}

async function replaceMonthlyRow(connection, config, row) {
    const targetTable = quoteIdentifier(config.target_table);

    const year = Number(row.year);
    const month = Number(row.month);
    const startWh = Number(row.start_wh);
    const endWh = Number(row.end_wh);

    if (
        !Number.isInteger(year) ||
        !Number.isInteger(month) ||
        month < 1 ||
        month > 12 ||
        !Number.isFinite(startWh) ||
        !Number.isFinite(endWh)
    ) {
        throw new Error(`Data bulanan tidak valid: ${JSON.stringify(row)}`);
    }

    // Tetap Wh, tidak dibagi 1.000.
    const startValue = roundTo3(startWh);
    const endValue = roundTo3(endWh);
    const totalValue = roundTo3(endWh - startWh);

    const monthMoment = moment.tz(
        { year, month: month - 1, date: 1, hour: 0, minute: 0, second: 0 },
        TIMEZONE
    );

    const monthName = monthMoment.locale("id").format("MMMM");
    const monthStartDate = monthMoment.format("YYYY-MM-DD");
    const monthEndDate = monthMoment.clone().endOf("month").format("YYYY-MM-DD");

    if (totalValue < 0) {
        console.warn(
            `[PERINGATAN] ${config.line_name} ${year}-${String(month).padStart(2, "0")}: ` +
                `total negatif (${totalValue} Wh). Meter mungkin mengalami reset.`
        );
    }

    // Cegah duplikasi karena tabel tujuan belum memiliki UNIQUE KEY gabungan.
    await connection.query(
        `
            DELETE FROM ${targetTable}
            WHERE \`pm_type\` = ?
              AND \`line_table\` = ?
              AND \`line_name\` = ?
              AND \`year\` = ?
              AND \`month\` = ?
        `,
        [config.pm_type, config.source_table, config.line_name, year, month]
    );

    await connection.query(
        `
            INSERT INTO ${targetTable} (
                \`pm_type\`, \`line_table\`, \`line_name\`,
                \`start_kwh\`, \`end_kwh\`, \`total_kwh\`,
                \`year\`, \`month\`, \`month_name\`,
                \`month_start_date\`, \`month_end_date\`,
                \`month_start_datetime\`, \`month_end_datetime\`,
                \`created_at\`, \`updated_at\`
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        `,
        [
            config.pm_type,
            config.source_table,
            config.line_name,
            startValue,
            endValue,
            totalValue,
            year,
            month,
            monthName,
            monthStartDate,
            monthEndDate,
            row.start_datetime,
            row.end_datetime,
        ]
    );

    return {
        year,
        month,
        startValue,
        endValue,
        totalValue,
        readingCount: Number(row.reading_count),
    };
}

async function syncLineMonthly(config) {
    const connection = await db.getConnection();

    try {
        await connection.query("SET time_zone = '+07:00'");
        await connection.query("SET SESSION group_concat_max_len = 1048576");

        const fullSync = await needsFullSync(connection, config);

        console.log(
            fullSync
                ? `[MODE] ${config.line_name}: sinkronisasi seluruh riwayat.`
                : `[MODE] ${config.line_name}: memperbarui ${LATEST_MONTHS_LIMIT} bulan terbaru.`
        );

        const { rows, description } = await getMonthlySourceData(
            connection,
            config,
            fullSync
        );

        if (rows.length === 0) {
            console.log(
                `[INFO] Tidak ada data valid pada ${config.source_table} (${description}).`
            );
            return;
        }

        await connection.beginTransaction();

        const results = [];
        for (const row of rows) {
            results.push(await replaceMonthlyRow(connection, config, row));
        }

        await connection.commit();

        for (const result of results) {
            console.log(
                `[OK] ${config.line_name} ${result.year}-${String(result.month).padStart(2, "0")} | ` +
                    `awal=${result.startValue.toFixed(3)} Wh | ` +
                    `akhir=${result.endValue.toFixed(3)} Wh | ` +
                    `total=${result.totalValue.toFixed(3)} Wh | ` +
                    `data=${result.readingCount}`
            );
        }

        console.log(`[INFO] ${results.length} bulan berhasil diproses.`);
    } catch (error) {
        try {
            await connection.rollback();
        } catch (_) {
            // Transaksi mungkin belum dimulai.
        }
        throw error;
    } finally {
        connection.release();
    }
}

async function runSync() {
    if (syncIsRunning) {
        console.log("[INFO] Proses sebelumnya masih berjalan; siklus dilewati.");
        return true;
    }

    syncIsRunning = true;
    console.log(
        `\n[START] Sync monthly kubikal 1: ${moment().format("YYYY-MM-DD HH:mm:ss")}`
    );

    try {
        for (const config of lineTables) {
            await syncLineMonthly(config);
        }

        console.log(
            `[DONE] Sinkronisasi selesai: ${moment().format("YYYY-MM-DD HH:mm:ss")}`
        );
        return true;
    } catch (error) {
        console.error("[ERROR] Sinkronisasi gagal:", error);
        return false;
    } finally {
        syncIsRunning = false;
    }
}

async function closeDatabase() {
    if (typeof db.end === "function") {
        await db.end();
    }
}

async function shutdown(signal) {
    console.log(`\n[INFO] Menerima ${signal}, menutup program...`);

    if (intervalId) {
        clearInterval(intervalId);
    }

    try {
        await closeDatabase();
    } catch (error) {
        console.error("[ERROR] Gagal menutup database:", error);
    }

    process.exit(0);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

(async () => {
    // Selalu langsung sinkronisasi ketika program mulai.
    const success = await runSync();

    if (RUN_ONCE) {
        await closeDatabase();
        if (!success) process.exitCode = 1;
        return;
    }

    intervalId = setInterval(() => {
        runSync().catch((error) => {
            console.error("[ERROR] Kesalahan interval:", error);
        });
    }, SYNC_INTERVAL_MS);

    console.log(
        `[INFO] Sinkronisasi berikutnya dijalankan setiap ${SYNC_INTERVAL_HOURS} jam.`
    );
})().catch(async (error) => {
    console.error("[FATAL] Program gagal dijalankan:", error);

    try {
        await closeDatabase();
    } catch (_) {
        // Abaikan.
    }

    process.exitCode = 1;
});
