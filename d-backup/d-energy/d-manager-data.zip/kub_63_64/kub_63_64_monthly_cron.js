// TRUNCATE TABLE tb_kub2_panel63_monthly;
// TRUNCATE TABLE tb_kub2_panel64_monthly;


const pool = require("../database");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
    { pm_type: "DA_01", source_table: "tb_kub2_panel63", target_table: "tb_kub2_panel63_monthly", line_name: "Panel_63" },
    { pm_type: "DA_01", source_table: "tb_kub2_panel64", target_table: "tb_kub2_panel64_monthly", line_name: "Panel_64" },
];

const TIMEZONE = "Asia/Jakarta";
const DATE_TIME_FORMAT = "YYYY-MM-DD HH:mm:ss";
const JOB_LOCK_NAME = "rekap_monthly_cron_job";
const IDENTIFIER_PATTERN = /^[A-Za-z0-9_]+$/;

moment.tz.setDefault(TIMEZONE);

function validateIdentifier(identifier, fieldName) {
    if (!IDENTIFIER_PATTERN.test(identifier)) {
        throw new Error(`${fieldName} tidak valid: ${identifier}`);
    }
}

function validateConfiguration() {
    if (!Array.isArray(lineTables) || lineTables.length === 0) {
        throw new Error("Tidak ada line aktif di dalam lineTables.");
    }

    for (const line of lineTables) {
        validateIdentifier(line.source_table, "source_table");
        validateIdentifier(line.target_table, "target_table");
    }
}

async function getMonthlyData(connection, tableName, startTime, endTime) {
    const params = [
        startTime.format(DATE_TIME_FORMAT),
        endTime.format(DATE_TIME_FORMAT)
    ];

    const [startRows] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time ASC
        LIMIT 1
    `, params);

    const [endRows] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time DESC
        LIMIT 1
    `, params);

    if (!startRows.length || !endRows.length) {
        return null;
    }

    const startValue = Number.parseFloat(startRows[0].value);
    const endValue = Number.parseFloat(endRows[0].value);

    if (!Number.isFinite(startValue) || !Number.isFinite(endValue)) {
        return null;
    }

    const totalValue = endValue - startValue;

    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: startRows[0].date_time,
        endDatetime: endRows[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertMonthlyToTable(connection, line, data) {
    await connection.query(`
        INSERT INTO ${line.target_table} (
            pm_type,
            line_table,
            line_name,
            year,
            month,
            month_name,
            month_start_date,
            month_end_date,
            month_start_datetime,
            month_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_name = VALUES(line_name),
            month_name = VALUES(month_name),
            month_start_date = VALUES(month_start_date),
            month_end_date = VALUES(month_end_date),
            month_start_datetime = VALUES(month_start_datetime),
            month_end_datetime = VALUES(month_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.year,
        data.month,
        data.month_name,
        data.month_start_date,
        data.month_end_date,
        data.month_start_datetime,
        data.month_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh
    ]);

    console.log(
        `✅ Upsert Monthly: ${line.target_table} | ${data.year}-${String(data.month).padStart(2, "0")} | ${data.total_kwh} kWh`
    );
}

async function acquireJobLock(connection) {
    const [rows] = await connection.query(
        "SELECT GET_LOCK(?, 0) AS acquired",
        [JOB_LOCK_NAME]
    );

    return Number(rows[0]?.acquired) === 1;
}

async function releaseJobLock(connection) {
    try {
        await connection.query("SELECT RELEASE_LOCK(?) AS released", [JOB_LOCK_NAME]);
    } catch (error) {
        console.error("⚠️ Gagal melepas job lock:", error.message);
    }
}

async function rekapMonthly() {
    validateConfiguration();

    const connection = await pool.getConnection();
    let lockAcquired = false;
    let successCount = 0;
    let skippedCount = 0;

    try {
        lockAcquired = await acquireJobLock(connection);

        if (!lockAcquired) {
            console.log("⚠️ Proses rekap monthly sebelumnya masih berjalan. Eksekusi cron ini dilewati.");
            return;
        }

        console.log(
            `🚀 Rekap monthly dimulai: ${moment.tz(TIMEZONE).format("YYYY-MM-DD HH:mm:ss z")}`
        );

        for (const line of lineTables) {
            console.log(`\n🔍 Proses Monthly: ${line.source_table} -> ${line.target_table}`);

            const [months] = await connection.query(`
                SELECT DISTINCT
                    YEAR(date_time) AS year_num,
                    MONTH(date_time) AS month_num
                FROM ${line.source_table}
                WHERE date_time IS NOT NULL
                ORDER BY year_num, month_num
            `);

            if (months.length === 0) {
                console.log(`⚠️ Tidak ada data bulan pada ${line.source_table}.`);
                continue;
            }

            for (const { year_num, month_num } of months) {
                const year = Number(year_num);
                const month = Number(month_num);
                const monthLabel = `${year}-${String(month).padStart(2, "0")}`;
                const monthStart = moment.tz(
                    `${monthLabel}-01 00:00:00`,
                    DATE_TIME_FORMAT,
                    TIMEZONE
                );
                const monthEnd = monthStart.clone().add(1, "month");

                const data = await getMonthlyData(
                    connection,
                    line.source_table,
                    monthStart,
                    monthEnd
                );

                if (!data) {
                    skippedCount += 1;
                    console.log(
                        `⚠️ Skip Monthly: ${line.target_table} | ${monthLabel} | data kosong, tidak valid, nol, atau negatif`
                    );
                    continue;
                }

                await upsertMonthlyToTable(connection, line, {
                    year,
                    month,
                    month_name: monthStart.format("MMMM"),
                    month_start_date: monthStart.format("YYYY-MM-DD"),
                    month_end_date: monthEnd.clone().subtract(1, "day").format("YYYY-MM-DD"),
                    month_start_datetime: data.startDatetime,
                    month_end_datetime: data.endDatetime,
                    start_kwh: data.startValue,
                    end_kwh: data.endValue,
                    total_kwh: data.totalValue
                });

                successCount += 1;
            }
        }

        console.log("\n🎉 Rekap monthly selesai.");
        console.log(`✅ Berhasil di-upsert: ${successCount}`);
        console.log(`⚠️ Dilewati: ${skippedCount}`);
        console.log(
            `🕒 Waktu selesai: ${moment.tz(TIMEZONE).format("YYYY-MM-DD HH:mm:ss z")}`
        );
    } finally {
        if (lockAcquired) {
            await releaseJobLock(connection);
        }

        connection.release();
    }
}

async function closePool() {
    if (typeof pool.end === "function") {
        await pool.end();
    }
}

async function main() {
    try {
        await rekapMonthly();
        process.exitCode = 0;
    } catch (error) {
        console.error("❌ Error rekap monthly:", error);
        process.exitCode = 1;
    } finally {
        try {
            await closePool();
        } catch (error) {
            console.error("⚠️ Gagal menutup pool database:", error.message);
            process.exitCode = 1;
        }
    }
}

main();
