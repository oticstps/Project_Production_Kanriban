// TRUNCATE TABLE tb_kub2_panel63_shiftly;
// TRUNCATE TABLE tb_kub2_panel64_shiftly;


const pool = require("../database");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");
const lineTables = [
    { pm_type: "DA_01", source_table: "tb_kub2_panel63", target_table: "tb_kub2_panel63_shiftly", line_name: "Panel_63" },
    { pm_type: "DA_01", source_table: "tb_kub2_panel64", target_table: "tb_kub2_panel64_shiftly", line_name: "Panel_64" },
];


function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Invalid table name: ${identifier}`);
    }
    return `\`${identifier}\``;
}

function formatDateTime(value) {
    return moment(value).format("YYYY-MM-DD HH:mm:ss");
}

async function getShiftData(connection, tableName, startTime, endTime) {
    const safeTable = escapeIdentifier(tableName);
    const startTimeString = startTime.format("YYYY-MM-DD HH:mm:ss");
    const endTimeString = endTime.format("YYYY-MM-DD HH:mm:ss");
    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time ASC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time DESC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    if (!startRow.length || !endRow.length) {
        return null;
    }
    const startValue = Number(startRow[0].value);
    const endValue = Number(endRow[0].value);
    if (!Number.isFinite(startValue) || !Number.isFinite(endValue)) {
        return null;
    }
    const totalValue = Number((endValue - startValue).toFixed(3));
    if (totalValue <= 0) {
        return null;
    }
    return {
        startDatetime: formatDateTime(startRow[0].date_time),
        endDatetime: formatDateTime(endRow[0].date_time),
        startValue,
        endValue,
        totalValue
    };
}

async function upsertShiftlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(`
        INSERT INTO ${safeTargetTable} (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_name = VALUES(line_name),
            shift_start_datetime = VALUES(shift_start_datetime),
            shift_end_datetime = VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.shift,
        data.shift_date,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name
    ]);

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | ${data.shift} | ${data.shift_date} | ${data.total_kwh} kWh`
    );
}

async function getAvailableDates(connection, sourceTable) {
    const safeSourceTable = escapeIdentifier(sourceTable);
    const [rows] = await connection.query(`
        SELECT DISTINCT
            DATE_FORMAT(date_time, '%Y-%m-%d') AS shift_date
        FROM ${safeSourceTable}
        WHERE date_time IS NOT NULL
        ORDER BY shift_date ASC
    `);
    return rows.map(row => row.shift_date);
}


async function processLine(connection, line) {
    console.log(`\n🔍 Proses Shiftly: ${line.source_table} -> ${line.target_table}`);
    const availableDates = await getAvailableDates(connection, line.source_table);

    if (!availableDates.length) {
        console.log(`⚠️ Tidak ada data tanggal pada tabel sumber: ${line.source_table}`);
        return;
    }
    for (const shiftDate of availableDates) {
        const dateObj = moment(shiftDate, "YYYY-MM-DD");

        const year = Number(dateObj.format("YYYY"));
        const month = Number(dateObj.format("M"));
        const day = Number(dateObj.format("D"));
        const monthName = dateObj.format("MMMM");
        const dayName = dateObj.format("dddd");
        const shift1Start = moment(shiftDate, "YYYY-MM-DD").set({
            hour: 7,
            minute: 10,
            second: 0,
            millisecond: 0
        });

        const shift1End = moment(shiftDate, "YYYY-MM-DD").set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });
        const shift2Start = moment(shiftDate, "YYYY-MM-DD").set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });
        const shift2End = moment(shiftDate, "YYYY-MM-DD")
            .add(1, "day")
            .set({
                hour: 7,
                minute: 10,
                second: 0,
                millisecond: 0
            });
        const shift1Data = await getShiftData(
            connection,
            line.source_table,
            shift1Start,
            shift1End
        );
        if (shift1Data) {
            await upsertShiftlyToTable(connection, line, {
                shift: "shift_1",
                shift_date: shiftDate,
                shift_start_datetime: shift1Data.startDatetime,
                shift_end_datetime: shift1Data.endDatetime,
                start_kwh: shift1Data.startValue,
                end_kwh: shift1Data.endValue,
                total_kwh: shift1Data.totalValue,
                year,
                month,
                month_name: monthName,
                day,
                day_name: dayName
            });
        } else {
            console.log(
                `⚠️ Skip: ${line.target_table} | shift_1 | ${shiftDate} | data kosong / 0 / negatif`
            );
        }
        const shift2Data = await getShiftData(
            connection,
            line.source_table,
            shift2Start,
            shift2End
        );
        if (shift2Data) {
            await upsertShiftlyToTable(connection, line, {
                shift: "shift_2",
                shift_date: shiftDate,
                shift_start_datetime: shift2Data.startDatetime,
                shift_end_datetime: shift2Data.endDatetime,
                start_kwh: shift2Data.startValue,
                end_kwh: shift2Data.endValue,
                total_kwh: shift2Data.totalValue,
                year,
                month,
                month_name: monthName,
                day,
                day_name: dayName
            });
        } else {
            console.log(
                `⚠️ Skip: ${line.target_table} | shift_2 | ${shiftDate} | data kosong / 0 / negatif`
            );
        }
    }
}




async function rekapShiftly() {
    const connection = await pool.getConnection();
    try {
        console.log("🚀 Mulai rekap shiftly...");
        console.log("🔐 Mode: UPSERT aktif, tidak double insert jika UNIQUE KEY sudah benar.");
        for (const line of lineTables) {
            try {
                await processLine(connection, line);
            } catch (lineError) {
                console.error(
                    `❌ Error pada line ${line.source_table} -> ${line.target_table}:`,
                    lineError.message
                );
            }
        }

        console.log("\n🎉 Rekap shiftly selesai.");
    } catch (err) {
        console.error("❌ Error utama rekap shiftly:", err);
    } finally {
        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

rekapShiftly()
    .then(() => {
        console.log("✅ Program selesai.");
        process.exit(0);
    })
    .catch((err) => {
        console.error("❌ Program gagal:", err);
        process.exit(1);
    });

