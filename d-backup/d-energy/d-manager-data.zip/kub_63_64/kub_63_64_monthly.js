// TRUNCATE TABLE tb_kub2_panel63_monthly;
// TRUNCATE TABLE tb_kub2_panel64_monthly;


const pool = require("../database");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
    { pm_type: "DA_01", source_table: "tb_kub2_panel63", target_table: "tb_kub2_panel63_monthly", line_name: "Panel_63" },
    { pm_type: "DA_01", source_table: "tb_kub2_panel64", target_table: "tb_kub2_panel64_monthly", line_name: "Panel_64" },
];

async function getMonthlyData(connection, tableName, startTime, endTime) {
    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
        ORDER BY date_time ASC
        LIMIT 1
    `, [
        startTime.format("YYYY-MM-DD HH:mm:ss"),
        endTime.format("YYYY-MM-DD HH:mm:ss")
    ]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
        ORDER BY date_time DESC
        LIMIT 1
    `, [
        startTime.format("YYYY-MM-DD HH:mm:ss"),
        endTime.format("YYYY-MM-DD HH:mm:ss")
    ]);

    if (!startRow.length || !endRow.length) {
        return null;
    }
    const startValue = parseFloat(startRow[0].value);
    const endValue = parseFloat(endRow[0].value);
    if (isNaN(startValue) || isNaN(endValue)) {
        return null;
    }
    const totalValue = endValue - startValue;
    if (totalValue <= 0) {
        return null;
    }
    return {
        startDatetime: startRow[0].date_time,
        endDatetime: endRow[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertMonthlyToTable(connection, line, data) {
    await connection.query(`
        INSERT INTO ${line.target_table} (
            pm_type,
            line_table,
            line_name,
            year,
            month,
            month_name,
            month_start_date,
            month_end_date,
            month_start_datetime,
            month_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            line_name = VALUES(line_name),
            month_name = VALUES(month_name),
            month_start_date = VALUES(month_start_date),
            month_end_date = VALUES(month_end_date),
            month_start_datetime = VALUES(month_start_datetime),
            month_end_datetime = VALUES(month_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.year,
        data.month,
        data.month_name,
        data.month_start_date,
        data.month_end_date,
        data.month_start_datetime,
        data.month_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh
    ]);
    console.log(`✅ Upsert Monthly: ${line.target_table} | ${data.year}-${String(data.month).padStart(2, "0")} | ${data.total_kwh} kWh`);
}


async function rekapMonthly() {
    const connection = await pool.getConnection();
    try {
        for (const line of lineTables) {
            console.log(`\n🔍 Proses Monthly: ${line.source_table} -> ${line.target_table}`);
            const [months] = await connection.query(`
                SELECT DISTINCT
                    YEAR(date_time) AS year_num,
                    MONTH(date_time) AS month_num
                FROM ${line.source_table}
                WHERE date_time IS NOT NULL
                ORDER BY year_num, month_num
            `);
            for (const { year_num, month_num } of months) {
                const monthStart = moment(`${year_num}-${String(month_num).padStart(2, "0")}-01 00:00:00`);
                const monthEnd = monthStart.clone().add(1, "month");

                const data = await getMonthlyData(connection, line.source_table, monthStart, monthEnd);

                if (!data) {
                    console.log(`⚠️ Skip Monthly: ${line.target_table} | ${year_num}-${month_num} | invalid / 0 / negatif`);
                    continue;
                }
                await upsertMonthlyToTable(connection, line, {
                    year: year_num,
                    month: month_num,
                    month_name: monthStart.format("MMMM"),
                    month_start_date: monthStart.format("YYYY-MM-DD"),
                    month_end_date: monthEnd.clone().subtract(1, "day").format("YYYY-MM-DD"),
                    month_start_datetime: data.startDatetime,
                    month_end_datetime: data.endDatetime,
                    start_kwh: data.startValue,
                    end_kwh: data.endValue,
                    total_kwh: data.totalValue
                });
            }
        }
        console.log("\n🎉 Rekap monthly selesai.");
    } catch (err) {
        console.error("❌ Error rekap monthly:", err);
    } finally {
        connection.release();
    }
}

rekapMonthly();