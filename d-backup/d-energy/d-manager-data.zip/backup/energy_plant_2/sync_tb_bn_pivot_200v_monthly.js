const mysql = require("mysql2/promise");

// ==============================
// KONFIGURASI DATABASE
// ==============================
const DB_CONFIG = {
  host: "192.168.137.131",
  port: 3306,
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_energy_listrik",
  timezone: "+07:00"
};

// ==============================
// KONFIGURASI TABEL
// ==============================
const SOURCE_TABLE = "tb_bn_pivot_200v";
const DEST_TABLE = "tb_bn_pivot_200v_monthly";
const LINE_TABLE = "tb_bn_pivot_200v";

// Jika data_wh masih Wh, gunakan 1000.
// Jika data_wh sudah kWh, ubah menjadi 1.
const WH_DIVIDER = 1000;

// ==============================
// VALIDASI NAMA TABEL
// ==============================
function q(identifier) {
  if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
    throw new Error(`Nama identifier tidak valid: ${identifier}`);
  }
  return `\`${identifier}\``;
}

// ==============================
// MEMBUAT UNIQUE KEY
// AGAR DATA TIDAK DOBEL
// ==============================
async function ensureUniqueKey(connection) {
  const sql = `
    ALTER TABLE ${q(DEST_TABLE)}
    ADD UNIQUE KEY uk_monthly_unique (
      pm_type,
      line_table,
      line_name,
      year,
      month
    )
  `;

  try {
    await connection.query(sql);
    console.log("Unique key berhasil dibuat.");
  } catch (error) {
    if (error.code === "ER_DUP_KEYNAME") {
      console.log("Unique key sudah ada. Lanjut proses.");
      return;
    }

    if (error.code === "ER_DUP_ENTRY") {
      throw new Error(
        "Gagal membuat UNIQUE KEY karena sudah ada data duplikat di tabel tujuan. Bersihkan data duplikat terlebih dahulu."
      );
    }

    throw error;
  }
}

// ==============================
// PROSES INSERT / UPDATE DATA MONTHLY
// ==============================
async function syncMonthlyData(connection) {
  const sql = `
    INSERT INTO ${q(DEST_TABLE)} (
      pm_type,
      line_table,
      line_name,
      start_kwh,
      end_kwh,
      total_kwh,
      year,
      month,
      month_name,
      month_start_date,
      month_end_date,
      month_start_datetime,
      month_end_datetime
    )
    SELECT
      qdata.pm_type,
      qdata.line_table,
      qdata.line_name,
      CAST(qdata.start_wh / ? AS DECIMAL(15,3)) AS start_kwh,
      CAST(qdata.end_wh / ? AS DECIMAL(15,3)) AS end_kwh,
      CAST((qdata.end_wh - qdata.start_wh) / ? AS DECIMAL(15,3)) AS total_kwh,
      qdata.year,
      qdata.month,
      qdata.month_name,
      qdata.month_start_date,
      qdata.month_end_date,
      qdata.month_start_datetime,
      qdata.month_end_datetime
    FROM (
      SELECT
        COALESCE(g.power_meter, 'UNKNOWN') AS pm_type,
        ? AS line_table,
        COALESCE(g.panel_name, 'UNKNOWN') AS line_name,

        (
          SELECT s1.data_wh
          FROM ${q(SOURCE_TABLE)} s1
          WHERE 
            s1.panel_name <=> g.panel_name
            AND s1.power_meter <=> g.power_meter
            AND YEAR(s1.timestamp) = g.year
            AND MONTH(s1.timestamp) = g.month
            AND s1.data_wh IS NOT NULL
            AND s1.timestamp IS NOT NULL
          ORDER BY s1.timestamp ASC, s1.id ASC
          LIMIT 1
        ) AS start_wh,

        (
          SELECT s2.data_wh
          FROM ${q(SOURCE_TABLE)} s2
          WHERE 
            s2.panel_name <=> g.panel_name
            AND s2.power_meter <=> g.power_meter
            AND YEAR(s2.timestamp) = g.year
            AND MONTH(s2.timestamp) = g.month
            AND s2.data_wh IS NOT NULL
            AND s2.timestamp IS NOT NULL
          ORDER BY s2.timestamp DESC, s2.id DESC
          LIMIT 1
        ) AS end_wh,

        g.year,
        g.month,

        CASE MONTH(STR_TO_DATE(CONCAT(g.year, '-', g.month, '-01'), '%Y-%c-%d'))
          WHEN 1 THEN 'January'
          WHEN 2 THEN 'February'
          WHEN 3 THEN 'March'
          WHEN 4 THEN 'April'
          WHEN 5 THEN 'May'
          WHEN 6 THEN 'June'
          WHEN 7 THEN 'July'
          WHEN 8 THEN 'August'
          WHEN 9 THEN 'September'
          WHEN 10 THEN 'October'
          WHEN 11 THEN 'November'
          WHEN 12 THEN 'December'
        END AS month_name,

        DATE(STR_TO_DATE(CONCAT(g.year, '-', g.month, '-01'), '%Y-%c-%d')) AS month_start_date,
        LAST_DAY(STR_TO_DATE(CONCAT(g.year, '-', g.month, '-01'), '%Y-%c-%d')) AS month_end_date,
        g.first_datetime AS month_start_datetime,
        g.last_datetime AS month_end_datetime

      FROM (
        SELECT
          panel_name,
          power_meter,
          YEAR(timestamp) AS year,
          MONTH(timestamp) AS month,
          MIN(timestamp) AS first_datetime,
          MAX(timestamp) AS last_datetime
        FROM ${q(SOURCE_TABLE)}
        WHERE 
          timestamp IS NOT NULL
          AND data_wh IS NOT NULL
        GROUP BY
          panel_name,
          power_meter,
          YEAR(timestamp),
          MONTH(timestamp)
      ) g
    ) qdata
    WHERE 
      qdata.start_wh IS NOT NULL
      AND qdata.end_wh IS NOT NULL

    ON DUPLICATE KEY UPDATE
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      month_name = VALUES(month_name),
      month_start_date = VALUES(month_start_date),
      month_end_date = VALUES(month_end_date),
      month_start_datetime = VALUES(month_start_datetime),
      month_end_datetime = VALUES(month_end_datetime),
      updated_at = CURRENT_TIMESTAMP
  `;

  const [result] = await connection.execute(sql, [
    WH_DIVIDER,
    WH_DIVIDER,
    WH_DIVIDER,
    LINE_TABLE
  ]);

  console.log("Sinkronisasi selesai.");
  console.log(`Affected rows: ${result.affectedRows}`);
}

// ==============================
// MAIN PROGRAM
// ==============================
async function main() {
  let connection;

  try {
    connection = await mysql.createConnection(DB_CONFIG);

    console.log("Berhasil terhubung ke database.");

    await ensureUniqueKey(connection);
    await syncMonthlyData(connection);

    console.log("Data monthly berhasil diinsert / update dengan benar.");
  } catch (error) {
    console.error("Terjadi error:");
    console.error(error.message);
  } finally {
    if (connection) {
      await connection.end();
      console.log("Koneksi database ditutup.");
    }
  }
}

main();