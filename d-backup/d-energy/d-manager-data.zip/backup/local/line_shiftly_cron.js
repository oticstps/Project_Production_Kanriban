
const pool = require("../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");


const lineTables = [
    // PM 200
    { pm_type: "PM 200", source_table: "tb_pm200_bs1", target_table: "tb_pm200_bs1_shiftly", line_name: "BS1" },
    { pm_type: "PM 200", source_table: "tb_pm200_bs2", target_table: "tb_pm200_bs2_shiftly", line_name: "BS2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cc1", target_table: "tb_pm200_cc1_shiftly", line_name: "CC1" },
    { pm_type: "PM_200V", source_table: "tb_pm200_cc234", target_table: "tb_pm200_cc234_shiftly", line_name: "CC234" },
    { pm_type: "PM-200V", source_table: "tb_pm200_chab", target_table: "tb_pm200_chab_shiftly", line_name: "CHAB" },
    { pm_type: "PM-3F", source_table: "tb_pm200_chcd", target_table: "tb_pm200_chcd_shiftly", line_name: "CHCD" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chef", target_table: "tb_pm200_chef_shiftly", line_name: "CHEF" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsaa", target_table: "tb_pm200_chsaa_shiftly", line_name: "CHSAA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsac", target_table: "tb_pm200_chsac_shiftly", line_name: "CHSAC" },
    { pm_type: "PM 200", source_table: "tb_pm200_conn", target_table: "tb_pm200_conn_shiftly", line_name: "CONN" },

    { pm_type: "PM 200", source_table: "tb_pm200_cr1", target_table: "tb_pm200_cr1_shiftly", line_name: "CR1" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr2", target_table: "tb_pm200_cr2_shiftly", line_name: "CR2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr3", target_table: "tb_pm200_cr3_shiftly", line_name: "CR3" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr4", target_table: "tb_pm200_cr4_shiftly", line_name: "CR4" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr5", target_table: "tb_pm200_cr5_shiftly", line_name: "CR5" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr6", target_table: "tb_pm200_cr6_shiftly", line_name: "CR6" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr7", target_table: "tb_pm200_cr7_shiftly", line_name: "CR7" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr8", target_table: "tb_pm200_cr8_shiftly", line_name: "CR8" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr9", target_table: "tb_pm200_cr9_shiftly", line_name: "CR9" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr10", target_table: "tb_pm200_cr10_shiftly", line_name: "CR10" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr11", target_table: "tb_pm200_cr11_shiftly", line_name: "CR11" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr12", target_table: "tb_pm200_cr12_shiftly", line_name: "CR12" },

    { pm_type: "PM_200V", source_table: "tb_pm200_ct", target_table: "tb_pm200_ct_shiftly", line_name: "CT" },
    { pm_type: "PM_200V", source_table: "tb_pm200_hla", target_table: "tb_pm200_hla_shiftly", line_name: "HLA" },
    { pm_type: "PM 200", source_table: "tb_pm200_ra", target_table: "tb_pm200_ra_shiftly", line_name: "RA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ret", target_table: "tb_pm200_ret_shiftly", line_name: "RET" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsab", target_table: "tb_pm200_chsab_shiftly", line_name: "CHSAB" },

    // PM 220
    { pm_type: "PM 220", source_table: "tb_pm220_bs1", target_table: "tb_pm220_bs1_shiftly", line_name: "BS1" },
    { pm_type: "PM 220", source_table: "tb_pm220_bs2", target_table: "tb_pm220_bs2_shiftly", line_name: "BS2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cc1", target_table: "tb_pm220_cc1_shiftly", line_name: "CC1" },
    { pm_type: "PM_220V", source_table: "tb_pm220_cc234", target_table: "tb_pm220_cc234_shiftly", line_name: "CC234" },
    { pm_type: "PM-220V", source_table: "tb_pm220_chab", target_table: "tb_pm220_chab_shiftly", line_name: "CHAB" },
    { pm_type: "PM-1F", source_table: "tb_pm220_chcd", target_table: "tb_pm220_chcd_shiftly", line_name: "CHCD" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chef", target_table: "tb_pm220_chef_shiftly", line_name: "CHEF" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsaa", target_table: "tb_pm220_chsaa_shiftly", line_name: "CHSAA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsac", target_table: "tb_pm220_chsac_shiftly", line_name: "CHSAC" },
    { pm_type: "PM 220", source_table: "tb_pm220_conn", target_table: "tb_pm220_conn_shiftly", line_name: "CONN" },

    { pm_type: "PM 220", source_table: "tb_pm220_cr1", target_table: "tb_pm220_cr1_shiftly", line_name: "CR1" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr2", target_table: "tb_pm220_cr2_shiftly", line_name: "CR2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr3", target_table: "tb_pm220_cr3_shiftly", line_name: "CR3" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr4", target_table: "tb_pm220_cr4_shiftly", line_name: "CR4" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr5", target_table: "tb_pm220_cr5_shiftly", line_name: "CR5" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr6", target_table: "tb_pm220_cr6_shiftly", line_name: "CR6" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr7", target_table: "tb_pm220_cr7_shiftly", line_name: "CR7" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr8", target_table: "tb_pm220_cr8_shiftly", line_name: "CR8" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr9", target_table: "tb_pm220_cr9_shiftly", line_name: "CR9" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr10", target_table: "tb_pm220_cr10_shiftly", line_name: "CR10" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr11", target_table: "tb_pm220_cr11_shiftly", line_name: "CR11" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr12", target_table: "tb_pm220_cr12_shiftly", line_name: "CR12" },

    { pm_type: "PM_220V", source_table: "tb_pm220_ct", target_table: "tb_pm220_ct_shiftly", line_name: "CT" },
    { pm_type: "PM 220", source_table: "tb_pm220_hla", target_table: "tb_pm220_hla_shiftly", line_name: "HLA" },
    { pm_type: "PM 220", source_table: "tb_pm220_ra", target_table: "tb_pm220_ra_shiftly", line_name: "RA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ret", target_table: "tb_pm220_ret_shiftly", line_name: "RET" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsab", target_table: "tb_pm220_chsab_shiftly", line_name: "CHSAB" },
];







/**
 * Konfigurasi proses.
 */
const APP_TIMEZONE = "Asia/Jakarta";
const PROCESS_LOCK_NAME = "rekap_shiftly_current_month";
const REQUIRED_UNIQUE_COLUMNS = ["line_table", "shift_date", "shift"];

/**
 * Pengaman nama tabel agar query dinamis tidak rawan SQL injection.
 */
function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Invalid table name: ${identifier}`);
    }

    return `\`${identifier}\``;
}

/**
 * Format datetime agar aman masuk ke kolom DATETIME MySQL.
 */
function formatDateTime(value) {
    return moment(value).tz(APP_TIMEZONE).format("YYYY-MM-DD HH:mm:ss");
}

/**
 * Cegah dua instance program berjalan bersamaan.
 * Unique key tetap menjadi pengaman utama terhadap duplikasi data.
 */
async function acquireProcessLock(connection) {
    const [rows] = await connection.query(
        "SELECT GET_LOCK(?, 0) AS acquired",
        [PROCESS_LOCK_NAME]
    );

    if (!rows.length || Number(rows[0].acquired) !== 1) {
        throw new Error(
            "Proses rekap shiftly lain masih berjalan. Eksekusi ini dihentikan agar tidak overlap."
        );
    }
}

async function releaseProcessLock(connection) {
    try {
        await connection.query("SELECT RELEASE_LOCK(?)", [PROCESS_LOCK_NAME]);
    } catch (error) {
        console.error("⚠️ Gagal melepas process lock:", error.message);
    }
}

/**
 * Pastikan target memiliki UNIQUE KEY:
 * (line_table, shift_date, shift)
 *
 * Tanpa unique key tersebut, ON DUPLICATE KEY UPDATE tidak dapat menjamin
 * bahwa data tidak menjadi duplikat.
 */
async function assertTargetUniqueKey(connection, targetTable) {
    const [rows] = await connection.query(`
        SELECT
            INDEX_NAME,
            GROUP_CONCAT(
                COLUMN_NAME
                ORDER BY SEQ_IN_INDEX
                SEPARATOR ','
            ) AS index_columns
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
          AND NON_UNIQUE = 0
        GROUP BY INDEX_NAME
    `, [targetTable]);

    const requiredColumns = REQUIRED_UNIQUE_COLUMNS.join(",");
    const hasRequiredUniqueKey = rows.some(
        row => String(row.index_columns).toLowerCase() === requiredColumns
    );

    if (!hasRequiredUniqueKey) {
        throw new Error(
            `Target ${targetTable} belum memiliki UNIQUE KEY ` +
            `(line_table, shift_date, shift). ` +
            `Program dihentikan untuk mencegah data duplikat.`
        );
    }
}

/**
 * Ambil data awal dan akhir berdasarkan rentang waktu shift.
 */
async function getShiftData(connection, tableName, startTime, endTime) {
    const safeTable = escapeIdentifier(tableName);

    const startTimeString = startTime.format("YYYY-MM-DD HH:mm:ss");
    const endTimeString = endTime.format("YYYY-MM-DD HH:mm:ss");

    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time ASC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time DESC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = Number(startRow[0].value);
    const endValue = Number(endRow[0].value);

    if (!Number.isFinite(startValue) || !Number.isFinite(endValue)) {
        return null;
    }

    const totalValue = Number((endValue - startValue).toFixed(3));

    /**
     * Abaikan data anomali:
     * - total 0
     * - total negatif
     * - meter reset / nilai turun
     */
    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: formatDateTime(startRow[0].date_time),
        endDatetime: formatDateTime(endRow[0].date_time),
        startValue,
        endValue,
        totalValue
    };
}

/**
 * Insert data baru atau update data yang sudah ada.
 * Tidak melakukan DELETE dan tidak melakukan TRUNCATE.
 */
async function upsertShiftlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(`
        INSERT INTO ${safeTargetTable} (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_name = VALUES(line_name),
            shift_start_datetime = VALUES(shift_start_datetime),
            shift_end_datetime = VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.shift,
        data.shift_date,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name
    ]);

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | ${data.shift} | ` +
        `${data.shift_date} | ${data.total_kwh} kWh`
    );
}

/**
 * Ambil tanggal yang tersedia hanya untuk bulan berjalan.
 * Filter menggunakan rentang datetime agar indeks date_time tetap bisa dipakai.
 */
async function getCurrentMonthAvailableDates(
    connection,
    sourceTable,
    monthStart,
    nextMonthStart
) {
    const safeSourceTable = escapeIdentifier(sourceTable);

    const [rows] = await connection.query(`
        SELECT DISTINCT
            DATE_FORMAT(date_time, '%Y-%m-%d') AS shift_date
        FROM ${safeSourceTable}
        WHERE date_time >= ?
          AND date_time < ?
        ORDER BY shift_date ASC
    `, [
        monthStart.format("YYYY-MM-DD HH:mm:ss"),
        nextMonthStart.format("YYYY-MM-DD HH:mm:ss")
    ]);

    return rows.map(row => row.shift_date);
}

/**
 * Proses satu shift hanya jika waktu akhirnya sudah terlewati.
 * Ini mencegah shift hari ini yang belum selesai ikut tersimpan sebagai data parsial.
 */
async function processCompletedShift(
    connection,
    line,
    shiftName,
    shiftDate,
    shiftStart,
    shiftEnd,
    now,
    dateMetadata
) {
    if (now.isBefore(shiftEnd)) {
        console.log(
            `⏭️ Belum selesai: ${line.target_table} | ${shiftName} | ` +
            `${shiftDate} | berakhir ${shiftEnd.format("YYYY-MM-DD HH:mm:ss")}`
        );
        return;
    }

    const shiftData = await getShiftData(
        connection,
        line.source_table,
        shiftStart,
        shiftEnd
    );

    if (!shiftData) {
        console.log(
            `⚠️ Skip: ${line.target_table} | ${shiftName} | ${shiftDate} | ` +
            `data kosong / 0 / negatif`
        );
        return;
    }

    await upsertShiftlyToTable(connection, line, {
        shift: shiftName,
        shift_date: shiftDate,
        shift_start_datetime: shiftData.startDatetime,
        shift_end_datetime: shiftData.endDatetime,
        start_kwh: shiftData.startValue,
        end_kwh: shiftData.endValue,
        total_kwh: shiftData.totalValue,
        ...dateMetadata
    });
}

/**
 * Proses satu line/tabel untuk bulan berjalan saja.
 */
async function processLine(connection, line, now, monthStart, nextMonthStart) {
    console.log(`\n🔍 Proses Shiftly: ${line.source_table} -> ${line.target_table}`);

    await assertTargetUniqueKey(connection, line.target_table);

    const availableDates = await getCurrentMonthAvailableDates(
        connection,
        line.source_table,
        monthStart,
        nextMonthStart
    );

    if (!availableDates.length) {
        console.log(
            `⚠️ Tidak ada data bulan berjalan pada tabel sumber: ${line.source_table}`
        );
        return;
    }

    for (const shiftDate of availableDates) {
        const dateObj = moment.tz(shiftDate, "YYYY-MM-DD", APP_TIMEZONE);

        const dateMetadata = {
            year: Number(dateObj.format("YYYY")),
            month: Number(dateObj.format("M")),
            month_name: dateObj.format("MMMM"),
            day: Number(dateObj.format("D")),
            day_name: dateObj.format("dddd")
        };

        /** Shift 1: 07:10 sampai 19:50 pada tanggal yang sama. */
        const shift1Start = dateObj.clone().set({
            hour: 7,
            minute: 10,
            second: 0,
            millisecond: 0
        });

        const shift1End = dateObj.clone().set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        /** Shift 2: 19:50 sampai 07:10 hari berikutnya. */
        const shift2Start = dateObj.clone().set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        const shift2End = dateObj.clone().add(1, "day").set({
            hour: 7,
            minute: 10,
            second: 0,
            millisecond: 0
        });

        await processCompletedShift(
            connection,
            line,
            "shift_1",
            shiftDate,
            shift1Start,
            shift1End,
            now,
            dateMetadata
        );

        await processCompletedShift(
            connection,
            line,
            "shift_2",
            shiftDate,
            shift2Start,
            shift2End,
            now,
            dateMetadata
        );
    }
}

/**
 * Program utama.
 */
async function rekapShiftly() {
    const connection = await pool.getConnection();
    let lockAcquired = false;

    const now = moment.tz(APP_TIMEZONE);
    const monthStart = now.clone().startOf("month");
    const nextMonthStart = monthStart.clone().add(1, "month");

    try {
        console.log("🚀 Mulai rekap shiftly bulan berjalan...");
        console.log(`🕒 Waktu proses: ${now.format("YYYY-MM-DD HH:mm:ss z")}`);
        console.log(
            `📅 Rentang bulan: ${monthStart.format("YYYY-MM-DD")} s.d. ` +
            `${nextMonthStart.clone().subtract(1, "day").format("YYYY-MM-DD")}`
        );
        console.log("🔐 Mode: UPSERT + UNIQUE KEY + process lock.");

        await acquireProcessLock(connection);
        lockAcquired = true;

        if (!lineTables.length) {
            throw new Error(
                "Tidak ada mapping tabel aktif pada lineTables. Aktifkan minimal satu tabel."
            );
        }

        const failedLines = [];

        for (const line of lineTables) {
            try {
                await processLine(
                    connection,
                    line,
                    now,
                    monthStart,
                    nextMonthStart
                );
            } catch (lineError) {
                failedLines.push({
                    sourceTable: line.source_table,
                    targetTable: line.target_table,
                    message: lineError.message
                });

                console.error(
                    `❌ Error pada line ${line.source_table} -> ` +
                    `${line.target_table}: ${lineError.message}`
                );
            }
        }

        if (failedLines.length > 0) {
            const failedTableNames = failedLines
                .map(item => item.targetTable)
                .join(", ");

            throw new Error(
                `${failedLines.length} tabel gagal diproses: ${failedTableNames}`
            );
        }

        console.log("\n🎉 Rekap shiftly bulan berjalan selesai tanpa error.");
    } catch (err) {
        console.error("❌ Error utama rekap shiftly:", err.message);
        throw err;
    } finally {
        if (lockAcquired) {
            await releaseProcessLock(connection);
        }

        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

/**
 * Jalankan program satu kali.
 * Penjadwalan pukul 07:30 dilakukan melalui cron/Task Scheduler/PM2.
 */
rekapShiftly()
    .then(() => {
        console.log("✅ Program selesai.");
        process.exit(0);
    })
    .catch((err) => {
        console.error("❌ Program gagal:", err.message);
        process.exit(1);
    });
