const moment = require("moment-timezone");
const mysql = require("mysql2/promise");

moment.tz.setDefault("Asia/Jakarta");

/*
|--------------------------------------------------------------------------
| Koneksi database sumber
|--------------------------------------------------------------------------
| Membaca data dari:
| 10.42.0.131.database_tps_energy_listrik.tb_kub1_total_kwh
*/
const sourcePool = mysql.createPool({
    host: "10.42.0.131",
    user: "otics_tps",
    password: "sukatno_ali",
    database: "database_tps_energy_listrik",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    timezone: "+07:00",
    dateStrings: true,
    charset: "utf8mb4"
});

/*
|--------------------------------------------------------------------------
| Koneksi database tujuan
|--------------------------------------------------------------------------
| Menyimpan data ke:
| 172.27.63.180.database_tps_energy_listrik.tb_pm_shiftly_kub_report
*/
const targetPool = mysql.createPool({
    host: "172.27.63.180",
    user: "otics_tps",
    password: "sukatno_ali",
    database: "database_tps_master",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    timezone: "+07:00",
    dateStrings: true,
    charset: "utf8mb4"
});

const CONFIG = {
    pm_type: "DA_01",
    source_table: "tb_kub1_total_kwh",
    target_table: "tb_pm_shiftly_kub_report",
    line_name: "kubikal_1"
};

/**
 * Mengubah nilai menjadi number.
 * Mengembalikan null jika nilainya tidak valid.
 */
function toNumber(value) {
    const numberValue = Number.parseFloat(value);
    return Number.isFinite(numberValue) ? numberValue : null;
}

/**
 * Mengambil seluruh power meter yang tersedia pada tabel sumber.
 */
async function getPowerMeters(sourceConnection) {
    const [rows] = await sourceConnection.query(`
        SELECT DISTINCT power_meter
        FROM \`${CONFIG.source_table}\`
        WHERE power_meter IS NOT NULL
          AND TRIM(power_meter) <> ''
        ORDER BY power_meter ASC
    `);

    return rows.map((row) => row.power_meter);
}

/**
 * Mengambil daftar tanggal berdasarkan power meter.
 */
async function getAvailableDates(sourceConnection, powerMeter) {
    const [rows] = await sourceConnection.query(`
        SELECT DISTINCT
            DATE(date_time) AS shift_date,
            YEAR(date_time) AS year,
            MONTH(date_time) AS month,
            DAY(date_time) AS day
        FROM \`${CONFIG.source_table}\`
        WHERE power_meter = ?
          AND date_time IS NOT NULL
        ORDER BY shift_date ASC
    `, [powerMeter]);

    return rows;
}

/**
 * Mengambil nilai awal dan nilai akhir pada rentang shift.
 */
async function getShiftData(
    sourceConnection,
    powerMeter,
    startTime,
    endTime
) {
    const startDatetime = startTime.format("YYYY-MM-DD HH:mm:ss");
    const endDatetime = endTime.format("YYYY-MM-DD HH:mm:ss");

    const [startRows] = await sourceConnection.query(`
        SELECT date_time, value
        FROM \`${CONFIG.source_table}\`
        WHERE power_meter = ?
          AND date_time >= ?
          AND date_time < ?
        ORDER BY date_time ASC
        LIMIT 1
    `, [
        powerMeter,
        startDatetime,
        endDatetime
    ]);

    const [endRows] = await sourceConnection.query(`
        SELECT date_time, value
        FROM \`${CONFIG.source_table}\`
        WHERE power_meter = ?
          AND date_time >= ?
          AND date_time < ?
        ORDER BY date_time DESC
        LIMIT 1
    `, [
        powerMeter,
        startDatetime,
        endDatetime
    ]);

    if (startRows.length === 0 || endRows.length === 0) {
        return null;
    }

    const startValue = toNumber(startRows[0].value);
    const endValue = toNumber(endRows[0].value);

    if (startValue === null || endValue === null) {
        return null;
    }

    const totalValue = endValue - startValue;

    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: startRows[0].date_time,
        endDatetime: endRows[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

/**
 * Menyimpan atau memperbarui data shift ke database tujuan.
 */
async function upsertShiftly(targetConnection, payload) {
    await targetConnection.query(`
        INSERT INTO \`${CONFIG.target_table}\` (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, NOW(), NOW()
        )
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_table = VALUES(line_table),
            line_name = VALUES(line_name),
            shift_start_datetime = VALUES(shift_start_datetime),
            shift_end_datetime = VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
    `, [
        payload.pm_type,
        payload.line_table,
        payload.line_name,
        payload.shift,
        payload.shift_date,
        payload.shift_start_datetime,
        payload.shift_end_datetime,
        payload.start_kwh,
        payload.end_kwh,
        payload.total_kwh,
        payload.year,
        payload.month,
        payload.month_name,
        payload.day,
        payload.day_name
    ]);
}

/**
 * Memproses satu shift.
 */
async function processShift({
    sourceConnection,
    targetConnection,
    powerMeter,
    shift,
    shiftDate,
    startTime,
    endTime,
    dateInformation
}) {
    const shiftData = await getShiftData(
        sourceConnection,
        powerMeter,
        startTime,
        endTime
    );

    if (!shiftData) {
        console.log(
            `⚠️ Skip ${powerMeter} | ${shift} | ${shiftDate}: data tidak mencukupi`
        );
        return;
    }

    await upsertShiftly(targetConnection, {
        pm_type: CONFIG.pm_type,
        line_table: CONFIG.source_table,
        line_name: CONFIG.line_name,
        shift,
        shift_date: shiftDate,
        shift_start_datetime: shiftData.startDatetime,
        shift_end_datetime: shiftData.endDatetime,
        start_kwh: shiftData.startValue,
        end_kwh: shiftData.endValue,
        total_kwh: shiftData.totalValue,
        year: dateInformation.year,
        month: dateInformation.month,
        month_name: dateInformation.monthName,
        day: dateInformation.day,
        day_name: dateInformation.dayName
    });

    console.log(
        `✅ ${powerMeter} | ${shift} | ${shiftDate} | ${shiftData.totalValue} kWh`
    );
}

/**
 * Fungsi utama rekapitulasi shift.
 */
async function rekapShiftly() {
    let sourceConnection;
    let targetConnection;

    try {
        sourceConnection = await sourcePool.getConnection();
        targetConnection = await targetPool.getConnection();

        console.log("✅ Berhasil terhubung ke database sumber.");
        console.log("✅ Berhasil terhubung ke database tujuan.");

        const powerMeters = await getPowerMeters(sourceConnection);

        if (powerMeters.length === 0) {
            console.log("⚠️ Tidak ada power meter pada tabel sumber.");
            return;
        }

        console.log(`📊 Jumlah power meter: ${powerMeters.length}`);

        for (const powerMeter of powerMeters) {
            console.log(`\n🔍 Memproses power meter: ${powerMeter}`);

            const dates = await getAvailableDates(
                sourceConnection,
                powerMeter
            );

            for (const row of dates) {
                const shiftDate = moment(row.shift_date).format("YYYY-MM-DD");
                const dateObject = moment.tz(
                    shiftDate,
                    "YYYY-MM-DD",
                    "Asia/Jakarta"
                );

                const dateInformation = {
                    year: dateObject.year(),
                    month: dateObject.month() + 1,
                    monthName: dateObject.format("MMMM"),
                    day: dateObject.date(),
                    dayName: dateObject.format("dddd")
                };

                // Shift 1: 07.10 sampai 19.50 pada hari yang sama.
                const shift1Start = dateObject.clone().set({
                    hour: 7,
                    minute: 10,
                    second: 0,
                    millisecond: 0
                });

                const shift1End = dateObject.clone().set({
                    hour: 19,
                    minute: 50,
                    second: 0,
                    millisecond: 0
                });

                // Shift 2: 19.50 sampai 07.10 pada hari berikutnya.
                const shift2Start = dateObject.clone().set({
                    hour: 19,
                    minute: 50,
                    second: 0,
                    millisecond: 0
                });

                const shift2End = dateObject.clone()
                    .add(1, "day")
                    .set({
                        hour: 7,
                        minute: 10,
                        second: 0,
                        millisecond: 0
                    });

                await processShift({
                    sourceConnection,
                    targetConnection,
                    powerMeter,
                    shift: "shift_1",
                    shiftDate,
                    startTime: shift1Start,
                    endTime: shift1End,
                    dateInformation
                });

                await processShift({
                    sourceConnection,
                    targetConnection,
                    powerMeter,
                    shift: "shift_2",
                    shiftDate,
                    startTime: shift2Start,
                    endTime: shift2End,
                    dateInformation
                });
            }
        }

        console.log("\n🎉 Rekap kub_shiftly selesai.");
    } catch (error) {
        console.error("\n❌ Error kub_shiftly:", {
            message: error.message,
            code: error.code,
            sqlMessage: error.sqlMessage
        });

        process.exitCode = 1;
    } finally {
        if (sourceConnection) {
            sourceConnection.release();
        }

        if (targetConnection) {
            targetConnection.release();
        }

        await Promise.allSettled([
            sourcePool.end(),
            targetPool.end()
        ]);
    }
}

rekapShiftly();