// const pool = require("../../config/db_core");
const moment = require("moment-timezone");



const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: "192.168.137.131",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_master",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  timezone: '+07:00',
  dateStrings: true,
  charset: 'utf8mb4'
});

module.exports = pool;





moment.tz.setDefault("Asia/Jakarta");

const CONFIG = {
    pm_type: "DA_01",
    source_table: "tb_kub1_total_kwh",
    target_table: "tb_pm_shiftly_kub_report",
};

function toNumber(value) {
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
}

async function getPowerMeters(connection) {
    const [rows] = await connection.query(`
        SELECT DISTINCT power_meter
        FROM ${CONFIG.source_table}
        WHERE power_meter IS NOT NULL
          AND TRIM(power_meter) <> ''
        ORDER BY power_meter ASC
    `);
    return rows.map(row => row.power_meter);
}

async function getShiftData(connection, powerMeter, startTime, endTime) {
    const params = [
        powerMeter,
        startTime.format("YYYY-MM-DD HH:mm:ss"),
        endTime.format("YYYY-MM-DD HH:mm:ss")
    ];

    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time >= ?
          AND date_time < ?
        ORDER BY date_time ASC
        LIMIT 1
    `, params);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time >= ?
          AND date_time < ?
        ORDER BY date_time DESC
        LIMIT 1
    `, params);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = toNumber(startRow[0].value);
    const endValue = toNumber(endRow[0].value);

    if (startValue === null || endValue === null) {
        return null;
    }

    const totalValue = endValue - startValue;
    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: startRow[0].date_time,
        endDatetime: endRow[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertShiftly(connection, payload) {
    await connection.query(`
        INSERT INTO ${CONFIG.target_table} (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            shift_start_datetime = VALUES(shift_start_datetime),
            shift_end_datetime = VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
    `, [
        payload.pm_type,
        payload.line_table,
        payload.line_name,
        payload.shift,
        payload.shift_date,
        payload.shift_start_datetime,
        payload.shift_end_datetime,
        payload.start_kwh,
        payload.end_kwh,
        payload.total_kwh,
        payload.year,
        payload.month,
        payload.month_name,
        payload.day,
        payload.day_name
    ]);
}

async function rekapShiftly() {
    const connection = await pool.getConnection();

    try {
        const powerMeters = await getPowerMeters(connection);

        for (const powerMeter of powerMeters) {
            console.log(`\n🔍 Proses shiftly power meter: ${powerMeter}`);

            const [dates] = await connection.query(`
                SELECT DISTINCT
                    DATE(date_time) AS shift_date,
                    YEAR(date_time) AS year,
                    MONTH(date_time) AS month,
                    DAY(date_time) AS day
                FROM ${CONFIG.source_table}
                WHERE power_meter = ?
                  AND date_time IS NOT NULL
                ORDER BY shift_date ASC
            `, [powerMeter]);

            for (const row of dates) {
                const shiftDate = moment(row.shift_date).format("YYYY-MM-DD");
                const dateObj = moment(shiftDate);

                const dayName = dateObj.format("dddd");
                const monthName = dateObj.format("MMMM");

                const shift1Start = moment(shiftDate).set({ hour: 7, minute: 10, second: 0 });
                const shift1End = moment(shiftDate).set({ hour: 19, minute: 50, second: 0 });

                const shift2Start = moment(shiftDate).set({ hour: 19, minute: 50, second: 0 });
                const shift2End = moment(shiftDate).add(1, "day").set({ hour: 7, minute: 10, second: 0 });

                const shift1Data = await getShiftData(connection, powerMeter, shift1Start, shift1End);
                if (shift1Data) {
                    await upsertShiftly(connection, {
                        pm_type: CONFIG.pm_type,
                        line_table: CONFIG.source_table,
                        line_name: "kubikal_1",   // nilai tetap
                        shift: "shift_1",
                        shift_date: shiftDate,
                        shift_start_datetime: shift1Data.startDatetime,
                        shift_end_datetime: shift1Data.endDatetime,
                        start_kwh: shift1Data.startValue,
                        end_kwh: shift1Data.endValue,
                        total_kwh: shift1Data.totalValue,
                        year: row.year,
                        month: row.month,
                        month_name: monthName,
                        day: row.day,
                        day_name: dayName
                    });

                    console.log(`✅ ${powerMeter} | shift_1 | ${shiftDate} | ${shift1Data.totalValue} kWh`);
                } else {
                    console.log(`⚠️ Skip ${powerMeter} | shift_1 | ${shiftDate}`);
                }

                const shift2Data = await getShiftData(connection, powerMeter, shift2Start, shift2End);
                if (shift2Data) {
                    await upsertShiftly(connection, {
                        pm_type: CONFIG.pm_type,
                        line_table: CONFIG.source_table,
                        line_name: "kubikal_1",   // nilai tetap
                        shift: "shift_2",
                        shift_date: shiftDate,
                        shift_start_datetime: shift2Data.startDatetime,
                        shift_end_datetime: shift2Data.endDatetime,
                        start_kwh: shift2Data.startValue,
                        end_kwh: shift2Data.endValue,
                        total_kwh: shift2Data.totalValue,
                        year: row.year,
                        month: row.month,
                        month_name: monthName,
                        day: row.day,
                        day_name: dayName
                    });

                    console.log(`✅ ${powerMeter} | shift_2 | ${shiftDate} | ${shift2Data.totalValue} kWh`);
                } else {
                    console.log(`⚠️ Skip ${powerMeter} | shift_2 | ${shiftDate}`);
                }
            }
        }

        console.log("\n🎉 Rekap kub_shiftly selesai.");
    } catch (error) {
        console.error("❌ Error kub_shiftly:", error);
    } finally {
        connection.release();
    }
}

rekapShiftly();