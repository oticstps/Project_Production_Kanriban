const pool = require("../../../config/db_core");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
    // PM 200
    { pm_type: "PM 200", source_table: "tb_pm200_bs1", target_table: "tb_pm200_bs1_daily", line_name: "BS1" },
    { pm_type: "PM 200", source_table: "tb_pm200_bs2", target_table: "tb_pm200_bs2_daily", line_name: "BS2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cc1", target_table: "tb_pm200_cc1_daily", line_name: "CC1" },
    { pm_type: "PM_200V", source_table: "tb_pm200_cc234", target_table: "tb_pm200_cc234_daily", line_name: "CC234" },
    { pm_type: "PM-200V", source_table: "tb_pm200_chab", target_table: "tb_pm200_chab_daily", line_name: "CHAB" },
    { pm_type: "PM-3F", source_table: "tb_pm200_chcd", target_table: "tb_pm200_chcd_daily", line_name: "CHCD" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chef", target_table: "tb_pm200_chef_daily", line_name: "CHEF" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsaa", target_table: "tb_pm200_chsaa_daily", line_name: "CHSAA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsac", target_table: "tb_pm200_chsac_daily", line_name: "CHSAC" },
    { pm_type: "PM 200", source_table: "tb_pm200_conn", target_table: "tb_pm200_conn_daily", line_name: "CONN" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr1", target_table: "tb_pm200_cr1_daily", line_name: "CR1" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr2", target_table: "tb_pm200_cr2_daily", line_name: "CR2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr3", target_table: "tb_pm200_cr3_daily", line_name: "CR3" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr4", target_table: "tb_pm200_cr4_daily", line_name: "CR4" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr5", target_table: "tb_pm200_cr5_daily", line_name: "CR5" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr6", target_table: "tb_pm200_cr6_daily", line_name: "CR6" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr7", target_table: "tb_pm200_cr7_daily", line_name: "CR7" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr8", target_table: "tb_pm200_cr8_daily", line_name: "CR8" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr9", target_table: "tb_pm200_cr9_daily", line_name: "CR9" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr10", target_table: "tb_pm200_cr10_daily", line_name: "CR10" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr11", target_table: "tb_pm200_cr11_daily", line_name: "CR11" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr12", target_table: "tb_pm200_cr12_daily", line_name: "CR12" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ct", target_table: "tb_pm200_ct_daily", line_name: "CT" },
    { pm_type: "PM_200V", source_table: "tb_pm200_hla", target_table: "tb_pm200_hla_daily", line_name: "HLA" },
    { pm_type: "PM 200", source_table: "tb_pm200_ra", target_table: "tb_pm200_ra_daily", line_name: "RA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ret", target_table: "tb_pm200_ret_daily", line_name: "RET" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsab", target_table: "tb_pm200_chsab_daily", line_name: "CHSAB" },

    // PM 220
    { pm_type: "PM 220", source_table: "tb_pm220_bs1", target_table: "tb_pm220_bs1_daily", line_name: "BS1" },
    { pm_type: "PM 220", source_table: "tb_pm220_bs2", target_table: "tb_pm220_bs2_daily", line_name: "BS2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cc1", target_table: "tb_pm220_cc1_daily", line_name: "CC1" },
    { pm_type: "PM_220V", source_table: "tb_pm220_cc234", target_table: "tb_pm220_cc234_daily", line_name: "CC234" },
    { pm_type: "PM-220V", source_table: "tb_pm220_chab", target_table: "tb_pm220_chab_daily", line_name: "CHAB" },
    { pm_type: "PM-1F", source_table: "tb_pm220_chcd", target_table: "tb_pm220_chcd_daily", line_name: "CHCD" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chef", target_table: "tb_pm220_chef_daily", line_name: "CHEF" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsaa", target_table: "tb_pm220_chsaa_daily", line_name: "CHSAA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsac", target_table: "tb_pm220_chsac_daily", line_name: "CHSAC" },
    { pm_type: "PM 220", source_table: "tb_pm220_conn", target_table: "tb_pm220_conn_daily", line_name: "CONN" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr1", target_table: "tb_pm220_cr1_daily", line_name: "CR1" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr2", target_table: "tb_pm220_cr2_daily", line_name: "CR2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr3", target_table: "tb_pm220_cr3_daily", line_name: "CR3" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr4", target_table: "tb_pm220_cr4_daily", line_name: "CR4" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr5", target_table: "tb_pm220_cr5_daily", line_name: "CR5" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr6", target_table: "tb_pm220_cr6_daily", line_name: "CR6" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr7", target_table: "tb_pm220_cr7_daily", line_name: "CR7" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr8", target_table: "tb_pm220_cr8_daily", line_name: "CR8" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr9", target_table: "tb_pm220_cr9_daily", line_name: "CR9" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr10", target_table: "tb_pm220_cr10_daily", line_name: "CR10" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr11", target_table: "tb_pm220_cr11_daily", line_name: "CR11" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr12", target_table: "tb_pm220_cr12_daily", line_name: "CR12" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ct", target_table: "tb_pm220_ct_daily", line_name: "CT" },
    { pm_type: "PM 220", source_table: "tb_pm220_hla", target_table: "tb_pm220_hla_daily", line_name: "HLA" },
    { pm_type: "PM 220", source_table: "tb_pm220_ra", target_table: "tb_pm220_ra_daily", line_name: "RA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ret", target_table: "tb_pm220_ret_daily", line_name: "RET" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsab", target_table: "tb_pm220_chsab_daily", line_name: "CHSAB" },
];

async function rekapHarian() {
    const connection = await pool.getConnection();

    try {
        for (const line of lineTables) {
            console.log(`\n🔍 Proses Harian: ${line.source_table} -> ${line.target_table}`);

            const [tanggalUnik] = await connection.query(`
                SELECT DISTINCT DATE(date_time) AS tgl
                FROM ${line.source_table}
                WHERE date_time IS NOT NULL
                ORDER BY tgl
            `);

            for (const { tgl } of tanggalUnik) {
                const [awal] = await connection.query(`
                    SELECT date_time, value
                    FROM ${line.source_table}
                    WHERE DATE(date_time) = ?
                    ORDER BY date_time ASC
                    LIMIT 1
                `, [tgl]);

                const [akhir] = await connection.query(`
                    SELECT date_time, value
                    FROM ${line.source_table}
                    WHERE DATE(date_time) = ?
                    ORDER BY date_time DESC
                    LIMIT 1
                `, [tgl]);

                if (!awal.length || !akhir.length) {
                    console.log(`⚠️ Skip: ${line.target_table} | ${tgl} | data awal/akhir tidak lengkap`);
                    continue;
                }

                const startDatetime = awal[0].date_time;
                const endDatetime = akhir[0].date_time;

                const startKwh = parseFloat(awal[0].value);
                const endKwh = parseFloat(akhir[0].value);

                if (isNaN(startKwh) || isNaN(endKwh)) {
                    console.log(`⚠️ Skip: ${line.target_table} | ${tgl} | start/end kWh tidak valid`);
                    continue;
                }

                const totalKwh = endKwh - startKwh;

                if (totalKwh <= 0) {
                    console.log(`⚠️ Skip: ${line.target_table} | ${tgl} | total_kwh ${totalKwh} (negatif / 0)`);
                    continue;
                }

                const m = moment(startDatetime);
                const shiftDate = m.format("YYYY-MM-DD");
                const year = m.year();
                const month = m.month() + 1;
                const monthName = m.format("MMMM");
                const day = m.date();
                const dayName = m.format("dddd");
                const shift = "Daily";

                // Lebih baik simpan asal data dari tabel sumber
                const lineTableValue = line.source_table;

                await connection.query(`
                    INSERT INTO ${line.target_table} (
                        pm_type,
                        line_table,
                        line_name,
                        shift,
                        shift_date,
                        shift_start_datetime,
                        shift_end_datetime,
                        start_kwh,
                        end_kwh,
                        total_kwh,
                        year,
                        month,
                        month_name,
                        day,
                        day_name,
                        created_at,
                        updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                    ON DUPLICATE KEY UPDATE
                        line_name = VALUES(line_name),
                        shift_start_datetime = VALUES(shift_start_datetime),
                        shift_end_datetime = VALUES(shift_end_datetime),
                        start_kwh = VALUES(start_kwh),
                        end_kwh = VALUES(end_kwh),
                        total_kwh = VALUES(total_kwh),
                        year = VALUES(year),
                        month = VALUES(month),
                        month_name = VALUES(month_name),
                        day = VALUES(day),
                        day_name = VALUES(day_name),
                        updated_at = NOW()
                `, [
                    line.pm_type,
                    lineTableValue,
                    line.line_name,
                    shift,
                    shiftDate,
                    startDatetime,
                    endDatetime,
                    startKwh,
                    endKwh,
                    totalKwh,
                    year,
                    month,
                    monthName,
                    day,
                    dayName
                ]);

                console.log(`✅ Upsert: ${line.target_table} | ${shiftDate} | ${totalKwh} kWh`);
            }
        }

        console.log("\n🎉 Rekap harian selesai.");
    } catch (err) {
        console.error("❌ Error rekap harian:", err);
    } finally {
        connection.release();
    }
}

rekapHarian();