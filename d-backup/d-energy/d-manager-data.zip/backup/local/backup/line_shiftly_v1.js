const pool = require("../../../config/db_core");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
    // PM 200
    { pm_type: "PM 200", source_table: "tb_pm200_bs1", target_table: "tb_pm200_bs1_weekly", line_name: "BS1" },
    { pm_type: "PM 200", source_table: "tb_pm200_bs2", target_table: "tb_pm200_bs2_weekly", line_name: "BS2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cc1", target_table: "tb_pm200_cc1_weekly", line_name: "CC1" },
    { pm_type: "PM_200V", source_table: "tb_pm200_cc234", target_table: "tb_pm200_cc234_weekly", line_name: "CC234" },
    { pm_type: "PM-200V", source_table: "tb_pm200_chab", target_table: "tb_pm200_chab_weekly", line_name: "CHAB" },
    { pm_type: "PM-3F", source_table: "tb_pm200_chcd", target_table: "tb_pm200_chcd_weekly", line_name: "CHCD" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chef", target_table: "tb_pm200_chef_weekly", line_name: "CHEF" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsaa", target_table: "tb_pm200_chsaa_weekly", line_name: "CHSAA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsac", target_table: "tb_pm200_chsac_weekly", line_name: "CHSAC" },
    { pm_type: "PM 200", source_table: "tb_pm200_conn", target_table: "tb_pm200_conn_weekly", line_name: "CONN" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr1", target_table: "tb_pm200_cr1_weekly", line_name: "CR1" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr2", target_table: "tb_pm200_cr2_weekly", line_name: "CR2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr3", target_table: "tb_pm200_cr3_weekly", line_name: "CR3" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr4", target_table: "tb_pm200_cr4_weekly", line_name: "CR4" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr5", target_table: "tb_pm200_cr5_weekly", line_name: "CR5" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr6", target_table: "tb_pm200_cr6_weekly", line_name: "CR6" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr7", target_table: "tb_pm200_cr7_weekly", line_name: "CR7" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr8", target_table: "tb_pm200_cr8_weekly", line_name: "CR8" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr9", target_table: "tb_pm200_cr9_weekly", line_name: "CR9" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr10", target_table: "tb_pm200_cr10_weekly", line_name: "CR10" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr11", target_table: "tb_pm200_cr11_weekly", line_name: "CR11" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr12", target_table: "tb_pm200_cr12_weekly", line_name: "CR12" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ct", target_table: "tb_pm200_ct_weekly", line_name: "CT" },
    { pm_type: "PM_200V", source_table: "tb_pm200_hla", target_table: "tb_pm200_hla_weekly", line_name: "HLA" },
    { pm_type: "PM 200", source_table: "tb_pm200_ra", target_table: "tb_pm200_ra_weekly", line_name: "RA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ret", target_table: "tb_pm200_ret_weekly", line_name: "RET" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsab", target_table: "tb_pm200_chsab_weekly", line_name: "CHSAB" },

    // PM 220
    { pm_type: "PM 220", source_table: "tb_pm220_bs1", target_table: "tb_pm220_bs1_weekly", line_name: "BS1" },
    { pm_type: "PM 220", source_table: "tb_pm220_bs2", target_table: "tb_pm220_bs2_weekly", line_name: "BS2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cc1", target_table: "tb_pm220_cc1_weekly", line_name: "CC1" },
    { pm_type: "PM_220V", source_table: "tb_pm220_cc234", target_table: "tb_pm220_cc234_weekly", line_name: "CC234" },
    { pm_type: "PM-220V", source_table: "tb_pm220_chab", target_table: "tb_pm220_chab_weekly", line_name: "CHAB" },
    { pm_type: "PM-1F", source_table: "tb_pm220_chcd", target_table: "tb_pm220_chcd_weekly", line_name: "CHCD" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chef", target_table: "tb_pm220_chef_weekly", line_name: "CHEF" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsaa", target_table: "tb_pm220_chsaa_weekly", line_name: "CHSAA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsac", target_table: "tb_pm220_chsac_weekly", line_name: "CHSAC" },
    { pm_type: "PM 220", source_table: "tb_pm220_conn", target_table: "tb_pm220_conn_weekly", line_name: "CONN" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr1", target_table: "tb_pm220_cr1_weekly", line_name: "CR1" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr2", target_table: "tb_pm220_cr2_weekly", line_name: "CR2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr3", target_table: "tb_pm220_cr3_weekly", line_name: "CR3" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr4", target_table: "tb_pm220_cr4_weekly", line_name: "CR4" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr5", target_table: "tb_pm220_cr5_weekly", line_name: "CR5" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr6", target_table: "tb_pm220_cr6_weekly", line_name: "CR6" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr7", target_table: "tb_pm220_cr7_weekly", line_name: "CR7" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr8", target_table: "tb_pm220_cr8_weekly", line_name: "CR8" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr9", target_table: "tb_pm220_cr9_weekly", line_name: "CR9" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr10", target_table: "tb_pm220_cr10_weekly", line_name: "CR10" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr11", target_table: "tb_pm220_cr11_weekly", line_name: "CR11" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr12", target_table: "tb_pm220_cr12_weekly", line_name: "CR12" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ct", target_table: "tb_pm220_ct_weekly", line_name: "CT" },
    { pm_type: "PM 220", source_table: "tb_pm220_hla", target_table: "tb_pm220_hla_weekly", line_name: "HLA" },
    { pm_type: "PM 220", source_table: "tb_pm220_ra", target_table: "tb_pm220_ra_weekly", line_name: "RA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ret", target_table: "tb_pm220_ret_weekly", line_name: "RET" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsab", target_table: "tb_pm220_chsab_weekly", line_name: "CHSAB" },
];

function getIsoWeekRange(year, week) {
    const start = moment().isoWeekYear(year).isoWeek(week).startOf("isoWeek");
    const end = start.clone().add(1, "week");
    return { start, end };
}

async function getWeeklyData(connection, tableName, startTime, endTime) {
    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
        ORDER BY date_time ASC
        LIMIT 1
    `, [
        startTime.format("YYYY-MM-DD HH:mm:ss"),
        endTime.format("YYYY-MM-DD HH:mm:ss")
    ]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
        ORDER BY date_time DESC
        LIMIT 1
    `, [
        startTime.format("YYYY-MM-DD HH:mm:ss"),
        endTime.format("YYYY-MM-DD HH:mm:ss")
    ]);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = parseFloat(startRow[0].value);
    const endValue = parseFloat(endRow[0].value);

    if (isNaN(startValue) || isNaN(endValue)) {
        return null;
    }

    const totalValue = endValue - startValue;

    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: startRow[0].date_time,
        endDatetime: endRow[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertWeeklyToTable(connection, line, data) {
    await connection.query(`
        INSERT INTO ${line.target_table} (
            pm_type,
            line_table,
            line_name,
            week,
            week_start_date,
            week_end_date,
            week_start_datetime,
            week_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            line_name = VALUES(line_name),
            week_start_date = VALUES(week_start_date),
            week_end_date = VALUES(week_end_date),
            week_start_datetime = VALUES(week_start_datetime),
            week_end_datetime = VALUES(week_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            month = VALUES(month),
            month_name = VALUES(month_name),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.week,
        data.week_start_date,
        data.week_end_date,
        data.week_start_datetime,
        data.week_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name
    ]);

    console.log(`✅ Upsert Weekly: ${line.target_table} | ${data.year}-W${String(data.week).padStart(2, "0")} | ${data.total_kwh} kWh`);
}

async function rekapWeekly() {
    const connection = await pool.getConnection();

    try {
        for (const line of lineTables) {
            console.log(`\n🔍 Proses Weekly: ${line.source_table} -> ${line.target_table}`);

            const [weeks] = await connection.query(`
                SELECT DISTINCT
                    YEARWEEK(date_time, 3) AS yearweek_num
                FROM ${line.source_table}
                WHERE date_time IS NOT NULL
                ORDER BY yearweek_num
            `);

            for (const { yearweek_num } of weeks) {
                const yearNum = Math.floor(yearweek_num / 100);
                const weekNum = yearweek_num % 100;

                const { start, end } = getIsoWeekRange(yearNum, weekNum);

                const data = await getWeeklyData(connection, line.source_table, start, end);

                if (!data) {
                    console.log(`⚠️ Skip Weekly: ${line.target_table} | ${yearNum}-W${String(weekNum).padStart(2, "0")} | invalid / 0 / negatif`);
                    continue;
                }

                await upsertWeeklyToTable(connection, line, {
                    week: weekNum,
                    week_start_date: start.format("YYYY-MM-DD"),
                    week_end_date: end.clone().subtract(1, "day").format("YYYY-MM-DD"),
                    week_start_datetime: data.startDatetime,
                    week_end_datetime: data.endDatetime,
                    start_kwh: data.startValue,
                    end_kwh: data.endValue,
                    total_kwh: data.totalValue,
                    year: yearNum,
                    month: start.month() + 1,
                    month_name: start.format("MMMM")
                });
            }
        }

        console.log("\n🎉 Rekap weekly selesai.");
    } catch (err) {
        console.error("❌ Error rekap weekly:", err);
    } finally {
        connection.release();
    }
}

rekapWeekly();