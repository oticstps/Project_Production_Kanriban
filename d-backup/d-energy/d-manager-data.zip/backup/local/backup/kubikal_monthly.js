const pool = require("../../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
  { pm_type: "DA_01", line_table: "tb_kub1_total_kwh", line_name: "kubikal_1" },
];

function toNumber(value) {
  if (value === null || value === undefined) return null;

  const cleaned = String(value).replace(/,/g, "").trim();
  const num = Number(cleaned);

  return Number.isFinite(num) ? num : null;
}

async function rekapBulanan() {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    for (const line of lineTables) {
      console.log(`\n🔍 Proses: ${line.line_table}`);

      const [periode] = await connection.query(`
        SELECT DISTINCT
          YEAR(date_time) AS year_num,
          MONTH(date_time) AS month_num
        FROM ${line.line_table}
        WHERE date_time IS NOT NULL
        ORDER BY year_num ASC, month_num ASC
      `);

      for (const { year_num, month_num } of periode) {
        const baseDate = moment({
          year: Number(year_num),
          month: Number(month_num) - 1,
          date: 1,
        });

        const monthName = baseDate.format("MMMM");
        const yearStr = String(year_num);

        const [awal] = await connection.query(
          `
            SELECT date_time, value
            FROM ${line.line_table}
            WHERE YEAR(date_time) = ? AND MONTH(date_time) = ?
            ORDER BY date_time ASC
            LIMIT 1
          `,
          [year_num, month_num]
        );

        const [akhir] = await connection.query(
          `
            SELECT date_time, value
            FROM ${line.line_table}
            WHERE YEAR(date_time) = ? AND MONTH(date_time) = ?
            ORDER BY date_time DESC
            LIMIT 1
          `,
          [year_num, month_num]
        );

        if (!awal.length || !akhir.length) {
          console.log(`⏭️ Lewati ${monthName} ${yearStr} (data tidak lengkap)`);
          continue;
        }

        const startDatetime = awal[0].date_time;
        const endDatetime = akhir[0].date_time;

        const startWhNum = toNumber(awal[0].value);
        const lastWhNum = toNumber(akhir[0].value);

        if (startWhNum === null || lastWhNum === null) {
          console.log(`⚠️ Nilai tidak valid pada ${monthName} ${yearStr}`);
          continue;
        }

        const totalWhNum = Number((lastWhNum - startWhNum).toFixed(3));

        const startWh = String(startWhNum);
        const lastWh = String(lastWhNum);
        const totalWh = String(totalWhNum);

        await connection.query(
          `
            INSERT INTO tb_pm_monthly_kub_report (
              pm_type,
              line_table,
              line_name,
              start_datetime,
              end_datetime,
              start_wh,
              last_wh,
              total_wh,
              month,
              year,
              created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE
              line_name = VALUES(line_name),
              start_datetime = VALUES(start_datetime),
              end_datetime = VALUES(end_datetime),
              start_wh = VALUES(start_wh),
              last_wh = VALUES(last_wh),
              total_wh = VALUES(total_wh)
          `,
          [
            line.pm_type,
            line.line_table,
            line.line_name,
            startDatetime,
            endDatetime,
            startWh,
            lastWh,
            totalWh,
            monthName,
            yearStr,
          ]
        );

        console.log(`✅ Upsert: ${monthName} ${yearStr} (${totalWh} Wh)`);
      }
    }

    await connection.commit();
    console.log("\n🎉 Rekap bulanan selesai tanpa duplikasi.");
  } catch (err) {
    await connection.rollback();
    console.error("❌ Error:", err);
    throw err;
  } finally {
    connection.release();
  }
}

async function runRekapBulanan() {
  try {
    await rekapBulanan();
    console.log("✅ Program selesai dijalankan");
    process.exit(0);
  } catch (error) {
    console.error("❌ Program gagal:", error);
    process.exit(1);
  }
}

if (require.main === module) {
  runRekapBulanan();
}

module.exports = { rekapBulanan };