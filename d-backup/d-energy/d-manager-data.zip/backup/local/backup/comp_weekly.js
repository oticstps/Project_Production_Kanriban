const pool = require("../../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");
// moment.locale("id");

const panelTables = [
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_panel_24_energy_vah_wh",
    target_table: "tb_panel_24_energy_vah_wh_weekly",
    line_name: "PANEL 24",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_panel_21_energy_vah_wh",
    target_table: "tb_panel_21_energy_vah_wh_weekly",
    line_name: "PANEL 21",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_panel_19_energy_vah_wh",
    target_table: "tb_panel_19_energy_vah_wh_weekly",
    line_name: "PANEL 19",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_kub_panel_20_wh",
    target_table: "tb_kub_panel_20_wh_weekly",
    line_name: "PANEL 20",
  },
];

function toNumber(value) {
  if (value === null || value === undefined) return NaN;
  return parseFloat(String(value).replace(/,/g, "").trim());
}

async function getDistinctDates(connection, tableName) {
  const [rows] = await connection.query(`
    SELECT DISTINCT DATE(date_time) AS period_date
    FROM ${tableName}
    WHERE date_time IS NOT NULL
    ORDER BY period_date ASC
  `);

  return rows.map((row) => moment(row.period_date).format("YYYY-MM-DD"));
}

async function getRangeData(connection, tableName, startTime, endTime) {
  const [startRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time ASC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  const [endRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time DESC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  if (!startRow.length || !endRow.length) {
    return null;
  }

  const startValue = toNumber(startRow[0].wh_value);
  const endValue = toNumber(endRow[0].wh_value);

  if (Number.isNaN(startValue) || Number.isNaN(endValue)) {
    return null;
  }

  const totalValue = endValue - startValue;

  if (totalValue <= 0) {
    return null;
  }

  return {
    startDatetime: moment(startRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    endDatetime: moment(endRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    startValue,
    endValue,
    totalValue,
  };
}

function buildWeeklyPeriods(dateStrings) {
  const map = new Map();

  for (const dateStr of dateStrings) {
    const m = moment(dateStr);
    const isoYear = m.isoWeekYear();
    const isoWeek = m.isoWeek();
    const key = `${isoYear}-${isoWeek}`;

    if (!map.has(key)) {
      const weekStart = m.clone().startOf("isoWeek");
      const weekEnd = weekStart.clone().add(6, "days");
      const nextWeekStart = weekStart.clone().add(1, "week");

      map.set(key, {
        year: isoYear,
        week: isoWeek,
        month: weekStart.month() + 1,
        month_name: weekStart.format("MMMM"),
        week_start_date: weekStart.format("YYYY-MM-DD"),
        week_end_date: weekEnd.format("YYYY-MM-DD"),
        range_start: weekStart.clone().startOf("day"),
        range_end: nextWeekStart.clone().startOf("day"),
      });
    }
  }

  return Array.from(map.values()).sort(
    (a, b) => a.range_start.valueOf() - b.range_start.valueOf()
  );
}

async function upsertWeeklyToTable(connection, line, data) {
  await connection.query(
    `
    INSERT INTO ${line.target_table} (
      pm_type,
      line_table,
      line_name,
      week,
      week_start_date,
      week_end_date,
      week_start_datetime,
      week_end_datetime,
      start_kwh,
      end_kwh,
      total_kwh,
      year,
      month,
      month_name,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      line_name = VALUES(line_name),
      week_start_date = VALUES(week_start_date),
      week_end_date = VALUES(week_end_date),
      week_start_datetime = VALUES(week_start_datetime),
      week_end_datetime = VALUES(week_end_datetime),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      month = VALUES(month),
      month_name = VALUES(month_name),
      updated_at = NOW()
    `,
    [
      line.pm_type,
      line.source_table,
      line.line_name,
      data.week,
      data.week_start_date,
      data.week_end_date,
      data.week_start_datetime,
      data.week_end_datetime,
      data.start_kwh,
      data.end_kwh,
      data.total_kwh,
      data.year,
      data.month,
      data.month_name,
    ]
  );

  console.log(
    `✅ Upsert: ${line.target_table} | year ${data.year} week ${data.week} | ${data.total_kwh.toFixed(3)} kWh`
  );
}

async function rekapWeekly() {
  const connection = await pool.getConnection();

  try {
    for (const line of panelTables) {
      console.log(`\n🔍 Proses Weekly: ${line.source_table} -> ${line.target_table}`);

      const dates = await getDistinctDates(connection, line.source_table);
      const weeklyPeriods = buildWeeklyPeriods(dates);

      for (const period of weeklyPeriods) {
        const weeklyData = await getRangeData(
          connection,
          line.source_table,
          period.range_start,
          period.range_end
        );

        if (weeklyData) {
          await upsertWeeklyToTable(connection, line, {
            week: period.week,
            week_start_date: period.week_start_date,
            week_end_date: period.week_end_date,
            week_start_datetime: weeklyData.startDatetime,
            week_end_datetime: weeklyData.endDatetime,
            start_kwh: weeklyData.startValue,
            end_kwh: weeklyData.endValue,
            total_kwh: weeklyData.totalValue,
            year: period.year,
            month: period.month,
            month_name: period.month_name,
          });
        } else {
          console.log(
            `⚠️ Skip: ${line.target_table} | year ${period.year} week ${period.week} | invalid / 0 / negatif`
          );
        }
      }
    }

    console.log("\n🎉 Rekap weekly panel compressor selesai.");
  } catch (err) {
    console.error("❌ Error rekap weekly:", err);
  } finally {
    connection.release();
  }
}

rekapWeekly();