const pool = require("../../../config/db_core");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");







const lineTables = [
    { pm_type: "DA_01", line_table: "tb_kub1_total_kwh", line_name: "kubikal_1" },
];
    













async function rekapMingguan() {
  const connection = await pool.getConnection();
  try {
    for (const line of lineTables) {
      console.log(`\n🔍 Proses: ${line.line_table}`);

      // Ambil semua kombinasi minggu dan tahun dari tabel sumber
      const [periode] = await connection.query(`
        SELECT DISTINCT 
          YEAR(date_time) as year,
          WEEK(date_time, 1) as week_number
        FROM ${line.line_table}
        WHERE date_time IS NOT NULL
        ORDER BY year, week_number;
      `);

      for (const { year, week_number } of periode) {
        // Ambil nilai awal dan akhir minggu
        const [awal] = await connection.query(`
          SELECT date_time, value
          FROM ${line.line_table}
          WHERE YEAR(date_time) = ? AND WEEK(date_time, 1) = ?
          ORDER BY date_time ASC
          LIMIT 1;
        `, [year, week_number]);

        const [akhir] = await connection.query(`
          SELECT date_time, value
          FROM ${line.line_table}
          WHERE YEAR(date_time) = ? AND WEEK(date_time, 1) = ?
          ORDER BY date_time DESC
          LIMIT 1;
        `, [year, week_number]);

        if (!awal.length || !akhir.length) continue;

        const startDatetime = awal[0].date_time;
        const endDatetime = akhir[0].date_time;
        const startWh = parseFloat(awal[0].value);
        const lastWh = parseFloat(akhir[0].value);
        const totalWh = lastWh - startWh;

        // Format nama minggu (contoh: "Week 12, 2024")
        const weekName = `Week ${week_number}, ${year}`;

        // Cek apakah data sudah ada di tb_pm_weekly_report berdasarkan kombinasi unik
        const [cek] = await connection.query(`
          SELECT * FROM tb_pm_weekly_report
          WHERE pm_type = ? AND line_table = ? AND year = ? AND week_number = ?;
        `, [line.pm_type, line.line_table, year, week_number]);

        if (cek.length === 0) {
          // INSERT jika belum ada
          await connection.query(`
            INSERT INTO tb_pm_weekly_report (
              pm_type, line_table, line_name,
              start_datetime, end_datetime,
              start_wh, last_wh, total_wh,
              year, week_number, week_name, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW());
          `, [
            line.pm_type,
            line.line_table,
            line.line_name,
            startDatetime,
            endDatetime,
            startWh,
            lastWh,
            totalWh,
            year,
            week_number,
            weekName,
          ]);
          console.log(`✅ Insert: ${weekName} (${totalWh} Wh)`);
        } else {
          // UPDATE berdasarkan kombinasi unik (asumsi primary key komposit)
          await connection.query(`
            UPDATE tb_pm_weekly_report
            SET start_datetime = ?, end_datetime = ?, 
                start_wh = ?, last_wh = ?, total_wh = ?, 
                week_name = ?, created_at = NOW()
            WHERE pm_type = ? AND line_table = ? AND year = ? AND week_number = ?;
          `, [
            startDatetime,
            endDatetime,
            startWh,
            lastWh,
            totalWh,
            weekName,
            line.pm_type,
            line.line_table,
            year,
            week_number
          ]);
          console.log(`♻️ Update: ${weekName} (${totalWh} Wh)`);
        }
      }
    }

    console.log("\n🎉 Rekap mingguan selesai tanpa duplikasi.");
  } catch (err) {
    console.error("❌ Error:", err);
  } finally {
    connection.release();
  }
}

rekapMingguan();