const pool = require("../../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

/**
 * REKAP SHIFTLY - INCREMENTAL UPDATE
 *
 * Default penggunaan:
 * 1. node rekap_shiftly_incremental_0720.js
 *    -> update 7 shift_date terakhir yang sudah selesai, lalu program selesai.
 *
 * 2. node rekap_shiftly_incremental_0720.js --schedule
 *    -> program tetap hidup dan menjalankan update otomatis setiap 07:20 WIB.
 *
 * 3. node rekap_shiftly_incremental_0720.js --current-month
 *    -> backfill bulan berjalan sampai shift_date kemarin.
 *
 * 4. node rekap_shiftly_incremental_0720.js --all
 *    -> backfill semua tanggal yang tersedia sampai shift_date kemarin.
 *
 * Konfigurasi opsional via environment variable:
 * - UPDATE_LOOKBACK_DAYS=7
 * - DAILY_HOUR=7
 * - DAILY_MINUTE=20
 */

const CONFIG = {
    timezone: "Asia/Jakarta",
    updateLookbackDays: Number(process.env.UPDATE_LOOKBACK_DAYS || 7),
    dailyHour: Number(process.env.DAILY_HOUR || 7),
    dailyMinute: Number(process.env.DAILY_MINUTE || 20)
};

const lineTables = [
    // PM 200
    { pm_type: "PM 200", source_table: "tb_pm200_bs1", target_table: "tb_pm200_bs1_shiftly", line_name: "BS1" },
    { pm_type: "PM 200", source_table: "tb_pm200_bs2", target_table: "tb_pm200_bs2_shiftly", line_name: "BS2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cc1", target_table: "tb_pm200_cc1_shiftly", line_name: "CC1" },
    { pm_type: "PM_200V", source_table: "tb_pm200_cc234", target_table: "tb_pm200_cc234_shiftly", line_name: "CC234" },
    { pm_type: "PM-200V", source_table: "tb_pm200_chab", target_table: "tb_pm200_chab_shiftly", line_name: "CHAB" },
    { pm_type: "PM-3F", source_table: "tb_pm200_chcd", target_table: "tb_pm200_chcd_shiftly", line_name: "CHCD" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chef", target_table: "tb_pm200_chef_shiftly", line_name: "CHEF" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsaa", target_table: "tb_pm200_chsaa_shiftly", line_name: "CHSAA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsac", target_table: "tb_pm200_chsac_shiftly", line_name: "CHSAC" },
    { pm_type: "PM 200", source_table: "tb_pm200_conn", target_table: "tb_pm200_conn_shiftly", line_name: "CONN" },

    { pm_type: "PM 200", source_table: "tb_pm200_cr1", target_table: "tb_pm200_cr1_shiftly", line_name: "CR1" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr2", target_table: "tb_pm200_cr2_shiftly", line_name: "CR2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr3", target_table: "tb_pm200_cr3_shiftly", line_name: "CR3" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr4", target_table: "tb_pm200_cr4_shiftly", line_name: "CR4" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr5", target_table: "tb_pm200_cr5_shiftly", line_name: "CR5" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr6", target_table: "tb_pm200_cr6_shiftly", line_name: "CR6" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr7", target_table: "tb_pm200_cr7_shiftly", line_name: "CR7" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr8", target_table: "tb_pm200_cr8_shiftly", line_name: "CR8" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr9", target_table: "tb_pm200_cr9_shiftly", line_name: "CR9" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr10", target_table: "tb_pm200_cr10_shiftly", line_name: "CR10" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr11", target_table: "tb_pm200_cr11_shiftly", line_name: "CR11" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr12", target_table: "tb_pm200_cr12_shiftly", line_name: "CR12" },

    { pm_type: "PM_200V", source_table: "tb_pm200_ct", target_table: "tb_pm200_ct_shiftly", line_name: "CT" },
    { pm_type: "PM_200V", source_table: "tb_pm200_hla", target_table: "tb_pm200_hla_shiftly", line_name: "HLA" },
    { pm_type: "PM 200", source_table: "tb_pm200_ra", target_table: "tb_pm200_ra_shiftly", line_name: "RA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ret", target_table: "tb_pm200_ret_shiftly", line_name: "RET" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsab", target_table: "tb_pm200_chsab_shiftly", line_name: "CHSAB" },

    // PM 220
    { pm_type: "PM 220", source_table: "tb_pm220_bs1", target_table: "tb_pm220_bs1_shiftly", line_name: "BS1" },
    { pm_type: "PM 220", source_table: "tb_pm220_bs2", target_table: "tb_pm220_bs2_shiftly", line_name: "BS2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cc1", target_table: "tb_pm220_cc1_shiftly", line_name: "CC1" },
    { pm_type: "PM_220V", source_table: "tb_pm220_cc234", target_table: "tb_pm220_cc234_shiftly", line_name: "CC234" },
    { pm_type: "PM-220V", source_table: "tb_pm220_chab", target_table: "tb_pm220_chab_shiftly", line_name: "CHAB" },
    { pm_type: "PM-1F", source_table: "tb_pm220_chcd", target_table: "tb_pm220_chcd_shiftly", line_name: "CHCD" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chef", target_table: "tb_pm220_chef_shiftly", line_name: "CHEF" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsaa", target_table: "tb_pm220_chsaa_shiftly", line_name: "CHSAA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsac", target_table: "tb_pm220_chsac_shiftly", line_name: "CHSAC" },
    { pm_type: "PM 220", source_table: "tb_pm220_conn", target_table: "tb_pm220_conn_shiftly", line_name: "CONN" },

    { pm_type: "PM 220", source_table: "tb_pm220_cr1", target_table: "tb_pm220_cr1_shiftly", line_name: "CR1" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr2", target_table: "tb_pm220_cr2_shiftly", line_name: "CR2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr3", target_table: "tb_pm220_cr3_shiftly", line_name: "CR3" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr4", target_table: "tb_pm220_cr4_shiftly", line_name: "CR4" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr5", target_table: "tb_pm220_cr5_shiftly", line_name: "CR5" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr6", target_table: "tb_pm220_cr6_shiftly", line_name: "CR6" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr7", target_table: "tb_pm220_cr7_shiftly", line_name: "CR7" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr8", target_table: "tb_pm220_cr8_shiftly", line_name: "CR8" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr9", target_table: "tb_pm220_cr9_shiftly", line_name: "CR9" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr10", target_table: "tb_pm220_cr10_shiftly", line_name: "CR10" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr11", target_table: "tb_pm220_cr11_shiftly", line_name: "CR11" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr12", target_table: "tb_pm220_cr12_shiftly", line_name: "CR12" },

    { pm_type: "PM_220V", source_table: "tb_pm220_ct", target_table: "tb_pm220_ct_shiftly", line_name: "CT" },
    { pm_type: "PM 220", source_table: "tb_pm220_hla", target_table: "tb_pm220_hla_shiftly", line_name: "HLA" },
    { pm_type: "PM 220", source_table: "tb_pm220_ra", target_table: "tb_pm220_ra_shiftly", line_name: "RA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ret", target_table: "tb_pm220_ret_shiftly", line_name: "RET" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsab", target_table: "tb_pm220_chsab_shiftly", line_name: "CHSAB" },
];

/**
 * Pengaman nama tabel agar query dinamis tidak rawan SQL injection.
 */
function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Invalid table name: ${identifier}`);
    }

    return `\`${identifier}\``;
}

/**
 * Format datetime agar aman masuk ke kolom DATETIME MySQL.
 */
function formatDateTime(value) {
    return moment(value).format("YYYY-MM-DD HH:mm:ss");
}

/**
 * Rentang pemrosesan shift_date.
 *
 * Catatan penting:
 * - Program sengaja mengecualikan shift_date hari ini.
 * - Alasannya, pada pukul 07:20 WIB shift hari ini belum lengkap.
 * - Shift_date terakhir yang aman diproses pada 07:20 adalah shift_date kemarin,
 *   karena shift_2 kemarin sudah berakhir pukul 07:10 hari ini.
 */
function getProcessingRange(mode = "last7") {
    const now = moment.tz(CONFIG.timezone);
    const todayStart = now.clone().startOf("day");
    const endDateExclusive = todayStart.clone();

    let startDate = null;
    let label = "ALL_AVAILABLE_UNTIL_YESTERDAY";

    if (mode === "current_month") {
        startDate = todayStart.clone().startOf("month");
        label = "CURRENT_MONTH_UNTIL_YESTERDAY";
    } else if (mode === "last7") {
        const days = Number.isFinite(CONFIG.updateLookbackDays) && CONFIG.updateLookbackDays > 0
            ? CONFIG.updateLookbackDays
            : 7;

        startDate = endDateExclusive.clone().subtract(days, "days");
        label = `LAST_${days}_COMPLETED_SHIFT_DATES`;
    } else if (mode === "all") {
        startDate = null;
        label = "ALL_AVAILABLE_UNTIL_YESTERDAY";
    } else {
        throw new Error(`Mode tidak dikenal: ${mode}. Gunakan last7, current_month, atau all.`);
    }

    return {
        mode,
        label,
        startDate,
        endDateExclusive,
        startDateString: startDate ? startDate.format("YYYY-MM-DD") : null,
        endDateExclusiveString: endDateExclusive.format("YYYY-MM-DD")
    };
}

/**
 * Ambil data awal dan akhir berdasarkan rentang waktu shift.
 */
async function getShiftData(connection, tableName, startTime, endTime) {
    const safeTable = escapeIdentifier(tableName);

    const startTimeString = startTime.format("YYYY-MM-DD HH:mm:ss");
    const endTimeString = endTime.format("YYYY-MM-DD HH:mm:ss");

    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time ASC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time DESC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = Number(startRow[0].value);
    const endValue = Number(endRow[0].value);

    if (!Number.isFinite(startValue) || !Number.isFinite(endValue)) {
        return null;
    }

    const totalValue = Number((endValue - startValue).toFixed(3));

    /**
     * Abaikan data anomali:
     * - total 0
     * - total negatif
     * - meter reset / nilai turun
     */
    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: formatDateTime(startRow[0].date_time),
        endDatetime: formatDateTime(endRow[0].date_time),
        startValue,
        endValue,
        totalValue
    };
}

/**
 * Insert atau update data shiftly.
 *
 * Syarat utama:
 * Setiap target_table wajib punya UNIQUE KEY:
 *
 * UNIQUE KEY uniq_line_shiftdate_shift (line_table, shift_date, shift)
 */
async function upsertShiftlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(`
        INSERT INTO ${safeTargetTable} (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_name = VALUES(line_name),
            shift_start_datetime = VALUES(shift_start_datetime),
            shift_end_datetime = VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.shift,
        data.shift_date,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name
    ]);

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | ${data.shift} | ${data.shift_date} | ${data.total_kwh} kWh`
    );
}

/**
 * Ambil daftar tanggal dari tabel sumber berdasarkan rentang proses.
 *
 * Perbaikan utama dari versi lama:
 * - Versi lama membaca semua DISTINCT DATE dari awal tabel.
 * - Versi baru hanya membaca tanggal dalam rentang yang diperlukan.
 */
async function getAvailableDates(connection, sourceTable, range) {
    const safeSourceTable = escapeIdentifier(sourceTable);

    const where = ["date_time IS NOT NULL"];
    const params = [];

    if (range.startDate) {
        where.push("date_time >= ?");
        params.push(`${range.startDate.format("YYYY-MM-DD")} 00:00:00`);
    }

    where.push("date_time < ?");
    params.push(`${range.endDateExclusive.format("YYYY-MM-DD")} 00:00:00`);

    const [rows] = await connection.query(`
        SELECT DISTINCT
            DATE_FORMAT(date_time, '%Y-%m-%d') AS shift_date
        FROM ${safeSourceTable}
        WHERE ${where.join(" AND ")}
        ORDER BY shift_date ASC
    `, params);

    return rows.map(row => row.shift_date);
}

/**
 * Proses satu line/tabel.
 */
async function processLine(connection, line, range) {
    console.log(`
🔍 Proses Shiftly: ${line.source_table} -> ${line.target_table}`);

    const availableDates = await getAvailableDates(connection, line.source_table, range);

    if (!availableDates.length) {
        console.log(
            `⚠️ Tidak ada data pada rentang ${range.startDateString || "awal data"} s.d. sebelum ${range.endDateExclusiveString} untuk tabel sumber: ${line.source_table}`
        );
        return { insertedOrUpdated: 0, skipped: 0 };
    }

    let insertedOrUpdated = 0;
    let skipped = 0;

    for (const shiftDate of availableDates) {
        const dateObj = moment.tz(shiftDate, "YYYY-MM-DD", CONFIG.timezone);

        const year = Number(dateObj.format("YYYY"));
        const month = Number(dateObj.format("M"));
        const day = Number(dateObj.format("D"));
        const monthName = dateObj.format("MMMM");
        const dayName = dateObj.format("dddd");

        /**
         * Shift 1:
         * 07:10 sampai 19:50 pada tanggal yang sama.
         */
        const shift1Start = moment.tz(shiftDate, "YYYY-MM-DD", CONFIG.timezone).set({
            hour: 7,
            minute: 10,
            second: 0,
            millisecond: 0
        });

        const shift1End = moment.tz(shiftDate, "YYYY-MM-DD", CONFIG.timezone).set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        /**
         * Shift 2:
         * 19:50 pada tanggal tersebut sampai 07:10 hari berikutnya.
         */
        const shift2Start = moment.tz(shiftDate, "YYYY-MM-DD", CONFIG.timezone).set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        const shift2End = moment.tz(shiftDate, "YYYY-MM-DD", CONFIG.timezone)
            .add(1, "day")
            .set({
                hour: 7,
                minute: 10,
                second: 0,
                millisecond: 0
            });

        const shift1Data = await getShiftData(
            connection,
            line.source_table,
            shift1Start,
            shift1End
        );

        if (shift1Data) {
            await upsertShiftlyToTable(connection, line, {
                shift: "shift_1",
                shift_date: shiftDate,
                shift_start_datetime: shift1Data.startDatetime,
                shift_end_datetime: shift1Data.endDatetime,
                start_kwh: shift1Data.startValue,
                end_kwh: shift1Data.endValue,
                total_kwh: shift1Data.totalValue,
                year,
                month,
                month_name: monthName,
                day,
                day_name: dayName
            });
            insertedOrUpdated += 1;
        } else {
            skipped += 1;
            console.log(
                `⚠️ Skip: ${line.target_table} | shift_1 | ${shiftDate} | data kosong / 0 / negatif`
            );
        }

        const shift2Data = await getShiftData(
            connection,
            line.source_table,
            shift2Start,
            shift2End
        );

        if (shift2Data) {
            await upsertShiftlyToTable(connection, line, {
                shift: "shift_2",
                shift_date: shiftDate,
                shift_start_datetime: shift2Data.startDatetime,
                shift_end_datetime: shift2Data.endDatetime,
                start_kwh: shift2Data.startValue,
                end_kwh: shift2Data.endValue,
                total_kwh: shift2Data.totalValue,
                year,
                month,
                month_name: monthName,
                day,
                day_name: dayName
            });
            insertedOrUpdated += 1;
        } else {
            skipped += 1;
            console.log(
                `⚠️ Skip: ${line.target_table} | shift_2 | ${shiftDate} | data kosong / 0 / negatif`
            );
        }
    }

    return { insertedOrUpdated, skipped };
}

/**
 * Program utama.
 */
async function rekapShiftly(mode = "last7") {
    const range = getProcessingRange(mode);
    const connection = await pool.getConnection();

    const summary = {
        mode: range.mode,
        rangeLabel: range.label,
        rangeStart: range.startDateString || "awal data",
        rangeEndExclusive: range.endDateExclusiveString,
        totalProcessed: 0,
        totalSkipped: 0,
        totalLineErrors: 0
    };

    try {
        console.log("🚀 Mulai rekap shiftly...");
        console.log("🔐 Mode: UPSERT aktif, tidak double insert jika UNIQUE KEY sudah benar.");
        console.log(`🗓️ Rentang proses: ${summary.rangeLabel}`);
        console.log(`📌 Shift_date diproses: ${summary.rangeStart} s.d. sebelum ${summary.rangeEndExclusive}`);
        console.log("📌 Catatan: shift_date hari ini tidak diproses agar tidak menyimpan data shift yang belum lengkap.");

        for (const line of lineTables) {
            try {
                const lineSummary = await processLine(connection, line, range);
                summary.totalProcessed += lineSummary.insertedOrUpdated;
                summary.totalSkipped += lineSummary.skipped;
            } catch (lineError) {
                summary.totalLineErrors += 1;
                console.error(
                    `❌ Error pada line ${line.source_table} -> ${line.target_table}:`,
                    lineError.message
                );
            }
        }

        console.log("\n🎉 Rekap shiftly selesai.");
        console.log(`📊 Total insert/update/no-change: ${summary.totalProcessed}`);
        console.log(`📊 Total skip: ${summary.totalSkipped}`);
        console.log(`📊 Total line error: ${summary.totalLineErrors}`);

        return summary;
    } catch (err) {
        console.error("❌ Error utama rekap shiftly:", err);
        throw err;
    } finally {
        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

let isJobRunning = false;

async function runJobSafely(mode = "last7") {
    if (isJobRunning) {
        console.log("⏳ Job sebelumnya masih berjalan. Eksekusi baru dilewati agar tidak overlap.");
        return null;
    }

    isJobRunning = true;

    try {
        return await rekapShiftly(mode);
    } finally {
        isJobRunning = false;
    }
}

function getNextDailyRun() {
    const now = moment.tz(CONFIG.timezone);
    const nextRun = now.clone().set({
        hour: CONFIG.dailyHour,
        minute: CONFIG.dailyMinute,
        second: 0,
        millisecond: 0
    });

    if (!nextRun.isAfter(now)) {
        nextRun.add(1, "day");
    }

    return nextRun;
}

function scheduleDailyRun() {
    const nextRun = getNextDailyRun();
    const delayMs = nextRun.diff(moment.tz(CONFIG.timezone));

    console.log(`🕒 Scheduler aktif. Eksekusi berikutnya: ${nextRun.format("YYYY-MM-DD HH:mm:ss")} WIB`);

    setTimeout(async () => {
        try {
            await runJobSafely("last7");
        } catch (err) {
            console.error("❌ Job scheduler gagal:", err.message);
        } finally {
            scheduleDailyRun();
        }
    }, delayMs);
}

function parseExecutionMode() {
    const args = process.argv.slice(2);

    if (args.includes("--schedule")) {
        return { type: "schedule", mode: "last7" };
    }

    if (args.includes("--current-month")) {
        return { type: "once", mode: "current_month" };
    }

    if (args.includes("--all")) {
        return { type: "once", mode: "all" };
    }

    return { type: "once", mode: "last7" };
}

async function main() {
    const execution = parseExecutionMode();

    if (execution.type === "schedule") {
        console.log("✅ Program berjalan dalam mode scheduler harian 07:20 WIB.");
        scheduleDailyRun();
        return;
    }

    await runJobSafely(execution.mode);
    console.log("✅ Program selesai.");
}

main().catch((err) => {
    console.error("❌ Program gagal:", err);
    process.exit(1);
});
