const pool = require("../../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");
// moment.locale("id");

const panelTables = [
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_panel_24_energy_vah_wh",
    target_table: "tb_panel_24_energy_vah_wh_daily",
    line_name: "PANEL 24",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_panel_21_energy_vah_wh",
    target_table: "tb_panel_21_energy_vah_wh_daily",
    line_name: "PANEL 21",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_panel_19_energy_vah_wh",
    target_table: "tb_panel_19_energy_vah_wh_daily",
    line_name: "PANEL 19",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_kub_panel_20_wh",
    target_table: "tb_kub_panel_20_wh_daily",
    line_name: "PANEL 20",
  },
];

function toNumber(value) {
  if (value === null || value === undefined) return NaN;
  return parseFloat(String(value).replace(/,/g, "").trim());
}

async function getDailyData(connection, tableName, startTime, endTime) {
  const [startRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time ASC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  const [endRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time DESC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  if (!startRow.length || !endRow.length) {
    return null;
  }

  const startValue = toNumber(startRow[0].wh_value);
  const endValue = toNumber(endRow[0].wh_value);

  if (Number.isNaN(startValue) || Number.isNaN(endValue)) {
    return null;
  }

  const totalValue = endValue - startValue;

  if (totalValue <= 0) {
    return null;
  }

  return {
    startDatetime: moment(startRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    endDatetime: moment(endRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    startValue,
    endValue,
    totalValue,
  };
}

async function upsertDailyToTable(connection, line, data) {
  await connection.query(
    `
    INSERT INTO ${line.target_table} (
      pm_type,
      line_table,
      line_name,
      shift,
      shift_date,
      shift_start_datetime,
      shift_end_datetime,
      start_kwh,
      end_kwh,
      total_kwh,
      year,
      month,
      month_name,
      day,
      day_name,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      line_name = VALUES(line_name),
      shift_start_datetime = VALUES(shift_start_datetime),
      shift_end_datetime = VALUES(shift_end_datetime),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      year = VALUES(year),
      month = VALUES(month),
      month_name = VALUES(month_name),
      day = VALUES(day),
      day_name = VALUES(day_name),
      updated_at = NOW()
    `,
    [
      line.pm_type,
      line.source_table,
      line.line_name,
      data.shift,
      data.shift_date,
      data.shift_start_datetime,
      data.shift_end_datetime,
      data.start_kwh,
      data.end_kwh,
      data.total_kwh,
      data.year,
      data.month,
      data.month_name,
      data.day,
      data.day_name,
    ]
  );

  console.log(
    `✅ Upsert: ${line.target_table} | ${data.shift_date} | ${data.total_kwh.toFixed(3)} kWh`
  );
}

async function rekapDaily() {
  const connection = await pool.getConnection();

  try {
    for (const line of panelTables) {
      console.log(`\n🔍 Proses Daily: ${line.source_table} -> ${line.target_table}`);

      const [periode] = await connection.query(
        `
        SELECT DISTINCT
          DATE(date_time) AS date_only,
          YEAR(date_time) AS year,
          MONTH(date_time) AS month,
          DAY(date_time) AS day
        FROM ${line.source_table}
        WHERE date_time IS NOT NULL
        ORDER BY date_only ASC
        `
      );

      for (const row of periode) {
        const dateStr = moment(row.date_only).format("YYYY-MM-DD");
        const dateObj = moment(dateStr);
        const dayName = dateObj.format("dddd");
        const monthName = dateObj.format("MMMM");

        const dayStart = dateObj.clone().startOf("day");
        const dayEnd = dateObj.clone().add(1, "day").startOf("day");

        const dailyData = await getDailyData(connection, line.source_table, dayStart, dayEnd);

        if (dailyData) {
          await upsertDailyToTable(connection, line, {
            shift: "daily",
            shift_date: dateStr,
            shift_start_datetime: dailyData.startDatetime,
            shift_end_datetime: dailyData.endDatetime,
            start_kwh: dailyData.startValue,
            end_kwh: dailyData.endValue,
            total_kwh: dailyData.totalValue,
            year: row.year,
            month: row.month,
            month_name: monthName,
            day: row.day,
            day_name: dayName,
          });
        } else {
          console.log(`⚠️ Skip: ${line.target_table} | ${dateStr} | invalid / 0 / negatif`);
        }
      }
    }

    console.log("\n🎉 Rekap daily panel compressor selesai.");
  } catch (err) {
    console.error("❌ Error rekap daily:", err);
  } finally {
    connection.release();
  }
}

rekapDaily();