CREATE TABLE tb_panel_24_energy_vah_wh_shiftly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_panel_24_energy_vah_wh_shiftly (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_21_energy_vah_wh_shiftly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_panel_21_energy_vah_wh_shiftly (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_19_energy_vah_wh_shiftly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_panel_19_energy_vah_wh_shiftly (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_kub_panel_20_wh_shiftly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_kub_panel_20_wh_shiftly (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;














CREATE TABLE tb_panel_24_energy_vah_wh_daily (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_panel_24_energy_vah_wh_daily (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_21_energy_vah_wh_daily (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_panel_21_energy_vah_wh_daily (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_19_energy_vah_wh_daily (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_panel_19_energy_vah_wh_daily (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_kub_panel_20_wh_daily (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_tb_kub_panel_20_wh_daily (line_table, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;











CREATE TABLE tb_panel_24_energy_vah_wh_weekly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    week INT(11) DEFAULT NULL,
    week_start_date DATE DEFAULT NULL,
    week_end_date DATE DEFAULT NULL,
    week_start_datetime DATETIME DEFAULT NULL,
    week_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_panel_24_energy_vah_wh_weekly (line_table, year, week),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_week (week),
    KEY idx_year (year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_21_energy_vah_wh_weekly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    week INT(11) DEFAULT NULL,
    week_start_date DATE DEFAULT NULL,
    week_end_date DATE DEFAULT NULL,
    week_start_datetime DATETIME DEFAULT NULL,
    week_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_panel_21_energy_vah_wh_weekly (line_table, year, week),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_week (week),
    KEY idx_year (year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_19_energy_vah_wh_weekly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    week INT(11) DEFAULT NULL,
    week_start_date DATE DEFAULT NULL,
    week_end_date DATE DEFAULT NULL,
    week_start_datetime DATETIME DEFAULT NULL,
    week_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_panel_19_energy_vah_wh_weekly (line_table, year, week),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_week (week),
    KEY idx_year (year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_kub_panel_20_wh_weekly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    week INT(11) DEFAULT NULL,
    week_start_date DATE DEFAULT NULL,
    week_end_date DATE DEFAULT NULL,
    week_start_datetime DATETIME DEFAULT NULL,
    week_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_kub_panel_20_wh_weekly (line_table, year, week),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_week (week),
    KEY idx_year (year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;






CREATE TABLE tb_panel_24_energy_vah_wh_monthly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    month_start_date DATE DEFAULT NULL,
    month_end_date DATE DEFAULT NULL,
    month_start_datetime DATETIME DEFAULT NULL,
    month_end_datetime DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_panel_24_energy_vah_wh_monthly (line_table, year, month),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_year (year),
    KEY idx_month (month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_21_energy_vah_wh_monthly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    month_start_date DATE DEFAULT NULL,
    month_end_date DATE DEFAULT NULL,
    month_start_datetime DATETIME DEFAULT NULL,
    month_end_datetime DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_panel_21_energy_vah_wh_monthly (line_table, year, month),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_year (year),
    KEY idx_month (month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_panel_19_energy_vah_wh_monthly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    month_start_date DATE DEFAULT NULL,
    month_end_date DATE DEFAULT NULL,
    month_start_datetime DATETIME DEFAULT NULL,
    month_end_datetime DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_panel_19_energy_vah_wh_monthly (line_table, year, month),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_year (year),
    KEY idx_month (month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE tb_kub_panel_20_wh_monthly (
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    start_kwh DECIMAL(15,3) DEFAULT NULL,
    end_kwh DECIMAL(15,3) DEFAULT NULL,
    total_kwh DECIMAL(15,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    month_start_date DATE DEFAULT NULL,
    month_end_date DATE DEFAULT NULL,
    month_start_datetime DATETIME DEFAULT NULL,
    month_end_datetime DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_tb_kub_panel_20_wh_monthly (line_table, year, month),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_year (year),
    KEY idx_month (month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
















CREATE TABLE IF NOT EXISTS tb_kub1_shiftly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    shift VARCHAR(20) DEFAULT NULL,
    shift_date DATE DEFAULT NULL,
    shift_start_datetime DATETIME DEFAULT NULL,
    shift_end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(18,3) DEFAULT NULL,
    end_kwh DECIMAL(18,3) DEFAULT NULL,
    total_kwh DECIMAL(18,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_kub1_shiftly (line_table, line_name, shift, shift_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_shift (shift),
    KEY idx_shift_date (shift_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE IF NOT EXISTS tb_kub1_daily (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    record_date DATE DEFAULT NULL,
    start_datetime DATETIME DEFAULT NULL,
    end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(18,3) DEFAULT NULL,
    end_kwh DECIMAL(18,3) DEFAULT NULL,
    total_kwh DECIMAL(18,3) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    day INT(11) DEFAULT NULL,
    day_name VARCHAR(20) DEFAULT NULL,
    week INT(11) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_kub1_daily (line_table, line_name, record_date),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_record_date (record_date),
    KEY idx_year_month (year, month),
    KEY idx_week (week)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE IF NOT EXISTS tb_kub1_weekly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    week INT(11) DEFAULT NULL,
    week_start_date DATE DEFAULT NULL,
    week_end_date DATE DEFAULT NULL,
    start_datetime DATETIME DEFAULT NULL,
    end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(18,3) DEFAULT NULL,
    end_kwh DECIMAL(18,3) DEFAULT NULL,
    total_kwh DECIMAL(18,3) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_kub1_weekly (line_table, line_name, year, week),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_year_week (year, week),
    KEY idx_week_start_date (week_start_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE IF NOT EXISTS tb_kub1_monthly (
    idPrimary INT(11) NOT NULL AUTO_INCREMENT,
    pm_type VARCHAR(50) DEFAULT NULL,
    line_table VARCHAR(100) DEFAULT NULL,
    line_name VARCHAR(100) DEFAULT NULL,
    year INT(11) DEFAULT NULL,
    month INT(11) DEFAULT NULL,
    month_name VARCHAR(20) DEFAULT NULL,
    month_start_date DATE DEFAULT NULL,
    month_end_date DATE DEFAULT NULL,
    start_datetime DATETIME DEFAULT NULL,
    end_datetime DATETIME DEFAULT NULL,
    start_kwh DECIMAL(18,3) DEFAULT NULL,
    end_kwh DECIMAL(18,3) DEFAULT NULL,
    total_kwh DECIMAL(18,3) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (idPrimary),
    UNIQUE KEY uq_kub1_monthly (line_table, line_name, year, month),
    KEY idx_pm_type (pm_type),
    KEY idx_line_table (line_table),
    KEY idx_year_month (year, month),
    KEY idx_month_start_date (month_start_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
