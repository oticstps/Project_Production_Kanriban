const pool = require("../../../config/db_core");
const moment = require("moment-timezone");

const TIMEZONE = "Asia/Jakarta";
const REPORT_TABLE = "tb_pm_shiftly_kub_report";

/**
 * Jumlah hari terakhir yang tetap diperiksa ulang.
 *
 * Tujuan:
 * - memperbarui data yang terlambat masuk;
 * - memperbaiki data beberapa hari terakhir;
 * - menghindari pembacaan seluruh histori pada setiap eksekusi.
 *
 * Contoh:
 * REFRESH_DAYS = 3
 * berarti laporan 3 hari terakhir tetap dihitung ulang.
 */
const REFRESH_DAYS = 3;

/**
 * Batas toleransi pencarian data di sekitar jam pergantian shift.
 *
 * Contoh:
 * Jika shift dimulai pukul 07:10, program mencari pembacaan meter
 * yang paling dekat dengan pukul 07:10 dalam rentang ±10 menit.
 */
const BOUNDARY_TOLERANCE_MINUTES = 10;

moment.tz.setDefault(TIMEZONE);
moment.locale("en");

/**
 * Daftar tabel sumber yang akan diproses.
 *
 * value_divisor:
 * - gunakan 1 jika value sumber sudah sesuai dengan satuan laporan;
 * - gunakan 1000 jika value sumber masih Wh dan laporan ingin disimpan dalam KWH;
 * - sesuaikan kembali dengan spesifikasi power meter Anda.
 */
const lineTables = [
  {
    pm_type: "DA_01",
    line_table: "tb_kub1_total_kwh",
    line_name: "kubikal_1",
    value_divisor: 1,
  },
];

/**
 * Memastikan nama tabel aman sebelum dimasukkan ke query.
 *
 * Parameter query (?) tidak dapat digunakan untuk nama tabel.
 * Karena itu, nama tabel dibatasi hanya menggunakan huruf,
 * angka, dan underscore.
 */
function quoteIdentifier(identifier) {
  if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
    throw new Error(`Nama tabel tidak valid: ${identifier}`);
  }

  return `\`${identifier}\``;
}

/**
 * Mengubah value varchar menjadi angka.
 *
 * Contoh:
 * "23,239,417,235" menjadi 23239417235
 * "23239417235" menjadi 23239417235
 */
function toNumber(value) {
  if (value === null || value === undefined) {
    return null;
  }

  const cleaned = String(value).replace(/,/g, "").trim();

  if (!cleaned) {
    return null;
  }

  const numberValue = Number(cleaned);

  return Number.isFinite(numberValue) ? numberValue : null;
}

/**
 * Membatasi angka desimal agar konsisten saat disimpan.
 */
function roundNumber(value, decimalPlaces = 3) {
  return Number(Number(value).toFixed(decimalPlaces));
}

/**
 * Menentukan tanggal shift terbaru yang aman diproses.
 *
 * Shift kedua berakhir pukul 07:10 pada hari berikutnya.
 *
 * Jika script dijalankan:
 * - sesudah atau tepat pukul 07:10, proses maksimal tanggal kemarin;
 * - sebelum pukul 07:10, proses maksimal dua hari sebelumnya.
 */
function getLatestEligibleShiftDate() {
  const now = moment.tz(TIMEZONE);
  const shiftTwoEndToday = now
    .clone()
    .startOf("day")
    .hour(7)
    .minute(10)
    .second(0)
    .millisecond(0);

  if (now.isSameOrAfter(shiftTwoEndToday)) {
    return now.clone().subtract(1, "day").startOf("day");
  }

  return now.clone().subtract(2, "days").startOf("day");
}

/**
 * Mengambil tanggal paling awal yang tersedia pada tabel sumber
 * untuk power meter tertentu.
 */
async function getEarliestSourceDate(connection, line) {
  const sourceTable = quoteIdentifier(line.line_table);

  const [rows] = await connection.query(
    `
      SELECT
        DATE_FORMAT(MIN(date_time), '%Y-%m-%d') AS earliest_date
      FROM ${sourceTable}
      WHERE power_meter = ?
        AND date_time IS NOT NULL
        AND value IS NOT NULL
    `,
    [line.pm_type]
  );

  if (!rows.length || !rows[0].earliest_date) {
    return null;
  }

  return moment.tz(rows[0].earliest_date, "YYYY-MM-DD", TIMEZONE);
}

/**
 * Mengambil daftar rekap yang sudah tersimpan.
 *
 * Set digunakan agar proses pengecekan lebih cepat:
 * YYYY-MM-DD|shift_1
 * YYYY-MM-DD|shift_2
 */
async function getExistingShiftKeys(connection, line, startDate, endDate) {
  const reportTable = quoteIdentifier(REPORT_TABLE);

  const [rows] = await connection.query(
    `
      SELECT
        DATE_FORMAT(shift_date, '%Y-%m-%d') AS shift_date,
        shift
      FROM ${reportTable}
      WHERE pm_type = ?
        AND line_table = ?
        AND shift_date >= ?
        AND shift_date <= ?
    `,
    [
      line.pm_type,
      line.line_table,
      startDate.format("YYYY-MM-DD"),
      endDate.format("YYYY-MM-DD"),
    ]
  );

  const keys = new Set();

  for (const row of rows) {
    keys.add(`${row.shift_date}|${row.shift}`);
  }

  return keys;
}

/**
 * Menentukan tanggal yang perlu diproses.
 *
 * Aturan:
 * 1. Jika laporan shift_1 atau shift_2 belum ada, tanggal diproses.
 * 2. Beberapa hari terakhir tetap dihitung ulang.
 *
 * Dengan pola ini:
 * - proses pertama melakukan backfill;
 * - proses berikutnya lebih ringan;
 * - data yang terlambat masuk tetap dapat diperbaiki.
 */
async function getCandidateDates(connection, line, earliestDate, latestDate) {
  const existingKeys = await getExistingShiftKeys(
    connection,
    line,
    earliestDate,
    latestDate
  );

  const refreshStartDate = latestDate
    .clone()
    .subtract(REFRESH_DAYS - 1, "days")
    .startOf("day");

  const candidateDates = [];
  const cursor = earliestDate.clone().startOf("day");

  while (cursor.isSameOrBefore(latestDate, "day")) {
    const dateString = cursor.format("YYYY-MM-DD");

    const hasShiftOne = existingKeys.has(`${dateString}|shift_1`);
    const hasShiftTwo = existingKeys.has(`${dateString}|shift_2`);

    const isRecentDate = cursor.isSameOrAfter(refreshStartDate, "day");
    const isIncomplete = !hasShiftOne || !hasShiftTwo;

    if (isRecentDate || isIncomplete) {
      candidateDates.push(cursor.clone());
    }

    cursor.add(1, "day");
  }

  return candidateDates;
}

/**
 * Mengambil data pembacaan meter yang paling dekat
 * dengan jam batas shift.
 *
 * Program tidak mengambil sembarang data pertama atau terakhir.
 * Program mencari nilai terdekat dengan waktu target.
 *
 * Contoh:
 * Waktu target 07:10:00
 * Data tersedia 07:09:58 dan 07:10:18
 * Program memilih data yang jaraknya paling dekat.
 */
async function getClosestReading(connection, line, boundaryTime) {
  const sourceTable = quoteIdentifier(line.line_table);

  const rangeStart = boundaryTime
    .clone()
    .subtract(BOUNDARY_TOLERANCE_MINUTES, "minutes")
    .format("YYYY-MM-DD HH:mm:ss");

  const rangeEnd = boundaryTime
    .clone()
    .add(BOUNDARY_TOLERANCE_MINUTES, "minutes")
    .format("YYYY-MM-DD HH:mm:ss");

  const boundaryString = boundaryTime.format("YYYY-MM-DD HH:mm:ss");

  const [rows] = await connection.query(
    `
      SELECT
        idPrimary,
        date_time,
        value
      FROM ${sourceTable}
      WHERE power_meter = ?
        AND date_time >= ?
        AND date_time <= ?
        AND value IS NOT NULL
      ORDER BY
        ABS(TIMESTAMPDIFF(SECOND, date_time, ?)) ASC,
        date_time ASC,
        idPrimary ASC
      LIMIT 1
    `,
    [line.pm_type, rangeStart, rangeEnd, boundaryString]
  );

  if (!rows.length) {
    return null;
  }

  return rows[0];
}

/**
 * Mengambil pembacaan meter awal dan akhir shift,
 * kemudian menghitung total pemakaian.
 */
async function getShiftData(connection, line, shiftStart, shiftEnd) {
  const startReading = await getClosestReading(connection, line, shiftStart);
  const endReading = await getClosestReading(connection, line, shiftEnd);

  if (!startReading || !endReading) {
    return {
      success: false,
      reason: "Data meter di sekitar batas waktu shift tidak ditemukan",
    };
  }

  const rawStartValue = toNumber(startReading.value);
  const rawEndValue = toNumber(endReading.value);

  if (rawStartValue === null || rawEndValue === null) {
    return {
      success: false,
      reason: "Value meter tidak dapat dikonversi menjadi angka",
    };
  }

  const startDatetime = moment(startReading.date_time);
  const endDatetime = moment(endReading.date_time);

  if (!startDatetime.isBefore(endDatetime)) {
    return {
      success: false,
      reason: "Waktu pembacaan meter awal harus lebih kecil dari waktu akhir",
    };
  }

  const rawTotalValue = rawEndValue - rawStartValue;

  if (rawTotalValue < 0) {
    return {
      success: false,
      reason:
        "Selisih meter bernilai negatif. Periksa kemungkinan reset meter atau rollover",
    };
  }

  const divisor = Number(line.value_divisor || 1);

  if (!Number.isFinite(divisor) || divisor <= 0) {
    throw new Error(`value_divisor tidak valid pada ${line.line_table}`);
  }

  return {
    success: true,
    startDatetime: startReading.date_time,
    endDatetime: endReading.date_time,
    startValue: roundNumber(rawStartValue / divisor),
    endValue: roundNumber(rawEndValue / divisor),
    totalValue: roundNumber(rawTotalValue / divisor),
  };
}

/**
 * Menyimpan rekap.
 *
 * INSERT ... ON DUPLICATE KEY UPDATE digunakan agar:
 * - data baru masuk sebagai INSERT;
 * - data lama diperbarui sebagai UPDATE;
 * - tidak terjadi duplikasi.
 *
 * Unique key wajib tersedia pada:
 * pm_type + line_table + shift + shift_date
 */
async function upsertShiftReport(connection, data) {
  const reportTable = quoteIdentifier(REPORT_TABLE);

  await connection.query(
    `
      INSERT INTO ${reportTable} (
        pm_type,
        line_table,
        line_name,
        shift,
        shift_date,
        shift_start_datetime,
        shift_end_datetime,
        start_kwh,
        end_kwh,
        total_kwh,
        year,
        month,
        month_name,
        day,
        day_name,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        line_name = VALUES(line_name),
        shift_start_datetime = VALUES(shift_start_datetime),
        shift_end_datetime = VALUES(shift_end_datetime),
        start_kwh = VALUES(start_kwh),
        end_kwh = VALUES(end_kwh),
        total_kwh = VALUES(total_kwh),
        year = VALUES(year),
        month = VALUES(month),
        month_name = VALUES(month_name),
        day = VALUES(day),
        day_name = VALUES(day_name),
        updated_at = NOW()
    `,
    [
      data.pm_type,
      data.line_table,
      data.line_name,
      data.shift,
      data.shift_date,
      data.shift_start_datetime,
      data.shift_end_datetime,
      data.start_kwh,
      data.end_kwh,
      data.total_kwh,
      data.year,
      data.month,
      data.month_name,
      data.day,
      data.day_name,
    ]
  );
}

/**
 * Memproses satu tanggal.
 */
async function processShiftDate(connection, line, baseDate) {
  const shifts = [
    {
      shift: "shift_1",
      start: baseDate
        .clone()
        .hour(7)
        .minute(10)
        .second(0)
        .millisecond(0),
      end: baseDate
        .clone()
        .hour(19)
        .minute(50)
        .second(0)
        .millisecond(0),
    },
    {
      shift: "shift_2",
      start: baseDate
        .clone()
        .hour(19)
        .minute(50)
        .second(0)
        .millisecond(0),
      end: baseDate
        .clone()
        .add(1, "day")
        .hour(7)
        .minute(10)
        .second(0)
        .millisecond(0),
    },
  ];

  for (const item of shifts) {
    const shiftData = await getShiftData(
      connection,
      line,
      item.start,
      item.end
    );

    if (!shiftData.success) {
      console.warn(
        `⏭️ Lewati ${line.pm_type} | ${baseDate.format("YYYY-MM-DD")} | ${
          item.shift
        } | ${shiftData.reason}`
      );

      continue;
    }

    await upsertShiftReport(connection, {
      pm_type: line.pm_type,
      line_table: line.line_table,
      line_name: line.line_name,
      shift: item.shift,
      shift_date: baseDate.format("YYYY-MM-DD"),
      shift_start_datetime: shiftData.startDatetime,
      shift_end_datetime: shiftData.endDatetime,
      start_kwh: shiftData.startValue,
      end_kwh: shiftData.endValue,
      total_kwh: shiftData.totalValue,
      year: baseDate.year(),
      month: baseDate.month() + 1,
      month_name: baseDate.format("MMMM"),
      day: baseDate.date(),
      day_name: baseDate.format("dddd"),
    });

    console.log(
      `✅ Upsert ${line.pm_type} | ${baseDate.format("YYYY-MM-DD")} | ${
        item.shift
      } | ${shiftData.totalValue.toFixed(3)} KWH`
    );
  }
}

/**
 * Fungsi utama.
 */
async function rekapShiftly() {
  const connection = await pool.getConnection();

  try {
    const latestEligibleDate = getLatestEligibleShiftDate();

    console.log("==================================================");
    console.log("🔄 Mulai proses rekap shiftly");
    console.log(`🕒 Waktu server: ${moment().format("YYYY-MM-DD HH:mm:ss")}`);
    console.log(
      `📅 Tanggal shift maksimal: ${latestEligibleDate.format("YYYY-MM-DD")}`
    );
    console.log("==================================================");

    for (const line of lineTables) {
      console.log(`\n🔍 Proses ${line.pm_type} | ${line.line_table}`);

      const earliestDate = await getEarliestSourceDate(connection, line);

      if (!earliestDate) {
        console.warn(
          `⚠️ Tidak ada data sumber untuk ${line.pm_type} pada ${line.line_table}`
        );

        continue;
      }

      if (earliestDate.isAfter(latestEligibleDate, "day")) {
        console.log(
          `⏭️ Belum ada tanggal shift lengkap untuk ${line.pm_type}`
        );

        continue;
      }

      const candidateDates = await getCandidateDates(
        connection,
        line,
        earliestDate,
        latestEligibleDate
      );

      console.log(
        `📌 Jumlah tanggal yang perlu diproses: ${candidateDates.length}`
      );

      if (!candidateDates.length) {
        console.log(`✅ Tidak ada pembaruan untuk ${line.pm_type}`);
        continue;
      }

      for (const baseDate of candidateDates) {
        await processShiftDate(connection, line, baseDate);
      }
    }

    console.log("\n🎉 Rekap shiftly selesai.");
  } catch (error) {
    console.error("\n❌ Rekap shiftly gagal:", error);
    throw error;
  } finally {
    connection.release();
  }
}

/**
 * Menjalankan script secara langsung dari terminal.
 */
async function runRekapShiftly() {
  try {
    await rekapShiftly();
    console.log("✅ Program selesai dijalankan");
    process.exit(0);
  } catch (error) {
    console.error("❌ Program gagal dijalankan:", error);
    process.exit(1);
  }
}

if (require.main === module) {
  runRekapShiftly();
}

module.exports = {
  rekapShiftly,
};