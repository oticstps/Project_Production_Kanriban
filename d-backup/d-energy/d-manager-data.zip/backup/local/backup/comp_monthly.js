// TRUNCATE TABLE tb_comp_19_shiftly;
// TRUNCATE TABLE tb_comp_20_shiftly;
// TRUNCATE TABLE tb_comp_21_shiftly;
// TRUNCATE TABLE tb_comp_24_shiftly;


// TRUNCATE TABLE tb_comp_19_monthly;
// TRUNCATE TABLE tb_comp_20_monthly;
// TRUNCATE TABLE tb_comp_21_monthly;
// TRUNCATE TABLE tb_comp_24_monthly;





const pool = require("../../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

const panelTablesMonthly = [
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_19",
    target_table: "tb_comp_19_monthly",
    line_name: "PANEL 19",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_20",
    target_table: "tb_comp_20_monthly",
    line_name: "PANEL 20",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_21",
    target_table: "tb_comp_21_monthly",
    line_name: "PANEL 21",
  },
  {
    pm_type: "PANEL COMPRESSOR",
    source_table: "tb_comp_24",
    target_table: "tb_comp_24_monthly",
    line_name: "PANEL 24",
  },
];

// Fungsi untuk mengkonversi string ke number
function toNumber(value) {
  if (value === null || value === undefined) return NaN;
  return parseFloat(String(value).replace(/,/g, "").trim());
}

// Fungsi untuk mendapatkan tanggal-tanggal unik
async function getDistinctDates(connection, tableName) {
  const [rows] = await connection.query(`
    SELECT DISTINCT DATE(date_time) AS period_date
    FROM ${tableName}
    WHERE date_time IS NOT NULL
    ORDER BY period_date ASC
  `);

  return rows.map((row) => moment(row.period_date).format("YYYY-MM-DD"));
}

// Fungsi untuk mengambil data range dalam periode tertentu
async function getRangeData(connection, tableName, startTime, endTime) {
  const [startRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time ASC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  const [endRow] = await connection.query(
    `
    SELECT
      date_time,
      CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
    FROM ${tableName}
    WHERE date_time >= ? AND date_time < ?
      AND wh IS NOT NULL
      AND TRIM(CAST(wh AS CHAR)) <> ''
    ORDER BY date_time DESC
    LIMIT 1
    `,
    [
      startTime.format("YYYY-MM-DD HH:mm:ss"),
      endTime.format("YYYY-MM-DD HH:mm:ss"),
    ]
  );

  if (!startRow.length || !endRow.length) {
    return null;
  }

  const startValue = toNumber(startRow[0].wh_value);
  const endValue = toNumber(endRow[0].wh_value);

  if (Number.isNaN(startValue) || Number.isNaN(endValue)) {
    return null;
  }

  const totalValue = endValue - startValue;

  // Abaikan jika totalValue <= 0
  if (totalValue <= 0) {
    return null;
  }

  return {
    startDatetime: moment(startRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    endDatetime: moment(endRow[0].date_time).format("YYYY-MM-DD HH:mm:ss"),
    startValue,
    endValue,
    totalValue,
  };
}

// Fungsi untuk membangun periode bulanan dari data tanggal
function buildMonthlyPeriods(dateStrings) {
  const map = new Map();

  for (const dateStr of dateStrings) {
    const m = moment(dateStr);
    const key = m.format("YYYY-MM");

    if (!map.has(key)) {
      const monthStart = m.clone().startOf("month");
      const nextMonthStart = monthStart.clone().add(1, "month");
      const monthEnd = nextMonthStart.clone().subtract(1, "day");

      map.set(key, {
        year: monthStart.year(),
        month: monthStart.month() + 1,
        month_name: monthStart.format("MMMM"),
        month_start_date: monthStart.format("YYYY-MM-DD"),
        month_end_date: monthEnd.format("YYYY-MM-DD"),
        range_start: monthStart.clone().startOf("day"),
        range_end: nextMonthStart.clone().startOf("day"),
      });
    }
  }

  return Array.from(map.values()).sort(
    (a, b) => a.range_start.valueOf() - b.range_start.valueOf()
  );
}

// Fungsi untuk menyimpan data monthly ke dalam tabel
async function upsertMonthlyToTable(connection, line, data) {
  await connection.query(
    `
    INSERT INTO ${line.target_table} (
      pm_type,
      line_table,
      line_name,
      start_kwh,
      end_kwh,
      total_kwh,
      year,
      month,
      month_name,
      month_start_date,
      month_end_date,
      month_start_datetime,
      month_end_datetime,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      line_name = VALUES(line_name),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      month_name = VALUES(month_name),
      month_start_date = VALUES(month_start_date),
      month_end_date = VALUES(month_end_date),
      month_start_datetime = VALUES(month_start_datetime),
      month_end_datetime = VALUES(month_end_datetime),
      updated_at = NOW()
    `,
    [
      line.pm_type,
      line.source_table,
      line.line_name,
      data.start_kwh,
      data.end_kwh,
      data.total_kwh,
      data.year,
      data.month,
      data.month_name,
      data.month_start_date,
      data.month_end_date,
      data.month_start_datetime,
      data.month_end_datetime,
    ]
  );

  console.log(
    `✅ Upsert: ${line.target_table} | ${data.year}-${String(data.month).padStart(2, "0")} | ${data.total_kwh.toFixed(3)} kWh`
  );
}

// Fungsi utama untuk menjalankan proses rekap monthly
async function rekapMonthly() {
  const connection = await pool.getConnection();

  try {
    for (const line of panelTablesMonthly) {
      console.log(`\n🔍 Proses Monthly: ${line.source_table} -> ${line.target_table}`);

      const dates = await getDistinctDates(connection, line.source_table);
      const monthlyPeriods = buildMonthlyPeriods(dates);

      // Proses Monthly untuk setiap periode bulanan
      for (const period of monthlyPeriods) {
        const monthlyData = await getRangeData(
          connection,
          line.source_table,
          period.range_start,
          period.range_end
        );

        if (monthlyData) {
          await upsertMonthlyToTable(connection, line, {
            start_kwh: monthlyData.startValue,
            end_kwh: monthlyData.endValue,
            total_kwh: monthlyData.totalValue,
            year: period.year,
            month: period.month,
            month_name: period.month_name,
            month_start_date: period.month_start_date,
            month_end_date: period.month_end_date,
            month_start_datetime: monthlyData.startDatetime,
            month_end_datetime: monthlyData.endDatetime,
          });
        } else {
          console.log(
            `⚠️ Skip: ${line.target_table} | ${period.year}-${String(period.month).padStart(2, "0")} | invalid / 0 / negatif`
          );
        }
      }
    }

    console.log("\n🎉 Rekap monthly selesai.");
  } catch (err) {
    console.error("❌ Error rekap monthly:", err);
  } finally {
    connection.release();
  }
}

// Menjalankan fungsi rekap monthly
rekapMonthly();