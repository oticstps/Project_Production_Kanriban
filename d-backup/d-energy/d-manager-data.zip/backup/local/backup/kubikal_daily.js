const pool = require("../../../config/db_core");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
    { pm_type: "DA_01", line_table: "tb_kub1_total_kwh", line_name: "kubikal_1" },
];

async function rekapHarian() {
    const connection = await pool.getConnection();

    try {
        for (const line of lineTables) {
            console.log(`\n🔍 Proses Harian: ${line.line_table}`);

            const [tanggalUnik] = await connection.query(`
                SELECT DISTINCT DATE(date_time) as tgl
                FROM ${line.line_table}
                WHERE date_time IS NOT NULL
                ORDER BY tgl;
            `);

            for (const { tgl } of tanggalUnik) {
                const [awal] = await connection.query(`
                    SELECT date_time, value
                    FROM ${line.line_table}
                    WHERE DATE(date_time) = ?
                    ORDER BY date_time ASC
                    LIMIT 1;
                `, [tgl]);

                const [akhir] = await connection.query(`
                    SELECT date_time, value
                    FROM ${line.line_table}
                    WHERE DATE(date_time) = ?
                    ORDER BY date_time DESC
                    LIMIT 1;
                `, [tgl]);

                if (!awal.length || !akhir.length) continue;

                const startDatetime = awal[0].date_time;
                const endDatetime = akhir[0].date_time;
                const startWh = parseInt(awal[0].value) || 0;
                const lastWh = parseInt(akhir[0].value) || 0;
                const totalWh = lastWh - startWh;

                const mStart = moment(startDatetime);
                const dateStr = mStart.format("YYYY-MM-DD");
                const year = mStart.year();
                const month = mStart.month() + 1;
                const monthName = mStart.format("MMMM");
                const day = mStart.date();
                const dayName = mStart.format("dddd");

                const [result] = await connection.query(`
                    INSERT INTO tb_pm_daily_report (
                        pm_type, line_table, line_name,
                        start_datetime, end_datetime,
                        start_wh, last_wh, total_wh,
                        date, year, month, month_name, day, day_name,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE
                        line_name = ?,
                        start_datetime = ?,
                        end_datetime = ?,
                        start_wh = ?,
                        last_wh = ?,
                        total_wh = ?,
                        year = ?,
                        month = ?,
                        month_name = ?,
                        day = ?,
                        day_name = ?,
                        created_at = NOW();
                `, [
                    line.pm_type,
                    line.line_table,
                    line.line_name,
                    startDatetime,
                    endDatetime,
                    startWh,
                    lastWh,
                    totalWh,
                    dateStr,
                    year,
                    month,
                    monthName,
                    day,
                    dayName,

                    line.line_name,
                    startDatetime,
                    endDatetime,
                    startWh,
                    lastWh,
                    totalWh,
                    year,
                    month,
                    monthName,
                    day,
                    dayName
                ]);

                if (result.affectedRows === 1) {
                    console.log(`✅ Insert Harian: ${dateStr} (${totalWh} Wh)`);
                } else {
                    console.log(`♻️ Upsert/Update Harian: ${dateStr} (${totalWh} Wh)`);
                }
            }
        }

        console.log("\n🎉 Rekap harian selesai.");
    } catch (err) {
        console.error("❌ Error rekap harian:", err);
    } finally {
        connection.release();
    }
}

rekapHarian();