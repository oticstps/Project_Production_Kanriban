const pool = require("../../../config/db_core");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");







const lineTables = [
    { pm_type: "DA_01", line_table: "tb_kub1_total_kwh", line_name: "kubikal_1" },
];
    









async function rekapHourly() {
    const connection = await pool.getConnection();
    try {
        for (const line of lineTables) {
            console.log(`\n🔍 Proses hourly: ${line.line_table}`);

            // Ambil semua tanggal unik dari tabel sumber
            const [periode] = await connection.query(`
                SELECT DISTINCT 
                    DATE(date_time) as date,
                    YEAR(date_time) as year,
                    MONTH(date_time) as month,
                    DAY(date_time) as day
                FROM ${line.line_table}
                WHERE date_time IS NOT NULL
                ORDER BY date;
            `);

            for (const { date, year, month, day } of periode) {
                const dateObj = moment(date);
                const dayName = dateObj.format('dddd');
                const monthName = dateObj.format('MMMM');

                // Loop untuk setiap jam dalam sehari (00:00 - 23:00)
                for (let hour = 0; hour < 24; hour++) {
                    const hourStart = moment(date).hour(hour).minute(0).second(0).millisecond(0);
                    const hourEnd = moment(date).hour(hour).minute(59).second(59).millisecond(999);

                    // Ambil data awal dan akhir untuk jam ini
                    const [startRow] = await connection.query(`
                        SELECT date_time, value
                        FROM ${line.line_table}
                        WHERE date_time >= ? AND date_time <= ?
                        ORDER BY date_time ASC
                        LIMIT 1;
                    `, [hourStart.format('YYYY-MM-DD HH:mm:ss'), hourEnd.format('YYYY-MM-DD HH:mm:ss')]);

                    const [endRow] = await connection.query(`
                        SELECT date_time, value
                        FROM ${line.line_table}
                        WHERE date_time >= ? AND date_time <= ?
                        ORDER BY date_time DESC
                        LIMIT 1;
                    `, [hourStart.format('YYYY-MM-DD HH:mm:ss'), hourEnd.format('YYYY-MM-DD HH:mm:ss')]);

                    if (startRow.length > 0 && endRow.length > 0) {
                        const startDatetime = startRow[0].date_time;
                        const endDatetime = endRow[0].date_time;
                        const startKwh = parseFloat(startRow[0].value);
                        const endKwh = parseFloat(endRow[0].value);
                        const totalKwh = endKwh - startKwh;

                        await upsertHourlyReport(connection, {
                            ...line,
                            hour_start_datetime: hourStart.format('YYYY-MM-DD HH:mm:ss'),
                            hour_end_datetime: hourEnd.format('YYYY-MM-DD HH:mm:ss'),
                            start_kwh: startKwh,
                            end_kwh: endKwh,
                            total_kwh: totalKwh,
                            date: date,
                            year, month, month_name: monthName, day, day_name: dayName,
                            hour_of_day: hour
                        });
                    } else {
                        console.log(`⚠️  Tidak ada data untuk ${line.line_table} pada jam ${hour}:00 - ${hour}:59`);
                    }
                }
            }
        }

        console.log("\n🎉 Rekap hourly selesai.");
    } catch (err) {
        console.error("❌ Error:", err);
    } finally {
        connection.release();
    }
}

// Fungsi untuk INSERT atau UPDATE data hourly (tanpa idPrimary)
async function upsertHourlyReport(connection, data) {
    // Cek keberadaan berdasarkan kombinasi unik
    const [cek] = await connection.query(`
        SELECT 1 FROM tb_pm_hourly_report
        WHERE pm_type = ? AND line_table = ? AND hour_start_datetime = ?
        LIMIT 1;
    `, [data.pm_type, data.line_table, data.hour_start_datetime]);

    if (cek.length === 0) {
        // INSERT
        await connection.query(`
            INSERT INTO tb_pm_hourly_report (
                pm_type, line_table, line_name,
                hour_start_datetime, hour_end_datetime,
                start_kwh, end_kwh, total_kwh,
                date, year, month, month_name, day, day_name, hour_of_day, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW());
        `, [
            data.pm_type, data.line_table, data.line_name,
            data.hour_start_datetime, data.hour_end_datetime,
            data.start_kwh, data.end_kwh, data.total_kwh,
            data.date, data.year, data.month, data.month_name, data.day, data.day_name, data.hour_of_day
        ]);
        console.log(`✅ Insert Hourly: ${data.hour_start_datetime} (${data.total_kwh} KWH)`);
    } else {
        // UPDATE berdasarkan kombinasi unik
        await connection.query(`
            UPDATE tb_pm_hourly_report
            SET line_name = ?,
                hour_end_datetime = ?,
                start_kwh = ?, end_kwh = ?, total_kwh = ?,
                date = ?, year = ?, month = ?, month_name = ?, day = ?, day_name = ?, hour_of_day = ?,
                created_at = NOW()
            WHERE pm_type = ? AND line_table = ? AND hour_start_datetime = ?;
        `, [
            data.line_name,
            data.hour_end_datetime,
            data.start_kwh, data.end_kwh, data.total_kwh,
            data.date, data.year, data.month, data.month_name, data.day, data.day_name, data.hour_of_day,
            data.pm_type, data.line_table, data.hour_start_datetime
        ]);
        console.log(`♻️ Update Hourly: ${data.hour_start_datetime} (${data.total_kwh} KWH)`);
    }
}

rekapHourly();