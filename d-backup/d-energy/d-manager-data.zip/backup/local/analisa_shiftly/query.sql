
DELETE FROM tb_pm_shiftly_report
WHERE line_name LIKE 'panel_16%';


DELETE FROM tb_pm_shiftly_report
WHERE line_name LIKE 'panel_17%';


DELETE FROM tb_pm_shiftly_report
WHERE line_name LIKE 'kubikal_1%';



