const pool = require("../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

const CONFIG = {
    pm_type: "POWER METER PUSAT",
    source_table: "tb_kub1_total_kwh",
    target_table: "tb_kub1_weekly",
};

function toNumber(value) {
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
}

async function getPowerMeters(connection) {
    const [rows] = await connection.query(`
        SELECT DISTINCT power_meter
        FROM ${CONFIG.source_table}
        WHERE power_meter IS NOT NULL
          AND TRIM(power_meter) <> ''
        ORDER BY power_meter ASC
    `);

    return rows.map(row => row.power_meter);
}

async function getWeeklyData(connection, powerMeter, year, week) {
    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND YEAR(date_time) = ?
          AND WEEK(date_time) = ?
        ORDER BY date_time ASC
        LIMIT 1
    `, [powerMeter, year, week]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND YEAR(date_time) = ?
          AND WEEK(date_time) = ?
        ORDER BY date_time DESC
        LIMIT 1
    `, [powerMeter, year, week]);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = toNumber(startRow[0].value);
    const endValue = toNumber(endRow[0].value);

    if (startValue === null || endValue === null) {
        return null;
    }

    const totalValue = endValue - startValue;

    if (totalValue <= 0) {
        return null;
    }

    return {
        week_start_date: moment(startRow[0].date_time).format("YYYY-MM-DD"),
        week_end_date: moment(endRow[0].date_time).format("YYYY-MM-DD"),
        startDatetime: startRow[0].date_time,
        endDatetime: endRow[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertWeekly(connection, payload) {
    await connection.query(`
        INSERT INTO ${CONFIG.target_table} (
            pm_type,
            line_table,
            line_name,
            year,
            week,
            week_start_date,
            week_end_date,
            start_datetime,
            end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            week_start_date = VALUES(week_start_date),
            week_end_date = VALUES(week_end_date),
            start_datetime = VALUES(start_datetime),
            end_datetime = VALUES(end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            updated_at = NOW()
    `, [
        payload.pm_type,
        payload.line_table,
        payload.line_name,
        payload.year,
        payload.week,
        payload.week_start_date,
        payload.week_end_date,
        payload.start_datetime,
        payload.end_datetime,
        payload.start_kwh,
        payload.end_kwh,
        payload.total_kwh
    ]);
}

async function rekapWeekly() {
    const connection = await pool.getConnection();

    try {
        const powerMeters = await getPowerMeters(connection);

        for (const powerMeter of powerMeters) {
            console.log(`\n🔍 Proses weekly power meter: ${powerMeter}`);

            const [periods] = await connection.query(`
                SELECT DISTINCT
                    YEAR(date_time) AS year,
                    WEEK(date_time) AS week
                FROM ${CONFIG.source_table}
                WHERE power_meter = ?
                  AND date_time IS NOT NULL
                ORDER BY year ASC, week ASC
            `, [powerMeter]);

            for (const row of periods) {
                const weeklyData = await getWeeklyData(connection, powerMeter, row.year, row.week);

                if (!weeklyData) {
                    console.log(`⚠️ Skip ${powerMeter} | year=${row.year} | week=${row.week}`);
                    continue;
                }

                await upsertWeekly(connection, {
                    pm_type: CONFIG.pm_type,
                    line_table: CONFIG.source_table,
                    line_name: powerMeter,
                    year: row.year,
                    week: row.week,
                    week_start_date: weeklyData.week_start_date,
                    week_end_date: weeklyData.week_end_date,
                    start_datetime: weeklyData.startDatetime,
                    end_datetime: weeklyData.endDatetime,
                    start_kwh: weeklyData.startValue,
                    end_kwh: weeklyData.endValue,
                    total_kwh: weeklyData.totalValue
                });

                console.log(`✅ ${powerMeter} | year=${row.year} | week=${row.week} | ${weeklyData.totalValue} kWh`);
            }
        }

        console.log("\n🎉 Rekap kub_weekly selesai.");
    } catch (error) {
        console.error("❌ Error kub_weekly:", error);
    } finally {
        connection.release();
    }
}

rekapWeekly();