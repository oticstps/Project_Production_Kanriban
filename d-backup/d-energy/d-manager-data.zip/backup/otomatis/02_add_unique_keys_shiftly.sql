-- Jalankan hanya setelah 01_check_duplicates_shiftly.sql menghasilkan 0 baris.
-- Disarankan membuat backup database terlebih dahulu.
-- Nama indeks boleh sama karena setiap indeks berada pada tabel yang berbeda.

ALTER TABLE `tb_pm200_bs1_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_bs2_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cc1_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cc234_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_chab_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_chcd_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_chef_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_chsaa_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_chsac_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_conn_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr1_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr2_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr3_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr4_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr5_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr6_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr7_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr8_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr9_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr10_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr11_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_cr12_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_ct_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_hla_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_ra_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_ret_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm200_chsab_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_bs1_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_bs2_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cc1_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cc234_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_chab_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_chcd_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_chef_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_chsaa_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_chsac_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_conn_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr1_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr2_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr3_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr4_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr5_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr6_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr7_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr8_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr9_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr10_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr11_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_cr12_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_ct_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_hla_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_ra_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_ret_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);
ALTER TABLE `tb_pm220_chsab_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);




CREATE TABLE `tb_kub1_total_kwh_shiftly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pm_type` varchar(50) DEFAULT NULL,
  `line_table` varchar(100) DEFAULT NULL,
  `line_name` varchar(100) DEFAULT NULL,
  `shift` varchar(20) DEFAULT NULL,
  `shift_date` date DEFAULT NULL,
  `shift_start_datetime` datetime DEFAULT NULL,
  `shift_end_datetime` datetime DEFAULT NULL,
  `start_kwh` decimal(15,3) DEFAULT NULL,
  `end_kwh` decimal(15,3) DEFAULT NULL,
  `total_kwh` decimal(15,3) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `month_name` varchar(20) DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `day_name` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `tb_kub1_total_kwh_shiftly` ADD UNIQUE KEY `uq_line_shift_date_shift` (`line_table`, `shift_date`, `shift`);