-- Pemeriksaan duplikat sebelum membuat UNIQUE KEY.
-- Hasil yang aman adalah: 0 baris.
-- Skrip ini tidak mengubah atau menghapus data.

SELECT
    'tb_pm200_bs1_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_bs1_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_bs2_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_bs2_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cc1_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cc1_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cc234_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cc234_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_chab_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_chab_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_chcd_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_chcd_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_chef_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_chef_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_chsaa_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_chsaa_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_chsac_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_chsac_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_conn_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_conn_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr1_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr1_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr2_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr2_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr3_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr3_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr4_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr4_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr5_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr5_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr6_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr6_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr7_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr7_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr8_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr8_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr9_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr9_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr10_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr10_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr11_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr11_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_cr12_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_cr12_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_ct_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_ct_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_hla_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_hla_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_ra_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_ra_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_ret_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_ret_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm200_chsab_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm200_chsab_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_bs1_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_bs1_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_bs2_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_bs2_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cc1_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cc1_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cc234_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cc234_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_chab_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_chab_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_chcd_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_chcd_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_chef_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_chef_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_chsaa_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_chsaa_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_chsac_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_chsac_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_conn_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_conn_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr1_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr1_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr2_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr2_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr3_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr3_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr4_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr4_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr5_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr5_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr6_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr6_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr7_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr7_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr8_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr8_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr9_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr9_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr10_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr10_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr11_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr11_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_cr12_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_cr12_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_ct_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_ct_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_hla_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_hla_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_ra_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_ra_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_ret_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_ret_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
UNION ALL
SELECT
    'tb_pm220_chsab_shiftly' AS target_table,
    line_table,
    shift_date,
    shift,
    COUNT(*) AS duplicate_count
FROM `tb_pm220_chsab_shiftly`
WHERE line_table IS NOT NULL
  AND shift_date IS NOT NULL
  AND shift IS NOT NULL
GROUP BY line_table, shift_date, shift
HAVING COUNT(*) > 1
ORDER BY target_table, duplicate_count DESC, shift_date;
