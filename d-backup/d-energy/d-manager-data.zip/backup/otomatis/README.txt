PERBAIKAN REKAP SHIFTLY - 15 DATA TERBARU
=========================================

Fungsi utama
------------
Program hanya memproses maksimal 15 data shift valid terbaru pada setiap tabel target.
Satu data adalah satu kombinasi:
- line_table
- shift_date
- shift

Dengan demikian, batas 15 berarti 15 baris shift terbaru per tabel, bukan 15 hari.

Cara kerja
----------
1. Program mengambil maksimal 45 tanggal terbaru dari setiap tabel sumber.
2. Program membentuk kandidat shift_1 dan shift_2 yang sudah selesai.
3. Kandidat diurutkan mulai dari shift paling baru.
4. Data kosong, nilai 0, nilai negatif, dan indikasi meter reset dilewati.
5. Program terus mencari ke data sebelumnya sampai maksimal 15 data valid berhasil di-UPSERT.
6. Data lama tidak dihapus dan tabel tidak di-TRUNCATE.
7. UNIQUE KEY tetap diperiksa dan dapat dibuat otomatis jika database mengizinkan ALTER TABLE.

Konfigurasi
-----------
Batas update berada pada file line_shiftly_cron.js:

const LATEST_UPDATE_LIMIT = 15;

Jumlah tanggal yang dipindai:

const RECENT_DATE_SCAN_LIMIT = Math.max(LATEST_UPDATE_LIMIT * 3, 30);

Jadwal
------
Program tetap dijalankan:
- satu kali saat startup
- setiap hari pukul 07:30 WIB

Pemasangan
----------
1. Hentikan program lama dengan Ctrl+C.
2. Backup file lama:
   cp line_shiftly_cron.js line_shiftly_cron.backup.js
3. Salin file line_shiftly_cron.js dari paket ini ke folder program.
4. Periksa sintaks:
   node --check line_shiftly_cron.js
5. Jalankan:
   node line_shiftly_cron.js

Log ringkasan yang diharapkan
-----------------------------
Ringkasan nama_tabel_shiftly: 15 data valid diperbarui dari 15 kandidat shift terbaru.

Jika terdapat data kosong atau anomali, jumlah kandidat yang diperiksa dapat lebih dari 15.
Jika total data valid memang kurang dari 15, program akan menampilkan peringatan dan memperbarui data yang tersedia saja.
