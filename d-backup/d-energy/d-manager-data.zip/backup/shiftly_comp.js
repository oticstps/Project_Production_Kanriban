const mysql = require('mysql2/promise');
const moment = require('moment');

// Konfigurasi database
const dbConfig = {
  host: '192.168.137.157',
  user: 'otics_tps',
  password: 'sukatno_ali',
  database: 'database_tps_master',
};

// Parameter
// const PANEL = 'panel_21';                // Nama panel yang akan diproses
// const SOURCE_TABLE = 'tb_kub_panel_20_wh';
// const TARGET_TABLE = 'tb_kub_comp_20_shiftly';



const PANEL = 'panel_24';
const SOURCE_TABLE = 'tb_panel_24_energy_vah_wh';
const TARGET_TABLE = 'tb_kub_comp_24_shiftly';






/**
 * Mendapatkan nama bulan dalam bahasa Inggris (sesuai ekspektasi tabel)
 */
function getMonthName(monthIndex) {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return months[monthIndex];
}

/**
 * Mendapatkan nama hari dalam bahasa Inggris
 */
function getDayName(date) {
  const days = [
    'Sunday', 'Monday', 'Tuesday', 'Wednesday',
    'Thursday', 'Friday', 'Saturday'
  ];
  return days[date.day()];
}

/**
 * Memproses satu shift pada tanggal tertentu
 */
async function processShift(connection, date, shiftNumber) {
  // Tentukan batas waktu shift
  const shiftStart = date.clone();
  const shiftEnd = date.clone();

  if (shiftNumber === 1) {
    shiftStart.hour(7).minute(10).second(0);
    shiftEnd.hour(19).minute(50).second(0);
  } else {
    // Shift 2: mulai hari ini jam 19:50, selesai besok jam 07:10
    shiftStart.hour(19).minute(50).second(0);
    shiftEnd.add(1, 'day').hour(7).minute(10).second(0);
  }

  // Cek apakah ada data dalam rentang shift ini
  const [countRows] = await connection.execute(
    `SELECT COUNT(*) as cnt FROM ${SOURCE_TABLE}
     WHERE panel = ? AND date_time BETWEEN ? AND ?`,
    [PANEL, shiftStart.format('YYYY-MM-DD HH:mm:ss'), shiftEnd.format('YYYY-MM-DD HH:mm:ss')]
  );

  if (countRows[0].cnt === 0) {
    console.log(`[SKIP] Tidak ada data untuk shift ${shiftNumber} pada ${date.format('YYYY-MM-DD')}`);
    return;
  }

  // Ambil pembacaan pertama dalam shift
  const [startRows] = await connection.execute(
    `SELECT date_time, wh FROM ${SOURCE_TABLE}
     WHERE panel = ? AND date_time >= ? AND date_time <= ?
     ORDER BY date_time ASC LIMIT 1`,
    [PANEL, shiftStart.format('YYYY-MM-DD HH:mm:ss'), shiftEnd.format('YYYY-MM-DD HH:mm:ss')]
  );

  // Ambil pembacaan terakhir dalam shift
  const [endRows] = await connection.execute(
    `SELECT date_time, wh FROM ${SOURCE_TABLE}
     WHERE panel = ? AND date_time >= ? AND date_time <= ?
     ORDER BY date_time DESC LIMIT 1`,
    [PANEL, shiftStart.format('YYYY-MM-DD HH:mm:ss'), shiftEnd.format('YYYY-MM-DD HH:mm:ss')]
  );

  if (startRows.length === 0 || endRows.length === 0) {
    console.log(`[SKIP] Data tidak lengkap untuk shift ${shiftNumber} pada ${date.format('YYYY-MM-DD')}`);
    return;
  }

  const start = startRows[0];
  const end = endRows[0];
  const startKwh = parseFloat(start.wh);
  const endKwh = parseFloat(end.wh);
  const totalKwh = endKwh - startKwh;

  if (totalKwh < 0) {
    console.warn(`[WARN] Konsumsi negatif untuk shift ${shiftNumber} pada ${date.format('YYYY-MM-DD')}: ${totalKwh}`);
    // Bisa ditambahkan logika penanganan reset counter jika diperlukan
  }

  // Cek apakah sudah pernah diproses (hindari duplikasi)
  const [existRows] = await connection.execute(
    `SELECT idPrimary FROM ${TARGET_TABLE}
     WHERE line_name = ? AND shift_date = ? AND shift = ?`,
    [PANEL, date.format('YYYY-MM-DD'), shiftNumber.toString()]
  );

  if (existRows.length > 0) {
    console.log(`[SKIP] Shift ${shiftNumber} pada ${date.format('YYYY-MM-DD')} sudah ada.`);
    return;
  }

  // Siapkan data untuk insert
  const shiftDateStr = date.format('YYYY-MM-DD');
  const year = date.year();
  const month = date.month() + 1;           // moment month 0-11
  const monthName = getMonthName(date.month());
  const day = date.date();
  const dayName = getDayName(date);

  await connection.execute(
    `INSERT INTO ${TARGET_TABLE}
     (pm_type, line_table, line_name, shift, shift_date,
      shift_start_datetime, shift_end_datetime,
      start_kwh, end_kwh, total_kwh,
      year, month, month_name, day, day_name, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      'kwh',                         // pm_type
      SOURCE_TABLE,                  // line_table
      PANEL,                          // line_name
      shiftNumber.toString(),         // shift
      shiftDateStr,                   // shift_date
      shiftStart.format('YYYY-MM-DD HH:mm:ss'), // shift_start_datetime
      shiftEnd.format('YYYY-MM-DD HH:mm:ss'),   // shift_end_datetime
      startKwh,                       // start_kwh
      endKwh,                          // end_kwh
      totalKwh,                        // total_kwh
      year,                            // year
      month,                           // month
      monthName,                       // month_name
      day,                             // day
      dayName,                         // day_name
      new Date()                       // created_at
    ]
  );

  console.log(`[INSERT] Shift ${shiftNumber} pada ${shiftDateStr} berhasil ditambahkan.`);
}

/**
 * Fungsi utama
 */
async function main() {
  let connection;
  try {
    connection = await mysql.createConnection(dbConfig);

    // Dapatkan rentang tanggal dari data yang ada
    const [rows] = await connection.execute(
      `SELECT MIN(date_time) as min_date, MAX(date_time) as max_date
       FROM ${SOURCE_TABLE}
       WHERE panel = ?`,
      [PANEL]
    );

    const minDate = moment(rows[0].min_date);
    const maxDate = moment(rows[0].max_date);

    if (!minDate.isValid() || !maxDate.isValid()) {
      console.log('Tidak ada data di tabel sumber.');
      return;
    }

    // Loop per hari dari minDate sampai maxDate (tanggal saja)
    let currentDate = minDate.clone().startOf('day');
    const endDate = maxDate.clone().startOf('day');

    while (currentDate <= endDate) {
      // Proses shift 1 dan shift 2 untuk hari tersebut
      await processShift(connection, currentDate, 1);
      await processShift(connection, currentDate, 2);

      currentDate.add(1, 'day');
    }

    console.log('Selesai memproses semua shift.');
  } catch (err) {
    console.error('Terjadi kesalahan:', err);
  } finally {
    if (connection) await connection.end();
  }
}

// Jalankan program
main();