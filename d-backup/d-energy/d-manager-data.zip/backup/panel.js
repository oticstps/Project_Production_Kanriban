
tb_area_cr1cr2
tb_kub1_active_power
tb_kub1_pershift
tb_kub1_total_kwh
tb_kub2_63_active_power
tb_kub2_63_apparent_power
tb_kub2_63_current
tb_kub2_63_frequency
tb_kub2_63_power_factor
tb_kub2_63_reactive_power
tb_kub2_63_voltage_ll
tb_kub2_63_voltage_ln
tb_kub2_64_active_power
tb_kub2_64_apparent_power
tb_kub2_64_current
tb_kub2_64_frequency
tb_kub2_64_power_factor
tb_kub2_64_reactive_power
tb_kub2_64_voltage_ll
tb_kub2_64_voltage_ln
tb_kub2_panel63
tb_kub2_panel64
tb_kub2_panel_1_total_kwh
tb_kub2_panel_2_total_kwh
tb_kub_active_power
tb_kub_apparent_power
tb_kub_comp_19
tb_kub_comp_19_shiftly
tb_kub_comp_20_shiftly
tb_kub_comp_21
tb_kub_comp_21_shiftly
tb_kub_comp_24
tb_kub_comp_24_shiftly
tb_kub_current
tb_kub_current_update
tb_kub_frequency
tb_kub_panel_16_ap
tb_kub_panel_16_wh
tb_kub_panel_17_ap
tb_kub_panel_17_wh
tb_kub_panel_20_ap
tb_kub_panel_20_wh
tb_kub_plant2_report
tb_kub_power_factor
tb_kub_reactive_power
tb_kub_voltage_ll
tb_kub_voltage_ln
tb_layout_otics_1
tb_lpdmtc
tb_lpf1
tb_lpf2
tb_lpqad
tb_lpsec
tb_lputils
tb_lp_dmtc
// ===========================================















tb_pm200_bs1_shiftly
tb_pm200_bs2_shiftly
tb_pm200_cc1_shiftly
tb_pm200_cc234_shiftly
tb_pm200_chab_shiftly
tb_pm200_chcd_shiftly
tb_pm200_chef_shiftly
tb_pm200_chsaa_shiftly
tb_pm200_chsab_shiftly
tb_pm200_chsac_shiftly
tb_pm200_conn_shiftly

tb_pm200_ct_shiftly
tb_pm200_hla_shiftly
tb_pm200_ra_shiftly
tb_pm200_ret_shiftly
tb_pm200_weng_shiftly
tb_pm220_bs1_shiftly
tb_pm220_bs2_shiftly
tb_pm220_cc1_shiftly
tb_pm220_cc234_shiftly
tb_pm220_chab_shiftly
tb_pm220_chcd_shiftly
tb_pm220_chef_shiftly
tb_pm220_chsaa_shiftly
tb_pm220_chsab_shiftly
tb_pm220_chsac_shiftly
tb_pm220_conn_shiftly

tb_pm200_cr1_shiftly
tb_pm200_cr2_shiftly
tb_pm200_cr3_shiftly
tb_pm200_cr4_shiftly
tb_pm200_cr5_shiftly
tb_pm200_cr6_shiftly
tb_pm200_cr7_shiftly
tb_pm200_cr8_shiftly
tb_pm200_cr9_shiftly
tb_pm200_cr10_shiftly
tb_pm200_cr11_shiftly
tb_pm200_cr12_shiftly

tb_pm220_cr1_shiftly
tb_pm220_cr2_shiftly
tb_pm220_cr3_shiftly
tb_pm220_cr4_shiftly
tb_pm220_cr5_shiftly
tb_pm220_cr6_shiftly
tb_pm220_cr7_shiftly
tb_pm220_cr8_shiftly
tb_pm220_cr9_shiftly
tb_pm220_cr10_shiftly
tb_pm220_cr11_shiftly
tb_pm220_cr12_shiftly

tb_pm220_ct_shiftly
tb_pm220_hla_shiftly
tb_pm220_lpf3_shiftly
tb_pm220_ra_shiftly
tb_pm220_ret_shiftly



//  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


tb_pm200_bs1_daily
tb_pm200_bs2_daily
tb_pm200_cc1_daily
tb_pm200_cc234_daily
tb_pm200_chab_daily
tb_pm200_chcd_daily
tb_pm200_chef_daily
tb_pm200_chsaa_daily
tb_pm200_chsab_daily
tb_pm200_chsac_daily
tb_pm200_conn_daily

tb_pm200_ct_daily
tb_pm200_hla_daily
tb_pm200_ra_daily
tb_pm200_ret_daily
tb_pm200_weng_daily

tb_pm220_bs1_daily
tb_pm220_bs2_daily
tb_pm220_cc1_daily
tb_pm220_cc234_daily
tb_pm220_chab_daily
tb_pm220_chcd_daily
tb_pm220_chef_daily
tb_pm220_chsaa_daily
tb_pm220_chsab_daily
tb_pm220_chsac_daily
tb_pm220_conn_daily

tb_pm200_cr1_daily
tb_pm200_cr2_daily
tb_pm200_cr3_daily
tb_pm200_cr4_daily
tb_pm200_cr5_daily
tb_pm200_cr6_daily
tb_pm200_cr7_daily
tb_pm200_cr8_daily
tb_pm200_cr9_daily
tb_pm200_cr10_daily
tb_pm200_cr11_daily
tb_pm200_cr12_daily

tb_pm220_cr1_daily
tb_pm220_cr2_daily
tb_pm220_cr3_daily
tb_pm220_cr4_daily
tb_pm220_cr5_daily
tb_pm220_cr6_daily
tb_pm220_cr7_daily
tb_pm220_cr8_daily
tb_pm220_cr9_daily
tb_pm220_cr10_daily
tb_pm220_cr11_daily
tb_pm220_cr12_daily

tb_pm220_ct_daily
tb_pm220_hla_daily
tb_pm220_lpf3_daily
tb_pm220_ra_daily
tb_pm220_ret_daily




//  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>





tb_pm200_bs1_weekly
tb_pm200_bs2_weekly
tb_pm200_cc1_weekly
tb_pm200_cc234_weekly
tb_pm200_chab_weekly
tb_pm200_chcd_weekly
tb_pm200_chef_weekly
tb_pm200_chsaa_weekly
tb_pm200_chsab_weekly
tb_pm200_chsac_weekly
tb_pm200_conn_weekly

tb_pm200_ct_weekly
tb_pm200_hla_weekly
tb_pm200_ra_weekly
tb_pm200_ret_weekly
tb_pm200_weng_weekly

tb_pm220_bs1_weekly
tb_pm220_bs2_weekly
tb_pm220_cc1_weekly
tb_pm220_cc234_weekly
tb_pm220_chab_weekly
tb_pm220_chcd_weekly
tb_pm220_chef_weekly
tb_pm220_chsaa_weekly
tb_pm220_chsab_weekly
tb_pm220_chsac_weekly
tb_pm220_conn_weekly

tb_pm200_cr1_weekly
tb_pm200_cr2_weekly
tb_pm200_cr3_weekly
tb_pm200_cr4_weekly
tb_pm200_cr5_weekly
tb_pm200_cr6_weekly
tb_pm200_cr7_weekly
tb_pm200_cr8_weekly
tb_pm200_cr9_weekly
tb_pm200_cr10_weekly
tb_pm200_cr11_weekly
tb_pm200_cr12_weekly

tb_pm220_cr1_weekly
tb_pm220_cr2_weekly
tb_pm220_cr3_weekly
tb_pm220_cr4_weekly
tb_pm220_cr5_weekly
tb_pm220_cr6_weekly
tb_pm220_cr7_weekly
tb_pm220_cr8_weekly
tb_pm220_cr9_weekly
tb_pm220_cr10_weekly
tb_pm220_cr11_weekly
tb_pm220_cr12_weekly

tb_pm220_ct_weekly
tb_pm220_hla_weekly
tb_pm220_lpf3_weekly
tb_pm220_ra_weekly
tb_pm220_ret_weekly




//  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>




tb_pm200_bs1_monthly
tb_pm200_bs2_monthly
tb_pm200_cc1_monthly
tb_pm200_cc234_monthly
tb_pm200_chab_monthly
tb_pm200_chcd_monthly
tb_pm200_chef_monthly
tb_pm200_chsaa_monthly
tb_pm200_chsab_monthly
tb_pm200_chsac_monthly
tb_pm200_conn_monthly

tb_pm200_ct_monthly
tb_pm200_hla_monthly
tb_pm200_ra_monthly
tb_pm200_ret_monthly
tb_pm200_weng_monthly

tb_pm220_bs1_monthly
tb_pm220_bs2_monthly
tb_pm220_cc1_monthly
tb_pm220_cc234_monthly
tb_pm220_chab_monthly
tb_pm220_chcd_monthly
tb_pm220_chef_monthly
tb_pm220_chsaa_monthly
tb_pm220_chsab_monthly
tb_pm220_chsac_monthly
tb_pm220_conn_monthly

tb_pm200_cr1_monthly
tb_pm200_cr2_monthly
tb_pm200_cr3_monthly
tb_pm200_cr4_monthly
tb_pm200_cr5_monthly
tb_pm200_cr6_monthly
tb_pm200_cr7_monthly
tb_pm200_cr8_monthly
tb_pm200_cr9_monthly
tb_pm200_cr10_monthly
tb_pm200_cr11_monthly
tb_pm200_cr12_monthly

tb_pm220_cr1_monthly
tb_pm220_cr2_monthly
tb_pm220_cr3_monthly
tb_pm220_cr4_monthly
tb_pm220_cr5_monthly
tb_pm220_cr6_monthly
tb_pm220_cr7_monthly
tb_pm220_cr8_monthly
tb_pm220_cr9_monthly
tb_pm220_cr10_monthly
tb_pm220_cr11_monthly
tb_pm220_cr12_monthly

tb_pm220_ct_monthly
tb_pm220_hla_monthly
tb_pm220_lpf3_monthly
tb_pm220_ra_monthly
tb_pm220_ret_monthly





//  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>





tb_pm200_bs1_yearly
tb_pm200_bs2_yearly
tb_pm200_cc1_yearly
tb_pm200_cc234_yearly
tb_pm200_chab_yearly
tb_pm200_chcd_yearly
tb_pm200_chef_yearly
tb_pm200_chsaa_yearly
tb_pm200_chsab_yearly
tb_pm200_chsac_yearly
tb_pm200_conn_yearly

tb_pm200_ct_yearly
tb_pm200_hla_yearly
tb_pm200_ra_yearly
tb_pm200_ret_yearly
tb_pm200_weng_yearly

tb_pm220_bs1_yearly
tb_pm220_bs2_yearly
tb_pm220_cc1_yearly
tb_pm220_cc234_yearly
tb_pm220_chab_yearly
tb_pm220_chcd_yearly
tb_pm220_chef_yearly
tb_pm220_chsaa_yearly
tb_pm220_chsab_yearly
tb_pm220_chsac_yearly
tb_pm220_conn_yearly

tb_pm200_cr1_yearly
tb_pm200_cr2_yearly
tb_pm200_cr3_yearly
tb_pm200_cr4_yearly
tb_pm200_cr5_yearly
tb_pm200_cr6_yearly
tb_pm200_cr7_yearly
tb_pm200_cr8_yearly
tb_pm200_cr9_yearly
tb_pm200_cr10_yearly
tb_pm200_cr11_yearly
tb_pm200_cr12_yearly

tb_pm220_cr1_yearly
tb_pm220_cr2_yearly
tb_pm220_cr3_yearly
tb_pm220_cr4_yearly
tb_pm220_cr5_yearly
tb_pm220_cr6_yearly
tb_pm220_cr7_yearly
tb_pm220_cr8_yearly
tb_pm220_cr9_yearly
tb_pm220_cr10_yearly
tb_pm220_cr11_yearly
tb_pm220_cr12_yearly

tb_pm220_ct_yearly
tb_pm220_hla_yearly
tb_pm220_lpf3_yearly
tb_pm220_ra_yearly
tb_pm220_ret_yearly






// ===========================================




tb_pm_daily_report
tb_pm_hourly_report
tb_pm_monthly_kub_report
tb_pm_monthly_report
tb_pm_shiftly_kub_report
tb_pm_shiftly_report
tb_pm_weekly_report