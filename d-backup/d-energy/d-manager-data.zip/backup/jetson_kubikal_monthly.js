const mysql = require("mysql2/promise");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

// Konfigurasi database
const dbConfigSource = {
  host: "192.168.137.131",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_master",
};

const dbConfigTarget = {
  host: "172.27.63.180",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_core",
};

// Pool source dan target
const sourcePool = mysql.createPool({
  ...dbConfigSource,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const targetPool = mysql.createPool({
  ...dbConfigTarget,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Daftar tabel sumber
const lineTables = [
  { pm_type: "DA_01", line_table: "tb_kub1_total_kwh", line_name: "kubikal_1" },
];

/**
 * Konversi value ke number aman
 */
function toNumber(value) {
  if (value === null || value === undefined) return null;

  const cleaned = String(value).replace(/,/g, "").trim();
  const num = Number(cleaned);

  return Number.isFinite(num) ? num : null;
}

async function rekapBulanan() {
  const sourceConn = await sourcePool.getConnection();
  const targetConn = await targetPool.getConnection();

  try {
    await targetConn.beginTransaction();

    for (const line of lineTables) {
      console.log(`\n🔍 Proses: ${line.line_table}`);

      // Ambil semua kombinasi bulan-tahun unik dari database sumber
      const [periode] = await sourceConn.query(`
        SELECT DISTINCT
          YEAR(date_time) AS year_num,
          MONTH(date_time) AS month_num
        FROM ${line.line_table}
        WHERE date_time IS NOT NULL
        ORDER BY year_num ASC, month_num ASC
      `);

      for (const { year_num, month_num } of periode) {
        const baseDate = moment({
          year: Number(year_num),
          month: Number(month_num) - 1,
          date: 1,
        });

        const monthName = baseDate.format("MMMM");
        const yearStr = String(year_num);

        // Ambil data awal bulan dari source
        const [awal] = await sourceConn.query(
          `
          SELECT date_time, value
          FROM ${line.line_table}
          WHERE YEAR(date_time) = ? AND MONTH(date_time) = ?
          ORDER BY date_time ASC
          LIMIT 1
          `,
          [year_num, month_num]
        );

        // Ambil data akhir bulan dari source
        const [akhir] = await sourceConn.query(
          `
          SELECT date_time, value
          FROM ${line.line_table}
          WHERE YEAR(date_time) = ? AND MONTH(date_time) = ?
          ORDER BY date_time DESC
          LIMIT 1
          `,
          [year_num, month_num]
        );

        if (!awal.length || !akhir.length) {
          console.log(`⏭️ Lewati ${monthName} ${yearStr} (data tidak lengkap)`);
          continue;
        }

        const startDatetime = awal[0].date_time;
        const endDatetime = akhir[0].date_time;

        const startWhNum = toNumber(awal[0].value);
        const lastWhNum = toNumber(akhir[0].value);

        if (startWhNum === null || lastWhNum === null) {
          console.log(`⚠️ Nilai tidak valid pada ${monthName} ${yearStr}`);
          continue;
        }

        const totalWhNum = Number((lastWhNum - startWhNum).toFixed(3));

        // Karena kolom target masih varchar
        const startWh = String(startWhNum);
        const lastWh = String(lastWhNum);
        const totalWh = String(totalWhNum);

        // Cek data existing di database target
        const [cek] = await targetConn.query(
          `
          SELECT pm_type, line_table, month, year
          FROM tb_pm_monthly_kub_report
          WHERE pm_type = ?
            AND line_table = ?
            AND month = ?
            AND year = ?
          LIMIT 1
          `,
          [line.pm_type, line.line_table, monthName, yearStr]
        );

        if (!cek.length) {
          // INSERT ke target
          await targetConn.query(
            `
            INSERT INTO tb_pm_monthly_kub_report (
              pm_type,
              line_table,
              line_name,
              start_datetime,
              end_datetime,
              start_wh,
              last_wh,
              total_wh,
              month,
              year,
              created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            `,
            [
              line.pm_type,
              line.line_table,
              line.line_name,
              startDatetime,
              endDatetime,
              startWh,
              lastWh,
              totalWh,
              monthName,
              yearStr,
            ]
          );

          console.log(`✅ Insert: ${monthName} ${yearStr} (${totalWh} Wh)`);
        } else {
          // UPDATE ke target
          await targetConn.query(
            `
            UPDATE tb_pm_monthly_kub_report
            SET
              line_name = ?,
              start_datetime = ?,
              end_datetime = ?,
              start_wh = ?,
              last_wh = ?,
              total_wh = ?
            WHERE pm_type = ?
              AND line_table = ?
              AND month = ?
              AND year = ?
            `,
            [
              line.line_name,
              startDatetime,
              endDatetime,
              startWh,
              lastWh,
              totalWh,
              line.pm_type,
              line.line_table,
              monthName,
              yearStr,
            ]
          );

          console.log(`♻️ Update: ${monthName} ${yearStr} (${totalWh} Wh)`);
        }
      }
    }

    await targetConn.commit();
    console.log("\n🎉 Rekap bulanan selesai tanpa duplikasi.");
  } catch (err) {
    await targetConn.rollback();
    console.error("❌ Error:", err);
    throw err;
  } finally {
    sourceConn.release();
    targetConn.release();
  }
}

async function runRekapBulanan() {
  try {
    await rekapBulanan();
    console.log("✅ Program selesai dijalankan");
    process.exit(0);
  } catch (error) {
    console.error("❌ Program gagal:", error);
    process.exit(1);
  }
}

if (require.main === module) {
  runRekapBulanan();
}

module.exports = { rekapBulanan };