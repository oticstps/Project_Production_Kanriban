

const db = require('../../config/db_core'); // Sesuaikan path jika perlu

const tables = [
  'tb_kub1_total_kwh',
  'tb_area_cr1cr2',
  'tb_kub1_active_power',
  'tb_kub2_panel63',
  'tb_kub2_panel64',
  'tb_kub2_panel_1_total_kwh',
  'tb_kub2_panel_2_total_kwh',
  'tb_kub_panel_20_wh',
  'tb_kub_panel_16_wh',
  'tb_kub_panel_17_wh',
  'tb_kub_comp_19',
  'tb_kub_comp_21',
  'tb_kub_comp_24',
  'tb_lpdmtc',
  'tb_lpf1',
  'tb_lpf2',
  'tb_lpqad',
  'tb_lpsec',
  'tb_lputils',
  'tb_lp_dmtc',
  'tb_pm200_bs1',
  'tb_pm200_bs2',
  'tb_pm200_cc1',
  'tb_pm200_cc234',
  'tb_pm200_chab',
  'tb_pm200_chcd',
  'tb_pm200_chef',
  'tb_pm200_chsaa',
  'tb_pm200_chsab',
  'tb_pm200_chsac',
  'tb_pm200_conn',
  'tb_pm200_cr1',
  'tb_pm200_cr2',
  'tb_pm200_cr3',
  'tb_pm200_cr4',
  'tb_pm200_cr5',
  'tb_pm200_cr6',
  'tb_pm200_cr7',
  'tb_pm200_cr8',
  'tb_pm200_cr9',
  'tb_pm200_cr10',
  'tb_pm200_cr11',
  'tb_pm200_cr12',
  'tb_pm200_ct',
  'tb_pm200_hla',
  'tb_pm200_ra',
  'tb_pm200_ret',
  'tb_pm200_weng',
  'tb_pm220_bs1',
  'tb_pm220_bs2',
  'tb_pm220_cc1',
  'tb_pm220_cc234',
  'tb_pm220_chab',
  'tb_pm220_chcd',
  'tb_pm220_chef',
  'tb_pm220_chsaa',
  'tb_pm220_chsab',
  'tb_pm220_chsac',
  'tb_pm220_conn',
  'tb_pm220_cr1',
  'tb_pm220_cr2',
  'tb_pm220_cr3',
  'tb_pm220_cr4',
  'tb_pm220_cr5',
  'tb_pm220_cr6',
  'tb_pm220_cr7',
  'tb_pm220_cr8',
  'tb_pm220_cr9',
  'tb_pm220_cr10',
  'tb_pm220_cr11',
  'tb_pm220_cr12',
  'tb_pm220_ct',
  'tb_pm220_hla',
  'tb_pm220_lpf3',
  'tb_pm220_ra',
  'tb_pm220_ret'
];

const SNAPSHOT_TABLE = 'tb_energy_snapshot';
const FIXED_ID = 1; // ID tetap untuk baris snapshot tunggal


const valueColumnMap = {
  // Tabel area / LP (menggunakan total_energy)
  'tb_area_cr1cr2': 'total_energy',
  'tb_lpdmtc': 'total_energy',
  'tb_lpf1': 'total_energy',
  'tb_lpf2': 'total_energy',
  'tb_lpqad': 'total_energy',
  'tb_lpsec': 'total_energy',
  'tb_lputils': 'total_energy',
  'tb_lp_dmtc': 'total_energy',
  // Tabel kompresor (menggunakan wh)
  'tb_kub_comp_19': 'wh',
  'tb_kub_comp_21': 'wh',
  'tb_kub_comp_24': 'wh',
  'tb_kub_panel_20_wh': 'wh',
  'tb_kub_panel_16_wh': 'wh',
  'tb_kub_panel_17_wh': 'wh'
};

/**
 * Membuat tabel snapshot jika belum ada.
 * Semua kolom nilai menggunakan tipe TEXT untuk menghindari batasan ukuran baris.
 */
async function createSnapshotTable() {
  const columnDefinitions = tables.map(table => `\`${table}_value\` TEXT NULL`).join(',\n  ');
  
  const createSQL = `
    CREATE TABLE IF NOT EXISTS \`${SNAPSHOT_TABLE}\` (
      id INT AUTO_INCREMENT PRIMARY KEY,
      snapshot_time DATETIME NOT NULL,
      ${columnDefinitions}
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `;

  await db.query(createSQL);
  console.log(`✅ Tabel ${SNAPSHOT_TABLE} siap (jika belum ada).`);
}

/**
 * Mengambil nilai terbaru dari semua tabel berdasarkan kolom yang sesuai.
 * Mengembalikan objek dengan key = nama_tabel, value = nilai (string) atau null.
 */
async function getLatestValues() {
  const results = {};

  for (const table of tables) {
    // Tentukan kolom yang akan diambil (default 'value')
    const column = valueColumnMap[table] || 'value';
    
    try {
      // Gunakan alias 'nilai' agar mudah diakses
      const [rows] = await db.query(
        `SELECT ${column} AS nilai FROM \`${table}\` ORDER BY date_time DESC LIMIT 1`
      );
      results[table] = rows.length > 0 ? rows[0].nilai : null;
    } catch (err) {
      console.error(`❌ Gagal membaca tabel ${table}:`, err.message);
      results[table] = null;
    }
  }

  return results;
}

/**
 * Memperbarui (upsert) baris snapshot dengan data terbaru.
 * Menggunakan id tetap = ${FIXED_ID}. Jika belum ada, akan di-INSERT.
 */
async function upsertSnapshot(values) {
  const now = new Date().toISOString().slice(0, 19).replace('T', ' '); // format MySQL DATETIME

  // Kolom yang akan diisi (termasuk id dan snapshot_time)
  const columns = ['id', 'snapshot_time', ...tables.map(t => `\`${t}_value\``)];
  
  // Placeholder untuk prepared statement
  const placeholders = columns.map(() => '?').join(', ');

  // Nilai untuk baris baru: [FIXED_ID, now, ...nilai_per_tabel]
  const insertValues = [FIXED_ID, now, ...tables.map(t => values[t])];

  // Bagian UPDATE dari ON DUPLICATE KEY UPDATE (semua kolom kecuali id)
  const updateAssignments = columns
    .filter(col => col !== 'id')
    .map(col => `${col} = VALUES(${col})`)
    .join(', ');

  const upsertSQL = `
    INSERT INTO \`${SNAPSHOT_TABLE}\` (${columns.join(', ')})
    VALUES (${placeholders})
    ON DUPLICATE KEY UPDATE ${updateAssignments}
  `;

  await db.query(upsertSQL, insertValues);
  console.log(`✅ Snapshot berhasil diperbarui pada ${now} (id = ${FIXED_ID})`);
}

/**
 * Fungsi utama
 */
(async () => {
  try {
    // 1. Pastikan tabel snapshot ada
    await createSnapshotTable();

    // 2. Ambil nilai terbaru dari semua tabel
    console.log('📡 Mengambil data terbaru dari semua tabel...');
    const latest = await getLatestValues();

    // 3. Lakukan upsert dengan id tetap
    await upsertSnapshot(latest);
  } catch (err) {
    console.error('❌ Gagal menjalankan skrip:', err);
    process.exit(1);
  } finally {
    if (db && typeof db.end === 'function') {
      await db.end();
    }
  }
})();