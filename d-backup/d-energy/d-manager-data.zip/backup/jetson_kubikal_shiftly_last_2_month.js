const mysql = require("mysql2/promise");
const moment = require("moment-timezone");

// =====================================================
// KONFIGURASI UMUM
// =====================================================

const TIMEZONE = "Asia/Jakarta";
const LOOKBACK_MONTHS = 2;

moment.tz.setDefault(TIMEZONE);
// moment.locale("id"); // Aktifkan jika sudah menginstal locale Indonesia

// =====================================================
// KONFIGURASI DATABASE SUMBER
// =====================================================

const dbConfigSource = {
  host: "192.168.137.131",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_energy_listrik",
  timezone: "+07:00",
  dateStrings: true,
};

// =====================================================
// KONFIGURASI DATABASE TARGET
// =====================================================

const dbConfigTarget = {
  host: "172.27.63.180",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_master",
  timezone: "+07:00",
  dateStrings: true,
};

// =====================================================
// CONNECTION POOL
// =====================================================

const sourcePool = mysql.createPool({
  ...dbConfigSource,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const targetPool = mysql.createPool({
  ...dbConfigTarget,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// =====================================================
// DAFTAR TABEL SUMBER
// =====================================================

const lineTables = [
  {
    pm_type: "DA_01",
    line_table: "tb_kub1_total_kwh",
    line_name: "kubikal_1",
  },
];

// =====================================================
// FUNGSI KONVERSI NILAI
// =====================================================

/**
 * Mengubah value menjadi number dengan aman.
 *
 * Contoh:
 * "1,234.56" menjadi 1234.56
 * null menjadi null
 */
function toNumber(value) {
  if (value === null || value === undefined) {
    return null;
  }

  const cleaned = String(value)
    .replace(/,/g, "")
    .trim();

  const numberValue = Number(cleaned);

  return Number.isFinite(numberValue)
    ? numberValue
    : null;
}

// =====================================================
// FUNGSI VALIDASI NAMA TABEL
// =====================================================

/**
 * Validasi sederhana untuk memastikan nama tabel hanya
 * mengandung huruf, angka, dan underscore.
 *
 * Nama tabel tidak dapat menggunakan parameter query (?),
 * sehingga perlu divalidasi sebelum dimasukkan ke SQL.
 */
function validateTableName(tableName) {
  const tableNamePattern = /^[a-zA-Z0-9_]+$/;

  if (!tableNamePattern.test(tableName)) {
    throw new Error(`Nama tabel tidak valid: ${tableName}`);
  }

  return tableName;
}

// =====================================================
// PROSES REKAP SHIFTLY
// =====================================================

async function rekapShiftly() {
  let sourceConn;
  let targetConn;

  try {
    sourceConn = await sourcePool.getConnection();
    targetConn = await targetPool.getConnection();

    await targetConn.beginTransaction();

    /*
     * Periode dua bulan terakhir secara berjalan.
     *
     * Contoh:
     * Tanggal eksekusi : 2026-07-03
     * Tanggal awal     : 2026-05-03 00:00:00
     * Tanggal akhir    : 2026-07-04 00:00:00
     *
     * periodEnd dibuat besok pukul 00:00 agar seluruh
     * data hari ini tetap ikut diproses.
     */
    const currentDate = moment.tz(TIMEZONE);

    const periodStart = currentDate
      .clone()
      .subtract(LOOKBACK_MONTHS, "months")
      .startOf("day");

    const periodEnd = currentDate
      .clone()
      .add(1, "day")
      .startOf("day");

    console.log("==============================================");
    console.log("REKAPITULASI KWH SHIFTLY");
    console.log("==============================================");
    console.log(`Zona waktu    : ${TIMEZONE}`);
    console.log(`Tanggal proses: ${currentDate.format("YYYY-MM-DD HH:mm:ss")}`);
    console.log(`Periode awal  : ${periodStart.format("YYYY-MM-DD HH:mm:ss")}`);
    console.log(`Periode akhir : ${periodEnd.format("YYYY-MM-DD HH:mm:ss")}`);
    console.log("==============================================");

    for (const line of lineTables) {
      const tableName = validateTableName(line.line_table);

      console.log(`\n🔍 Memproses tabel: ${tableName}`);
      console.log(`   PM Type        : ${line.pm_type}`);
      console.log(`   Line Name      : ${line.line_name}`);

      // Ambil tanggal unik hanya dalam periode dua bulan terakhir
      const [periode] = await sourceConn.query(
        `
          SELECT DISTINCT
            DATE(date_time) AS shift_date
          FROM ${tableName}
          WHERE date_time IS NOT NULL
            AND date_time >= ?
            AND date_time < ?
          ORDER BY shift_date ASC
        `,
        [
          periodStart.format("YYYY-MM-DD HH:mm:ss"),
          periodEnd.format("YYYY-MM-DD HH:mm:ss"),
        ]
      );

      if (!periode.length) {
        console.log(
          `⚠️ Tidak ditemukan data pada ${tableName} dalam periode tersebut.`
        );
        continue;
      }

      console.log(`📊 Jumlah tanggal ditemukan: ${periode.length}`);

      for (const row of periode) {
        /*
         * dateStrings: true memastikan shift_date diterima
         * sebagai string YYYY-MM-DD dan tidak bergeser
         * karena konversi zona waktu JavaScript.
         */
        const baseDate = moment.tz(
          row.shift_date,
          "YYYY-MM-DD",
          TIMEZONE
        ).startOf("day");

        if (!baseDate.isValid()) {
          console.warn(
            `⚠️ Tanggal tidak valid dan dilewati: ${row.shift_date}`
          );
          continue;
        }

        const year = baseDate.year();
        const month = baseDate.month() + 1;
        const day = baseDate.date();
        const monthName = baseDate.format("MMMM");
        const dayName = baseDate.format("dddd");

        const shifts = [
          {
            shift: "shift_1",
            start: baseDate
              .clone()
              .hour(7)
              .minute(10)
              .second(0)
              .millisecond(0),

            end: baseDate
              .clone()
              .hour(19)
              .minute(50)
              .second(0)
              .millisecond(0),
          },
          {
            shift: "shift_2",
            start: baseDate
              .clone()
              .hour(19)
              .minute(50)
              .second(0)
              .millisecond(0),

            end: baseDate
              .clone()
              .add(1, "day")
              .hour(7)
              .minute(10)
              .second(0)
              .millisecond(0),
          },
        ];

        for (const item of shifts) {
          const shiftData = await getShiftData(
            sourceConn,
            tableName,
            item.start,
            item.end
          );

          if (!shiftData) {
            console.log(
              `⏭️ Lewati ${item.shift} - ` +
              `${baseDate.format("YYYY-MM-DD")} ` +
              `(data tidak tersedia atau tidak valid)`
            );

            continue;
          }

          await upsertShiftReport(targetConn, {
            pm_type: line.pm_type,
            line_table: line.line_table,
            line_name: line.line_name,

            shift: item.shift,
            shift_date: baseDate.format("YYYY-MM-DD"),

            shift_start_datetime: shiftData.startDatetime,
            shift_end_datetime: shiftData.endDatetime,

            start_kwh: shiftData.startValue,
            end_kwh: shiftData.endValue,
            total_kwh: shiftData.totalValue,

            year,
            month,
            month_name: monthName,
            day,
            day_name: dayName,
          });
        }
      }
    }

    await targetConn.commit();

    console.log("\n==============================================");
    console.log("🎉 Rekap shiftly selesai tanpa duplikasi.");
    console.log("==============================================");
  } catch (error) {
    if (targetConn) {
      try {
        await targetConn.rollback();
        console.log("↩️ Transaksi database target dibatalkan.");
      } catch (rollbackError) {
        console.error(
          "❌ Gagal melakukan rollback:",
          rollbackError.message
        );
      }
    }

    console.error("❌ Error proses rekap shiftly:", error);
    throw error;
  } finally {
    if (sourceConn) {
      sourceConn.release();
    }

    if (targetConn) {
      targetConn.release();
    }
  }
}

// =====================================================
// AMBIL DATA AWAL DAN AKHIR SHIFT
// =====================================================

/**
 * Mengambil data pertama dan data terakhir dalam
 * rentang waktu shift.
 */
async function getShiftData(
  sourceConn,
  tableName,
  startTime,
  endTime
) {
  const validTableName = validateTableName(tableName);

  const startStr = startTime.format("YYYY-MM-DD HH:mm:ss");
  const endStr = endTime.format("YYYY-MM-DD HH:mm:ss");

  // Ambil data paling awal dalam rentang shift
  const [startRows] = await sourceConn.query(
    `
      SELECT
        date_time,
        value
      FROM ${validTableName}
      WHERE date_time >= ?
        AND date_time < ?
        AND value IS NOT NULL
      ORDER BY date_time ASC
      LIMIT 1
    `,
    [startStr, endStr]
  );

  // Ambil data paling akhir dalam rentang shift
  const [endRows] = await sourceConn.query(
    `
      SELECT
        date_time,
        value
      FROM ${validTableName}
      WHERE date_time >= ?
        AND date_time < ?
        AND value IS NOT NULL
      ORDER BY date_time DESC
      LIMIT 1
    `,
    [startStr, endStr]
  );

  if (!startRows.length || !endRows.length) {
    return null;
  }

  const startValue = toNumber(startRows[0].value);
  const endValue = toNumber(endRows[0].value);

  if (startValue === null || endValue === null) {
    console.warn(
      `⚠️ Nilai KWH tidak valid pada ${validTableName} ` +
      `antara ${startStr} sampai ${endStr}`
    );

    return null;
  }

  /*
   * Meter KWH kumulatif seharusnya memiliki nilai akhir
   * lebih besar atau sama dengan nilai awal.
   */
  if (endValue < startValue) {
    console.warn(
      `⚠️ Nilai akhir lebih kecil dari nilai awal pada ${validTableName}. ` +
      `Periode: ${startStr} sampai ${endStr}. ` +
      `Start: ${startValue}, End: ${endValue}`
    );

    return null;
  }

  const totalValue = Number(
    (endValue - startValue).toFixed(3)
  );

  return {
    startDatetime: startRows[0].date_time,
    endDatetime: endRows[0].date_time,
    startValue,
    endValue,
    totalValue,
  };
}

// =====================================================
// INSERT ATAU UPDATE DATA TARGET
// =====================================================

/**
 * Menyimpan laporan shift ke database target.
 *
 * Kunci pemeriksaan:
 * - pm_type
 * - line_table
 * - shift
 * - shift_date
 */
async function upsertShiftReport(targetConn, data) {
  const [existing] = await targetConn.query(
    `
      SELECT
        pm_type,
        line_table,
        shift,
        shift_date
      FROM tb_pm_shiftly_kub_report
      WHERE pm_type = ?
        AND line_table = ?
        AND shift = ?
        AND shift_date = ?
      LIMIT 1
    `,
    [
      data.pm_type,
      data.line_table,
      data.shift,
      data.shift_date,
    ]
  );

  if (!existing.length) {
    await targetConn.query(
      `
        INSERT INTO tb_pm_shiftly_kub_report (
          pm_type,
          line_table,
          line_name,
          shift,
          shift_date,
          shift_start_datetime,
          shift_end_datetime,
          start_kwh,
          end_kwh,
          total_kwh,
          year,
          month,
          month_name,
          day,
          day_name,
          created_at,
          updated_at
        ) VALUES (
          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, NOW(), NOW()
        )
      `,
      [
        data.pm_type,
        data.line_table,
        data.line_name,
        data.shift,
        data.shift_date,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name,
      ]
    );

    console.log(
      `✅ Insert ${data.shift} - ${data.shift_date} ` +
      `(${data.total_kwh.toFixed(3)} KWH)`
    );

    return;
  }

  await targetConn.query(
    `
      UPDATE tb_pm_shiftly_kub_report
      SET
        line_name = ?,
        shift_start_datetime = ?,
        shift_end_datetime = ?,
        start_kwh = ?,
        end_kwh = ?,
        total_kwh = ?,
        year = ?,
        month = ?,
        month_name = ?,
        day = ?,
        day_name = ?,
        updated_at = NOW()
      WHERE pm_type = ?
        AND line_table = ?
        AND shift = ?
        AND shift_date = ?
    `,
    [
      data.line_name,
      data.shift_start_datetime,
      data.shift_end_datetime,
      data.start_kwh,
      data.end_kwh,
      data.total_kwh,
      data.year,
      data.month,
      data.month_name,
      data.day,
      data.day_name,

      data.pm_type,
      data.line_table,
      data.shift,
      data.shift_date,
    ]
  );

  console.log(
    `♻️ Update ${data.shift} - ${data.shift_date} ` +
    `(${data.total_kwh.toFixed(3)} KWH)`
  );
}

// =====================================================
// MENJALANKAN PROGRAM
// =====================================================

async function runRekapShiftly() {
  try {
    await rekapShiftly();

    console.log("✅ Program selesai dijalankan.");
    process.exitCode = 0;
  } catch (error) {
    console.error("❌ Program gagal:", error.message);
    process.exitCode = 1;
  } finally {
    /*
     * Menutup pool agar aplikasi dapat berhenti
     * dengan bersih setelah seluruh proses selesai.
     */
    try {
      await sourcePool.end();
    } catch (error) {
      console.error(
        "⚠️ Gagal menutup source pool:",
        error.message
      );
    }

    try {
      await targetPool.end();
    } catch (error) {
      console.error(
        "⚠️ Gagal menutup target pool:",
        error.message
      );
    }
  }
}

if (require.main === module) {
  runRekapShiftly();
}

module.exports = {
  rekapShiftly,
  getShiftData,
  upsertShiftReport,
};