const pool = require("../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

const CONFIG = {
    pm_type: "POWER METER PUSAT",
    source_table: "tb_kub1_total_kwh",
    target_table: "tb_kub1_monthly",
};

function toNumber(value) {
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
}

async function getPowerMeters(connection) {
    const [rows] = await connection.query(`
        SELECT DISTINCT power_meter
        FROM ${CONFIG.source_table}
        WHERE power_meter IS NOT NULL
          AND TRIM(power_meter) <> ''
        ORDER BY power_meter ASC
    `);

    return rows.map(row => row.power_meter);
}

async function getMonthlyData(connection, powerMeter, year, month) {
    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND YEAR(date_time) = ?
          AND MONTH(date_time) = ?
        ORDER BY date_time ASC
        LIMIT 1
    `, [powerMeter, year, month]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND YEAR(date_time) = ?
          AND MONTH(date_time) = ?
        ORDER BY date_time DESC
        LIMIT 1
    `, [powerMeter, year, month]);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = toNumber(startRow[0].value);
    const endValue = toNumber(endRow[0].value);

    if (startValue === null || endValue === null) {
        return null;
    }

    const totalValue = endValue - startValue;

    if (totalValue <= 0) {
        return null;
    }

    return {
        month_start_date: moment(startRow[0].date_time).format("YYYY-MM-DD"),
        month_end_date: moment(endRow[0].date_time).format("YYYY-MM-DD"),
        startDatetime: startRow[0].date_time,
        endDatetime: endRow[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertMonthly(connection, payload) {
    await connection.query(`
        INSERT INTO ${CONFIG.target_table} (
            pm_type,
            line_table,
            line_name,
            year,
            month,
            month_name,
            month_start_date,
            month_end_date,
            start_datetime,
            end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            month_name = VALUES(month_name),
            month_start_date = VALUES(month_start_date),
            month_end_date = VALUES(month_end_date),
            start_datetime = VALUES(start_datetime),
            end_datetime = VALUES(end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            updated_at = NOW()
    `, [
        payload.pm_type,
        payload.line_table,
        payload.line_name,
        payload.year,
        payload.month,
        payload.month_name,
        payload.month_start_date,
        payload.month_end_date,
        payload.start_datetime,
        payload.end_datetime,
        payload.start_kwh,
        payload.end_kwh,
        payload.total_kwh
    ]);
}

async function rekapMonthly() {
    const connection = await pool.getConnection();

    try {
        const powerMeters = await getPowerMeters(connection);

        for (const powerMeter of powerMeters) {
            console.log(`\n🔍 Proses monthly power meter: ${powerMeter}`);

            const [periods] = await connection.query(`
                SELECT DISTINCT
                    YEAR(date_time) AS year,
                    MONTH(date_time) AS month
                FROM ${CONFIG.source_table}
                WHERE power_meter = ?
                  AND date_time IS NOT NULL
                ORDER BY year ASC, month ASC
            `, [powerMeter]);

            for (const row of periods) {
                const monthlyData = await getMonthlyData(connection, powerMeter, row.year, row.month);

                if (!monthlyData) {
                    console.log(`⚠️ Skip ${powerMeter} | year=${row.year} | month=${row.month}`);
                    continue;
                }

                await upsertMonthly(connection, {
                    pm_type: CONFIG.pm_type,
                    line_table: CONFIG.source_table,
                    line_name: powerMeter,
                    year: row.year,
                    month: row.month,
                    month_name: moment(`${row.year}-${row.month}-01`, "YYYY-M-D").format("MMMM"),
                    month_start_date: monthlyData.month_start_date,
                    month_end_date: monthlyData.month_end_date,
                    start_datetime: monthlyData.startDatetime,
                    end_datetime: monthlyData.endDatetime,
                    start_kwh: monthlyData.startValue,
                    end_kwh: monthlyData.endValue,
                    total_kwh: monthlyData.totalValue
                });

                console.log(`✅ ${powerMeter} | year=${row.year} | month=${row.month} | ${monthlyData.totalValue} kWh`);
            }
        }

        console.log("\n🎉 Rekap kub_monthly selesai.");
    } catch (error) {
        console.error("❌ Error kub_monthly:", error);
    } finally {
        connection.release();
    }
}

rekapMonthly();