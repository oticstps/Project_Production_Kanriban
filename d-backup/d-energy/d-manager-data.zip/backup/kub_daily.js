const pool = require("../../config/db_core");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");

const CONFIG = {
    pm_type: "POWER METER PUSAT",
    source_table: "tb_kub1_total_kwh",
    target_table: "tb_kub1_daily",
};

function toNumber(value) {
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
}

async function getPowerMeters(connection) {
    const [rows] = await connection.query(`
        SELECT DISTINCT power_meter
        FROM ${CONFIG.source_table}
        WHERE power_meter IS NOT NULL
          AND TRIM(power_meter) <> ''
        ORDER BY power_meter ASC
    `);

    return rows.map(row => row.power_meter);
}

async function getDailyData(connection, powerMeter, startTime, endTime) {
    const params = [
        powerMeter,
        startTime.format("YYYY-MM-DD HH:mm:ss"),
        endTime.format("YYYY-MM-DD HH:mm:ss")
    ];

    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time >= ?
          AND date_time < ?
        ORDER BY date_time ASC
        LIMIT 1
    `, params);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time >= ?
          AND date_time < ?
        ORDER BY date_time DESC
        LIMIT 1
    `, params);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = toNumber(startRow[0].value);
    const endValue = toNumber(endRow[0].value);

    if (startValue === null || endValue === null) {
        return null;
    }

    const totalValue = endValue - startValue;

    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: startRow[0].date_time,
        endDatetime: endRow[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertDaily(connection, payload) {
    await connection.query(`
        INSERT INTO ${CONFIG.target_table} (
            pm_type,
            line_table,
            line_name,
            record_date,
            start_datetime,
            end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            week,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            start_datetime = VALUES(start_datetime),
            end_datetime = VALUES(end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            week = VALUES(week),
            updated_at = NOW()
    `, [
        payload.pm_type,
        payload.line_table,
        payload.line_name,
        payload.record_date,
        payload.start_datetime,
        payload.end_datetime,
        payload.start_kwh,
        payload.end_kwh,
        payload.total_kwh,
        payload.year,
        payload.month,
        payload.month_name,
        payload.day,
        payload.day_name,
        payload.week
    ]);
}

async function rekapDaily() {
    const connection = await pool.getConnection();

    try {
        const powerMeters = await getPowerMeters(connection);

        for (const powerMeter of powerMeters) {
            console.log(`\n🔍 Proses daily power meter: ${powerMeter}`);

            const [dates] = await connection.query(`
                SELECT DISTINCT
                    DATE(date_time) AS record_date,
                    YEAR(date_time) AS year,
                    MONTH(date_time) AS month,
                    DAY(date_time) AS day,
                    WEEK(date_time) AS week
                FROM ${CONFIG.source_table}
                WHERE power_meter = ?
                  AND date_time IS NOT NULL
                ORDER BY record_date ASC
            `, [powerMeter]);

            for (const row of dates) {
                const recordDate = moment(row.record_date).format("YYYY-MM-DD");
                const dateObj = moment(recordDate);

                const startTime = moment(recordDate).startOf("day");
                const endTime = moment(recordDate).add(1, "day").startOf("day");

                const dailyData = await getDailyData(connection, powerMeter, startTime, endTime);

                if (!dailyData) {
                    console.log(`⚠️ Skip ${powerMeter} | ${recordDate}`);
                    continue;
                }

                await upsertDaily(connection, {
                    pm_type: CONFIG.pm_type,
                    line_table: CONFIG.source_table,
                    line_name: powerMeter,
                    record_date: recordDate,
                    start_datetime: dailyData.startDatetime,
                    end_datetime: dailyData.endDatetime,
                    start_kwh: dailyData.startValue,
                    end_kwh: dailyData.endValue,
                    total_kwh: dailyData.totalValue,
                    year: row.year,
                    month: row.month,
                    month_name: dateObj.format("MMMM"),
                    day: row.day,
                    day_name: dateObj.format("dddd"),
                    week: row.week
                });

                console.log(`✅ ${powerMeter} | ${recordDate} | ${dailyData.totalValue} kWh`);
            }
        }

        console.log("\n🎉 Rekap kub_daily selesai.");
    } catch (error) {
        console.error("❌ Error kub_daily:", error);
    } finally {
        connection.release();
    }
}

rekapDaily();