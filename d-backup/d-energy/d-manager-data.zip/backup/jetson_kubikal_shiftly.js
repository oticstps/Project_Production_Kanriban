const mysql = require("mysql2/promise");
const moment = require("moment-timezone");

moment.tz.setDefault("Asia/Jakarta");
// moment.locale("id"); // aktifkan jika ingin nama hari/bulan Indonesia

// Konfigurasi database
const dbConfigSource = {
  host: "192.168.137.131",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_energy_listrik"
};

const dbConfigTarget = {
  host: "172.27.63.180",
  user: "otics_tps",
  password: "sukatno_ali",
  database: "database_tps_master"
};

// Pool source dan target
const sourcePool = mysql.createPool({
  ...dbConfigSource,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

const targetPool = mysql.createPool({
  ...dbConfigTarget,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Daftar tabel sumber
const lineTables = [
  { pm_type: "DA_01", line_table: "tb_kub1_total_kwh", line_name: "kubikal_1" },
];

/**
 * Konversi value menjadi number aman
 */
function toNumber(value) {
  if (value === null || value === undefined) return null;

  const cleaned = String(value).replace(/,/g, "").trim();
  const num = Number(cleaned);

  return Number.isFinite(num) ? num : null;
}

async function rekapShiftly() {
  const sourceConn = await sourcePool.getConnection();
  const targetConn = await targetPool.getConnection();

  try {
    await targetConn.beginTransaction();

    for (const line of lineTables) {
      console.log(`\n🔍 Proses shiftly: ${line.line_table}`);

      // Ambil tanggal unik dari database sumber
      const [periode] = await sourceConn.query(`
        SELECT DISTINCT DATE(date_time) AS shift_date
        FROM ${line.line_table}
        WHERE date_time IS NOT NULL
        ORDER BY shift_date ASC
      `);

      for (const row of periode) {
        const baseDate = moment(row.shift_date).startOf("day");

        const year = baseDate.year();
        const month = baseDate.month() + 1;
        const day = baseDate.date();
        const monthName = baseDate.format("MMMM");
        const dayName = baseDate.format("dddd");

        const shifts = [
          {
            shift: "shift_1",
            start: baseDate.clone().hour(7).minute(10).second(0).millisecond(0),
            end: baseDate.clone().hour(19).minute(50).second(0).millisecond(0),
          },
          {
            shift: "shift_2",
            start: baseDate.clone().hour(19).minute(50).second(0).millisecond(0),
            end: baseDate.clone().add(1, "day").hour(7).minute(10).second(0).millisecond(0),
          },
        ];

        for (const item of shifts) {
          const shiftData = await getShiftData(
            sourceConn,
            line.line_table,
            item.start,
            item.end
          );

          if (!shiftData) {
            console.log(
              `⏭️ Lewati ${item.shift} - ${baseDate.format("YYYY-MM-DD")} (data tidak lengkap)`
            );
            continue;
          }

          await upsertShiftReport(targetConn, {
            ...line,
            shift: item.shift,
            shift_date: baseDate.format("YYYY-MM-DD"),
            shift_start_datetime: shiftData.startDatetime,
            shift_end_datetime: shiftData.endDatetime,
            start_kwh: shiftData.startValue,
            end_kwh: shiftData.endValue,
            total_kwh: shiftData.totalValue,
            year,
            month,
            month_name: monthName,
            day,
            day_name: dayName,
          });
        }
      }
    }

    await targetConn.commit();
    console.log("\n🎉 Rekap shiftly selesai tanpa duplikasi.");
  } catch (err) {
    await targetConn.rollback();
    console.error("❌ Error:", err);
    throw err;
  } finally {
    sourceConn.release();
    targetConn.release();
  }
}

/**
 * Ambil data awal dan akhir dalam rentang shift dari database sumber
 */
async function getShiftData(sourceConn, tableName, startTime, endTime) {
  const startStr = startTime.format("YYYY-MM-DD HH:mm:ss");
  const endStr = endTime.format("YYYY-MM-DD HH:mm:ss");

  const [startRows] = await sourceConn.query(
    `
      SELECT date_time, value
      FROM ${tableName}
      WHERE date_time >= ? AND date_time < ?
      ORDER BY date_time ASC
      LIMIT 1
    `,
    [startStr, endStr]
  );

  const [endRows] = await sourceConn.query(
    `
      SELECT date_time, value
      FROM ${tableName}
      WHERE date_time >= ? AND date_time < ?
      ORDER BY date_time DESC
      LIMIT 1
    `,
    [startStr, endStr]
  );

  if (!startRows.length || !endRows.length) {
    return null;
  }

  const startValue = toNumber(startRows[0].value);
  const endValue = toNumber(endRows[0].value);

  if (startValue === null || endValue === null) {
    console.warn(`⚠️ Nilai tidak valid pada ${tableName} antara ${startStr} s.d. ${endStr}`);
    return null;
  }

  const totalValue = Number((endValue - startValue).toFixed(3));

  return {
    startDatetime: startRows[0].date_time,
    endDatetime: endRows[0].date_time,
    startValue,
    endValue,
    totalValue
  };
}

/**
 * Insert / Update ke database target tanpa idPrimary
 * Kunci unik: pm_type + line_table + shift + shift_date
 */
async function upsertShiftReport(targetConn, data) {
  const [existing] = await targetConn.query(
    `
      SELECT pm_type, line_table, shift, shift_date
      FROM tb_pm_shiftly_kub_report
      WHERE pm_type = ?
        AND line_table = ?
        AND shift = ?
        AND shift_date = ?
      LIMIT 1
    `,
    [data.pm_type, data.line_table, data.shift, data.shift_date]
  );

  if (!existing.length) {
    await targetConn.query(
      `
        INSERT INTO tb_pm_shiftly_kub_report (
          pm_type,
          line_table,
          line_name,
          shift,
          shift_date,
          shift_start_datetime,
          shift_end_datetime,
          start_kwh,
          end_kwh,
          total_kwh,
          year,
          month,
          month_name,
          day,
          day_name,
          created_at,
          updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      `,
      [
        data.pm_type,
        data.line_table,
        data.line_name,
        data.shift,
        data.shift_date,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name,
      ]
    );

    console.log(
      `✅ Insert ${data.shift} - ${data.shift_date} (${data.total_kwh.toFixed(3)} KWH)`
    );
  } else {
    await targetConn.query(
      `
        UPDATE tb_pm_shiftly_kub_report
        SET
          line_name = ?,
          shift_start_datetime = ?,
          shift_end_datetime = ?,
          start_kwh = ?,
          end_kwh = ?,
          total_kwh = ?,
          year = ?,
          month = ?,
          month_name = ?,
          day = ?,
          day_name = ?,
          updated_at = NOW()
        WHERE pm_type = ?
          AND line_table = ?
          AND shift = ?
          AND shift_date = ?
      `,
      [
        data.line_name,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name,
        data.pm_type,
        data.line_table,
        data.shift,
        data.shift_date,
      ]
    );

    console.log(
      `♻️ Update ${data.shift} - ${data.shift_date} (${data.total_kwh.toFixed(3)} KWH)`
    );
  }
}

async function runRekapShiftly() {
  try {
    await rekapShiftly();
    console.log("✅ Program selesai dijalankan");
    process.exit(0);
  } catch (error) {
    console.error("❌ Program gagal:", error);
    process.exit(1);
  }
}

if (require.main === module) {
  runRekapShiftly();
}

module.exports = { rekapShiftly };