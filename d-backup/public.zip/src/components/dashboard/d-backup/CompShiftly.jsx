import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import * as XLSX from 'xlsx';
import Layout from '../layout/Layout';

// ─── Konstanta ────────────────────────────────────────────────────────────────
const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92;

const AVAILABLE_LINES = [
  'BS1', 'BS2', 'CC1', 'CC234', 'CHAB', 'CHCD', 'CHEF',
  'CHSAA', 'CHSAB', 'CHSAC', 'CONN', 'CR1', 'CR10', 'CR11',
  'CR12', 'CR2', 'CR3', 'CR4', 'CR5', 'CR6', 'CR7', 'CR8',
  'CR9', 'CT', 'HLA', 'kubikal_1', 'panel_16', 'panel_17',
  'panel_19', 'panel_20', 'panel_21', 'panel_24', 'RA', 'RET',
];

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const YEARS = [2024, 2025, 2026];

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmt = (n) => Number(n || 0).toLocaleString('id-ID');
const fmtCurrency = (n) => `Rp ${Number(n || 0).toLocaleString('id-ID')}`;

// ─── Sub-components ───────────────────────────────────────────────────────────

const StatCard = ({ icon, label, value, color }) => (
  <div style={{
    background: '#fff',
    padding: '14px 16px',
    borderRadius: 10,
    boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
    borderTop: `3px solid ${color}`,
    display: 'flex',
    flexDirection: 'column',
    gap: 6,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: color, fontSize: 13, fontWeight: 600 }}>
      <span style={{ fontSize: 18 }}>{icon}</span>
      {label}
    </div>
    <div style={{ fontSize: 20, fontWeight: 700, color: '#1a202c' }}>{value}</div>
  </div>
);

const LoadingOverlay = () => (
  <div style={{
    position: 'absolute', inset: 0, zIndex: 20,
    background: 'rgba(255,255,255,0.82)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    borderRadius: 12,
    backdropFilter: 'blur(2px)',
  }}>
    <div style={{ textAlign: 'center' }}>
      <div style={{
        width: 44, height: 44,
        border: '4px solid #dbeafe',
        borderTopColor: '#3b82f6',
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
        margin: '0 auto 10px',
      }} />
      <span style={{ color: '#3b82f6', fontWeight: 600, fontSize: 14 }}>Memuat data...</span>
    </div>
  </div>
);

// ─── Main Component ───────────────────────────────────────────────────────────
const CompShiftly = () => {
  const now = new Date();
  const [shiftData, setShiftData]     = useState([]);
  const [loading, setLoading]         = useState(true);
  const [isFetching, setIsFetching]   = useState(false);
  const [error, setError]             = useState(null);
  const [displayMode, setDisplayMode] = useState('single');

  const [selectedMonth, setSelectedMonth] = useState(now.toLocaleString('en-US', { month: 'long' }));
  const [selectedYear, setSelectedYear]   = useState(now.getFullYear());
  const [selectedLine, setSelectedLine]   = useState('kubikal_1');

  // ── Fetch ────────────────────────────────────────────────────────────────────
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsFetching(true);
        setError(null);

        const response = await axios.get('/api/pm-shiftly-kwh');
        if (!response.data?.success) throw new Error('Invalid API response');

        let rawData = response.data.data || [];

        // Filter bulan & tahun
        rawData = rawData.filter(
          (item) => item.month_name === selectedMonth && parseInt(item.year) === selectedYear
        );

        if (selectedLine === 'semua') {
          // ── Mode ALL ────────────────────────────────────────────────────────
          const byDatePanel = {};
          rawData.forEach((item) => {
            const dateKey = `${item.day_name} ${item.day} ${item.month_name.slice(0, 3)}`;
            if (!byDatePanel[dateKey]) byDatePanel[dateKey] = {};
            const kwh = parseFloat(item.total_kwh) / 1000;
            byDatePanel[dateKey][item.line_name] = (byDatePanel[dateKey][item.line_name] || 0) + kwh;
          });

          const sortedDates = Object.keys(byDatePanel).sort((a, b) => {
            const parse = (s) => {
              const [, day, mon] = s.split(' ');
              return new Date(`${mon} ${day}, ${selectedYear}`);
            };
            return parse(a) - parse(b);
          });

          const chartData = sortedDates.map((dateKey) => {
            const dayData = byDatePanel[dateKey];
            let totalPanel = 0, kubikal1 = 0;
            Object.entries(dayData).forEach(([panel, value]) => {
              if (panel.toLowerCase() === 'kubikal_1') kubikal1 = value;
              else totalPanel += value;
            });
            return {
              date: dateKey,
              totalPanel: Math.round(totalPanel),
              kubikal1: Math.round(kubikal1),
              selisih: Math.round(kubikal1 - totalPanel),
              ...dayData,
            };
          });

          setShiftData(chartData);
          setDisplayMode('all');
        } else {
          // ── Mode SINGLE ─────────────────────────────────────────────────────
          const filtered = rawData.filter((item) => item.line_name === selectedLine);
          const groupedByDate = {};

          filtered.forEach((item) => {
            const dateKey = `${item.day_name} ${item.day} ${item.month_name.slice(0, 3)}`;
            const shiftKey = item.shift === 'shift_1' ? 'shift1' : 'shift2';
            if (!groupedByDate[dateKey]) {
              groupedByDate[dateKey] = { date: dateKey, shift1: 0, shift2: 0, records: [] };
            }
            const kwh = parseFloat(item.total_kwh) / 1000;
            groupedByDate[dateKey][shiftKey] += kwh;
            groupedByDate[dateKey].records.push({
              ...item,
              kwh: Math.round(kwh),
              cost: Math.round(kwh * COST_PER_KWH),
              co2Kg: Math.round(kwh * CO2_EMISSION_FACTOR),
            });
          });

          const sortedDates = Object.keys(groupedByDate).sort((a, b) => {
            const parse = (s) => {
              const [, day, mon] = s.split(' ');
              return new Date(`${mon} ${day}, ${selectedYear}`);
            };
            return parse(a) - parse(b);
          });

          const chartData = sortedDates.map((dateKey) => ({
            date: dateKey,
            shift1: Math.round(groupedByDate[dateKey].shift1),
            shift2: Math.round(groupedByDate[dateKey].shift2),
            records: groupedByDate[dateKey].records,
          }));

          setShiftData(chartData);
          setDisplayMode('single');
        }
      } catch (err) {
        console.error(err);
        setError('Gagal memuat data dari server. Periksa koneksi atau coba lagi.');
      } finally {
        setLoading(false);
        setIsFetching(false);
      }
    };

    fetchData();
  }, [selectedMonth, selectedYear, selectedLine]);

  // ── Export Excel ─────────────────────────────────────────────────────────────
  const exportToExcel = () => {
    const exportData = [];

    if (displayMode === 'single') {
      shiftData.forEach((day) => {
        day.records.forEach((record) => {
          exportData.push({
            Date: day.date,
            Shift: record.shift === 'shift_1' ? 'Shift 1' : 'Shift 2',
            Line: record.line_name,
            'Energy (kWh)': record.kwh,
            'Cost (IDR)': record.cost,
            'CO2 (kg)': record.co2Kg,
            Month: selectedMonth,
            Year: selectedYear,
          });
        });
      });
    } else {
      shiftData.forEach((day) => {
        exportData.push({
          Date: day.date,
          'Total Panel Lain (kWh)': day.totalPanel,
          'Kubikal 1 (kWh)': day.kubikal1,
          'Selisih (kWh)': day.selisih,
          Month: selectedMonth,
          Year: selectedYear,
        });
      });
    }

    const totalKubikal1  = shiftData.reduce((s, d) => s + (d.kubikal1  || 0), 0);
    const totalPanelLain = shiftData.reduce((s, d) => s + (d.totalPanel || 0), 0);

    exportData.push({}, {
      Date: 'TOTAL',
      'Total Panel Lain (kWh)': Math.round(totalPanelLain),
      'Kubikal 1 (kWh)':        Math.round(totalKubikal1),
      'Selisih (kWh)':          Math.round(totalKubikal1 - totalPanelLain),
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Energy Report');
    ws['!cols'] = [{ wch: 18 }, { wch: 22 }, { wch: 16 }, { wch: 16 }, { wch: 10 }, { wch: 8 }];
    XLSX.writeFile(wb, `Energy_${selectedLine}_${selectedMonth}_${selectedYear}.xlsx`);
  };

  // ── Statistik ────────────────────────────────────────────────────────────────
  let totalKwh = 0, totalShift1 = 0, totalShift2 = 0;
  let totalKubikal1 = 0, totalPanelLain = 0, selisihTotal = 0;
  let daysCount = shiftData.length;
  let avgDaily = 0, peakValue = 0, totalCost = 0, totalCo2 = 0;

  if (displayMode === 'single') {
    totalKwh    = shiftData.reduce((s, i) => s + i.shift1 + i.shift2, 0);
    totalShift1 = shiftData.reduce((s, i) => s + i.shift1, 0);
    totalShift2 = shiftData.reduce((s, i) => s + i.shift2, 0);
    avgDaily    = daysCount ? Math.round(totalKwh / daysCount) : 0;
    peakValue   = shiftData.length ? Math.max(...shiftData.map((d) => Math.max(d.shift1, d.shift2))) : 0;
    totalCost   = Math.round(totalKwh * COST_PER_KWH);
    totalCo2    = Math.round(totalKwh * CO2_EMISSION_FACTOR);
  } else {
    totalKubikal1  = shiftData.reduce((s, d) => s + (d.kubikal1  || 0), 0);
    totalPanelLain = shiftData.reduce((s, d) => s + (d.totalPanel || 0), 0);
    selisihTotal   = Math.round(totalKubikal1 - totalPanelLain);
    totalKwh       = totalKubikal1;
    avgDaily       = daysCount ? Math.round(totalKwh / daysCount) : 0;
    peakValue      = shiftData.length
      ? Math.max(...shiftData.map((d) => Math.max(d.kubikal1 || 0, d.totalPanel || 0)))
      : 0;
    totalCost = Math.round(totalKwh * COST_PER_KWH);
    totalCo2  = Math.round(totalKwh * CO2_EMISSION_FACTOR);
  }

  const statCards = displayMode === 'single'
    ? [
        { icon: '⚡', label: 'Total Energy',  value: `${fmt(totalKwh)} kWh`,    color: '#3b82f6' },
        { icon: '💰', label: 'Total Biaya',   value: fmtCurrency(totalCost),    color: '#f59e0b' },
        { icon: '📈', label: 'Rata-rata/Hari',value: `${fmt(avgDaily)} kWh`,    color: '#10b981' },
        { icon: '⏰', label: 'Shift 1 Total', value: `${fmt(totalShift1)} kWh`, color: '#06b6d4' },
        { icon: '🌙', label: 'Shift 2 Total', value: `${fmt(totalShift2)} kWh`, color: '#6366f1' },
        { icon: '⬆️', label: 'Peak Value',    value: `${fmt(peakValue)} kWh`,   color: '#ef4444' },
      ]
    : [
        { icon: '🔴', label: 'Total Kubikal 1',   value: `${fmt(totalKubikal1)} kWh`,  color: '#ef4444' },
        { icon: '🔵', label: 'Total Panel Lain',  value: `${fmt(totalPanelLain)} kWh`, color: '#3b82f6' },
        { icon: '⚖️', label: 'Selisih',           value: `${fmt(selisihTotal)} kWh`,   color: selisihTotal >= 0 ? '#10b981' : '#ef4444' },
        { icon: '💰', label: 'Total Biaya',        value: fmtCurrency(totalCost),       color: '#f59e0b' },
        { icon: '📈', label: 'Rata-rata/Hari',     value: `${fmt(avgDaily)} kWh`,       color: '#10b981' },
        { icon: '⬆️', label: 'Peak Value',         value: `${fmt(peakValue)} kWh`,      color: '#ef4444' },
      ];

  // ── Select style ─────────────────────────────────────────────────────────────
  const selectStyle = {
    padding: '7px 10px',
    borderRadius: 8,
    border: '1.5px solid #e2e8f0',
    fontSize: 13,
    background: '#f8fafc',
    color: '#1e293b',
    cursor: 'pointer',
    outline: 'none',
    fontFamily: 'inherit',
  };

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <Layout>
      <div style={{ padding: 20, fontFamily: "'Segoe UI', sans-serif", background: '#f1f5f9', minHeight: '100vh' }}>

        {/* ── Top Bar ── */}
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          flexWrap: 'wrap', gap: 12, marginBottom: 20,
          background: '#fff', padding: '14px 20px', borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
        }}>
          {/* Judul */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 22 }}>⚡</span>
            <div>
              <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: '#1e293b' }}>
                Otics Indonesia — Energy Dashboard
              </h2>
              <p style={{ margin: 0, fontSize: 12, color: '#64748b' }}>
                Monitoring konsumsi energi per panel / shift
              </p>
            </div>
            {isFetching && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#64748b', marginLeft: 8 }}>
                <div style={{
                  width: 14, height: 14, border: '2px solid #dbeafe',
                  borderTopColor: '#3b82f6', borderRadius: '50%',
                  animation: 'spin 0.8s linear infinite',
                }} />
                Memperbarui...
              </div>
            )}
          </div>

          {/* Controls */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <button
              onClick={exportToExcel}
              style={{
                padding: '8px 14px', background: 'linear-gradient(135deg,#16a34a,#15803d)',
                color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer',
                fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6,
                boxShadow: '0 2px 6px rgba(22,163,74,0.3)',
              }}
            >
              📊 Export Excel
            </button>

            {/* Line selector */}
            <select value={selectedLine} onChange={(e) => setSelectedLine(e.target.value)} style={selectStyle}>
              {AVAILABLE_LINES.map((line) => (
                <option key={line} value={line}>{line}</option>
              ))}
            </select>

            {/* Month */}
            <select value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} style={selectStyle}>
              {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>

            {/* Year */}
            <select value={selectedYear} onChange={(e) => setSelectedYear(parseInt(e.target.value))} style={selectStyle}>
              {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        </div>

        {/* ── Content Area (loading hanya di sini) ── */}
        <div style={{ position: 'relative' }}>
          {(loading || isFetching) && <LoadingOverlay />}

          {/* Warning */}
          <div style={{
            marginBottom: 14, padding: '10px 16px',
            background: '#fffbeb', border: '1px solid #fde68a',
            borderRadius: 8, color: '#92400e', fontSize: 13, fontWeight: 500,
          }}>
            ⚠️ Panel 19 dan Panel 24 sedang dalam proses analisa karakteristik data.
          </div>

          {/* Active line label */}
          <div style={{ marginBottom: 14, fontSize: 14, color: '#475569' }}>
            Menampilkan data untuk:{' '}
            <strong style={{
              color: '#2563eb',
              background: '#dbeafe',
              padding: '2px 10px',
              borderRadius: 20,
              fontSize: 13,
            }}>
              {selectedLine}
            </strong>
            {' '}— {selectedMonth} {selectedYear}
          </div>

          {/* Error */}
          {error && !loading && (
            <div style={{
              padding: '14px 18px', background: '#fef2f2',
              border: '1px solid #fecaca', borderRadius: 10,
              color: '#b91c1c', marginBottom: 16, fontSize: 14,
            }}>
              ❌ {error}
            </div>
          )}

          {!error && (
            <>
              {/* ── Stat Cards ── */}
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))',
                gap: 12, marginBottom: 20,
              }}>
                {statCards.map((s, i) => <StatCard key={i} {...s} />)}
              </div>

              {/* ── CO2 + Cost Analysis ── */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 20 }}>
                {/* CO2 */}
                <div style={{
                  background: '#fff', borderRadius: 10, padding: '16px 20px',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                  borderLeft: '4px solid #ef4444',
                }}>
                  <div style={{ fontWeight: 700, color: '#ef4444', fontSize: 15, marginBottom: 10 }}>
                    🔥 CO₂ Emissions
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
                    {[
                      ['Bulan ini',   `${fmt(totalCo2)} kg`],
                      ['Rata-rata/hr', `${(totalCo2 / (daysCount || 1)).toFixed(1)} kg`],
                      ['Proyeksi/thn',`${fmt(Math.round(totalCo2 * 12))} kg`],
                    ].map(([lbl, val]) => (
                      <div key={lbl} style={{ background: '#fef2f2', borderRadius: 8, padding: '8px 10px', textAlign: 'center' }}>
                        <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 3 }}>{lbl}</div>
                        <div style={{ fontWeight: 700, fontSize: 13, color: '#1e293b' }}>{val}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cost */}
                <div style={{
                  background: '#fff', borderRadius: 10, padding: '16px 20px',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                  borderLeft: '4px solid #f59e0b',
                }}>
                  <div style={{ fontWeight: 700, color: '#d97706', fontSize: 15, marginBottom: 10 }}>
                    💰 Cost Analysis
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
                    {[
                      ['Bulan ini',    fmtCurrency(totalCost)],
                      ['Rata-rata/hr', daysCount ? fmtCurrency(Math.round(totalCost / daysCount)) : 'Rp 0'],
                      ['Per kWh',      `Rp ${COST_PER_KWH.toFixed(0)}`],
                    ].map(([lbl, val]) => (
                      <div key={lbl} style={{ background: '#fffbeb', borderRadius: 8, padding: '8px 10px', textAlign: 'center' }}>
                        <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 3 }}>{lbl}</div>
                        <div style={{ fontWeight: 700, fontSize: 13, color: '#1e293b' }}>{val}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* ── Chart ── */}
              <div style={{
                background: '#fff', borderRadius: 12,
                boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                padding: '20px 16px 10px',
              }}>
                <div style={{ fontWeight: 700, color: '#1e293b', fontSize: 15, marginBottom: 14, paddingLeft: 8 }}>
                  📊 Grafik Konsumsi Energi —{' '}
                  <span style={{ color: '#3b82f6' }}>{selectedLine}</span>
                </div>

                {shiftData.length === 0 && !loading && !isFetching ? (
                  <div style={{ textAlign: 'center', padding: '60px 0', color: '#94a3b8', fontSize: 14 }}>
                    🗂️ Tidak ada data untuk periode ini.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={380}>
                    <BarChart data={shiftData} margin={{ top: 30, right: 20, left: 10, bottom: 20 }}>
                      <defs>
                        <linearGradient id="gradShift1" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%"   stopColor="#06b6d4" stopOpacity={1} />
                          <stop offset="100%" stopColor="#0891b2" stopOpacity={0.7} />
                        </linearGradient>
                        <linearGradient id="gradShift2" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%"   stopColor="#6366f1" stopOpacity={1} />
                          <stop offset="100%" stopColor="#4f46e5" stopOpacity={0.7} />
                        </linearGradient>
                        <linearGradient id="gradPanel" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%"   stopColor="#3b82f6" stopOpacity={1} />
                          <stop offset="100%" stopColor="#2563eb" stopOpacity={0.7} />
                        </linearGradient>
                        <linearGradient id="gradKub" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%"   stopColor="#ef4444" stopOpacity={1} />
                          <stop offset="100%" stopColor="#dc2626" stopOpacity={0.7} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis
                        dataKey="date"
                        tick={{ fontSize: 11, fill: '#64748b' }}
                        tickFormatter={(v) => v.split(' ').slice(1, 3).join('-')}
                      />
                      <YAxis
                        tickFormatter={fmt}
                        tick={{ fontSize: 11, fill: '#64748b' }}
                        label={{ value: 'kWh', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 12 }}
                      />
                      <Tooltip
                        contentStyle={{ borderRadius: 8, border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.12)', fontSize: 13 }}
                        formatter={(value, name) => {
                          if (displayMode === 'all') {
                            if (name === 'totalPanel') return [`${fmt(value)} kWh`, 'Total Panel Lain'];
                            if (name === 'kubikal1')   return [`${fmt(value)} kWh`, 'Kubikal 1'];
                          }
                          return [`${fmt(value)} kWh`, name === 'shift1' ? 'Shift 1' : 'Shift 2'];
                        }}
                        labelFormatter={(label) => `📅 ${label}`}
                      />
                      <Legend
                        verticalAlign="top"
                        content={() => (
                          <div style={{ display: 'flex', justifyContent: 'center', gap: 24, paddingBottom: 8, fontSize: 13 }}>
                            {displayMode === 'single' ? (
                              <>
                                <span><span style={{ color: '#06b6d4', fontWeight: 700 }}>●</span> Shift 1: {fmt(totalShift1)} kWh</span>
                                <span><span style={{ color: '#6366f1', fontWeight: 700 }}>●</span> Shift 2: {fmt(totalShift2)} kWh</span>
                              </>
                            ) : (
                              <>
                                <span><span style={{ color: '#3b82f6', fontWeight: 700 }}>●</span> Total Panel Lain: {fmt(totalPanelLain)} kWh</span>
                                <span><span style={{ color: '#ef4444', fontWeight: 700 }}>●</span> Kubikal 1: {fmt(totalKubikal1)} kWh</span>
                              </>
                            )}
                          </div>
                        )}
                      />

                      {displayMode === 'single' ? (
                        <>
                          <Bar dataKey="shift1" fill="url(#gradShift1)" radius={[4, 4, 0, 0]} maxBarSize={32} />
                          <Bar dataKey="shift2" fill="url(#gradShift2)" radius={[4, 4, 0, 0]} maxBarSize={32} />
                        </>
                      ) : (
                        <>
                          <Bar dataKey="totalPanel" fill="url(#gradPanel)" name="Total Panel Lain" radius={[4, 4, 0, 0]} maxBarSize={32} />
                          <Bar dataKey="kubikal1"   fill="url(#gradKub)"   name="Kubikal 1"        radius={[4, 4, 0, 0]} maxBarSize={32} />
                        </>
                      )}
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </>
          )}
        </div>

        {/* CSS */}
        <style>{`
          @keyframes spin {
            0%   { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    </Layout>
  );
};

export default CompShiftly;