import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Layout from '../layout/Layout';

const API_BASE = '/api/hikitori';

const Hikitori = () => {
  const [data, setData] = useState([]);

  const [summary, setSummary] = useState({
    total_trips: 0,
    abnormal_count: 0,
    avg_loading_time: '0:00',
    total_cycles: 0
  });

  const [loading, setLoading] = useState(true);

  const [filters, setFilters] = useState({
    name: '',
    status: '',
    startDate: '',
    endDate: ''
  });

  const fetchData = async (customFilters = filters) => {
    setLoading(true);

    try {
      const params = {};

      if (customFilters.name) {
        params.name = customFilters.name;
      }

      if (customFilters.status) {
        params.status = customFilters.status;
      }

      if (customFilters.startDate) {
        params.startDate = customFilters.startDate;
      }

      if (customFilters.endDate) {
        params.endDate = customFilters.endDate;
      }

      const [dataRes, summaryRes] = await Promise.all([
        axios.get(API_BASE, { params }),
        axios.get(`${API_BASE}/summary`, { params })
      ]);

      if (dataRes.data?.success) {
        setData(dataRes.data.data || []);
      } else {
        setData([]);
      }

      if (summaryRes.data?.success) {
        setSummary(summaryRes.data.data || {
          total_trips: 0,
          abnormal_count: 0,
          avg_loading_time: '0:00',
          total_cycles: 0
        });
      }
    } catch (error) {
      console.error('Error fetching data:', error);

      setData([]);

      setSummary({
        total_trips: 0,
        abnormal_count: 0,
        avg_loading_time: '0:00',
        total_cycles: 0
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;

    setFilters((prevFilters) => ({
      ...prevFilters,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchData(filters);
  };

  const resetFilters = () => {
    const emptyFilters = {
      name: '',
      status: '',
      startDate: '',
      endDate: ''
    };

    setFilters(emptyFilters);
    fetchData(emptyFilters);
  };

  const formatDateTime = (dateTime) => {
    if (!dateTime) {
      return '-';
    }

    return new Date(dateTime).toLocaleString('id-ID', {
      dateStyle: 'medium',
      timeStyle: 'short'
    });
  };

  return (
    <Layout>
      <div className="container mx-auto p-4">
        <h2 className="text-3xl font-bold mb-6">
          Hikitori
        </h2>

        {/* Kartu Ringkasan */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-blue-100 p-4 rounded shadow">
            <div className="text-sm text-blue-800">
              Total Perjalanan
            </div>
            <div className="text-3xl font-bold">
              {summary.total_trips}
            </div>
          </div>

          <div className="bg-red-100 p-4 rounded shadow">
            <div className="text-sm text-red-800">
              Abnormal
            </div>
            <div className="text-3xl font-bold">
              {summary.abnormal_count}
            </div>
          </div>

          <div className="bg-green-100 p-4 rounded shadow">
            <div className="text-sm text-green-800">
              Rata-rata Loading
            </div>
            <div className="text-3xl font-bold">
              {summary.avg_loading_time}
            </div>
          </div>

          <div className="bg-purple-100 p-4 rounded shadow">
            <div className="text-sm text-purple-800">
              Total Cycle
            </div>
            <div className="text-3xl font-bold">
              {summary.total_cycles}
            </div>
          </div>
        </div>

        {/* Form Filter */}
        <form
          onSubmit={handleSubmit}
          className="bg-white p-4 rounded shadow mb-8 flex flex-wrap gap-4 items-end"
        >
          <div>
            <label className="block text-sm font-medium">
              Nama Hikitori
            </label>
            <input
              type="text"
              name="name"
              value={filters.name}
              onChange={handleFilterChange}
              className="mt-1 p-2 border rounded"
              placeholder="Contoh: HIKITORI A"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">
              Status
            </label>
            <select
              name="status"
              value={filters.status}
              onChange={handleFilterChange}
              className="mt-1 p-2 border rounded"
            >
              <option value="">Semua</option>
              <option value="NORMAL">Normal</option>
              <option value="ABNORMAL">Abnormal</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium">
              Tanggal Mulai
            </label>
            <input
              type="date"
              name="startDate"
              value={filters.startDate}
              onChange={handleFilterChange}
              className="mt-1 p-2 border rounded"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">
              Tanggal Akhir
            </label>
            <input
              type="date"
              name="endDate"
              value={filters.endDate}
              onChange={handleFilterChange}
              className="mt-1 p-2 border rounded"
            />
          </div>

          <button
            type="submit"
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
          >
            Terapkan
          </button>

          <button
            type="button"
            onClick={resetFilters}
            className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
          >
            Reset
          </button>
        </form>

        {/* Tabel Data */}
        {loading ? (
          <div className="text-center py-8">
            Memuat data...
          </div>
        ) : (
          <div className="overflow-x-auto bg-white rounded shadow">
            <table className="min-w-full table-auto">
              <thead className="bg-gray-200">
                <tr>
                  <th className="px-4 py-2 text-left">ID</th>
                  <th className="px-4 py-2 text-left">Waktu</th>
                  <th className="px-4 py-2 text-left">Nama</th>
                  <th className="px-4 py-2 text-left">Actual Pouling</th>
                  <th className="px-4 py-2 text-left">Loading Time</th>
                  <th className="px-4 py-2 text-left">Status</th>
                  <th className="px-4 py-2 text-left">Cycle Normal</th>
                  <th className="px-4 py-2 text-left">Andon</th>
                </tr>
              </thead>

              <tbody>
                {data.length === 0 ? (
                  <tr>
                    <td
                      colSpan="8"
                      className="px-4 py-4 text-center text-gray-500"
                    >
                      Tidak ada data
                    </td>
                  </tr>
                ) : (
                  data.map((item) => (
                    <tr
                      key={item.id}
                      className="border-b hover:bg-gray-50"
                    >
                      <td className="px-4 py-2">
                        {item.id}
                      </td>

                      <td className="px-4 py-2">
                        {formatDateTime(item.date_time)}
                      </td>

                      <td className="px-4 py-2">
                        {item.name_hikitori || '-'}
                      </td>

                      <td className="px-4 py-2">
                        {item.actual_pouling || '-'}
                      </td>

                      <td className="px-4 py-2">
                        {item.loading_time || '-'}
                      </td>

                      <td className="px-4 py-2">
                        <span
                          className={`px-2 py-1 rounded text-xs ${
                            item.status === 'ABNORMAL'
                              ? 'bg-red-200 text-red-800'
                              : item.status === 'NORMAL'
                                ? 'bg-green-200 text-green-800'
                                : 'bg-gray-200 text-gray-800'
                          }`}
                        >
                          {item.status || '-'}
                        </span>
                      </td>

                      <td className="px-4 py-2">
                        {item.cycle_normal ?? '-'}
                      </td>

                      <td className="px-4 py-2">
                        {item.andon ?? '-'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Hikitori;