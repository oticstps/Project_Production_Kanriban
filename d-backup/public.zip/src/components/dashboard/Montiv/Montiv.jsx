import React, { useEffect, useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Clock,
  Eye,
  EyeOff,
  Target,
  TrendingUp,
} from 'lucide-react';
import Layout from '../../layout/Layout';

const productionLines = [
  { id: 'common_rail_1_filtered', name: 'CR1', category: 'PG' },
  { id: 'common_rail_2_filtered', name: 'CR2', category: 'PG' },
  { id: 'common_rail_3_filtered', name: 'CR3', category: 'PG' },
  { id: 'common_rail_4_filtered', name: 'CR4', category: 'PG' },
  { id: 'common_rail_5_filtered', name: 'CR5', category: 'PG' },
  { id: 'common_rail_6_filtered', name: 'CR6', category: 'PG' },
  { id: 'common_rail_7_filtered', name: 'CR7', category: 'PG' },
  { id: 'common_rail_8_filtered', name: 'CR8', category: 'PG' },
  { id: 'common_rail_9_filtered', name: 'CR9', category: 'PG' },
  { id: 'common_rail_10_filtered', name: 'CR10', category: 'PG' },
  { id: 'common_rail_11_filtered', name: 'CR11', category: 'PG' },
  { id: 'common_rail_12_filtered', name: 'CR12', category: 'PG' },
  { id: 'cam_housing_assy_a', name: 'CHSAA', category: 'PG' },
  { id: 'cam_housing_assy_b', name: 'CHSAB', category: 'PG' },
];

const productionGroups = [
  { id: 'pg_1', name: 'PG-1' },
  { id: 'pg_2_1', name: 'PG 2-1' },
  { id: 'pg_2_2', name: 'PG 2-2' },
  { id: 'pg_2_3', name: 'PG 2-3' },
  { id: 'pg_3_1', name: 'PG 3-1' },
  { id: 'pg_3_2', name: 'PG 3-2' },
];

const metricColors = {
  actual_pcs: '#1f77b4',
  target: '#ff7f0e',
  efficiency: '#2ca02c',
  loading_time: '#d62728',
  cycle_time: '#9467bd',
  actual_ct: '#8c564b',
};

const pd1Data = {
  title: 'PD-1',
  target: 93,
  months: ['Base', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'],
  actualProductivityHours: [73.06, 7.964, 7.618, 6.764, 6.633, 7.62, 7.5, 7.2, 7.3, 7.4, 7.1, 7.0, 7.65],
  targetProductivityHours: [73.06, 7.422, 7.378, 6.333, 6.029, 7.1, 7.0, 6.9, 7.1, 7.2, 6.95, 6.8, 7.5],
  productivityPercent: [100, 93.19, 96.85, 93.62, 90.9, 93.19, 93.33, 95.83, 97.3, 97.22, 96.45, 94.12, 98.04],
  totalManHour: [20.94, 18.87, 19.91, 18.97, 18.54, 19.46, 19.3, 19.1, 19.25, 19.4, 19.0, 18.9, 19.6],
};

const paretoData = [
  { name: 'HOUSING WATER SLE 1', value: 4.36 },
  { name: 'BALANCE SHAFT No.1 & 2', value: 3.73 },
  { name: 'INLET WATER 1H', value: 1.66 },
  { name: 'CONNECTOR', value: 1.65 },
  { name: 'RETAHER OIL SEAL INLET WATER 1H', value: 1.47 },
  { name: 'DRIVE GEAR & SPACER', value: 1.22 },
  { name: 'INSPECTION - PACKING DAM HOUSING - A', value: 1.11 },
  { name: 'INSPECTION - PACKING DAM HOUSING - C', value: 0.92 },
  { name: 'INSPECTION - PACKING DAM HOUSING - B', value: 0.87 },
  { name: 'INSPEC - COMMON SEAL', value: 0.84 },
  { name: 'PACKING COMBINA', value: 0.36 },
];

const paretoTotal = 19.46;

const formatDateForInput = (date) => {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getCurrentDate = () => formatDateForInput(new Date());

const getYesterdayDate = () => {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  return formatDateForInput(yesterday);
};

const getCurrentMonthStart = () => {
  const now = new Date();
  return formatDateForInput(new Date(now.getFullYear(), now.getMonth(), 1));
};

const getCurrentMonthEnd = () => {
  const now = new Date();
  return formatDateForInput(new Date(now.getFullYear(), now.getMonth() + 1, 0));
};

const isDateInRange = (date, startDate, endDate) => {
  const d = new Date(date);
  const start = startDate ? new Date(startDate) : null;
  const end = endDate ? new Date(endDate) : null;

  if (start) start.setHours(0, 0, 0, 0);
  if (end) end.setHours(23, 59, 59, 999);
  d.setHours(0, 0, 0, 0);

  if (start && end) return d >= start && d <= end;
  if (start) return d >= start;
  if (end) return d <= end;
  return true;
};

const filterDataByDateRange = (data, startDate, endDate) => {
  if (!Array.isArray(data)) return [];
  if (!startDate && !endDate) return data;
  return data.filter((item) => isDateInRange(item.created_at, startDate, endDate));
};

const getUniqueDates = (data) => {
  if (!Array.isArray(data)) return [];
  const dates = data.map((item) => formatDateForInput(item.created_at));
  return [...new Set(dates)].sort((a, b) => new Date(b) - new Date(a));
};

const isBreakTime = (date) => {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const timeStr = `${hours}:${minutes}`;

  const inShift1Break =
    (timeStr >= '09:20' && timeStr <= '09:30') ||
    (timeStr >= '12:00' && timeStr <= '12:40') ||
    (timeStr >= '14:20' && timeStr <= '14:30') ||
    (timeStr >= '16:20' && timeStr <= '16:30');

  const inShift2Break =
    (timeStr >= '21:50' && timeStr <= '22:00') ||
    (timeStr >= '00:00' && timeStr <= '00:10') ||
    (timeStr >= '02:10' && timeStr <= '02:50') ||
    (timeStr >= '04:50' && timeStr <= '05:10');

  return inShift1Break || inShift2Break;
};

const getShiftAndSlot = (timestamp) => {
  const date = new Date(timestamp);
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const timeInMinutes = hours * 60 + minutes;

  const shift1Slots = [
    { start: 7 * 60 + 10, end: 8 * 60 + 10, label: '07:10 - 08:10', theme: 'Schedule' },
    { start: 8 * 60 + 10, end: 9 * 60 + 10, label: '08:10 - 09:10', theme: 'Schedule' },
    { start: 9 * 60 + 30, end: 10 * 60 + 20, label: '09:30 - 10:20', theme: 'Schedule' },
    { start: 10 * 60 + 20, end: 11 * 60 + 20, label: '10:20 - 11:20', theme: 'Schedule' },
    { start: 12 * 60 + 40, end: 13 * 60, label: '12:40 - 13:00', theme: 'Schedule' },
    { start: 13 * 60, end: 14 * 60, label: '13:00 - 14:00', theme: 'Schedule' },
    { start: 14 * 60 + 30, end: 15 * 60 + 10, label: '14:30 - 15:10', theme: 'Schedule' },
    { start: 15 * 60 + 10, end: 16 * 60 + 10, label: '15:10 - 16:10', theme: 'Schedule' },
    { start: 16 * 60 + 30, end: 17 * 60 + 30, label: '16:30 - 17:30', theme: 'Overtime' },
    { start: 17 * 60 + 30, end: 18 * 60 + 30, label: '17:30 - 18:30', theme: 'Overtime' },
    { start: 19 * 60, end: 20 * 60, label: '19:00 - 20:00', theme: 'Overtime' },
  ];

  const shift2Slots = [
    { start: 19 * 60 + 50, end: 20 * 60 + 50, label: '19:50 - 20:50', theme: 'Schedule' },
    { start: 20 * 60 + 50, end: 21 * 60 + 50, label: '20:50 - 21:50', theme: 'Schedule' },
    { start: 22 * 60, end: 23 * 60, label: '22:00 - 23:00', theme: 'Schedule' },
    { start: 23 * 60, end: 24 * 60, label: '23:00 - 00:00', theme: 'Schedule' },
    { start: 10, end: 70, label: '00:10 - 01:10', theme: 'Schedule' },
    { start: 70, end: 130, label: '01:10 - 02:10', theme: 'Schedule' },
    { start: 170, end: 230, label: '02:50 - 03:50', theme: 'Schedule' },
    { start: 230, end: 290, label: '03:50 - 04:50', theme: 'Schedule' },
    { start: 310, end: 370, label: '05:10 - 06:10', theme: 'Overtime' },
    { start: 370, end: 430, label: '06:10 - 07:10', theme: 'Overtime' },
  ];

  for (const slot of shift1Slots) {
    if (timeInMinutes >= slot.start && timeInMinutes < slot.end) {
      return { shift: 'SHIFT1', slot: slot.label, theme: slot.theme };
    }
  }

  for (const slot of shift2Slots) {
    if (
      (slot.start <= slot.end && timeInMinutes >= slot.start && timeInMinutes < slot.end) ||
      (slot.start > slot.end && (timeInMinutes >= slot.start || timeInMinutes < slot.end))
    ) {
      return { shift: 'SHIFT2', slot: slot.label, theme: slot.theme };
    }
  }

  return { shift: 'OTHER', slot: 'Non-Production', theme: 'Other' };
};

const isProductionSlot = (timestamp) => {
  const { theme } = getShiftAndSlot(timestamp);
  return theme === 'Schedule' || theme === 'Overtime';
};

const getLineLabel = (lineId) => {
  const group = productionGroups.find((item) => item.id === lineId);
  if (group) return group.name;
  const line = productionLines.find((item) => item.id === lineId);
  return line ? line.name : lineId;
};

const useProductionData = (selectedLine) => {
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchProductionData = async (lineId) => {
    if (!lineId || productionGroups.some((group) => group.id === lineId)) {
      setChartData([]);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`http://172.27.6.191:4000/all/table/${lineId}?page=1&limit=800`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

      const result = await response.json();
      if (!result.data || result.data.length === 0) throw new Error('No data available');

      const sortedData = [...result.data].sort(
        (a, b) => new Date(a.created_at) - new Date(b.created_at)
      );

      const formattedData = sortedData.map((item, index, array) => {
        const createdAt = new Date(item.created_at);
        let actualCt = 0;

        if (index > 0) {
          const prevItem = array[index - 1];
          const prevCreatedAt = new Date(prevItem.created_at);
          const currentActual = parseInt(item.actual, 10) || 0;
          const prevActual = parseInt(prevItem.actual, 10) || 0;

          if (currentActual - prevActual === 1) {
            const diffMs = createdAt.getTime() - prevCreatedAt.getTime();
            actualCt = isBreakTime(createdAt) ? 0 : Math.round(diffMs / 1000);
          } else {
            actualCt = (parseInt(item.cycle_time, 10) || 0) / 10;
          }
        }

        return {
          ...item,
          line_name: getLineLabel(lineId),
          time: createdAt.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
          date: createdAt.toLocaleDateString('id-ID'),
          actual_pcs: parseInt(item.actual, 10) || 0,
          target: parseInt(item.target, 10) || 0,
          efficiency: (parseInt(item.efficiency, 10) || 0) / 10,
          loading_time: parseInt(item.loading_time, 10) || 0,
          cycle_time: (parseInt(item.cycle_time, 10) || 0) / 10,
          delay: parseInt(item.delay, 10) || 0,
          product_name: item.name_product || item.product_name || '-',
          status: item.status || 'NORMAL',
          actual_ct: actualCt,
        };
      });

      setChartData(formattedData);
    } catch (err) {
      setError(`Gagal memuat data: ${err.message}`);
      setChartData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedLine) fetchProductionData(selectedLine);
  }, [selectedLine]);

  return { chartData, loading, error, fetchProductionData };
};

const useDeltaActualData = (selectedLine) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!selectedLine || !selectedLine.includes('common_rail_3')) {
        setData([]);
        setLoading(false);
        setError(null);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const response = await fetch('/api/cr3hourly');
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

        const result = await response.json();
        if (result.status !== 'success') throw new Error('Failed to fetch data');

        const filteredData = result.data.filter(
          (item) => item.line === selectedLine || !item.line
        );
        setData(filteredData);
      } catch (err) {
        setError(err.message);
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [selectedLine]);

  return { data, loading, error };
};

const DigitalClock = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedDate = currentTime.toLocaleDateString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="text-center">
      <p className="text-xs text-gray-600">{formattedDate}</p>
      <p className="text-lg font-bold text-green-600">
        {currentTime.toLocaleTimeString('id-ID')}
      </p>
    </div>
  );
};

const Header = ({ latestData, selectedLineLabel }) => {
  const data = latestData || {};

  return (
    <div className="bg-white p-3 border border-gray-300 rounded-lg shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-sm font-bold text-gray-800">Line: {data.line_name || selectedLineLabel}</p>
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-sm font-bold text-amber-700">
              Product: {data.product_name || data.name_product || '-'}
            </p>
            <div
              className={`px-2 py-0.5 text-xs font-semibold rounded ${
                data.status === 'NORMAL' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
              }`}
            >
              {data.status || 'LOADING'}
            </div>
          </div>
        </div>
        <DigitalClock />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-gray-50 p-2 rounded border border-gray-200">
          <div className="flex items-center mb-1">
            <Activity className="w-3 h-3 text-blue-600 mr-1" />
            <span className="text-xs font-medium text-gray-700">Actual PCS</span>
          </div>
          <div className="text-sm font-bold text-gray-900">{data.actual_pcs ?? '---'}</div>
        </div>
        <div className="bg-gray-50 p-2 rounded border border-gray-200">
          <div className="flex items-center mb-1">
            <Target className="w-3 h-3 text-green-600 mr-1" />
            <span className="text-xs font-medium text-gray-700">Target</span>
          </div>
          <div className="text-sm font-bold text-gray-900">{data.target ?? '---'}</div>
        </div>
        <div className="bg-gray-50 p-2 rounded border border-gray-200">
          <div className="flex items-center mb-1">
            <TrendingUp className="w-3 h-3 text-purple-600 mr-1" />
            <span className="text-xs font-medium text-gray-700">Efficiency</span>
          </div>
          <div className="text-sm font-bold text-gray-900">{data.efficiency ?? '---'}%</div>
        </div>
        <div className="bg-gray-50 p-2 rounded border border-gray-200">
          <div className="flex items-center mb-1">
            <Clock className="w-3 h-3 text-orange-600 mr-1" />
            <span className="text-xs font-medium text-gray-700">Cycle Time</span>
          </div>
          <div className="text-sm font-bold text-gray-900">{data.cycle_time ?? '---'}s</div>
        </div>
      </div>
    </div>
  );
};

const ChartControls = ({
  chartType,
  setChartType,
  loading,
  fetchProductionData,
  selectedLine,
  chartData,
  viewMode,
  setViewMode,
  selectedMetrics,
  handleMetricToggle,
  getLineColor,
}) => {
  const viewModes = [
    { mode: 'normal', label: 'Normal' },
    // { mode: 'hourly', label: 'Hourly' },
    // { mode: 'shift', label: 'Shift' },
  ];

  return (
    <div className="bg-white p-3 border shadow-md rounded-md">
      <div className="flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => fetchProductionData(selectedLine)}
            disabled={loading || productionGroups.some((group) => group.id === selectedLine)}
            className="px-3 py-1.5 text-xs bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-300 disabled:text-gray-600 text-black flex items-center border border-black transition-all rounded"
            style={{ boxShadow: '0 2px 4px 0 rgba(0,0,0,0.35), 0 1px 0 #222' }}
          >
            <Activity className={`w-3 h-3 mr-1 ${loading ? 'animate-spin' : ''}`} />
            {loading ? 'Loading...' : 'Refresh'}
          </button>

          <div className="flex items-center gap-1">
            <BarChart3 className="w-4 h-4 text-gray-600" />
            <select
              value={chartType}
              onChange={(e) => setChartType(e.target.value)}
              className="bg-white text-xs px-2 py-1 border border-gray-300 text-gray-800 rounded"
            >
              <option value="line">Line Chart</option>
              <option value="bar">Bar Chart</option>
              <option value="area">Area Chart</option>
            </select>
          </div>

          <div className="flex gap-1 flex-wrap">
            {viewModes.map(({ mode, label }) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`px-2 py-1 text-xs rounded border transition-all ${
                  viewMode === mode
                    ? 'bg-green-400 border-black text-black font-medium'
                    : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-100'
                }`}
                style={{
                  boxShadow:
                    viewMode === mode
                      ? '0 2px 4px 0 rgba(0,0,0,0.35), 0 1px 0 #222'
                      : 'none',
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {chartData.length > 0 && (
          <div className="text-xs text-gray-600">
            Showing {chartData.length} records | Latest:{' '}
            {new Date(chartData[chartData.length - 1]?.created_at).toLocaleString('id-ID')}
          </div>
        )}
      </div>

      <div className="mt-3 pt-3 border-t border-gray-200">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-medium text-gray-700">Metrics:</span>
        </div>
        <div className="flex flex-wrap gap-1">
          {Object.entries(selectedMetrics).map(([metric, isSelected]) => (
            <button
              key={metric}
              onClick={() => handleMetricToggle(metric)}
              className={`px-2 py-1 text-xs rounded border flex items-center transition-all ${
                isSelected
                  ? 'bg-green-400 border-black text-black'
                  : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-100'
              }`}
              style={{
                boxShadow: isSelected
                  ? '0 2px 4px 0 rgba(0,0,0,0.35), 0 1px 0 #222'
                  : 'none',
              }}
            >
              <div
                className="w-2 h-2 mr-1 rounded-full"
                style={{ backgroundColor: getLineColor(metric) }}
              />
              {metric.replace('_', ' ').toUpperCase()}
              {isSelected ? (
                <Eye className="w-2.5 h-2.5 ml-1" />
              ) : (
                <EyeOff className="w-2.5 h-2.5 ml-1" />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

const DateFilter = ({ selectedDate, onDateChange, availableDates }) => {
  return (
    <div className="mb-4 p-4 border border-gray-300 rounded-md bg-white shadow-sm">
      <h3 className="mb-3 text-sm font-semibold text-gray-800">Filter Data</h3>
      <div className="flex items-center gap-3 flex-wrap">
        <label htmlFor="dateFilter" className="font-medium text-sm text-gray-700">
          Pilih Tanggal:
        </label>
        <input
          id="dateFilter"
          type="date"
          value={selectedDate || ''}
          onChange={(e) => onDateChange(e.target.value)}
          max={availableDates[0] || ''}
          className="px-3 py-2 border border-gray-300 rounded-md text-sm"
        />
        {selectedDate && (
          <button
            onClick={() => onDateChange('')}
            className="px-3 py-2 bg-red-500 text-white rounded-md text-sm font-medium hover:bg-red-600"
          >
            Reset Filter
          </button>
        )}
      </div>
      {availableDates.length > 0 && (
        <div className="mt-2 text-xs text-gray-500 italic">
          Tanggal tersedia: {availableDates.length} hari
        </div>
      )}
    </div>
  );
};

const FilterControls = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  selectedChartType,
  onChartTypeChange,
  availableDates,
}) => {
  return (
    <div className="mb-3 p-3 border border-gray-300 rounded-lg bg-white shadow-md">
      <h3 className="mb-3 text-gray-800 text-base font-semibold">Kontrol Filter</h3>

      <div className="flex items-center gap-2 flex-wrap mb-3">
        <label className="font-medium w-20 text-sm text-gray-700">Tanggal:</label>
        <div className="flex items-center gap-2 flex-wrap flex-1">
          <input
            type="date"
            value={startDate || ''}
            max={availableDates[0] || ''}
            onChange={(e) => onStartDateChange(e.target.value)}
            className="px-2 py-1 border border-gray-300 rounded-md text-sm text-gray-900 w-40 bg-white"
          />
          <span className="text-gray-500">-</span>
          <input
            type="date"
            value={endDate || ''}
            max={availableDates[0] || ''}
            onChange={(e) => onEndDateChange(e.target.value)}
            className="px-2 py-1 border border-gray-300 rounded-md text-sm text-gray-900 w-40 bg-white"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap mb-2">
        <label className="font-medium w-20 text-sm text-gray-700">Chart:</label>
        <div className="flex gap-1 flex-wrap flex-1">
          {['bar', 'line', 'area'].map((type) => (
            <button
              key={type}
              onClick={() => onChartTypeChange(type)}
              className={`px-3 py-1 border border-gray-300 rounded-md text-sm font-medium transition-colors ${
                selectedChartType === type
                  ? type === 'bar'
                    ? 'bg-green-500 text-white border-green-500'
                    : type === 'line'
                    ? 'bg-blue-500 text-white border-blue-500'
                    : 'bg-orange-500 text-white border-orange-500'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {type === 'bar' ? 'Bar' : type === 'line' ? 'Line' : 'Area'}
            </button>
          ))}
        </div>
      </div>

      {(startDate || endDate) && (
        <button
          onClick={() => {
            onStartDateChange('');
            onEndDateChange('');
          }}
          className="px-3 py-1 bg-red-500 text-white border border-red-500 rounded-md text-sm font-medium hover:bg-red-600 transition-colors"
        >
          Reset
        </button>
      )}

      {availableDates.length > 0 && (
        <div className="mt-2 text-xs text-gray-500 italic">
          Tanggal tersedia: {availableDates.length} hari
        </div>
      )}
    </div>
  );
};

const DeltaActualBarChart = ({ data }) => {
  const chartData = (data || []).map((item) => ({
    name: new Date(item.created_at).toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
    }),
    delta_actual: parseInt(item.delta_actual, 10) || 0,
  }));

  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="delta_actual" name="Delta Actual" fill="#8884d8" />
      </BarChart>
    </ResponsiveContainer>
  );
};

const ChartComponent = ({ data, chartType = 'bar', startDate, endDate }) => {
  const chartData = (data || [])
    .map((item) => ({
      name: new Date(item.created_at).toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      delta_actual: parseInt(item.delta_actual, 10) || 0,
      created_at: new Date(item.created_at).toLocaleString('id-ID'),
      timestamp: new Date(item.created_at).getTime(),
      date: new Date(item.created_at).toLocaleDateString('id-ID'),
    }))
    .sort((a, b) => a.timestamp - b.timestamp);

  const uniqueDates = [...new Set(chartData.map((item) => item.date))];

  const customTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const item = payload[0].payload;
      return (
        <div className="bg-white p-2 border border-green-200 rounded shadow text-xs">
          <p className="font-bold text-green-700 mb-1">Waktu: {label}</p>
          <p className="text-green-600 font-medium">Δ Actual: {item.delta_actual}</p>
          <p className="text-blue-600 text-[10px]">Tanggal: {item.date}</p>
          <p className="text-gray-500 text-[10px] mt-1">{item.created_at}</p>
        </div>
      );
    }
    return null;
  };

  const commonProps = {
    data: chartData,
    margin: { top: 15, right: 20, left: 15, bottom: 45 },
  };

  const commonElements = (
    <>
      <CartesianGrid strokeDasharray="3 3" stroke="#c8e6c9" />
      <XAxis
        dataKey="name"
        angle={-45}
        textAnchor="end"
        height={45}
        tick={{ fontSize: 10, fill: '#2e7d32' }}
      />
      <YAxis
        tick={{ fontSize: 10, fill: '#2e7d32' }}
        label={{
          value: 'Unit',
          angle: -90,
          position: 'insideLeft',
          style: { textAnchor: 'middle', fontSize: '11px', fill: '#2e7d32' },
        }}
      />
      <Tooltip content={customTooltip} />
      <Legend wrapperStyle={{ fontSize: '11px' }} />
    </>
  );

  const renderChart = () => {
    switch (chartType) {
      case 'line':
        return (
          <LineChart {...commonProps}>
            {commonElements}
            <Line
              type="monotone"
              dataKey="delta_actual"
              name="Delta Actual"
              stroke="#4caf50"
              strokeWidth={2}
              dot={{ r: 3 }}
              activeDot={{ r: 5 }}
            />
          </LineChart>
        );
      case 'area':
        return (
          <AreaChart {...commonProps}>
            {commonElements}
            <Area
              type="monotone"
              dataKey="delta_actual"
              name="Delta Actual"
              fill="#81c784"
              stroke="#4caf50"
              fillOpacity={0.3}
            />
          </AreaChart>
        );
      case 'bar':
      default:
        return (
          <BarChart {...commonProps}>
            {commonElements}
            <Bar
              dataKey="delta_actual"
              name="Delta Actual"
              fill="#4caf50"
              radius={[3, 3, 0, 0]}
            />
          </BarChart>
        );
    }
  };

  const formatDateRange = () => {
    if (startDate && endDate) {
      return `${new Date(startDate).toLocaleDateString('id-ID')} - ${new Date(endDate).toLocaleDateString('id-ID')}`;
    }
    if (startDate) return new Date(startDate).toLocaleDateString('id-ID');
    if (endDate) return new Date(endDate).toLocaleDateString('id-ID');
    return 'Semua Tanggal';
  };

  const getDateInfo = () => {
    if (uniqueDates.length === 1) return `Data tanggal: ${uniqueDates[0]}`;
    if (uniqueDates.length > 1) {
      return `Data tanggal: ${uniqueDates[0]} sampai ${uniqueDates[uniqueDates.length - 1]}`;
    }
    return 'Tidak ada data tanggal';
  };

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-md p-6 mb-6">
      <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
        <h3 className="text-xl font-bold text-gray-800">Grafik Delta Actual Pcs/Jam</h3>
        <div className="text-sm text-blue-600 font-medium bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
          {startDate || endDate ? formatDateRange() : getDateInfo()}
        </div>
      </div>

      <div className="relative w-full h-64 md:h-80 lg:h-96 bg-gray-50 border border-gray-300 rounded-lg overflow-hidden">
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </div>

      {chartData.length === 0 && (
        <div className="text-center p-5 text-gray-600 bg-lime-50 rounded mt-2 text-xs border border-lime-200">
          Tidak ada data untuk filter yang dipilih
        </div>
      )}

      {chartData.length > 0 && uniqueDates.length > 0 && (
        <div className="mt-2 px-3 py-2 bg-gray-100 rounded text-[10px] text-gray-600 border border-gray-200 text-center">
          Menampilkan data dari {uniqueDates.length} tanggal: {uniqueDates.join(', ')}
        </div>
      )}
    </div>
  );
};

const ActualConsumptionChart = ({ data, startDate, endDate }) => {
  const filteredData = useMemo(() => {
    if (!Array.isArray(data)) return [];
    return filterDataByDateRange(data, startDate, endDate);
  }, [data, startDate, endDate]);

  const chartData = useMemo(() => {
    const dateShiftMap = {};

    filteredData.forEach((item) => {
      if (!isProductionSlot(item.created_at)) return;

      const { shift } = getShiftAndSlot(item.created_at);
      if (shift !== 'SHIFT1' && shift !== 'SHIFT2') return;

      const date = new Date(item.created_at).toISOString().split('T')[0];
      if (!dateShiftMap[date]) {
        dateShiftMap[date] = { date, Shift1: 0, Shift2: 0 };
      }

      dateShiftMap[date][shift === 'SHIFT1' ? 'Shift1' : 'Shift2'] +=
        parseInt(item.delta_actual, 10) || 0;
    });

    return Object.values(dateShiftMap).sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [filteredData]);

  const customTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border border-green-200 rounded shadow text-xs">
          <p className="font-bold text-green-700 mb-1">Tanggal: {label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color }} className="font-medium">
              {entry.name}: {entry.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-md p-6 mb-6">
      <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
        <h3 className="text-xl font-bold text-gray-800">Grafik Konsumsi Actual per Shift</h3>
        <div className="text-sm text-blue-600 font-medium bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
          {startDate && endDate
            ? `${new Date(startDate).toLocaleDateString('id-ID')} - ${new Date(endDate).toLocaleDateString('id-ID')}`
            : 'Semua Tanggal'}
        </div>
      </div>

      <div className="relative w-full h-64 md:h-80 lg:h-96 bg-gray-50 border border-gray-300 rounded-lg overflow-hidden">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 15, right: 20, left: 15, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#c8e6c9" />
            <XAxis
              dataKey="date"
              tick={{ fontSize: 10, fill: '#2e7d32' }}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis
              tick={{ fontSize: 10, fill: '#2e7d32' }}
              label={{
                value: 'Konsumsi Actual',
                angle: -90,
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontSize: '11px', fill: '#2e7d32' },
              }}
            />
            <Tooltip content={customTooltip} />
            <Legend wrapperStyle={{ fontSize: '11px' }} />
            <Bar dataKey="Shift1" name="Shift 1" fill="#4caf50" radius={[3, 3, 0, 0]} />
            <Bar dataKey="Shift2" name="Shift 2" fill="#2196f3" radius={[3, 3, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {chartData.length === 0 && (
        <div className="text-center p-5 text-gray-600 bg-lime-50 rounded mt-2 text-xs border border-lime-200">
          Tidak ada data konsumsi actual untuk filter yang dipilih
        </div>
      )}
    </div>
  );
};

const ProductivityChart = () => {
  const width = 800;
  const height = 300;
  const padding = 50;
  const chartWidth = width - padding * 2;
  const chartHeight = height - padding * 2;

  const scaleY = (value) => chartHeight - (value - 60) * 0.6;
  const scaleX = (index) => padding + index * (chartWidth / (pd1Data.months.length - 1));

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-6 mb-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Produktivitas Bulanan (%)</h3>
      <div className="relative w-full h-72 bg-gray-50 border border-gray-300 rounded-lg overflow-hidden">
        <svg width="100%" height="100%" viewBox={`0 0 ${width} ${height}`} className="select-none">
          {[...Array(11)].map((_, i) => {
            const y = padding + i * (chartHeight / 10);
            const label = 100 - i * 4;
            return (
              <g key={`grid-y-${i}`}>
                <line x1={padding} y1={y} x2={width - padding} y2={y} stroke="#e5e7eb" strokeWidth="1" />
                <text x={padding - 10} y={y + 4} textAnchor="end" fontSize="10" fill="#6b7280">
                  {label}%
                </text>
              </g>
            );
          })}

          {pd1Data.months.map((_, i) => {
            const x = scaleX(i);
            return <line key={`grid-x-${i}`} x1={x} y1={padding} x2={x} y2={height - padding} stroke="#e5e7eb" strokeWidth="1" />;
          })}

          <line
            x1={padding}
            y1={scaleY(pd1Data.target)}
            x2={width - padding}
            y2={scaleY(pd1Data.target)}
            stroke="#ef4444"
            strokeWidth="2"
            strokeDasharray="6,4"
            className="opacity-90"
          />

          <polyline
            fill="none"
            stroke="#2563eb"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={pd1Data.productivityPercent
              .map((pct, i) => `${scaleX(i)},${scaleY(pct)}`)
              .join(' ')}
          />

          {pd1Data.productivityPercent.map((pct, i) => (
            <circle
              key={`point-${i}`}
              cx={scaleX(i)}
              cy={scaleY(pct)}
              r="5"
              fill="#2563eb"
              stroke="#1d4ed8"
              strokeWidth="2"
              className="drop-shadow-sm"
            />
          ))}
        </svg>

        <div className="absolute bottom-2 left-0 right-0 flex justify-between px-4 text-xs text-gray-600 font-medium">
          {pd1Data.months.map((month, i) => (
            <span key={i} className="text-center min-w-[40px]">
              {month}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

const ParetoChart = () => {
  const width = 1000;
  const height = 320;
  const padding = 50;
  const chartWidth = width - padding * 2;
  const chartHeight = height - padding * 2;

  const scaleY = (value) => chartHeight - value * 10;
  const scaleX = (index) => padding + index * (chartWidth / (paretoData.length - 1));

  const cumulativePercentages = paretoData.map((item, index) => {
    const total = paretoData.slice(0, index + 1).reduce((sum, row) => sum + row.value, 0);
    return (total / paretoTotal) * 100;
  });

  const scalePercentY = (percent) => chartHeight - percent * 2;

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Pareto Rata-rata Man Hour per Line PD-1</h3>
      <div className="relative w-full h-72 bg-gray-50 border border-gray-300 rounded-lg overflow-hidden">
        <svg width="100%" height="100%" viewBox={`0 0 ${width} ${height}`} className="select-none">
          {[...Array(15)].map((_, i) => {
            const y = padding + i * (chartHeight / 14);
            const label = 14 - i;
            return (
              <g key={`grid-y-${i}`}>
                <line x1={padding} y1={y} x2={width - padding} y2={y} stroke="#e5e7eb" strokeWidth="1" />
                <text x={padding - 10} y={y + 4} textAnchor="end" fontSize="10" fill="#6b7280">
                  {label.toFixed(1)}
                </text>
              </g>
            );
          })}

          {paretoData.map((_, i) => {
            const x = scaleX(i);
            return <line key={`grid-x-${i}`} x1={x} y1={padding} x2={x} y2={height - padding} stroke="#e5e7eb" strokeWidth="1" />;
          })}

          <polyline
            fill="none"
            stroke="#3b82f6"
            strokeWidth="2"
            strokeLinecap="round"
            points={cumulativePercentages
              .map((pct, i) => `${scaleX(i)},${scalePercentY(pct)}`)
              .join(' ')}
          />

          {cumulativePercentages.map((pct, i) => (
            <circle key={`point-${i}`} cx={scaleX(i)} cy={scalePercentY(pct)} r="3" fill="#3b82f6" stroke="#1d4ed8" strokeWidth="1" />
          ))}

          {paretoData.map((item, i) => {
            const x = scaleX(i);
            const y = scaleY(item.value);
            const barWidth = (chartWidth / (paretoData.length - 1)) * 0.8;
            return (
              <g key={`bar-${i}`}>
                <rect x={x - barWidth / 2} y={y} width={barWidth} height={chartHeight - y} fill="#3b82f6" opacity="0.8" rx="4" />
                <text x={x} y={y - 10} textAnchor="middle" fontSize="10" fill="#1f2937" fontWeight="bold">
                  {item.value.toFixed(2)}
                </text>
              </g>
            );
          })}

          <text x={width / 2} y={height / 2 + 10} textAnchor="middle" fontSize="12" fill="#374151" fontWeight="bold">
            Total = {paretoTotal} Mnt / pcs
          </text>

          <text x={padding - 20} y={padding + 10} transform="rotate(-90, 0, 0)" fontSize="10" fill="#6b7280" textAnchor="middle">
            Minutes (pcs)
          </text>

          <g>
            <text x={width - padding + 10} y={padding + 10} transform="rotate(90, 0, 0)" fontSize="10" fill="#6b7280" textAnchor="middle">
              Cumulative %
            </text>
            {[0, 20, 40, 60, 80, 100].map((pct) => (
              <g key={`right-y-${pct}`}>
                <line x1={width - padding} y1={scalePercentY(pct)} x2={width - padding + 5} y2={scalePercentY(pct)} stroke="#e5e7eb" strokeWidth="1" />
                <text x={width - padding + 10} y={scalePercentY(pct) + 4} textAnchor="start" fontSize="10" fill="#6b7280">
                  {pct}%
                </text>
              </g>
            ))}
          </g>
        </svg>

        <div className="absolute bottom-2 left-0 right-0 flex justify-between px-4 text-xs text-gray-600 font-medium">
          {paretoData.map((item, i) => (
            <div key={i} className="text-center min-w-[80px]">
              <div className="truncate">{item.name}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const Pd1Dashboard = () => {
  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-6 flex-wrap gap-2">
        <h2 className="text-2xl font-extrabold text-gray-800">PD-1 Productivity Dashboard</h2>
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-lg text-sm font-semibold">
          Target: {pd1Data.target}%
        </div>
      </div>

      <ProductivityChart />

      <div className="overflow-x-auto mt-6 mb-6 border-gray-600 rounded-lg shadow-lg">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="bg-gray-100 border-b-2 border-gray-300">
              <th className="px-4 py-3 text-left font-bold text-gray-800">Kategori</th>
              <th className="px-4 py-3 text-right font-bold text-gray-800">Base</th>
              <th className="px-4 py-3 text-right font-bold text-gray-800">Jan</th>
              <th className="px-4 py-3 text-right font-bold text-gray-800">Feb</th>
              <th className="px-4 py-3 text-right font-bold text-gray-800">Mar</th>
              <th className="px-4 py-3 text-right font-bold text-gray-800">Apr</th>
              <th className="px-4 py-3 text-right font-bold text-gray-800">Mei</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
              <td className="px-4 py-3 text-left font-medium text-gray-800">Target Produktivitas (hours)</td>
              <td className="px-4 py-3 text-right text-gray-700">73.06</td>
              <td className="px-4 py-3 text-right text-gray-700">7.964</td>
              <td className="px-4 py-3 text-right text-gray-700">7.618</td>
              <td className="px-4 py-3 text-right text-gray-700">6.764</td>
              <td className="px-4 py-3 text-right text-gray-700">6.633</td>
              <td className="px-4 py-3 text-right text-gray-700">7.620</td>
            </tr>
            <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
              <td className="px-4 py-3 text-left font-medium text-gray-800">Produktivitas Actual (hours)</td>
              <td className="px-4 py-3 text-right text-gray-700">73.06</td>
              <td className="px-4 py-3 text-right text-gray-700">7.422</td>
              <td className="px-4 py-3 text-right text-gray-700">7.378</td>
              <td className="px-4 py-3 text-right text-gray-700">6.333</td>
              <td className="px-4 py-3 text-right text-gray-700">6.029</td>
              <td className="px-4 py-3 text-right text-gray-700">7.100</td>
            </tr>
            <tr className="border-b border-gray-200 bg-blue-50">
              <td className="px-4 py-3 text-left font-bold text-blue-800">Persentase (%)</td>
              <td className="px-4 py-3 text-right font-bold text-blue-700">100</td>
              <td className="px-4 py-3 text-right font-bold text-blue-700">93.19</td>
              <td className="px-4 py-3 text-right font-bold text-blue-700">96.85</td>
              <td className="px-4 py-3 text-right font-bold text-blue-700">93.62</td>
              <td className="px-4 py-3 text-right font-bold text-blue-700">90.90</td>
              <td className="px-4 py-3 text-right font-bold text-blue-700">93.19</td>
            </tr>
            <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
              <td className="px-4 py-3 text-left font-medium text-gray-800">Total man hour</td>
              <td className="px-4 py-3 text-right text-gray-700">20.94</td>
              <td className="px-4 py-3 text-right text-gray-700">18.87</td>
              <td className="px-4 py-3 text-right text-gray-700">19.91</td>
              <td className="px-4 py-3 text-right text-gray-700">18.97</td>
              <td className="px-4 py-3 text-right text-gray-700">18.54</td>
              <td className="px-4 py-3 text-right text-gray-700">19.46</td>
            </tr>
          </tbody>
        </table>
      </div>

      <ParetoChart />
    </div>
  );
};

const ProductionChart = ({
  chartType,
  setChartType,
  chartData,
  loading,
  error,
  fetchProductionData,
  selectedLine,
  selectedMetrics,
  handleMetricToggle,
  getLineColor,
  viewMode,
  setViewMode,
}) => {
  const selectedSeries = Object.entries(selectedMetrics).filter(([, enabled]) => enabled);
  const latestData = chartData.length > 0 ? chartData[chartData.length - 1] : null;

  const renderChart = () => {
    const commonChartProps = {
      data: chartData,
      margin: { top: 5, right: 5, left: 5, bottom: 5 },
    };

    const commonComponents = (
      <>
        <CartesianGrid strokeDasharray="3 3" stroke="#D1D5DB" />
        <XAxis
          dataKey="created_at"
          stroke="#000000"
          fontSize={10}
          tickFormatter={(value) => {
            const date = new Date(value);
            return `${date.getHours().toString().padStart(2, '0')}:${date
              .getMinutes()
              .toString()
              .padStart(2, '0')}`;
          }}
        />
        <YAxis stroke="#000000" fontSize={10} />
        <Tooltip
          content={({ active, payload, label }) => {
            if (active && payload && payload.length) {
              return (
                <div className="bg-white border border-black p-2 text-xs text-black rounded shadow">
                  <p className="font-semibold">{new Date(label).toLocaleString('id-ID')}</p>
                  {payload.map((entry, index) => (
                    <p key={index} style={{ color: entry.color }}>
                      {entry.name}: <strong>{entry.value}</strong>
                    </p>
                  ))}
                  {payload[0]?.payload?.product_name && (
                    <p className="mt-1 text-black">
                      Product: <strong>{payload[0].payload.product_name}</strong>
                    </p>
                  )}
                </div>
              );
            }
            return null;
          }}
        />
        <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px', color: '#374151' }} />
      </>
    );

    const renderSeries = () =>
      selectedSeries.map(([metric]) => {
        if (chartType === 'bar') {
          return (
            <Bar
              key={metric}
              dataKey={metric}
              fill={getLineColor(metric)}
              name={metric.replace('_', ' ').toUpperCase()}
            />
          );
        }

        if (chartType === 'area') {
          return (
            <Area
              key={metric}
              type="monotone"
              dataKey={metric}
              fill={getLineColor(metric)}
              stroke={getLineColor(metric)}
              name={metric.replace('_', ' ').toUpperCase()}
              fillOpacity={0.2}
            />
          );
        }

        return (
          <Line
            key={metric}
            type="monotone"
            dataKey={metric}
            stroke={getLineColor(metric)}
            strokeWidth={metric === 'actual_pcs' ? 2 : 1.5}
            dot={false}
            name={metric.replace('_', ' ').toUpperCase()}
            strokeDasharray={metric === 'target' ? '5 5' : undefined}
          />
        );
      });

    if (chartType === 'bar') {
      return <BarChart {...commonChartProps}>{commonComponents}{renderSeries()}</BarChart>;
    }

    if (chartType === 'area') {
      return <AreaChart {...commonChartProps}>{commonComponents}{renderSeries()}</AreaChart>;
    }

    return <LineChart {...commonChartProps}>{commonComponents}{renderSeries()}</LineChart>;
  };

  return (
    <div className="space-y-4">
      <Header latestData={latestData} selectedLineLabel={getLineLabel(selectedLine)} />

      <div className="bg-white p-4 border rounded-md shadow-sm">
        <ChartControls
          chartType={chartType}
          setChartType={setChartType}
          loading={loading}
          fetchProductionData={fetchProductionData}
          selectedLine={selectedLine}
          chartData={chartData}
          viewMode={viewMode}
          setViewMode={setViewMode}
          selectedMetrics={selectedMetrics}
          handleMetricToggle={handleMetricToggle}
          getLineColor={getLineColor}
        />

        <div className="flex items-center justify-between mt-4 mb-2">
          <h3 className="text-sm font-semibold text-green-700">Production Chart</h3>
          {loading && (
            <div className="flex items-center text-blue-500 text-xs">
              <div className="animate-spin h-3 w-3 border-b-2 border-black mr-1" />
              Loading...
            </div>
          )}
        </div>

        {error ? (
          <div className="flex flex-col items-center justify-center h-96 text-red-500">
            <AlertTriangle className="w-8 h-8 mb-2" />
            <p className="text-sm font-medium mb-1">Failed to Load Data</p>
            <p className="text-xs text-black mb-3">{error}</p>
            <button
              onClick={() => fetchProductionData(selectedLine)}
              className="px-3 py-1 text-xs bg-red-500 hover:bg-red-600 text-white rounded"
            >
              Try Again
            </button>
          </div>
        ) : chartData.length === 0 && !loading ? (
          <div className="flex flex-col items-center justify-center h-96 text-black">
            <Activity className="w-8 h-8 mb-2" />
            <p className="text-sm font-medium mb-1">No Data Available</p>
            <p className="text-xs text-black mb-3">No production data found</p>
            <button
              onClick={() => fetchProductionData(selectedLine)}
              className="px-3 py-1 text-xs bg-blue-500 hover:bg-blue-600 text-white rounded"
            >
              Refresh Data
            </button>
          </div>
        ) : (
          <div className="h-64 md:h-80 lg:h-96">
            <ResponsiveContainer width="100%" height="100%">
              {renderChart()}
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};

const Montiv = () => {
  const [chartType, setChartType] = useState('line');
  const [viewMode, setViewMode] = useState('normal');
  const [selectedLine, setSelectedLine] = useState('common_rail_1_filtered');
  const [selectedMetrics, setSelectedMetrics] = useState({
    actual_pcs: true,
    target: true,
    efficiency: false,
    loading_time: false,
    cycle_time: true,
    actual_ct: true,
  });

  const [startDate, setStartDate] = useState(getYesterdayDate());
  const [endDate, setEndDate] = useState(getCurrentDate());
  const [selectedChartType, setSelectedChartType] = useState('bar');

  const [shiftStartDate, setShiftStartDate] = useState(getCurrentMonthStart());
  const [shiftEndDate, setShiftEndDate] = useState(getCurrentMonthEnd());

  const { chartData, loading, error, fetchProductionData } = useProductionData(selectedLine);
  const { data: deltaHourlyData, loading: hourlyLoading, error: hourlyError } = useDeltaActualData(selectedLine);

  const availableDates = useMemo(() => getUniqueDates(deltaHourlyData), [deltaHourlyData]);

  const filteredHourlyData = useMemo(
    () => filterDataByDateRange(deltaHourlyData, startDate, endDate),
    [deltaHourlyData, startDate, endDate]
  );

  const handleMetricToggle = (metric) => {
    setSelectedMetrics((prev) => ({ ...prev, [metric]: !prev[metric] }));
  };

  const getLineColor = (metric) => metricColors[metric] || '#111827';
  const isProductionGroup = productionGroups.some((group) => group.id === selectedLine);
  const selectedGroup = productionGroups.find((group) => group.id === selectedLine);

  return (
    <Layout>
      <div className="min-h-screen bg-white text-gray-900 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="lg:w-[230px] flex-shrink-0">
            <div className="bg-white p-3 border rounded-md shadow-md h-[calc(126vh-8rem)] overflow-y-auto">
              <div className="mb-4">
                <h2 className="text-lg font-bold text-green-700">Analytics</h2>
                <p className="text-xs text-gray-500 mt-1">Montiv unified single-file dashboard</p>
              </div>

              {/* <div className="mb-5">
                <h3 className="text-sm font-semibold mb-2 text-green-700">Groups</h3>
                <div className="grid grid-cols-2 gap-2">
                  {productionGroups.map((group) => (
                    <button
                      key={group.id}
                      onClick={() => setSelectedLine(group.id)}
                      className={`w-full text-left px-3 py-2 text-sm rounded border flex items-center transition-all ${
                        selectedLine === group.id
                          ? 'bg-green-400 border-black text-black shadow-[0_2px_4px_0_rgba(0,0,0,0.35),_0_1px_0_#222]'
                          : 'bg-white border-gray-300 text-gray-700 hover:bg-green-50'
                      }`}
                    >
                      <div
                        className="w-2 h-2 mr-2 rounded-full"
                        style={{ backgroundColor: selectedLine === group.id ? '#166534' : '#16a34a' }}
                      />
                      {group.name}
                    </button>
                  ))}
                </div>
              </div> */}

              <div>
                <h3 className="text-sm font-semibold mb-2 text-green-700">Lines</h3>
                <div className="space-y-1">
                  {productionLines.map((line) => (
                    <button
                      key={line.id}
                      onClick={() => setSelectedLine(line.id)}
                      className={`w-full text-left px-3 py-2 text-sm rounded border flex items-center transition-all ${
                        selectedLine === line.id
                          ? 'bg-green-400 border-black text-black shadow-[0_2px_4px_0_rgba(0,0,0,0.35),_0_1px_0_#222]'
                          : 'bg-white border-gray-300 text-gray-700 hover:bg-green-50'
                      }`}
                    >
                      <div
                        className="w-2 h-2 mr-2 rounded-full"
                        style={{ backgroundColor: selectedLine === line.id ? '#166534' : '#16a34a' }}
                      />
                      {line.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1">
            {isProductionGroup && selectedLine === 'pg_1' ? (
              <Pd1Dashboard />
            ) : isProductionGroup ? (
              <div className="bg-blue-50 border border-blue-300 rounded-lg p-6 text-blue-900 shadow-md">
                <h2 className="text-xl font-bold mb-2">📊 Group Dashboard: {selectedGroup?.name}</h2>
                <p className="text-sm mb-4">
                  You have selected <strong>{selectedGroup?.name}</strong>. This section displays the group placeholder for aggregated efficiency, productivity, and performance metrics.
                </p>
                <div className="bg-white p-4 rounded border border-blue-200 mt-4">
                  <h3 className="font-semibold text-blue-800 mb-2">Planned Features:</h3>
                  <ul className="list-disc list-inside text-sm text-blue-700 space-y-1">
                    <li>Combined efficiency chart across lines</li>
                    <li>Productivity comparison vs target</li>
                    <li>Shift-wise performance summary</li>
                    <li>Exportable group report</li>
                  </ul>
                </div>
              </div>
            ) : viewMode === 'hourly' ? (
              <div className="p-2 md:p-4 bg-white rounded shadow border border-gray-300 min-h-[60vh] w-full">
                {hourlyLoading ? (
                  <div className="p-4 text-center">
                    <div className="text-sm md:text-base font-medium">Memuat data...</div>
                  </div>
                ) : hourlyError ? (
                  <div className="p-4 text-red-500 text-center text-sm md:text-base">Error: {hourlyError}</div>
                ) : (
                  <>
                    <div className="mb-4">
                      <ChartControls
                        chartType={chartType}
                        setChartType={setChartType}
                        loading={loading}
                        fetchProductionData={fetchProductionData}
                        selectedLine={selectedLine}
                        chartData={chartData}
                        viewMode={viewMode}
                        setViewMode={setViewMode}
                        selectedMetrics={selectedMetrics}
                        handleMetricToggle={handleMetricToggle}
                        getLineColor={getLineColor}
                      />
                    </div>

                    <h1 className="text-center text-xl md:text-2xl font-semibold mb-2 text-gray-800 mt-1">
                      Catatan Delta Actual Per Jam - {getLineLabel(selectedLine)}
                    </h1>

                    <FilterControls
                      startDate={startDate}
                      endDate={endDate}
                      onStartDateChange={setStartDate}
                      onEndDateChange={setEndDate}
                      selectedChartType={selectedChartType}
                      onChartTypeChange={setSelectedChartType}
                      availableDates={availableDates}
                    />

                    <div className="w-full mt-2 min-h-[22rem] md:min-h-[28rem] mb-2">
                      <ChartComponent
                        data={filteredHourlyData}
                        chartType={selectedChartType}
                        startDate={startDate}
                        endDate={endDate}
                      />
                    </div>

                    {(startDate || endDate) && (
                      <div className="mt-2 p-2 bg-gray-50 rounded border border-gray-300 text-sm md:text-base text-gray-600 text-center shadow-sm mb-2">
                        <strong>Filter Aktif:</strong>{' '}
                        {startDate ? `Tanggal Mulai: ${new Date(startDate).toLocaleDateString('id-ID')}` : ''}
                        {endDate ? ` | Tanggal Akhir: ${new Date(endDate).toLocaleDateString('id-ID')}` : ''}
                      </div>
                    )}

                    {selectedLine !== 'common_rail_3_filtered' && (
                      <div className="mt-3 p-3 bg-amber-50 border border-amber-200 text-amber-800 rounded text-sm">
                        Mode hourly saat ini memakai endpoint delta actual untuk CR3. Pilih line <strong>CR3</strong> bila ingin melihat data hourly yang tersedia.
                      </div>
                    )}
                  </>
                )}
              </div>
            ) : viewMode === 'shift' ? (
              <div className="p-2 md:p-4 bg-white rounded shadow border border-gray-300 min-h-[60vh] w-full">
                {hourlyLoading ? (
                  <div className="p-4 text-center">
                    <div className="text-sm md:text-base font-medium">Memuat data...</div>
                  </div>
                ) : hourlyError ? (
                  <div className="p-4 text-red-500 text-center text-sm md:text-base">Error: {hourlyError}</div>
                ) : (
                  <>
                    <div className="mb-4">
                      <ChartControls
                        chartType={chartType}
                        setChartType={setChartType}
                        loading={loading}
                        fetchProductionData={fetchProductionData}
                        selectedLine={selectedLine}
                        chartData={chartData}
                        viewMode={viewMode}
                        setViewMode={setViewMode}
                        selectedMetrics={selectedMetrics}
                        handleMetricToggle={handleMetricToggle}
                        getLineColor={getLineColor}
                      />
                    </div>

                    <h1 className="text-center text-xl md:text-2xl font-semibold mb-2 text-gray-800 mt-1">
                      Konsumsi Actual per Shift - {getLineLabel(selectedLine)}
                    </h1>

                    <FilterControls
                      startDate={shiftStartDate}
                      endDate={shiftEndDate}
                      onStartDateChange={setShiftStartDate}
                      onEndDateChange={setShiftEndDate}
                      selectedChartType={selectedChartType}
                      onChartTypeChange={setSelectedChartType}
                      availableDates={availableDates}
                    />

                    <div className="w-full mt-4 min-h-[22rem] md:min-h-[28rem] mb-2">
                      <ActualConsumptionChart
                        data={deltaHourlyData}
                        startDate={shiftStartDate}
                        endDate={shiftEndDate}
                      />
                    </div>

                    {(shiftStartDate || shiftEndDate) && (
                      <div className="mt-2 p-2 bg-gray-50 rounded border border-gray-300 text-sm md:text-base text-gray-600 text-center shadow-sm mb-2">
                        <strong>Filter Aktif:</strong>{' '}
                        {shiftStartDate
                          ? `Tanggal Mulai: ${new Date(shiftStartDate).toLocaleDateString('id-ID')}`
                          : ''}
                        {shiftEndDate
                          ? ` | Tanggal Akhir: ${new Date(shiftEndDate).toLocaleDateString('id-ID')}`
                          : ''}
                      </div>
                    )}

                    {selectedLine !== 'common_rail_3_filtered' && (
                      <div className="mt-3 p-3 bg-amber-50 border border-amber-200 text-amber-800 rounded text-sm">
                        Mode shift saat ini memakai endpoint delta actual untuk CR3. Pilih line <strong>CR3</strong> bila ingin melihat data shift yang tersedia.
                      </div>
                    )}
                  </>
                )}
              </div>
            ) : (
              <ProductionChart
                chartType={chartType}
                setChartType={setChartType}
                chartData={chartData}
                loading={loading}
                error={error}
                fetchProductionData={fetchProductionData}
                selectedLine={selectedLine}
                selectedMetrics={selectedMetrics}
                handleMetricToggle={handleMetricToggle}
                getLineColor={getLineColor}
                viewMode={viewMode}
                setViewMode={setViewMode}
              />
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Montiv;
