import React, { useState, useEffect } from 'react';
import Layout from '../layout/Layout';

const KanribanGrafikBawahPG21 = () => {
  // ========== STATE UTAMA ==========
  const [data, setData] = useState({
    productCode: '902F-F',
    line: 'LINE COMMON RAIL 12',
    mct: '88.4',
    target100: 41,
    target89: 36,
    manpower: 4,
    yMin: 30,
    yMax: 50,
    dailyData: []
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState('902F-F');
  const [weekendDates, setWeekendDates] = useState([]);

  // Flash alert
  const [flashAlert, setFlashAlert] = useState({
    show: false,
    message: '',
    type: 'error'
  });

  // Filter state
  const [filters, setFilters] = useState({
    line: 'LINE COMMON RAIL 12',
    part: '',
    year: 2026,
    month: 2
  });

  // Opsi filter – LINE (manual, urut dari terbesar)
  const [availableLines] = useState([
    { value: 'LINE COMMON RAIL 12', label: 'LINE COMMON RAIL 12' },
    { value: 'LINE COMMON RAIL 11', label: 'LINE COMMON RAIL 11' },
    { value: 'LINE COMMON RAIL 10', label: 'LINE COMMON RAIL 10' },
    { value: 'LINE COMMON RAIL 9', label: 'LINE COMMON RAIL 9' },
    { value: 'LINE COMMON RAIL 8', label: 'LINE COMMON RAIL 8' },
    { value: 'LINE COMMON RAIL 7', label: 'LINE COMMON RAIL 7' },
    { value: 'LINE COMMON RAIL 6', label: 'LINE COMMON RAIL 6' },
    { value: 'LINE COMMON RAIL 5', label: 'LINE COMMON RAIL 5' },
    { value: 'LINE COMMON RAIL 4', label: 'LINE COMMON RAIL 4' },
    { value: 'LINE COMMON RAIL 3', label: 'LINE COMMON RAIL 3' },
    { value: 'LINE COMMON RAIL 2', label: 'LINE COMMON RAIL 2' },
    { value: 'LINE COMMON RAIL 1', label: 'LINE COMMON RAIL 1' }
  ]);

  // Opsi filter – dinamis, dengan default agar tidak kosong
  const [availableProducts, setAvailableProducts] = useState(['902F-F']);
  const [availableYears, setAvailableYears] = useState([2026]);
  const [availableMonths] = useState([
    { value: 1, label: 'Januari' },
    { value: 2, label: 'Februari' },
    { value: 3, label: 'Maret' },
    { value: 4, label: 'April' },
    { value: 5, label: 'Mei' },
    { value: 6, label: 'Juni' },
    { value: 7, label: 'Juli' },
    { value: 8, label: 'Agustus' },
    { value: 9, label: 'September' },
    { value: 10, label: 'Oktober' },
    { value: 11, label: 'November' },
    { value: 12, label: 'Desember' }
  ]);

  // Mapping line → endpoint
  const lineEndpoints = {
    'LINE COMMON RAIL 1': '/apiCr1/cr1Stop',
    'LINE COMMON RAIL 2': '/apiCr2/cr2Stop',
    'LINE COMMON RAIL 3': '/apiCr3/cr3Stop',
    'LINE COMMON RAIL 4': '/apiCr4/cr4Stop',
    'LINE COMMON RAIL 5': '/apiCr5/cr5Stop',
    'LINE COMMON RAIL 6': '/apiCr6/cr6Stop',
    'LINE COMMON RAIL 7': '/apiCr7/cr7Stop',
    'LINE COMMON RAIL 8': '/apiCr8/cr8Stop',
    'LINE COMMON RAIL 9': '/apiCr9/cr9Stop',
    'LINE COMMON RAIL 10': '/apiCr10/cr10Stop',
    'LINE COMMON RAIL 11': '/apiCr11/cr11Stop',
    'LINE COMMON RAIL 12': '/apiCr12/cr12Stop'
  };

  // ========== FUNGSI HELPER ==========
  const showFlashAlert = (message, type = 'error', duration = 5000) => {
    setFlashAlert({ show: false, message: '', type: 'error' });
    setTimeout(() => {
      setFlashAlert({ show: true, message, type });
      setTimeout(() => {
        setFlashAlert(prev => ({ ...prev, show: false }));
      }, duration);
    }, 50);
  };

  // Hitung weekend (hardcode untuk Feb 2026, sisanya otomatis)
  const calculateWeekendDates = (year, month) => {
    if (year === 2026 && month === 2) {
      return [1, 7, 8, 14, 15, 21, 22, 28];
    }
    const weekends = [];
    const daysInMonth = new Date(year, month, 0).getDate();
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month - 1, day);
      const dayOfWeek = date.getDay();
      if (dayOfWeek === 0 || dayOfWeek === 6) weekends.push(day);
    }
    return weekends;
  };

  // Tampilkan data kosong + hitung ulang target
  const setEmptyData = (line, year, month, part = '') => {
    const daysInMonth = new Date(year, month, 0).getDate();
    const weekendDates = calculateWeekendDates(year, month);
    setWeekendDates(weekendDates);

    setData(prev => {
      const mctValue = parseFloat(prev.mct || 88.4);
      const target100 = Math.round((3600 / (mctValue / 10)) * 10) / 10;
      const target89 = Math.round(target100 * 0.89 * 10) / 10;

      return {
        ...prev,
        productCode: part || prev.productCode,
        line,
        target100,
        target89,
        yMin: 30,
        yMax: 50,
        dailyData: Array.from({ length: daysInMonth }, (_, i) => ({
          day: i + 1,
          shift1Production: '',
          shift1LoadingTime: '',
          shift1PcsJam: '',
          shift2Production: '',
          shift2LoadingTime: '',
          shift2PcsJam: '',
          dangae: '',
          isWeekend: weekendDates.includes(i + 1)
        }))
      };
    });
  };

  // Ekstrak opsi filter dari data API
  const extractFilterOptions = (apiData) => {
    if (!apiData || apiData.length === 0) return;
    const products = [...new Set(apiData
      .map(item => item.name_product)
      .filter(p => p && p.trim() !== '')
    )].sort();
    setAvailableProducts(products.length ? products : ['902F-F']);

    const years = [...new Set(apiData
      .map(item => {
        if (item.year) return parseInt(item.year);
        if (item.created_at) return new Date(item.created_at).getFullYear();
        return null;
      })
      .filter(y => !isNaN(y) && y > 0)
    )].sort((a, b) => b - a);
    setAvailableYears(years.length ? years : [2026]);
  };

  // ========== PROSES DATA UNTUK GRAFIK & TABEL ==========
  const processFilteredData = (apiData, currentFilters, isInitial = false) => {
    const { part, year, month } = currentFilters;

    // Filter data
    const filteredData = apiData.filter(item => {
      if (part && item.name_product !== part) return false;
      let itemYear;
      if (item.year) itemYear = parseInt(item.year);
      else if (item.created_at) itemYear = new Date(item.created_at).getFullYear();
      if (year && itemYear !== year) return false;

      let itemMonth;
      if (item.month) itemMonth = parseInt(item.month);
      else if (item.created_at) itemMonth = new Date(item.created_at).getMonth() + 1;
      if (month && itemMonth !== month) return false;
      return true;
    });

    // Jika tidak ada data → tampilkan data kosong
    if (filteredData.length === 0) {
      const message = `Tidak ada data untuk ${part || 'produk terpilih'} pada ${getMonthName(month)} ${year}`;
      setError(message);
      showFlashAlert(message, 'warning');
      setEmptyData(currentFilters.line, year, month, part);
      return;
    }

    setError(null);
    if (!isInitial) {
      showFlashAlert(`Data berhasil ditampilkan`, 'success', 3000);
    }

    // Hitung weekend
    const weekendDates = calculateWeekendDates(year, month);
    setWeekendDates(weekendDates);

    // Hitung target dari cycle_time
    const calculateTarget100 = (cycleTime) => {
      const val = parseFloat(cycleTime) || 88.4;
      return Math.round((3600 / (val / 10)) * 10) / 10;
    };
    const calculateTarget89 = (t100) => Math.round(t100 * 0.89 * 10) / 10;

    const firstItem = filteredData[0];
    const target100 = calculateTarget100(firstItem.cycle_time);
    const target89 = calculateTarget89(target100);

    // Grouping per hari + shift
    const dailyStats = {};
    const daysInMonth = new Date(year, month, 0).getDate();

    filteredData.forEach(item => {
      if (!item.created_at) return;
      const [datePart, timePart = '00:00:00'] = item.created_at.split(' ');
      const [iy, im, id] = datePart.split('-').map(Number);
      const [hours, minutes] = timePart.split(':').map(Number);

      const shift = item.shift || 'Shift 1';
      const totalMinutes = (hours || 0) * 60 + (minutes || 0);
      const shift1Start = 7 * 60 + 10;
      const shift1End = 19 * 60 + 50;
      const shift2Start = 19 * 60 + 50;
      const shift2End = 7 * 60 + 10;

      let day = id;
      if (shift === 'Shift 2' && totalMinutes <= shift2End) {
        day = id - 1;
      }
      if (day < 1) day = daysInMonth;
      if (day > daysInMonth) day = daysInMonth;

      if (!dailyStats[day]) {
        dailyStats[day] = {
          shift1: { production: 0, loadingTime: 0, pcsJam: 0, hasData: false, items: [] },
          shift2: { production: 0, loadingTime: 0, pcsJam: 0, hasData: false, items: [] }
        };
      }

      const shiftKey = shift === 'Shift 1' ? 'shift1' : 'shift2';
      const production = parseInt(item.actual) || 0;
      let loadingTime = 0;
      if (item.loading_time) {
        loadingTime = parseFloat(item.loading_time.replace(' menit', '').trim()) || 0;
      } else if (item.loading_time) {
        loadingTime = parseFloat(item.loading_time) || 0;
      }

      dailyStats[day][shiftKey].items.push({ production, loadingTime, createdAt: item.created_at, hours, minutes, originalDay: id, shift });
      dailyStats[day][shiftKey].hasData = true;
    });

    // Hitung total per shift
    Object.keys(dailyStats).forEach(day => {
      ['shift1', 'shift2'].forEach(sk => {
        const s = dailyStats[day][sk];
        if (s.items.length > 0) {
          s.production = s.items.reduce((sum, it) => sum + it.production, 0);
          const totalLT = s.items.reduce((sum, it) => sum + it.loadingTime, 0);
          s.loadingTime = s.items.length ? totalLT / s.items.length : 0;
          s.pcsJam = s.loadingTime > 0 ? (s.production / (s.loadingTime / 60)) : 0;
        }
      });
    });

    // Konversi ke array
    const dailyDataArray = Object.keys(dailyStats).map(day => {
      const d = parseInt(day);
      return {
        day: d,
        shift1Production: dailyStats[d].shift1.production,
        shift1LoadingTime: dailyStats[d].shift1.loadingTime,
        shift1PcsJam: Math.round(dailyStats[d].shift1.pcsJam * 10) / 10,
        shift2Production: dailyStats[d].shift2.production,
        shift2LoadingTime: dailyStats[d].shift2.loadingTime,
        shift2PcsJam: Math.round(dailyStats[d].shift2.pcsJam * 10) / 10,
        dangae: '',
        isWeekend: weekendDates.includes(d)
      };
    }).sort((a, b) => a.day - b.day);

    // Hitung range Y
    const allPcsJam = dailyDataArray.flatMap(d => [d.shift1PcsJam, d.shift2PcsJam]).filter(v => v > 0);
    const minPcs = allPcsJam.length ? Math.min(...allPcsJam) : 30;
    const maxPcs = allPcsJam.length ? Math.max(...allPcsJam) : 50;
    const yMin = Math.max(0, Math.floor(minPcs / 5) * 5 - 5);
    const yMax = Math.ceil(Math.max(maxPcs, target100) / 5) * 5 + 5;

    setSelectedProduct(part);
    setData(prev => ({
      ...prev,
      productCode: part || firstItem.name_product || prev.productCode,
      line: firstItem.line_name || filters.line || prev.line,
      mct: firstItem.setup_ct || prev.mct,
      target100,
      target89,
      yMin,
      yMax,
      dailyData: dailyDataArray
    }));
  };

  // ========== FETCH DATA – SATU SATU-NYA useEffect ==========
  useEffect(() => {
    let isMounted = true;
    const controller = new AbortController();

    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const endpoint = lineEndpoints[filters.line];
        if (!endpoint) {
          throw new Error(`Endpoint tidak ditemukan untuk ${filters.line}`);
        }

        const response = await fetch(endpoint, { signal: controller.signal });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();

        if (!isMounted) return;

        if (result.status === 'success' && result.data?.length > 0) {
          extractFilterOptions(result.data);
          processFilteredData(result.data, filters, false);
        } else {
          const msg = `Tidak ada data untuk ${filters.line}`;
          setError(msg);
          showFlashAlert(msg, 'warning');
          setEmptyData(filters.line, filters.year, filters.month, filters.part);
        }
      } catch (err) {
        if (!isMounted || err.name === 'AbortError') return;
        console.error('Fetch error:', err);
        showFlashAlert(`Gagal mengambil data dari ${filters.line}`, 'error');
        setEmptyData(filters.line, filters.year, filters.month, filters.part);
        setError(err.message);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchData();

    return () => {
      isMounted = false;
      controller.abort();
    };
  }, [filters]); // HANYA SATU useEffect – dependensi [filters]

  // ========== INISIALISASI PERTAMA ==========
  useEffect(() => {
    // Set filter default, useEffect di atas akan otomatis menjalankan fetch
    setFilters({
      line: 'LINE COMMON RAIL 12',
      part: '',
      year: 2026,
      month: 2
    });
    setAvailableYears([2026]);
    setAvailableProducts(['902F-F']);
  }, []);

  // ========== HANDLER FILTER ==========
  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  const handleResetFilters = () => {
    setFilters({
      line: 'LINE COMMON RAIL 12',
      part: '',
      year: 2026,
      month: 2
    });
  };

  // ========== FORMAT NAMA BULAN & HARI ==========
  const getMonthName = (month) => {
    const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    return months[month - 1] || '';
  };

  const getDayName = (day) => {
    const date = new Date(filters.year, filters.month - 1, day);
    return ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][date.getDay()];
  };

  // ========== PERHITUNGAN CHART ==========
  const totalDays = new Date(filters.year, filters.month, 0).getDate();
  const chartWidth = 1200;
  const chartHeight = 200;
  const dayWidth = chartWidth / totalDays;

  const getXPosition = (dayIndex) => dayIndex * dayWidth + dayWidth / 2;

  const getYPosition = (value) => {
    const minY = data.yMin || 30;
    const maxY = data.yMax || 50;
    const range = maxY - minY;
    return chartHeight - ((value - minY) / range) * chartHeight;
  };

  const generateYAxisValues = () => {
    const minY = data.yMin || 30;
    const maxY = data.yMax || 50;
    const step = Math.ceil((maxY - minY) / 4);
    const values = [];
    for (let i = minY; i <= maxY; i += step) values.push(Math.round(i));
    if (!values.includes(Math.round(data.target100))) values.push(Math.round(data.target100));
    if (!values.includes(Math.round(data.target89))) values.push(Math.round(data.target89));
    return values.sort((a, b) => a - b);
  };

  // ========== RENDER ==========
  if (loading) {
    return (
      <Layout>
        <div style={{ padding: '20px', textAlign: 'center', fontSize: '18px' }}>
          Loading data dari {filters.line}...
        </div>
      </Layout>
    );
  }

  const yAxisValues = generateYAxisValues();

  return (
    <Layout>
      <div style={{ 
        padding: '20px', 
        backgroundColor: 'white',
        border: '4px solid black',
        borderRadius: '15px',
        fontFamily: 'Arial, sans-serif'
      }}>
        {/* Flash Alert */}
        {flashAlert.show && (
          <div style={{
            position: 'fixed',
            top: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 1000,
            padding: '20px 30px',
            backgroundColor: flashAlert.type === 'error' ? '#f8d7da' : 
                           flashAlert.type === 'warning' ? '#fff3cd' : '#d4edda',
            color: flashAlert.type === 'error' ? '#721c24' : 
                   flashAlert.type === 'warning' ? '#856404' : '#155724',
            border: `3px solid ${flashAlert.type === 'error' ? '#f5c6cb' : 
                              flashAlert.type === 'warning' ? '#ffeaa7' : '#c3e6cb'}`,
            borderRadius: '12px',
            boxShadow: '0 6px 20px rgba(0,0,0,0.25)',
            fontWeight: 'bold',
            fontSize: '20px',
            animation: flashAlert.type === 'error' ? 'blink 1s infinite' : 'fadeIn 0.5s',
            minWidth: '400px',
            textAlign: 'center',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '15px'
          }}>
            {flashAlert.type === 'error' ? '❌' : 
             flashAlert.type === 'warning' ? '⚠️' : '✅'}
            <span>{flashAlert.message}</span>
          </div>
        )}

        {/* Filter Section */}
        <div style={{
          marginBottom: '20px',
          padding: '15px',
          backgroundColor: '#f8f9fa',
          border: '1px solid #dee2e6',
          borderRadius: '8px'
        }}>
          <h3 style={{ marginTop: 0, marginBottom: '15px', color: '#333' }}>
            Filter Data
          </h3>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '15px',
            marginBottom: '15px'
          }}>
            {/* Line Filter */}
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                Line
              </label>
              <select
                value={filters.line}
                onChange={(e) => handleFilterChange('line', e.target.value)}
                style={{
                  width: '100%',
                  padding: '8px',
                  border: '1px solid #ced4da',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                {availableLines.map(line => (
                  <option key={line.value} value={line.value}>
                    {line.label}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Product/Part Filter */}
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                Product / Part
              </label>
              <select
                value={filters.part}
                onChange={(e) => handleFilterChange('part', e.target.value)}
                style={{
                  width: '100%',
                  padding: '8px',
                  border: '1px solid #ced4da',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                <option value="">All Products</option>
                {availableProducts.map(product => (
                  <option key={product} value={product}>
                    {product}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Year Filter */}
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                Tahun
              </label>
              <select
                value={filters.year}
                onChange={(e) => handleFilterChange('year', parseInt(e.target.value))}
                style={{
                  width: '100%',
                  padding: '8px',
                  border: '1px solid #ced4da',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                {availableYears.map(year => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Month Filter */}
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                Bulan
              </label>
              <select
                value={filters.month}
                onChange={(e) => handleFilterChange('month', parseInt(e.target.value))}
                style={{
                  width: '100%',
                  padding: '8px',
                  border: '1px solid #ced4da',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                {availableMonths.map(month => (
                  <option key={month.value} value={month.value}>
                    {month.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div style={{ fontSize: '14px', color: '#666' }}>
              Menampilkan data untuk: <strong>{filters.line}</strong> -{' '}
              <strong>{filters.part || 'Semua Produk'}</strong> -{' '}
              <strong>{getMonthName(filters.month)} {filters.year}</strong>
            </div>
            
            <button
              onClick={handleResetFilters}
              style={{
                padding: '8px 16px',
                backgroundColor: '#6c757d',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              Reset Filter
            </button>
          </div>
        </div>

        {/* Header */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'flex-start',
          marginBottom: '10px'
        }}>
          <div style={{ fontSize: '14px', fontWeight: 'bold' }}>
            <div>Target (100%) :</div>
            <div>{data.target100} Pcs/Jam</div>
            <div style={{ marginTop: '5px' }}>Target (89%) :</div>
            <div>{data.target89} Pcs/Jam</div>
          </div>
          <div style={{ 
            textAlign: 'center',
            fontSize: '18px',
            fontWeight: 'bold'
          }}>
            <div>{data.line}</div>
            <div style={{ fontSize: '24px', marginTop: '5px' }}>
              GRAFIK Pcs/Jam {data.productCode}
            </div>
            <div style={{ fontSize: '14px', marginTop: '5px', color: 'blue' }}>
              Product: {data.productCode} | Cycle Time: {parseFloat(data.mct || 88.4)}s
            </div>
            <div style={{ fontSize: '12px', marginTop: '5px', color: 'green' }}>
              Periode: {getMonthName(filters.month)} {filters.year}
            </div>
          </div>
          <div style={{ fontSize: '14px', fontWeight: 'bold' }}>
            <div>{parseFloat(data.manpower) || 4}MP Cycle Time = {data.mct}s/Pcs</div>
            <div style={{ marginTop: '5px' }}>Y-Axis Range:</div>
            <div>{data.yMin || 30} - {data.yMax || 50} Pcs/Jam</div>
          </div>
        </div>

        {/* Chart Area */}
        <div style={{ 
          position: 'relative', 
          height: '240px', 
          marginBottom: '10px',
          marginLeft: '50px',
          marginRight: '20px'
        }}>
          <svg width="100%" height="100%" viewBox="0 0 1200 200" preserveAspectRatio="xMidYMid meet">
            {/* Background grid - horizontal lines */}
            {yAxisValues.map((val, idx) => (
              <line 
                key={`h-${idx}`}
                x1="0" 
                y1={getYPosition(val)} 
                x2="1200" 
                y2={getYPosition(val)}
                stroke="#B8E6F5" 
                strokeWidth="0.5"
              />
            ))}
            
            {/* Vertical lines for each day - TIDAK LAGI MERAH UNTUK WEEKEND */}
            {Array.from({ length: totalDays + 1 }).map((_, idx) => (
              <line 
                key={`v-${idx}`}
                x1={idx * dayWidth} 
                y1="0" 
                x2={idx * dayWidth} 
                y2="200"
                stroke="#B8E6F5"      // ← warna grid standar
                strokeWidth="0.5"      // ← ketebalan tipis
              />
            ))}

            {/* Target line (100%) */}
            <line 
              x1="0" 
              y1={getYPosition(data.target100)} 
              x2="1200" 
              y2={getYPosition(data.target100)}
              stroke="red" 
              strokeWidth="2"
              strokeDasharray="10,5"
            />
            <g>
              <rect 
                x="1180" 
                y={getYPosition(data.target100) - 8} 
                width="50" 
                height="16" 
                fill="white" 
                stroke="red" 
                strokeWidth="0.5"
                rx="2"
              />
              <text 
                x="1205" 
                y={getYPosition(data.target100) + 3} 
                fontSize="10" 
                fill="red"
                fontWeight="bold"
                textAnchor="middle"
              >
                100% ({data.target100})
              </text>
            </g>

            {/* Target line (89%) */}
            <line 
              x1="0" 
              y1={getYPosition(data.target89)} 
              x2="1200" 
              y2={getYPosition(data.target89)}
              stroke="red" 
              strokeWidth="2"
              strokeDasharray="10,5"
            />
            <g>
              <rect 
                x="1180" 
                y={getYPosition(data.target89) - 8} 
                width="50" 
                height="16" 
                fill="white" 
                stroke="red" 
                strokeWidth="0.5"
                rx="2"
              />
              <text 
                x="1205" 
                y={getYPosition(data.target89) + 3} 
                fontSize="10" 
                fill="red"
                fontWeight="bold"
                textAnchor="middle"
              >
                89% ({data.target89})
              </text>
            </g>

            {/* Plot data points and lines for Shift 1 (Blue) */}
            {data.dailyData.length > 0 && data.dailyData.some(d => d.shift1PcsJam > 0) && (
              <>
                <polyline
                  points={data.dailyData
                    .filter(d => d.shift1PcsJam > 0)
                    .map(d => `${getXPosition(d.day - 1)},${getYPosition(d.shift1PcsJam)}`)
                    .join(' ')}
                  fill="none"
                  stroke="blue"
                  strokeWidth="2"
                />
                {data.dailyData.map((d, idx) => 
                  d.shift1PcsJam > 0 && (
                    <g key={`s1-${idx}`}>
                      <circle 
                        cx={getXPosition(d.day - 1)} 
                        cy={getYPosition(d.shift1PcsJam)} 
                        r="4" 
                        fill="blue" 
                      />
                      <text 
                        x={getXPosition(d.day - 1)} 
                        y={getYPosition(d.shift1PcsJam) - 8} 
                        fontSize="8" 
                        textAnchor="middle"
                        fill="blue"
                        fontWeight="bold"
                      >
                        {d.shift1PcsJam}
                      </text>
                    </g>
                  )
                )}
              </>
            )}

            {/* Plot data points and lines for Shift 2 (Black) */}
            {data.dailyData.length > 0 && data.dailyData.some(d => d.shift2PcsJam > 0) && (
              <>
                <polyline
                  points={data.dailyData
                    .filter(d => d.shift2PcsJam > 0)
                    .map(d => `${getXPosition(d.day - 1)},${getYPosition(d.shift2PcsJam)}`)
                    .join(' ')}
                  fill="none"
                  stroke="black"
                  strokeWidth="2"
                />
                {data.dailyData.map((d, idx) => 
                  d.shift2PcsJam > 0 && (
                    <g key={`s2-${idx}`}>
                      <circle 
                        cx={getXPosition(d.day - 1)} 
                        cy={getYPosition(d.shift2PcsJam)} 
                        r="4" 
                        fill="black" 
                      />
                      <text 
                        x={getXPosition(d.day - 1)} 
                        y={getYPosition(d.shift2PcsJam) - 8} 
                        fontSize="8" 
                        textAnchor="middle"
                        fill="black"
                        fontWeight="bold"
                      >
                        {d.shift2PcsJam}
                      </text>
                    </g>
                  )
                )}
              </>
            )}
          </svg>

          {/* Y-axis labels */}
          <div style={{ 
            position: 'absolute', 
            left: '-50px', 
            top: '0', 
            height: '100%',
            width: '40px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between'
          }}>
            {yAxisValues.slice().reverse().map((val) => (
              <div 
                key={val}
                style={{ 
                  fontSize: '12px',
                  fontWeight: 'bold',
                  textAlign: 'right',
                  paddingRight: '5px',
                  backgroundColor: 'white',
                  padding: '2px'
                }}
              >
                {val}
              </div>
            ))}
          </div>

          {/* X-axis labels - tanggal di bawah chart */}
          <div style={{
            position: 'absolute',
            bottom: '-25px',
            left: '0',
            width: '100%',
            display: 'flex',
            justifyContent: 'space-between'
          }}>
            {Array.from({ length: totalDays }, (_, i) => {
              const day = i + 1;
              const isWeekend = weekendDates.includes(day);
              const dayName = getDayName(day).substring(0, 3);
              
              return (
                <div
                  key={`xlabel-${day}`}
                  style={{
                    width: `${dayWidth}px`,
                    textAlign: 'center',
                    fontSize: '10px',
                    fontWeight: isWeekend ? 'bold' : 'normal',
                    color: isWeekend ? 'red' : 'black',
                    transform: 'translateX(-50%)',
                    marginLeft: `${dayWidth/2}px`
                  }}
                >
                  <div style={{ fontSize: '8px' }}>{dayName}</div>
                  <div style={{ fontWeight: 'bold' }}>{day}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Legend dan Info */}
        <div style={{ 
          display: 'flex', 
          gap: '20px', 
          marginBottom: '10px', 
          marginLeft: '20px',
          marginTop: '30px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <div style={{ width: '30px', height: '15px', backgroundColor: 'blue' }}></div>
            <span style={{ fontSize: '12px', fontWeight: 'bold' }}>Shift 1</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <div style={{ width: '30px', height: '15px', backgroundColor: 'black' }}></div>
            <span style={{ fontSize: '12px', fontWeight: 'bold' }}>Shift 2</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <div style={{ width: '30px', height: '2px', backgroundColor: 'red', border: '1px dashed red' }}></div>
            <span style={{ fontSize: '12px', fontWeight: 'bold', color: 'red' }}>Target (100% & 89%)</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <div style={{ width: '15px', height: '15px', backgroundColor: '#ffcccc' }}></div>
            <span style={{ fontSize: '12px', fontWeight: 'bold' }}>Tanggal Merah</span>
          </div>
        </div>

        {/* Data Table */}
        <div style={{ overflowX: 'auto', marginTop: '20px' }}>
          <table style={{ 
            width: '100%', 
            borderCollapse: 'collapse',
            fontSize: '11px',
            minWidth: '1200px'
          }}>
            <thead>
              <tr>
                <th style={{ 
                  border: '1px solid black', 
                  padding: '4px', 
                  minWidth: '100px',
                  textAlign: 'center',
                  position: 'sticky',
                  left: 0,
                  backgroundColor: 'white',
                  zIndex: 10
                }}>
                  <div>Hari/Tgl</div>
                  <div>{getMonthName(filters.month)} {filters.year}</div>
                </th>
                {Array.from({ length: totalDays }, (_, i) => {
                  const day = i + 1;
                  const isWeekend = weekendDates.includes(day);
                  const dayName = getDayName(day);
                  
                  return (
                    <th 
                      key={`th-${day}`}
                      style={{ 
                        border: '1px solid black',
                        padding: '4px',
                        backgroundColor: isWeekend ? '#ffcccc' : 'white',
                        fontSize: '10px',
                        minWidth: '35px',
                        textAlign: 'center'
                      }}
                    >
                      <div style={{ 
                        fontSize: '8px', 
                        color: isWeekend ? 'red' : 'black',
                        fontWeight: isWeekend ? 'bold' : 'normal'
                      }}>
                        {dayName.substring(0, 3)}
                      </div>
                      <div style={{ 
                        fontWeight: 'bold', 
                        fontSize: '12px',
                        color: isWeekend ? 'red' : 'black'
                      }}>
                        {day}
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>

            <tbody>
              {/* Shift 1 (Blue) */}
              <tr>
                <td style={{ 
                  border: '1px solid black', 
                  padding: '4px', 
                  fontWeight: 'bold', 
                  backgroundColor: 'blue', 
                  color: 'white',
                  verticalAlign: 'middle',
                  textAlign: 'center',
                  position: 'sticky',
                  left: 0,
                  zIndex: 9
                }}>
                  Shift 1
                </td>
                {Array.from({ length: totalDays }, (_, i) => {
                  const day = i + 1;
                  const dayData = data.dailyData.find(d => d.day === day);
                  const pcsJam = dayData?.shift1PcsJam || 0;
                  const isAboveTarget100 = pcsJam >= data.target100;
                  const isAboveTarget89 = pcsJam >= data.target89;
                  const isWeekend = weekendDates.includes(day);
                  
                  return (
                    <td 
                      key={`s1p-${day}`}
                      style={{ 
                        border: '1px solid black',
                        padding: '4px',
                        textAlign: 'center',
                        fontWeight: 'bold',
                        backgroundColor: isAboveTarget100 ? '#90EE90' : 
                                       isAboveTarget89 ? '#FFD700' : 
                                       pcsJam > 0 ? '#FFB6C1' : 
                                       isWeekend ? '#ffcccc' : 'white'
                      }}
                    >
                      {dayData?.shift1Production || ''}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td style={{ 
                  border: '1px solid black', 
                  padding: '4px',
                  textAlign: 'center',
                  position: 'sticky',
                  left: 0,
                  backgroundColor: 'white',
                  zIndex: 9
                }}>
                  Loading Time
                </td>
                {Array.from({ length: totalDays }, (_, i) => {
                  const day = i + 1;
                  const dayData = data.dailyData.find(d => d.day === day);
                  const isWeekend = weekendDates.includes(day);
                  
                  return (
                    <td 
                      key={`s1lt-${day}`}
                      style={{ 
                        border: '1px solid black',
                        padding: '4px',
                        textAlign: 'center',
                        backgroundColor: isWeekend ? '#ffcccc' : 'white'
                      }}
                    >
                      {dayData?.shift1LoadingTime ? Math.round(dayData.shift1LoadingTime) : ''}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td style={{ 
                  border: '1px solid black', 
                  padding: '4px',
                  textAlign: 'center',
                  position: 'sticky',
                  left: 0,
                  backgroundColor: 'white',
                  zIndex: 9
                }}>
                  Pcs/jam
                </td>
                {Array.from({ length: totalDays }, (_, i) => {
                  const day = i + 1;
                  const dayData = data.dailyData.find(d => d.day === day);
                  const pcsJam = dayData?.shift1PcsJam || 0;
                  const isAboveTarget100 = pcsJam >= data.target100;
                  const isAboveTarget89 = pcsJam >= data.target89;
                  const isWeekend = weekendDates.includes(day);
                  
                  return (
                    <td 
                      key={`s1pj-${day}`}
                      style={{ 
                        border: '1px solid black',
                        padding: '4px',
                        textAlign: 'center',
                        fontWeight: 'bold',
                        backgroundColor: isAboveTarget100 ? '#90EE90' : 
                                       isAboveTarget89 ? '#FFD700' : 
                                       pcsJam > 0 ? '#FFB6C1' : 
                                       isWeekend ? '#ffcccc' : 'white'
                      }}
                    >
                      {dayData?.shift1PcsJam || ''}
                    </td>
                  );
                })}
              </tr>

              {/* Shift 2 (Black) */}
              <tr>
                <td style={{ 
                  border: '1px solid black', 
                  padding: '4px', 
                  fontWeight: 'bold', 
                  backgroundColor: 'black', 
                  color: 'white',
                  verticalAlign: 'middle',
                  textAlign: 'center',
                  position: 'sticky',
                  left: 0,
                  zIndex: 9
                }}>
                  Shift 2
                </td>
                {Array.from({ length: totalDays }, (_, i) => {
                  const day = i + 1;
                  const dayData = data.dailyData.find(d => d.day === day);
                  const pcsJam = dayData?.shift2PcsJam || 0;
                  const isAboveTarget100 = pcsJam >= data.target100;
                  const isAboveTarget89 = pcsJam >= data.target89;
                  const isWeekend = weekendDates.includes(day);
                  
                  return (
                    <td 
                      key={`s2p-${day}`}
                      style={{ 
                        border: '1px solid black',
                        padding: '4px',
                        textAlign: 'center',
                        fontWeight: 'bold',
                        backgroundColor: isAboveTarget100 ? '#90EE90' : 
                                       isAboveTarget89 ? '#FFD700' : 
                                       pcsJam > 0 ? '#FFB6C1' : 
                                       isWeekend ? '#ffcccc' : 'white'
                      }}
                    >
                      {dayData?.shift2Production || ''}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td style={{ 
                  border: '1px solid black', 
                  padding: '4px',
                  textAlign: 'center',
                  position: 'sticky',
                  left: 0,
                  backgroundColor: 'white',
                  zIndex: 9
                }}>
                  Loading Time
                </td>
                {Array.from({ length: totalDays }, (_, i) => {
                  const day = i + 1;
                  const dayData = data.dailyData.find(d => d.day === day);
                  const isWeekend = weekendDates.includes(day);
                  
                  return (
                    <td 
                      key={`s2lt-${day}`}
                      style={{ 
                        border: '1px solid black',
                        padding: '4px',
                        textAlign: 'center',
                        backgroundColor: isWeekend ? '#ffcccc' : 'white'
                      }}
                    >
                      {dayData?.shift2LoadingTime ? Math.round(dayData.shift2LoadingTime) : ''}
                    </td>
                  );
                })}
              </tr>
              <tr>
                <td style={{ 
                  border: '1px solid black', 
                  padding: '4px',
                  textAlign: 'center',
                  position: 'sticky',
                  left: 0,
                  backgroundColor: 'white',
                  zIndex: 9
                }}>
                  Pcs/jam
                </td>
                {Array.from({ length: totalDays }, (_, i) => {
                  const day = i + 1;
                  const dayData = data.dailyData.find(d => d.day === day);
                  const pcsJam = dayData?.shift2PcsJam || 0;
                  const isAboveTarget100 = pcsJam >= data.target100;
                  const isAboveTarget89 = pcsJam >= data.target89;
                  const isWeekend = weekendDates.includes(day);
                  
                  return (
                    <td 
                      key={`s2pj-${day}`}
                      style={{ 
                        border: '1px solid black',
                        padding: '4px',
                        textAlign: 'center',
                        fontWeight: 'bold',
                        backgroundColor: isAboveTarget100 ? '#90EE90' : 
                                       isAboveTarget89 ? '#FFD700' : 
                                       pcsJam > 0 ? '#FFB6C1' : 
                                       isWeekend ? '#ffcccc' : 'white'
                      }}
                    >
                      {dayData?.shift2PcsJam || ''}
                    </td>
                  );
                })}
              </tr>
            </tbody>
          </table>
        </div>
        
        {/* Color Legend dan Info */}
        <div style={{ 
          marginTop: '15px', 
          display: 'flex', 
          justifyContent: 'space-between',
          alignItems: 'flex-start',
          flexWrap: 'wrap',
          gap: '15px'
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '10px', fontWeight: 'bold', marginBottom: '5px' }}>
              Legend Warna Tabel:
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <div style={{ width: '15px', height: '15px', backgroundColor: '#90EE90' }}></div>
                <span style={{ fontSize: '10px' }}>≥ Target 100% ({data.target100} Pcs/Jam)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <div style={{ width: '15px', height: '15px', backgroundColor: '#FFD700' }}></div>
                <span style={{ fontSize: '10px' }}>≥ Target 89% ({data.target89} Pcs/Jam)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <div style={{ width: '15px', height: '15px', backgroundColor: '#FFB6C1' }}></div>
                <span style={{ fontSize: '10px' }}>&lt; Target 89%</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <div style={{ width: '15px', height: '15px', backgroundColor: '#ffcccc' }}></div>
                <span style={{ fontSize: '10px' }}>Tanggal Merah (Weekend/Hari Libur)</span>
              </div>
            </div>
          </div>
          
          <div style={{ 
            padding: '8px',
            backgroundColor: '#f0f0f0',
            border: '1px solid #ccc',
            borderRadius: '5px',
            fontSize: '11px',
            flex: 1
          }}>
            <div><strong>Info Filter & Perhitungan:</strong></div>
            <div>• Line: {filters.line}</div>
            <div>• Product: {filters.part || 'All Products'}</div>
            <div>• Periode: {getMonthName(filters.month)} {filters.year}</div>
            <div>• Target 100% = 3600 / (Cycle Time / 10) = 3600 / ({parseFloat(data.mct || 88.4)} / 10) = {data.target100} Pcs/Jam</div>
            <div>• Target 89% = Target 100% × 0.89 = {data.target100} × 0.89 = {data.target89} Pcs/Jam</div>
            <div>• Cycle Time: {parseFloat(data.mct || 88.4)} detik per pcs</div>
            <div>• Data Source: {lineEndpoints[filters.line] || 'Unknown'}</div>
          </div>
        </div>
      </div>

      {/* CSS untuk animasi */}
      <style>{`
        @keyframes blink {
          0% { opacity: 1; transform: translateX(-50%) scale(1); }
          50% { opacity: 0.7; transform: translateX(-50%) scale(1.05); }
          100% { opacity: 1; transform: translateX(-50%) scale(1); }
        }
        
        @keyframes fadeIn {
          from { opacity: 0; transform: translateX(-50%) translateY(-20px); }
          to { opacity: 1; transform: translateX(-50%) translateY(0); }
        }
      `}</style>
    </Layout>
  );
};

export default KanribanGrafikBawahPG21;