import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Wrench,
  Zap,
  FileText,
  Home,
  X,
  ChevronRight,
  ChevronLeft,
  User,
  Calendar,
  Activity,
  Layout,
  Settings,
  Image,
  EllipsisVertical,
  TruckElectric,
  CompassIcon,
  UtilityPole,
  PanelBottomCloseIcon,
  CommandIcon,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { AirOutlined, SolarPower } from '@mui/icons-material';

const Sidebar = ({ isCollapsed, onToggle, onClose }) => {
  const { user } = useAuth();

  const menuSections = [
    {
      title: 'MANHOUR',
      items: [
        { name: 'Manhour Setting', path: '/manhour', icon: Settings },
        // { name: 'Breakdown Manhour', path: '/breakdown', icon: Wrench },
        { name: 'Manhour User', path: '/ManhourGuest', icon: User },
        { name: 'Manhour Monthly', path: '/ManhourBawah', icon: Calendar },
        { name: 'Asakai', path: '/cr7', icon: Activity },
      ],
    },




    {
      title: 'PRODUCTION',
      items: [
        { name: 'Montiv', path: '/montiv', icon: Settings },
      ],
    },


    {
      title: 'PLTS',
      items: [
        { name: 'PLTS PLANT 1', path: '/plts_p1', icon: SolarPower },
        { name: 'PLTS PLANT 2', path: '/plts', icon: SolarPower },
        { name: 'PLTS Dashboard', path: '/plts_common_dashboard', icon: CommandIcon },
        { name: 'PLTS Report', path: '/plts_common', icon: CommandIcon },

      ],
    },




    {
      title: 'LISTRIK',
      items: [
        { name: 'Listrik Otics 1', path: '/kwh', icon: Zap },
        { name: 'Compresor', path: '/comp', icon: CompassIcon },
        { name: 'Line Detail', path: '/line', icon: FileText },
        


        // { name: 'Report Comp', path: '/facility', icon: FileText },
        { name: 'Home Listrik Otics 1', path: '/smile', icon: Home },
        { name: 'Layout Listrik Otics 1', path: '/layoutotics1', icon: Layout },
        { name: 'Kubikal', path: '/kub', icon: TruckElectric },
       


        
        
        // { name: 'Compresor', path: '/comp', icon: CompassIcon },
        
        
      ],
    },
    {
      title: 'Hikitori',
      items: [{ name: 'Hikitori', path: '/hikitori', icon: Image }],
    },
    {
      title: 'Developer Only',
      items: [
        
        { name: 'Get Coordinate Img', path: '/GetPosisitionImg', icon: Image },
        { name: 'Get Data PLTS 1', path: '/convert_exel_p1', icon: PanelBottomCloseIcon },
        { name: 'Get Data PLTS 2', path: '/convert_exel_p2', icon: PanelBottomCloseIcon },
        { name: 'Get PLTS 1 Hourly', path: '/convert_exel_p1_hourly', icon: PanelBottomCloseIcon },
        { name: 'Get PLTS 2 Hourly', path: '/convert_exel_p2_hourly', icon: PanelBottomCloseIcon },


      ],


    },
  ];

  const renderToggleButton = () => {
    if (window.innerWidth < 1024) {
      return (
        <button
          onClick={onClose}
          className="text-gray-600 hover:text-gray-800 hover:bg-gray-100 p-1.5 rounded-lg transition"
          aria-label="Close menu"
        >
          <X className="w-4 h-4" />
        </button>
      );
    }
    return (
      <button
        onClick={onToggle}
        className="text-gray-600 hover:text-gray-800 hover:bg-gray-100 p-1.5 rounded-lg transition"
        aria-label={isCollapsed ? 'Expand menu' : 'Collapse menu'}
      >
        {isCollapsed ? (
          <ChevronRight className="w-4 h-4" />
        ) : (
          <ChevronLeft className="w-4 h-4" />
        )}
      </button>
    );
  };

  // Custom scrollbar CSS (opsional, tambahkan di index.css atau global CSS)
  // .sidebar-scroll::-webkit-scrollbar { width: 6px; }
  // .sidebar-scroll::-webkit-scrollbar-track { background: #f1f1f1; }
  // .sidebar-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
  // .sidebar-scroll::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

  // Mode collapsed
  if (isCollapsed) {
    const allItems = menuSections.flatMap((section) => section.items);
    return (
      <div className="w-full bg-white h-screen flex flex-col border-r border-gray-200 shadow-xl">
        {/* Header */}
        <div className="p-3 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50 flex-shrink-0">
          <div className="flex items-center justify-between">{renderToggleButton()}</div>
        </div>

        {/* Scrollable menu icons */}
        <div className="flex-1 overflow-y-auto sidebar-scroll py-3 px-1 min-h-0">
          <ul className="space-y-1">
            {allItems.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    title={item.name}
                    className={({ isActive }) =>
                      `flex items-center justify-center w-10 h-10 rounded-lg transition mx-auto ${
                        isActive
                          ? 'bg-blue-500 text-white shadow'
                          : 'text-gray-600 hover:bg-gray-100'
                      }`
                    }
                    onClick={() => window.innerWidth < 1024 && onClose()}
                  >
                    <Icon className="w-4 h-4" />
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Footer user info - tetap fixed di bawah */}
        <div className="p-3 border-t border-gray-200 bg-gray-50 flex-shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-4 h-4 text-white" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium text-gray-900 truncate">
                {user?.name || user?.username || 'Guest'}
              </p>
              <p className="text-[0.65rem] text-gray-500 truncate">
                {user?.username || 'user@example.com'}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Mode expanded
  return (
    <div className="w-full bg-white h-screen flex flex-col border-r border-gray-200 shadow-xl">
      {/* Header */}
      <div className="p-3 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50 flex-shrink-0">
        <div className="flex items-center justify-between">
          <h1 className="text-sm font-semibold text-gray-800">Menu</h1>
          {renderToggleButton()}
        </div>
      </div>

      {/* Scrollable sections */}
      <div className="flex-1 overflow-y-auto sidebar-scroll py-3 px-2 min-h-0">
        {menuSections.map((section) => (
          <div key={section.title} className="mb-4">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider px-3 mb-2">
              {section.title}
            </h2>
            <ul className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.path}>
                    <NavLink
                      to={item.path}
                      className={({ isActive }) =>
                        `flex items-center py-2 px-3 rounded-lg transition ${
                          isActive
                            ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-lg'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`
                      }
                      onClick={() => window.innerWidth < 1024 && onClose()}
                      style={{ paddingLeft: '1.5rem' }}
                    >
                      <Icon className="w-4 h-4 mr-2.5 flex-shrink-0" />
                      <span className="text-sm font-medium truncate">{item.name}</span>
                    </NavLink>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>

      {/* Footer user info */}
      <div className="p-3 border-t border-gray-200 bg-gray-50 flex-shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-medium text-gray-900 truncate">
              {user?.name || user?.username || 'Guest'}
            </p>
            <p className="text-[0.65rem] text-gray-500 truncate">
              {user?.username || 'user@example.com'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;