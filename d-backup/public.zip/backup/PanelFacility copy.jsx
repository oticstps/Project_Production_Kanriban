


// COMP.JSX (dengan tambahan panel_19 dan panel_20)
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, AreaChart, Area, Cell, PieChart, Pie
} from 'recharts';
import Layout from '../src/components/layout/Layout'; // Sesuaikan dengan path proyek

// Mapping warna untuk setiap Production Group
const PG_COLOR_MAP = {
  'PG Komp 24': '#0088FE', // Biru
  'PG Komp 21': '#00C49F', // Hijau
  'PG Komp 19': '#FF8042', // Oranye
  'PG Komp 20': '#FF00FF', // Magenta
  'Unknown': '#aaaaaa'     // Abu-abu
};

// Mapping line_table ke Production Group
const tableNameMapping = {
  'tb_kub_comp_24': ['Kompresor 24', 'PG Komp 24'],
  'tb_kub_comp_21': ['Kompresor 21', 'PG Komp 21'],
  'tb_kub_comp_19': ['Kompresor 19', 'PG Komp 19'],
  'tb_kub_panel_20_wh': ['Kompresor 20', 'PG Komp 20']
};

// Fungsi untuk menormalisasi tipe PM (dalam data hanya "kwh")
const normalizePmType = (type) => {
  if (!type) return 'Unknown';
  const lower = type.toLowerCase();
  if (lower.includes('kwh')) return 'KWH';
  return type.toUpperCase();
};

const COMP = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // State untuk filter
  const [filters, setFilters] = useState({
    month: '',
    year: '',
    line: '',
    pmType: '',
    searchTerm: ''
  });

  // State untuk pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);

  // State untuk sorting
  const [sortConfig, setSortConfig] = useState({ key: 'shift_start_datetime', direction: 'desc' });

  // State untuk menampilkan detail baris
  const [expandedRow, setExpandedRow] = useState(null);

  // State untuk tipe chart
  const [topChartType, setTopChartType] = useState('bar');
  const [topNCount, setTopNCount] = useState(20);

  // Fungsi fetch data dari keempat API
  const fetchData = useCallback(async (showLoading = true) => {
    if (showLoading) {
      setLoading(true);
      setError(null);
    } else {
      setIsRefreshing(true);
    }

    try {
      const [res24, res21, res19, res20] = await Promise.all([
        fetch('/api/comp24'),
        fetch('/api/comp21'),
        fetch('/api/comp19'),
        fetch('/api/comp20')  // tambahan panel_20
      ]);

      if (!res24.ok || !res21.ok || !res19.ok || !res20.ok) {
        throw new Error('Gagal mengambil data dari salah satu API');
      }

      const data24 = await res24.json();
      const data21 = await res21.json();
      const data19 = await res19.json();
      const data20 = await res20.json();

      // Gabungkan data
      const combinedData = [...data24, ...data21, ...data19, ...data20];
      setData(combinedData);
    } catch (err) {
      setError(err.message);
    } finally {
      if (showLoading) {
        setLoading(false);
      } else {
        setIsRefreshing(false);
      }
    }
  }, []);

  // Fetch data pertama kali
  useEffect(() => {
    fetchData(true);
  }, [fetchData]);

  // Interval polling setiap 30 detik
  useEffect(() => {
    const intervalId = setInterval(() => {
      fetchData(false);
    }, 30000);
    return () => clearInterval(intervalId);
  }, [fetchData]);

  // Ekstrak opsi filter dari data
  const filterOptions = useMemo(() => {
    if (!data.length) return { months: [], years: [], lines: [], pmTypes: [] };
    const months = [...new Set(data.map(item => item.month))].sort();
    const years = [...new Set(data.map(item => item.year))].sort((a, b) => b - a);
    const lines = [...new Set(data.map(item => item.line_name))].sort();
    const pmTypes = [...new Set(data.map(item => normalizePmType(item.pm_type)))].sort();
    return { months, years, lines, pmTypes };
  }, [data]);

  // Dapatkan PG berdasarkan line_table
  const getPGByLineTable = (lineTable) => {
    return tableNameMapping[lineTable]?.[1] || 'Unknown';
  };

  // Dapatkan warna berdasarkan PG
  const getColorByPG = (pg) => {
    return PG_COLOR_MAP[pg] || '#aaaaaa';
  };

  // Format angka tanpa desimal
  const formatNumber = (num) => {
    if (num === null || num === undefined) return '0';
    return Math.round(Number(num)).toString();
  };

  // Format dari Wh ke kWh (karena data dari API kemungkinan dalam Wh)
  const formatKWh = (whValue) => {
    if (whValue === null || whValue === undefined) return '0';
    const kWh = Number(whValue) / 1000;
    return formatNumber(kWh);
  };

  // Format tanggal
  const formatDate = (dateString) => {
    if (!dateString) return '-';
    try {
      const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      };
      return new Date(dateString).toLocaleDateString('id-ID', options);
    } catch {
      return dateString;
    }
  };

  // Hitung durasi shift
  const formatDuration = (start, end) => {
    if (!start || !end) return '-';
    try {
      const startTime = new Date(start);
      const endTime = new Date(end);
      const diffMs = endTime - startTime;
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      return `${diffHours}h ${diffMinutes}m`;
    } catch {
      return '-';
    }
  };

  // Sorting data
  const sortedData = useMemo(() => {
    if (!data.length) return [];
    const sortable = [...data];
    if (sortConfig.key) {
      sortable.sort((a, b) => {
        let aVal = a[sortConfig.key];
        let bVal = b[sortConfig.key];
        if (sortConfig.key === 'shift_start_datetime' || sortConfig.key === 'shift_end_datetime' || sortConfig.key === 'created_at') {
          aVal = new Date(aVal).getTime();
          bVal = new Date(bVal).getTime();
        }
        if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortable;
  }, [data, sortConfig]);

  // Filter data berdasarkan filter dan pencarian
  const filteredData = useMemo(() => {
    return sortedData.filter(item => {
      const matchFilter =
        (filters.month ? item.month === filters.month : true) &&
        (filters.year ? item.year === filters.year : true) &&
        (filters.line ? item.line_name === filters.line : true) &&
        (filters.pmType ? normalizePmType(item.pm_type) === filters.pmType : true);

      if (!filters.searchTerm) return matchFilter;

      const searchLower = filters.searchTerm.toLowerCase();
      const pg = getPGByLineTable(item.line_table).toLowerCase();
      const lineName = item.line_name?.toLowerCase() || '';
      const monthName = item.month_name?.toLowerCase() || '';
      const dayName = item.day_name?.toLowerCase() || '';

      return (
        matchFilter &&
        (lineName.includes(searchLower) ||
         pg.includes(searchLower) ||
         monthName.includes(searchLower) ||
         dayName.includes(searchLower) ||
         item.shift?.includes(searchLower) ||
         item.year?.toString().includes(searchLower))
      );
    });
  }, [sortedData, filters]);

  // Pagination
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredData.slice(start, start + itemsPerPage);
  }, [filteredData, currentPage, itemsPerPage]);

  // Data untuk chart konsumsi tertinggi per line (top N)
  const topKwhPerLineData = useMemo(() => {
    const lineMap = {};
    filteredData.forEach(item => {
      const line = item.line_name;
      const kWh = Number(item.total_kwh) / 1000;
      if (!isNaN(kWh)) {
        if (!lineMap[line] || kWh > lineMap[line].kWh) {
          const pg = getPGByLineTable(item.line_table);
          lineMap[line] = {
            line,
            kWh,
            period: `${item.month} ${item.year}`,
            table: item.line_table,
            pg,
            color: getColorByPG(pg)
          };
        }
      }
    });
    return Object.values(lineMap)
      .map(item => ({ ...item, kWh: parseFloat(formatNumber(item.kWh)) }))
      .sort((a, b) => b.kWh - a.kWh)
      .slice(0, topNCount);
  }, [filteredData, topNCount]);

  // Data untuk chart total kWh per line (semua data)
  const totalKWhPerLineAllData = useMemo(() => {
    const lineSum = {};
    filteredData.forEach(item => {
      const line = item.line_name;
      const kWh = Number(item.total_kwh) / 1000;
      if (!isNaN(kWh)) {
        if (!lineSum[line]) {
          const pg = getPGByLineTable(item.line_table);
          lineSum[line] = { line, totalKWh: 0, pg, color: getColorByPG(pg) };
        }
        lineSum[line].totalKWh += kWh;
      }
    });
    return Object.values(lineSum)
      .map(item => ({ ...item, totalKWh: parseFloat(formatNumber(item.totalKWh)) }))
      .sort((a, b) => b.totalKWh - a.totalKWh);
  }, [filteredData]);

  // Statistik
  const totalKWh = useMemo(() => {
    return filteredData.reduce((sum, item) => sum + (Number(item.total_kwh) / 1000), 0);
  }, [filteredData]);

  const avgKWh = useMemo(() => {
    return filteredData.length ? totalKWh / filteredData.length : 0;
  }, [filteredData, totalKWh]);

  const isAllFilterMode = filters.month === '' && filters.year === '' && filters.line === '' && filters.pmType === '';

  const maxKWhItem = useMemo(() => {
    if (isAllFilterMode) {
      return totalKWhPerLineAllData.reduce((max, item) => item.totalKWh > max.totalKWh ? item : max, totalKWhPerLineAllData[0] || { totalKWh: 0 });
    } else {
      return filteredData.reduce((max, item) => {
        const val = Number(item.total_kwh) / 1000;
        return val > (Number(max.total_kwh) / 1000) ? item : max;
      }, filteredData[0] || { total_kwh: 0 });
    }
  }, [isAllFilterMode, totalKWhPerLineAllData, filteredData]);

  const minKWhItem = useMemo(() => {
    if (isAllFilterMode) {
      const nonZero = totalKWhPerLineAllData.filter(i => i.totalKWh > 0);
      if (!nonZero.length) return totalKWhPerLineAllData[0] || { totalKWh: 0 };
      return nonZero.reduce((min, item) => item.totalKWh < min.totalKWh ? item : min, nonZero[0]);
    } else {
      const nonZero = filteredData.filter(i => Number(i.total_kwh) > 0);
      if (!nonZero.length) return filteredData[0] || { total_kwh: 0 };
      return nonZero.reduce((min, item) => {
        return (Number(item.total_kwh) / 1000) < (Number(min.total_kwh) / 1000) ? item : min;
      }, nonZero[0]);
    }
  }, [isAllFilterMode, totalKWhPerLineAllData, filteredData]);

  // Ekspor CSV
  const exportToCSV = () => {
    const headers = ['ID', 'Tipe PM', 'Line', 'Shift', 'Tanggal Shift', 'Start', 'End', 'Start kWh', 'End kWh', 'Total kWh', 'Durasi', 'Production Group'];
    const rows = paginatedData.map(item => [
      item.idPrimary || '',
      normalizePmType(item.pm_type),
      item.line_name || '',
      item.shift || '',
      item.shift_date || '',
      formatDate(item.shift_start_datetime),
      formatDate(item.shift_end_datetime),
      formatKWh(item.start_kwh),
      formatKWh(item.end_kwh),
      formatKWh(item.total_kwh),
      formatDuration(item.shift_start_datetime, item.shift_end_datetime),
      getPGByLineTable(item.line_table)
    ]);
    const csvContent = [headers.join(','), ...rows.map(row => row.map(f => `"${f}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `kompresor_report_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
  };

  // Handler filter
  const handleFilterChange = (name, value) => {
    setFilters(prev => ({ ...prev, [name]: value }));
    setCurrentPage(1);
  };

  const handleSearchChange = (e) => {
    setFilters(prev => ({ ...prev, searchTerm: e.target.value }));
    setCurrentPage(1);
  };

  const handleResetFilters = () => {
    setFilters({ month: '', year: '', line: '', pmType: '', searchTerm: '' });
    setCurrentPage(1);
  };

  const toggleRowDetail = (id) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  // Custom tooltip untuk chart
  const CustomBarTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-300 rounded-lg shadow-lg">
          <p className="font-semibold text-gray-800">{data.line}</p>
          <p className="text-sm text-gray-600">PG: {data.pg || 'Unknown'}</p>
          <p className="text-sm text-gray-600">kWh: {payload[0].value.toLocaleString()}</p>
          {data.period && <p className="text-xs text-gray-500">Periode: {data.period}</p>}
        </div>
      );
    }
    return null;
  };

  // Pie chart data untuk distribusi per PG
  const pieData = useMemo(() => {
    const pgMap = {};
    filteredData.forEach(item => {
      const pg = getPGByLineTable(item.line_table);
      const kWh = Number(item.total_kwh) / 1000;
      if (!isNaN(kWh)) {
        pgMap[pg] = (pgMap[pg] || 0) + kWh;
      }
    });
    return Object.entries(pgMap).map(([name, value]) => ({
      name,
      value: parseFloat(formatNumber(value)),
      color: getColorByPG(name)
    }));
  }, [filteredData]);






  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 pb-12">
        {loading ? (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-lg text-gray-700">Memuat data...</p>
            </div>
          </div>
        ) : error ? (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
            <div className="text-center p-8 bg-white rounded-xl shadow-lg max-w-md">
              <div className="text-red-500 text-5xl mb-4">⚠️</div>
              <h2 className="text-xl font-bold text-red-600 mb-2">Terjadi Kesalahan</h2>
              <p className="text-gray-600 mb-4">{error}</p>
              <button
                onClick={() => fetchData(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors shadow"
              >
                Coba Lagi
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Filter Section */}
            <div className="bg-white p-3 rounded-lg shadow mb-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-2">
                <div className="flex items-center">
                  <h2 className="text-base font-semibold text-blue-700">Filter & Pencarian</h2>
                  {isRefreshing && (
                    <span className="ml-3 text-xs text-blue-500 animate-pulse flex items-center">
                      <svg className="animate-spin h-4 w-4 mr-1" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      Memperbarui...
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => fetchData(false)}
                    disabled={isRefreshing}
                    className="px-3 py-1.5 text-xs bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors shadow-sm flex items-center disabled:opacity-50"
                  >
                    <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    {isRefreshing ? 'Memperbarui...' : 'Refresh'}
                  </button>
                  <button
                    onClick={exportToCSV}
                    className="px-3 py-1.5 text-xs bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors shadow-sm"
                  >
                    Ekspor CSV
                  </button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2 items-end">
                <input
                  type="text"
                  placeholder="Cari Line, PG, Bulan, Hari, Shift..."
                  value={filters.searchTerm}
                  onChange={handleSearchChange}
                  className="flex-grow px-2 py-1.5 text-xs border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 w-full sm:w-auto">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Bulan</label>
                    <select
                      value={filters.month}
                      onChange={(e) => handleFilterChange('month', e.target.value)}
                      className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded-md"
                    >
                      <option value="">Semua</option>
                      {filterOptions.months.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Tahun</label>
                    <select
                      value={filters.year}
                      onChange={(e) => handleFilterChange('year', e.target.value)}
                      className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded-md"
                    >
                      <option value="">Semua</option>
                      {filterOptions.years.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Line</label>
                    <select
                      value={filters.line}
                      onChange={(e) => handleFilterChange('line', e.target.value)}
                      className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded-md"
                    >
                      <option value="">Semua</option>
                      {filterOptions.lines.map(line => <option key={line} value={line}>{line}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Tipe PM</label>
                    <select
                      value={filters.pmType}
                      onChange={(e) => handleFilterChange('pmType', e.target.value)}
                      className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded-md"
                    >
                      <option value="">Semua</option>
                      {filterOptions.pmTypes.map(type => <option key={type} value={type}>{type}</option>)}
                    </select>
                  </div>
                </div>
                <button
                  onClick={handleResetFilters}
                  className="px-3 py-1.5 text-xs bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors shadow-sm w-full sm:w-auto"
                >
                  Reset Semua
                </button>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
              <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
                <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wider">Total Laporan</h3>
                <p className="text-xl font-bold text-gray-900">{filteredData.length}</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
                <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wider">Total kWh</h3>
                <p className="text-xl font-bold text-blue-600">{formatNumber(totalKWh)}</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
                <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wider">Rata-rata kWh</h3>
                <p className="text-xl font-bold text-green-600">{formatNumber(avgKWh)}</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
                <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wider">KWh Tertinggi</h3>
                <p className="text-xl font-bold text-amber-600">
                  {maxKWhItem ? (isAllFilterMode ? formatNumber(maxKWhItem.totalKWh) : formatKWh(maxKWhItem.total_kwh)) : '0'}
                </p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
                <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wider">KWh Terendah</h3>
                <p className="text-xl font-bold text-purple-600">
                  {minKWhItem ? (isAllFilterMode ? formatNumber(minKWhItem.totalKWh) : formatKWh(minKWhItem.total_kwh)) : '0'}
                </p>
              </div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-6">
              <div className="lg:col-span-3 bg-white p-4 rounded-lg shadow border border-gray-200">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-1">
                  {/* Pie Chart Distribusi per PG */}
                  <div className="lg:col-span-1 flex flex-col h-full">
                    <h3 className="text-sm font-semibold text-gray-800 mb-2">Distribusi kWh per Production Group</h3>
                    <div className="bg-white rounded-lg shadow border border-gray-200 p-3 flex-grow">
                      <ResponsiveContainer width="100%" height={250}>
                        <PieChart>
                          <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="flex flex-wrap justify-center mt-2 gap-2">
                        {Object.entries(PG_COLOR_MAP).map(([pg, color]) => (
                          <div key={pg} className="flex items-center">
                            <div className="w-3 h-3 rounded-full mr-1" style={{ backgroundColor: color }}></div>
                            <span className="text-xs text-gray-600">{pg}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Bar/Line/Area Chart - Top N atau Total per Line */}
                  <div className="lg:col-span-2 flex flex-col h-full">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1">
                      <h3 className="text-sm font-semibold text-gray-800">
                        {isAllFilterMode ? 'Total Konsumsi per Line (Semua Data)' : `Top ${topNCount} Konsumsi Tertinggi per Line`}
                      </h3>
                      <div className="flex items-center space-x-2 mt-1 sm:mt-0">
                        {!isAllFilterMode && (
                          <>
                            <span className="text-xs text-gray-600">Tampilkan:</span>
                            <select
                              value={topNCount}
                              onChange={(e) => setTopNCount(Number(e.target.value))}
                              className="px-2 py-1 text-xs border border-gray-300 rounded"
                            >
                              <option value={10}>10</option>
                              <option value={15}>15</option>
                              <option value={20}>20</option>
                            </select>
                          </>
                        )}
                        <div className="flex space-x-1 ml-2">
                          <button
                            onClick={() => setTopChartType('bar')}
                            className={`px-2 py-1 text-xs rounded ${topChartType === 'bar' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
                          >
                            Bar
                          </button>
                          <button
                            onClick={() => setTopChartType('line')}
                            className={`px-2 py-1 text-xs rounded ${topChartType === 'line' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
                          >
                            Line
                          </button>
                          <button
                            onClick={() => setTopChartType('area')}
                            className={`px-2 py-1 text-xs rounded ${topChartType === 'area' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
                          >
                            Area
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="bg-white rounded-lg shadow border border-gray-200 p-3 flex-grow">
                      <ResponsiveContainer width="100%" height={300}>
                        {topChartType === 'bar' ? (
                          <BarChart data={isAllFilterMode ? totalKWhPerLineAllData : topKwhPerLineData} margin={{ top: 5, right: 30, left: 50, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="line" interval={0} angle={-45} textAnchor="end" height={90} />
                            <YAxis />
                            <Tooltip content={<CustomBarTooltip />} />
                            <Bar dataKey={isAllFilterMode ? 'totalKWh' : 'kWh'} name={isAllFilterMode ? "Total kWh" : "KWh Tertinggi"} radius={[2,2,0,0]}>
                              {(isAllFilterMode ? totalKWhPerLineAllData : topKwhPerLineData).map((entry, idx) => (
                                <Cell key={`cell-${idx}`} fill={entry.color || getColorByPG(entry.pg)} />
                              ))}
                            </Bar>
                          </BarChart>
                        ) : topChartType === 'line' ? (
                          <LineChart data={isAllFilterMode ? totalKWhPerLineAllData : topKwhPerLineData} margin={{ top: 5, right: 30, left: 50, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="line" interval={0} angle={-45} textAnchor="end" height={90} />
                            <YAxis />
                            <Tooltip content={<CustomBarTooltip />} />
                            <Line type="monotone" dataKey={isAllFilterMode ? 'totalKWh' : 'kWh'} stroke="#8884d8" strokeWidth={2} activeDot={{ r: 6 }} />
                          </LineChart>
                        ) : (
                          <AreaChart data={isAllFilterMode ? totalKWhPerLineAllData : topKwhPerLineData} margin={{ top: 5, right: 30, left: 50, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="line" interval={0} angle={-45} textAnchor="end" height={90} />
                            <YAxis />
                            <Tooltip content={<CustomBarTooltip />} />
                            <Area type="monotone" dataKey={isAllFilterMode ? 'totalKWh' : 'kWh'} stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} strokeWidth={2} />
                          </AreaChart>
                        )}
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tabel Data */}
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      {[
                        { key: 'pm_type', label: 'Tipe (Terkelompok)' },
                        { key: 'line_name', label: 'Line' },
                        { key: 'pg', label: 'Production Group' },
                        { key: 'shift', label: 'Shift' },
                        { key: 'periode', label: 'Periode' },
                        { key: 'duration', label: 'Durasi' },
                        { key: 'kwh', label: 'Konsumsi (kWh)' },
                        { key: 'action', label: 'Detail' }
                      ].map(header => (
                        <th key={header.key} className="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase tracking-wider">
                          {header.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {paginatedData.length > 0 ? (
                      paginatedData.map((item, index) => {
                        const pg = getPGByLineTable(item.line_table);
                        const pgColor = getColorByPG(pg);
                        const normalizedPm = normalizePmType(item.pm_type);
                        return (
                          <React.Fragment key={item.idPrimary || index}>
                            <tr className={`hover:bg-gray-50 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-25'}`}>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="text-sm font-medium text-blue-700">{normalizedPm}</div>
                                <div className="text-xs text-gray-500">{item.pm_type}</div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{item.line_name}</div>
                                <div className="text-xs text-gray-500">{item.line_table}</div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: pgColor }}></div>
                                  <span className="text-sm font-medium text-gray-900">{pg}</span>
                                </div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{item.shift}</td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{item.month}</div>
                                <div className="text-xs text-gray-500">{item.year}</div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                                {formatDuration(item.shift_start_datetime, item.shift_end_datetime)}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="text-sm font-bold text-green-700">{formatKWh(item.total_kwh)}</div>
                                <div className="text-xs text-gray-500">({formatKWh(item.start_kwh)} → {formatKWh(item.end_kwh)})</div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm">
                                <button
                                  onClick={() => toggleRowDetail(item.idPrimary)}
                                  className="text-blue-600 hover:text-blue-900 text-xs font-medium px-2 py-1 rounded hover:bg-blue-50 transition-colors"
                                >
                                  {expandedRow === item.idPrimary ? 'Sembunyikan' : 'Detail'}
                                </button>
                              </td>
                            </tr>
                            {expandedRow === item.idPrimary && (
                              <tr className="bg-blue-50">
                                <td colSpan="8" className="px-4 py-3">
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                                    <div>
                                      <p><span className="font-medium">ID:</span> {item.idPrimary}</p>
                                      <p><span className="font-medium">Tabel:</span> {item.line_table}</p>
                                      <p><span className="font-medium">Tanggal Shift:</span> {item.shift_date}</p>
                                      <p><span className="font-medium">Mulai:</span> {formatDate(item.shift_start_datetime)}</p>
                                      <p><span className="font-medium">Selesai:</span> {formatDate(item.shift_end_datetime)}</p>
                                    </div>
                                    <div>
                                      <p><span className="font-medium">Dibuat:</span> {formatDate(item.created_at)}</p>
                                      <p><span className="font-medium">Production Group:</span> <span style={{ color: pgColor }}>{pg}</span></p>
                                      <p><span className="font-medium">Hari:</span> {item.day_name}, {item.day}</p>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </React.Fragment>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan="8" className="px-6 py-8 text-center text-sm text-gray-500">
                          <div className="flex flex-col items-center">
                            <div className="text-3xl mb-1">🔍</div>
                            <p>Tidak ada data yang ditemukan.</p>
                            <p className="text-xs mt-1">Coba ubah filter atau pencarian Anda.</p>
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              {filteredData.length > 0 && (
                <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                  <div className="flex-1 flex justify-between sm:hidden">
                    <button
                      onClick={() => setCurrentPage(p => Math.max(1, p-1))}
                      disabled={currentPage === 1}
                      className="relative inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md disabled:bg-gray-100 disabled:text-gray-400 bg-white text-gray-700 hover:bg-gray-50 border border-gray-300"
                    >
                      Sebelumnya
                    </button>
                    <button
                      onClick={() => setCurrentPage(p => Math.min(Math.ceil(filteredData.length/itemsPerPage), p+1))}
                      disabled={currentPage >= Math.ceil(filteredData.length/itemsPerPage)}
                      className="ml-2 relative inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md disabled:bg-gray-100 disabled:text-gray-400 bg-white text-gray-700 hover:bg-gray-50 border border-gray-300"
                    >
                      Berikutnya
                    </button>
                  </div>
                  <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                    <p className="text-sm text-gray-700">
                      Menampilkan <span className="font-medium">{Math.min((currentPage-1)*itemsPerPage+1, filteredData.length)}</span> hingga{' '}
                      <span className="font-medium">{Math.min(currentPage*itemsPerPage, filteredData.length)}</span> dari{' '}
                      <span className="font-medium">{filteredData.length}</span> entri
                    </p>
                    <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                      <button
                        onClick={() => setCurrentPage(p => Math.max(1, p-1))}
                        disabled={currentPage === 1}
                        className="relative inline-flex items-center px-2 py-2 rounded-l-md text-sm font-medium disabled:bg-gray-100 disabled:text-gray-400 bg-white text-gray-500 hover:bg-gray-50 border border-gray-300"
                      >
                        &larr;
                      </button>
                      {[...Array(Math.min(5, Math.ceil(filteredData.length/itemsPerPage))).keys()].map(i => {
                        const pageNum = Math.max(1, Math.min(currentPage-2, Math.ceil(filteredData.length/itemsPerPage)-4)) + i;
                        return (
                          <button
                            key={pageNum}
                            onClick={() => setCurrentPage(pageNum)}
                            className={`relative inline-flex items-center px-3 py-2 text-sm font-medium ${currentPage === pageNum ? 'z-10 bg-blue-50 border border-blue-500 text-blue-600' : 'bg-white border border-gray-300 text-gray-500 hover:bg-gray-50'}`}
                          >
                            {pageNum}
                          </button>
                        );
                      })}
                      <button
                        onClick={() => setCurrentPage(p => Math.min(Math.ceil(filteredData.length/itemsPerPage), p+1))}
                        disabled={currentPage >= Math.ceil(filteredData.length/itemsPerPage)}
                        className="relative inline-flex items-center px-2 py-2 rounded-r-md text-sm font-medium disabled:bg-gray-100 disabled:text-gray-400 bg-white text-gray-500 hover:bg-gray-50 border border-gray-300"
                      >
                        &rarr;
                      </button>
                    </nav>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </Layout>
  );
};

export default COMP;