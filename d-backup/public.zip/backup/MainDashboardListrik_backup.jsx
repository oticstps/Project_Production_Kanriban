import React from 'react';
import { Container } from 'react-bootstrap';
import Nais_Layout from '../src/components/layout/Layout';
import MonthlyReport from '../src/components/dashboard/MainDashboardPlant1/MonthlyReport';
import ShiftlyReport from '../src/components/dashboard/MainDashboardPlant1/ShiftlyReport';

const MainDashboardListrik = () => {
  return (
    <Nais_Layout>
      <Container fluid className="p-1">
        <ShiftlyReport />
        <MonthlyReport />
      </Container>
    </Nais_Layout>
  );
};

export default MainDashboardListrik;