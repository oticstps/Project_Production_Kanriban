import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';
import Layout from '../src/components/layout/Layout'; // sesuaikan jika path berbeda

const API_ROOT = import.meta.env.VITE_API_ROOT || 'http://172.27.6.191:4000/api';

const API_ENDPOINTS = {
  shiftly: {
    comp19: `${API_ROOT}/comp19Shiftly`,
    comp20: `${API_ROOT}/comp20Shiftly`,
    comp21: `${API_ROOT}/comp21Shiftly`,
    comp24: `${API_ROOT}/comp24Shiftly`,
  },
  monthly: {
    comp19: `${API_ROOT}/comp19Monthly`,
    comp20: `${API_ROOT}/comp20Monthly`,
    comp21: `${API_ROOT}/comp21Monthly`,
    comp24: `${API_ROOT}/comp24Monthly`,
  },
};

const SOURCE_META = {
  comp19: {
    label: 'PANEL 19',
    pg: 'PG Komp 19',
    color: '#FF8042',
    lineTables: ['tb_comp_19', 'tb_kub_comp_19'],
  },
  comp20: {
    label: 'PANEL 20',
    pg: 'PG Komp 20',
    color: '#FF00FF',
    lineTables: ['tb_comp_20', 'tb_kub_panel_20_wh', 'tb_kub_comp_20'],
  },
  comp21: {
    label: 'PANEL 21',
    pg: 'PG Komp 21',
    color: '#00C49F',
    lineTables: ['tb_comp_21', 'tb_kub_comp_21'],
  },
  comp24: {
    label: 'PANEL 24',
    pg: 'PG Komp 24',
    color: '#0088FE',
    lineTables: ['tb_comp_24', 'tb_kub_comp_24'],
  },
};

const PG_COLOR_MAP = Object.values(SOURCE_META).reduce((acc, item) => {
  acc[item.pg] = item.color;
  return acc;
}, { Unknown: '#A0AEC0' });

const PANEL_REFERENCE_INFO = {
  'PANEL 20': {
    unit: 'MWH',
    details: ['Compressor 6', 'Compressor 9', 'Baby Compressor', 'Air Dryer-6'],
  },
  'PANEL 19': {
    unit: 'KWH',
    details: ['Compressor 5', 'Air Dryer-3'],
  },
  'PANEL 24': {
    unit: 'GWH',
    details: ['Compressor 7', 'Compressor 10', 'Air Dryer-5'],
  },
  'PANEL 21': {
    unit: 'GWH',
    details: ['Compressor 8', 'Compressor 11', 'Air Dryer-7'],
  },
  'PANEL 9': {
    unit: 'GWH',
    details: [],
  },
  'PANEL 16': {
    unit: 'GWH',
    details: [],
  },
  'PANEL 17': {
    unit: 'GWH',
    details: [],
  },
};

const toDateSafe = (value) => {
  if (!value) return null;
  const normalized = String(value).replace(' ', 'T');
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? null : date;
};

const toNumber = (value) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
};

const formatNumber = (value, digits = 0) => {
  return new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(toNumber(value));
};

const formatDateTime = (value) => {
  const date = toDateSafe(value);
  if (!date) return '-';

  return new Intl.DateTimeFormat('id-ID', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(date);
};

const formatDuration = (start, end) => {
  const startDate = toDateSafe(start);
  const endDate = toDateSafe(end);

  if (!startDate || !endDate) return '-';

  const diffMs = endDate.getTime() - startDate.getTime();
  if (diffMs <= 0) return '-';

  const totalMinutes = Math.floor(diffMs / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  return `${hours} jam ${minutes} menit`;
};

const normalizePmType = (type) => {
  if (!type) return 'UNKNOWN';
  return String(type).trim().toUpperCase();
};

const getSourceMetaByLineTable = (lineTable, fallbackSourceKey) => {
  const fromLineTable = Object.entries(SOURCE_META).find(([, meta]) =>
    meta.lineTables.includes(lineTable)
  );

  if (fromLineTable) {
    return { sourceKey: fromLineTable[0], ...fromLineTable[1] };
  }

  if (fallbackSourceKey && SOURCE_META[fallbackSourceKey]) {
    return { sourceKey: fallbackSourceKey, ...SOURCE_META[fallbackSourceKey] };
  }

  return {
    sourceKey: fallbackSourceKey || 'unknown',
    label: 'UNKNOWN',
    pg: 'Unknown',
    color: '#A0AEC0',
    lineTables: [],
  };
};

const normalizeRecord = (item, sourceKey, mode) => {
  const meta = getSourceMetaByLineTable(item.line_table, sourceKey);

  const startDateTime =
    mode === 'monthly' ? item.month_start_datetime : item.shift_start_datetime;
  const endDateTime =
    mode === 'monthly' ? item.month_end_datetime : item.shift_end_datetime;

  const totalKwh = toNumber(item.total_kwh) / 1000;
  const startKwh = toNumber(item.start_kwh) / 1000;
  const endKwh = toNumber(item.end_kwh) / 1000;

  const sortDate =
    toDateSafe(endDateTime)?.getTime() ||
    toDateSafe(startDateTime)?.getTime() ||
    toDateSafe(item.created_at)?.getTime() ||
    0;

  const periodLabel =
    mode === 'monthly'
      ? `${item.month_name || item.month || '-'} ${item.year || ''}`.trim()
      : `${item.shift_date || '-'} • ${String(item.shift || '-').replace('_', ' ').toUpperCase()}`;

  const durationLabel =
    mode === 'monthly'
      ? `${item.month_start_date || '-'} s.d. ${item.month_end_date || '-'}`
      : formatDuration(startDateTime, endDateTime);

  return {
    ...item,
    rowId:
      item.idPrimary ||
      `${sourceKey}-${mode}-${item.year || 'x'}-${item.month || 'x'}-${item.shift_date || item.month_start_date || 'x'}-${item.shift || 'monthly'}`,
    mode,
    sourceKey,
    sourceLabel: meta.label,
    pg: meta.pg,
    color: meta.color,
    panelUnit: PANEL_REFERENCE_INFO[meta.label]?.unit || '-',
    panelDetails: PANEL_REFERENCE_INFO[meta.label]?.details || [],
    lineDisplay: item.line_name || meta.label,
    pmTypeDisplay: normalizePmType(item.pm_type),
    startDateTime,
    endDateTime,
    totalKwh,
    startKwh,
    endKwh,
    sortDate,
    periodLabel,
    durationLabel,
  };
};

const SummaryCard = ({ title, value, subtitle, valueClassName = 'text-slate-900' }) => (
  <div className="rounded-md border border-slate-200 bg-white px-2 py-1.5 shadow-sm">
    <p className="text-[9px] font-semibold uppercase tracking-wide text-slate-500">{title}</p>
    <p className={`mt-0.5 text-[15px] font-bold leading-none ${valueClassName}`}>{value}</p>
    {subtitle ? <p className="mt-0.5 truncate text-[10px] leading-tight text-slate-500" title={subtitle}>{subtitle}</p> : null}
  </div>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="rounded-md border border-slate-200 bg-white p-1.5 shadow-lg">
      <p className="mb-0.5 text-xs font-semibold text-slate-800">{label}</p>
      {payload.map((item) => (
        <p key={item.dataKey} className="text-[11px] text-slate-600">
          {item.name} {formatNumber(item.value, 2)} kWh
        </p>
      ))}
    </div>
  );
};

const PanelInfoCompact = () => (
  <div className="mt-2 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
    <div className="mb-1.5 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h2 className="text-xs font-bold text-slate-800">Informasi Panel</h2>
        <p className="text-[10px] text-slate-500">Referensi unit dan equipment panel.</p>
      </div>
      <span className="w-fit rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
        {Object.keys(PANEL_REFERENCE_INFO).length} panel referensi
      </span>
    </div>

    <div className="grid grid-cols-1 gap-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
      {Object.entries(PANEL_REFERENCE_INFO).map(([panelName, info]) => {
        const color = Object.values(SOURCE_META).find((meta) => meta.label === panelName)?.color ?? '#94A3B8';
        const details = info.details.length ? info.details.join(', ') : 'Belum ada detail equipment';

        return (
          <div key={panelName} className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 transition hover:border-slate-300 hover:bg-white">
            <div className="mb-0.5 flex items-center justify-between gap-1.5">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: color }} />
                <h3 className="text-[11px] font-bold text-slate-800">{panelName}</h3>
              </div>
              <span className="rounded bg-white px-1.5 py-0.5 text-[9px] font-bold text-slate-600 ring-1 ring-slate-200">
                {info.unit}
              </span>
            </div>
            <p className="truncate text-[10px] leading-tight text-slate-500" title={details}>
              {details}
            </p>
          </div>
        );
      })}
    </div>
  </div>
);

const PanelFacility = () => {
  const [mode, setMode] = useState('shiftly');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [expandedRow, setExpandedRow] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(15);
  const [filters, setFilters] = useState({
    year: '',
    month: '',
    line: '',
    pmType: '',
    search: '',
  });

  const fetchData = useCallback(
    async (showLoading = true) => {
      if (showLoading) {
        setLoading(true);
      } else {
        setIsRefreshing(true);
      }
      setError('');

      try {
        const entries = Object.entries(API_ENDPOINTS[mode]);
        const responses = await Promise.all(
          entries.map(async ([sourceKey, url]) => {
            const response = await fetch(url);
            if (!response.ok) {
              throw new Error(`Gagal mengambil data dari ${url}`);
            }
            const json = await response.json();
            return (Array.isArray(json) ? json : []).map((item) =>
              normalizeRecord(item, sourceKey, mode)
            );
          })
        );

        const merged = responses.flat().sort((a, b) => b.sortDate - a.sortDate);
        setData(merged);
      } catch (err) {
        setError(err.message || 'Terjadi kesalahan saat mengambil data');
      } finally {
        if (showLoading) {
          setLoading(false);
        } else {
          setIsRefreshing(false);
        }
      }
    },
    [mode]
  );

  useEffect(() => {
    fetchData(true);
  }, [fetchData]);

  useEffect(() => {
    const interval = setInterval(() => {
      fetchData(false);
    }, 30000);

    return () => clearInterval(interval);
  }, [fetchData]);

  useEffect(() => {
    setCurrentPage(1);
    setExpandedRow(null);
  }, [mode]);

  const filterOptions = useMemo(() => {
    return {
      years: [...new Set(data.map((item) => String(item.year)).filter(Boolean))].sort((a, b) => Number(b) - Number(a)),
      months: [...new Set(data.map((item) => String(item.month)).filter(Boolean))].sort((a, b) => Number(a) - Number(b)),
      lines: [...new Set(data.map((item) => item.lineDisplay).filter(Boolean))].sort(),
      pmTypes: [...new Set(data.map((item) => item.pmTypeDisplay).filter(Boolean))].sort(),
    };
  }, [data]);

  const filteredData = useMemo(() => {
    return data.filter((item) => {
      const byYear = filters.year ? String(item.year) === String(filters.year) : true;
      const byMonth = filters.month ? String(item.month) === String(filters.month) : true;
      const byLine = filters.line ? item.lineDisplay === filters.line : true;
      const byPmType = filters.pmType ? item.pmTypeDisplay === filters.pmType : true;

      const search = filters.search.trim().toLowerCase();
      const bySearch = search
        ? [
            item.lineDisplay,
            item.pg,
            item.pmTypeDisplay,
            item.periodLabel,
            item.shift,
            item.shift_date,
            item.month_name,
            item.day_name,
            item.line_table,
          ]
            .filter(Boolean)
            .some((value) => String(value).toLowerCase().includes(search))
        : true;

      return byYear && byMonth && byLine && byPmType && bySearch;
    });
  }, [data, filters]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredData.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredData, currentPage, itemsPerPage]);

  const totalPages = Math.max(1, Math.ceil(filteredData.length / itemsPerPage));

  const summary = useMemo(() => {
    const total = filteredData.reduce((sum, item) => sum + item.totalKwh, 0);
    const average = filteredData.length ? total / filteredData.length : 0;
    const maxItem = filteredData.length
      ? filteredData.reduce((prev, curr) => (curr.totalKwh > prev.totalKwh ? curr : prev))
      : null;
    const minItem = filteredData.length
      ? filteredData.reduce((prev, curr) => (curr.totalKwh < prev.totalKwh ? curr : prev))
      : null;

    return {
      totalRecords: filteredData.length,
      totalKwh: total,
      averageKwh: average,
      maxItem,
      minItem,
      activeLines: new Set(filteredData.map((item) => item.lineDisplay)).size,
    };
  }, [filteredData]);

  const barChartData = useMemo(() => {
    const map = {};

    filteredData.forEach((item) => {
      if (!map[item.lineDisplay]) {
        map[item.lineDisplay] = {
          name: item.lineDisplay,
          totalKwh: 0,
          color: item.color,
        };
      }
      map[item.lineDisplay].totalKwh += item.totalKwh;
    });

    return Object.values(map)
      .map((item) => ({ ...item, totalKwh: Number(item.totalKwh.toFixed(2)) }))
      .sort((a, b) => b.totalKwh - a.totalKwh);
  }, [filteredData]);

  const pieChartData = useMemo(() => {
    const map = {};

    filteredData.forEach((item) => {
      if (!map[item.pg]) {
        map[item.pg] = {
          name: item.pg,
          value: 0,
          color: PG_COLOR_MAP[item.pg] || item.color,
        };
      }
      map[item.pg].value += item.totalKwh;
    });

    return Object.values(map).map((item) => ({
      ...item,
      value: Number(item.value.toFixed(2)),
    }));
  }, [filteredData]);

  const trendChartData = useMemo(() => {
    return filteredData
      .slice()
      .sort((a, b) => a.sortDate - b.sortDate)
      .map((item) => ({
        name:
          mode === 'monthly'
            ? `${item.month_name || item.month}-${item.year}`
            : `${item.shift_date || '-'} ${String(item.shift || '').replace('_', ' ')}`,
        totalKwh: Number(item.totalKwh.toFixed(2)),
      }));
  }, [filteredData, mode]);

  const exportCsv = () => {
    const headers = [
      'mode',
      'line',
      'production_group',
      'pm_type',
      'period',
      'start_datetime',
      'end_datetime',
      'duration',
      'start_kwh',
      'end_kwh',
      'total_kwh',
    ];

    const rows = filteredData.map((item) => [
      item.mode,
      item.lineDisplay,
      item.pg,
      item.pmTypeDisplay,
      item.periodLabel,
      item.startDateTime || '',
      item.endDateTime || '',
      item.durationLabel,
      item.startKwh,
      item.endKwh,
      item.totalKwh,
    ]);

    const csvContent = [headers.join(','), ...rows.map((row) => row.map((cell) => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `dashboard-compressor-${mode}-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
  };

  const resetFilters = () => {
    setFilters({ year: '', month: '', line: '', pmType: '', search: '' });
    setCurrentPage(1);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-slate-50 p-1.5 text-xs md:p-2">
        <div className="mb-2 rounded-md border border-amber-200 bg-amber-50 px-2 py-1.5 text-[11px] font-medium text-amber-800 shadow-sm">
          Sebagian data masih dalam proses integrasi sistem filter.
        </div>

        <div className="mb-2 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
          <div className="flex flex-col gap-1.5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className="text-base font-bold text-slate-800 md:text-lg">Dashboard Compressor</h1>
              <p className="mt-0.5 text-[11px] text-slate-500">
                Monitoring konsumsi listrik panel compressor: Shiftly dan Monthly.
              </p>
            </div>

            <div className="flex flex-wrap gap-1">
              <button
                onClick={() => setMode('shiftly')}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                  mode === 'shiftly'
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Shiftly
              </button>
              <button
                onClick={() => setMode('monthly')}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition ${
                  mode === 'monthly'
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => fetchData(false)}
                disabled={isRefreshing}
                className="rounded-md bg-emerald-600 px-2.5 py-1 text-[11px] font-semibold text-white transition hover:bg-emerald-700 disabled:opacity-60"
              >
                {isRefreshing ? 'Memperbarui...' : 'Refresh'}
              </button>
              <button
                onClick={exportCsv}
                className="rounded-md bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-white transition hover:bg-slate-900"
              >
                Ekspor CSV
              </button>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex min-h-[42vh] items-center justify-center">
            <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
              <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
              <p className="mt-2 text-center text-[11px] text-slate-600">Memuat data dashboard...</p>
            </div>
          </div>
        ) : error ? (
          <div className="rounded-lg border border-red-200 bg-red-50 p-2.5 text-red-700 shadow-sm">
            <h2 className="text-base font-bold">Terjadi kesalahan</h2>
            <p className="mt-0.5 text-xs">{error}</p>
          </div>
        ) : (
          <>
            <div className="mb-2 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
              <div className="grid grid-cols-2 gap-1.5 md:grid-cols-4 xl:grid-cols-6">
                <div className="xl:col-span-2">
                  <label className="mb-0.5 block text-[9px] font-semibold uppercase tracking-wide text-slate-500">
                    Cari data
                  </label>
                  <input
                    type="text"
                    value={filters.search}
                    onChange={(e) => {
                      setFilters((prev) => ({ ...prev, search: e.target.value }));
                      setCurrentPage(1);
                    }}
                    placeholder="Cari line, PG, shift, bulan, atau tabel"
                    className="w-full rounded-md border border-slate-300 px-2 py-1 text-[11px] focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="mb-0.5 block text-[9px] font-semibold uppercase tracking-wide text-slate-500">Tahun</label>
                  <select
                    value={filters.year}
                    onChange={(e) => {
                      setFilters((prev) => ({ ...prev, year: e.target.value }));
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-md border border-slate-300 px-2 py-1 text-[11px] focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">Semua</option>
                    {filterOptions.years.map((year) => (
                      <option key={year} value={year}>
                        {year}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-0.5 block text-[9px] font-semibold uppercase tracking-wide text-slate-500">Bulan</label>
                  <select
                    value={filters.month}
                    onChange={(e) => {
                      setFilters((prev) => ({ ...prev, month: e.target.value }));
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-md border border-slate-300 px-2 py-1 text-[11px] focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">Semua</option>
                    {filterOptions.months.map((month) => (
                      <option key={month} value={month}>
                        {month}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-0.5 block text-[9px] font-semibold uppercase tracking-wide text-slate-500">Line</label>
                  <select
                    value={filters.line}
                    onChange={(e) => {
                      setFilters((prev) => ({ ...prev, line: e.target.value }));
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-md border border-slate-300 px-2 py-1 text-[11px] focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">Semua</option>
                    {filterOptions.lines.map((line) => (
                      <option key={line} value={line}>
                        {line}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-0.5 block text-[9px] font-semibold uppercase tracking-wide text-slate-500">PM Type</label>
                  <select
                    value={filters.pmType}
                    onChange={(e) => {
                      setFilters((prev) => ({ ...prev, pmType: e.target.value }));
                      setCurrentPage(1);
                    }}
                    className="w-full rounded-md border border-slate-300 px-2 py-1 text-[11px] focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">Semua</option>
                    {filterOptions.pmTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mt-1.5 flex flex-wrap items-center justify-between gap-1.5">
                <p className="text-[10px] text-slate-500">
                  Mode aktif <span className="font-semibold text-slate-700">{mode}</span>
                </p>
                <button
                  onClick={resetFilters}
                  className="rounded-md bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-700 transition hover:bg-slate-200"
                >
                  Reset filter
                </button>
              </div>
            </div>

            <div className="mb-2 grid grid-cols-2 gap-1.5 md:grid-cols-3 xl:grid-cols-5">
              <SummaryCard
                title="Total Data"
                value={formatNumber(summary.totalRecords)}
                subtitle={`${summary.activeLines} line aktif`}
              />
              <SummaryCard
                title="Total Konsumsi"
                value={`${formatNumber(summary.totalKwh, 2)} kWh`}
                subtitle="Akumulasi data terfilter"
                valueClassName="text-emerald-600"
              />
              <SummaryCard
                title="Rata-rata"
                value={`${formatNumber(summary.averageKwh, 2)} kWh`}
                subtitle="Per record"
              />
              <SummaryCard
                title="Tertinggi"
                value={summary.maxItem ? `${formatNumber(summary.maxItem.totalKwh, 2)} kWh` : '-'}
                subtitle={summary.maxItem?.lineDisplay || '-'}
                valueClassName="text-blue-600"
              />
              <SummaryCard
                title="Terendah"
                value={summary.minItem ? `${formatNumber(summary.minItem.totalKwh, 2)} kWh` : '-'}
                subtitle={summary.minItem?.lineDisplay || '-'}
                valueClassName="text-slate-700"
              />
            </div>

            <div className="mb-2 grid grid-cols-1 gap-2 xl:grid-cols-3">
              <div className="rounded-lg border border-slate-200 bg-white p-2 shadow-sm xl:col-span-2">
                <h2 className="mb-1.5 text-xs font-bold text-slate-800">Total konsumsi per line</h2>
                <ResponsiveContainer width="100%" height={170}>
                  <BarChart data={barChartData} margin={{ top: 4, right: 8, left: -8, bottom: 18 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-14} textAnchor="end" height={32} tick={{ fontSize: 9 }} />
                    <YAxis tick={{ fontSize: 9 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="totalKwh" name="Total kWh" radius={[3, 3, 0, 0]}>
                      {barChartData.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
                <h2 className="mb-1.5 text-xs font-bold text-slate-800">Distribusi per production group</h2>
                <ResponsiveContainer width="100%" height={170}>
                  <PieChart>
                    <Pie
                      data={pieChartData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={58}
                      label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                    >
                      {pieChartData.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${formatNumber(value, 2)} kWh`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="mb-2 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
              <h2 className="mb-1.5 text-xs font-bold text-slate-800">Tren konsumsi</h2>
              <ResponsiveContainer width="100%" height={160}>
                <LineChart data={trendChartData} margin={{ top: 4, right: 8, left: -8, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" hide={trendChartData.length > 10} tick={{ fontSize: 9 }} />
                  <YAxis tick={{ fontSize: 9 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line type="monotone" dataKey="totalKwh" name="Total kWh" stroke="#2563EB" strokeWidth={1.8} dot={{ r: 1.8 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 text-[11px]">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Line</th>
                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Production Group</th>
                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">PM Type</th>
                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Periode</th>
                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Mulai</th>
                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Selesai</th>
                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Durasi / Range</th>
                      <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Total kWh</th>
                      <th className="px-2 py-1.5 text-center font-semibold text-slate-600">Detail</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {paginatedData.length > 0 ? (
                      paginatedData.map((item) => (
                        <React.Fragment key={item.rowId}>
                          <tr className="hover:bg-slate-50">
                            <td className="px-2 py-1.5">
                              <div className="font-semibold text-slate-800">{item.lineDisplay}</div>
                              <div className="text-[10px] text-slate-500">{item.line_table}</div>
                            </td>
                            <td className="px-2 py-1.5">
                              <div className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-700">
                                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                                {item.pg}
                              </div>
                            </td>
                            <td className="px-2 py-1.5">{item.pmTypeDisplay}</td>
                            <td className="px-2 py-1.5">{item.periodLabel}</td>
                            <td className="px-2 py-1.5">{formatDateTime(item.startDateTime)}</td>
                            <td className="px-2 py-1.5">{formatDateTime(item.endDateTime)}</td>
                            <td className="px-2 py-1.5">{item.durationLabel}</td>
                            <td className="px-2 py-1.5 text-right font-bold text-emerald-600">{formatNumber(item.totalKwh, 2)}</td>
                            <td className="px-2 py-1.5 text-center">
                              <button
                                onClick={() => setExpandedRow((prev) => (prev === item.rowId ? null : item.rowId))}
                                className="rounded bg-blue-50 px-1.5 py-0.5 text-[10px] font-semibold text-blue-700 transition hover:bg-blue-100"
                              >
                                {expandedRow === item.rowId ? 'Tutup' : 'Lihat'}
                              </button>
                            </td>
                          </tr>

                          {expandedRow === item.rowId ? (
                            <tr className="bg-blue-50/50">
                              <td colSpan={9} className="px-2 py-2">
                                <div className="grid grid-cols-2 gap-1.5 md:grid-cols-4">
                                  <div>
                                    <p className="text-[10px] text-slate-500">Start kWh</p>
                                    <p className="text-[11px] font-semibold text-slate-800">{formatNumber(item.startKwh, 2)}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] text-slate-500">End kWh</p>
                                    <p className="text-[11px] font-semibold text-slate-800">{formatNumber(item.endKwh, 2)}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] text-slate-500">Created At</p>
                                    <p className="text-[11px] font-semibold text-slate-800">{formatDateTime(item.created_at)}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] text-slate-500">Unit Panel</p>
                                    <p className="text-[11px] font-semibold text-slate-800">{item.panelUnit}</p>
                                  </div>
                                  {mode === 'shiftly' ? (
                                    <>
                                      <div>
                                        <p className="text-[10px] text-slate-500">Shift</p>
                                        <p className="text-[11px] font-semibold text-slate-800">{item.shift || '-'}</p>
                                      </div>
                                      <div>
                                        <p className="text-[10px] text-slate-500">Shift Date</p>
                                        <p className="text-[11px] font-semibold text-slate-800">{item.shift_date || '-'}</p>
                                      </div>
                                      <div>
                                        <p className="text-[10px] text-slate-500">Hari</p>
                                        <p className="text-[11px] font-semibold text-slate-800">{item.day_name || '-'}</p>
                                      </div>
                                    </>
                                  ) : (
                                    <>
                                      <div>
                                        <p className="text-[10px] text-slate-500">Month Start Date</p>
                                        <p className="text-[11px] font-semibold text-slate-800">{item.month_start_date || '-'}</p>
                                      </div>
                                      <div>
                                        <p className="text-[10px] text-slate-500">Month End Date</p>
                                        <p className="text-[11px] font-semibold text-slate-800">{item.month_end_date || '-'}</p>
                                      </div>
                                      <div>
                                        <p className="text-[10px] text-slate-500">Bulan</p>
                                        <p className="text-[11px] font-semibold text-slate-800">{item.month_name || '-'} {item.year || ''}</p>
                                      </div>
                                    </>
                                  )}
                                  <div className="md:col-span-4">
                                    <p className="mb-1 text-[10px] text-slate-500">Detail panel terkait</p>
                                    <div className="flex flex-wrap gap-1">
                                      {item.panelDetails.length > 0 ? (
                                        item.panelDetails.map((detail) => (
                                          <span
                                            key={detail}
                                            className="rounded-full border border-blue-200 bg-white px-1.5 py-0.5 text-[10px] font-medium text-slate-700"
                                          >
                                            {detail}
                                          </span>
                                        ))
                                      ) : (
                                        <span className="text-[11px] text-slate-400">Belum ada detail equipment tambahan.</span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ) : null}
                        </React.Fragment>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={9} className="px-2 py-5 text-center text-slate-500">
                          Tidak ada data yang cocok dengan filter saat ini.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-col gap-1.5 border-t border-slate-200 px-2 py-1.5 text-[11px] md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-600">
                  <span>Tampilkan</span>
                  <select
                    value={itemsPerPage}
                    onChange={(e) => {
                      setItemsPerPage(Number(e.target.value));
                      setCurrentPage(1);
                    }}
                    className="rounded border border-slate-300 px-1.5 py-0.5 text-[11px]"
                  >
                    <option value={5}>5</option>
                    <option value={10}>10</option>
                    <option value={15}>15</option>
                    <option value={20}>20</option>
                    <option value={50}>50</option>
                  </select>
                  <span>baris</span>
                </div>

                <p className="text-[11px] text-slate-600">
                  Menampilkan {filteredData.length === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1} sampai{' '}
                  {Math.min(currentPage * itemsPerPage, filteredData.length)} dari {filteredData.length} data
                </p>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="rounded border border-slate-300 px-2 py-0.5 text-[11px] font-semibold text-slate-700 transition hover:bg-slate-100 disabled:opacity-50"
                  >
                    Sebelumnya
                  </button>
                  <span className="text-[11px] font-semibold text-slate-700">
                    {currentPage} / {totalPages}
                  </span>
                  <button
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="rounded border border-slate-300 px-2 py-0.5 text-[11px] font-semibold text-slate-700 transition hover:bg-slate-100 disabled:opacity-50"
                  >
                    Berikutnya
                  </button>
                </div>
              </div>
            </div>

            <PanelInfoCompact />
          </>
        )}
      </div>
    </Layout>
  );
};

export default PanelFacility;
