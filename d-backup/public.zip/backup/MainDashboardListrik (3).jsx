import React, { useEffect, useMemo, useState } from 'react';
import { Container } from 'react-bootstrap';
import axios from 'axios';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
} from 'recharts';
import * as XLSX from 'xlsx';
import Nais_Layout from '../src/components/layout/Layout';

// Konstanta biaya dan emisi
const COST_PER_KWH = 2092.94;
const CO2_EMISSION_FACTOR = 0.92; // kg per kWh
const API_BASE_URL = 'http://172.27.6.191:4000';
const SHIFTLY_API_URL = `${API_BASE_URL}/api/pm-shiftly-kub-kwh`;
const MONTHLY_API_URL = `${API_BASE_URL}/api/pm-monthly-kub-kwh`;

const MONTH_ORDER = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const numberFormatter = new Intl.NumberFormat('id-ID');
const currencyFormatter = new Intl.NumberFormat('id-ID', {
  style: 'currency',
  currency: 'IDR',
  maximumFractionDigits: 0,
});

const formatNumber = (value) => numberFormatter.format(Number(value) || 0);
const formatCurrency = (value) => currencyFormatter.format(Number(value) || 0);
const formatPerKwh = (value) => `Rp ${Number(value || 0).toFixed(3)}`;

const sortByMonthYear = (a, b) => {
  const yearDiff = Number(a.year) - Number(b.year);
  if (yearDiff !== 0) return yearDiff;
  return MONTH_ORDER.indexOf(a.month) - MONTH_ORDER.indexOf(b.month);
};

const ShiftlyReport = () => {
  const [shiftData, setShiftData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const now = new Date();
  const currentMonth = now.toLocaleString('en-US', { month: 'long' });
  const currentYear = now.getFullYear();

  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedYear, setSelectedYear] = useState(currentYear);

  useEffect(() => {
    const controller = new AbortController();

    const fetchData = async () => {
      setLoading(true);
      setError(null);

      try {
        const response = await axios.get(SHIFTLY_API_URL, {
          signal: controller.signal,
          timeout: 15000,
        });

        if (!response.data?.success || !Array.isArray(response.data.data)) {
          throw new Error('Format respons API tidak valid.');
        }

        let rawData = response.data.data || [];

        rawData = rawData.filter((item) => item.line_name === 'kubikal_1');
        rawData = rawData.filter((item) => {
          return item.month_name === selectedMonth && Number(item.year) === selectedYear;
        });

        const groupedByDate = {};

        rawData.forEach((item) => {
          const dateKey = `${item.day_name} ${item.day} ${item.month_name.slice(0, 3)}`;
          const shiftKey = item.shift === 'shift_1' ? 'shift1' : 'shift2';

          if (!groupedByDate[dateKey]) {
            groupedByDate[dateKey] = {
              date: dateKey,
              day: Number(item.day),
              month: item.month_name,
              year: Number(item.year),
              shift1: 0,
              shift2: 0,
              records: [],
            };
          }

          const kwh = Number(item.total_kwh || 0) / 1000;
          groupedByDate[dateKey][shiftKey] += Number.isFinite(kwh) ? kwh : 0;

          groupedByDate[dateKey].records.push({
            ...item,
            kwh: Math.round(kwh),
            cost: Math.round(kwh * COST_PER_KWH),
            co2Kg: Math.round(kwh * CO2_EMISSION_FACTOR),
          });
        });

        const sortedDates = Object.values(groupedByDate).sort((a, b) => {
          const monthDiff = MONTH_ORDER.indexOf(a.month) - MONTH_ORDER.indexOf(b.month);
          if (monthDiff !== 0) return monthDiff;
          return a.day - b.day;
        });

        const chartData = sortedDates.map((item) => ({
          date: item.date,
          shift1: Math.round(item.shift1),
          shift2: Math.round(item.shift2),
          records: item.records,
        }));

        setShiftData(chartData);
      } catch (err) {
        if (axios.isCancel(err) || err?.name === 'CanceledError' || err?.name === 'AbortError') {
          return;
        }

        console.error(err);
        setError(err?.message || 'Gagal memuat data dari server.');
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    };

    fetchData();
    return () => controller.abort();
  }, [selectedMonth, selectedYear]);

  const exportToExcel = () => {
    const exportData = [];

    shiftData.forEach((day) => {
      day.records.forEach((record) => {
        exportData.push({
          Date: day.date,
          Shift: record.shift === 'shift_1' ? 'Shift 1' : 'Shift 2',
          'Energy (kWh)': record.kwh,
          'Cost (IDR)': record.cost,
          'CO2 Emission (kg)': record.co2Kg,
          Month: selectedMonth,
          Year: selectedYear,
        });
      });
    });

    const totalKwh = shiftData.reduce((sum, item) => sum + item.shift1 + item.shift2, 0);
    const totalCost = Math.round(totalKwh * COST_PER_KWH);
    const totalCo2 = Math.round(totalKwh * CO2_EMISSION_FACTOR);

    exportData.push({});
    exportData.push({
      Date: 'TOTAL',
      Shift: '-',
      'Energy (kWh)': Math.round(totalKwh),
      'Cost (IDR)': totalCost,
      'CO2 Emission (kg)': totalCo2,
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Energy Report');

    ws['!cols'] = [
      { wch: 15 },
      { wch: 10 },
      { wch: 15 },
      { wch: 15 },
      { wch: 18 },
      { wch: 10 },
      { wch: 8 },
    ];

    XLSX.writeFile(wb, `Energy_Report_Kubikal1_${selectedMonth}_${selectedYear}.xlsx`);
  };

  if (loading) {
    return <div style={{ padding: '14px', fontSize: '14px', color: '#333' }}>Memuat data...</div>;
  }

  if (error) {
    return <div style={{ padding: '14px', color: '#e74c3c', fontSize: '14px' }}>{error}</div>;
  }

  const totalKwh = shiftData.reduce((sum, item) => sum + item.shift1 + item.shift2, 0);
  const totalShift1 = shiftData.reduce((sum, item) => sum + item.shift1, 0);
  const totalShift2 = shiftData.reduce((sum, item) => sum + item.shift2, 0);
  const daysCount = shiftData.length;
  const avgDaily = daysCount > 0 ? Math.round(totalKwh / daysCount) : 0;
  const peakValue = shiftData.length
    ? Math.max(...shiftData.map((item) => Math.max(item.shift1, item.shift2)))
    : 0;
  const totalCost = Math.round(totalKwh * COST_PER_KWH);
  const totalCo2 = Math.round(totalKwh * CO2_EMISSION_FACTOR);

  return (
    <div style={{ padding: '14px', fontFamily: 'Segoe UI, Arial, sans-serif', backgroundColor: '#ffffff', height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px', gap: '10px', flexWrap: 'wrap' }}>
        <div>
          <h2 style={{ color: '#3498db', margin: 0, fontSize: '20px' }}>
            <span style={{ marginRight: '6px' }}>⚡</span> Otics Indonesia Energy Dashboard – Kubikal 1
          </h2>
          <p style={{ margin: '3px 0 0 0', fontSize: '14px', color: '#666' }}>
            オーティックス・インドネシア エネルギー消費ダッシュボード (キュービカル1)
          </p>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
          <button
            onClick={exportToExcel}
            style={{
              padding: '6px 12px',
              backgroundColor: '#27ae60',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
            }}
          >
            📊 Export Excel
          </button>

          <span style={{ fontSize: '14px', fontWeight: '500' }}>📅 Month:</span>

          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            style={{
              padding: '5px 10px',
              borderRadius: '5px',
              border: '1px solid #ddd',
              fontSize: '14px',
              backgroundColor: '#fff',
            }}
          >
            {MONTH_ORDER.map((month) => (
              <option key={month} value={month}>{month}</option>
            ))}
          </select>

          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            style={{
              padding: '5px 10px',
              borderRadius: '5px',
              border: '1px solid #ddd',
              fontSize: '14px',
              backgroundColor: '#fff',
            }}
          >
            {[2024, 2025, 2026].map((year) => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))',
        gap: '10px',
        marginBottom: '14px',
        padding: '10px',
        backgroundColor: '#e3f2fd',
        borderRadius: '6px',
      }}>
        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '5px' }}>
            <span style={{ fontSize: '20px', color: '#3498db' }}>⚡</span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#3498db' }}>Total Energy</span>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '3px' }}>(総エネルギー)</div>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatNumber(totalKwh)} kWh</div>
        </div>

        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '5px' }}>
            <span style={{ fontSize: '20px', color: '#f39c12' }}>💰</span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#f39c12' }}>Cost</span>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '3px' }}>(コスト)</div>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatCurrency(totalCost)}</div>
        </div>

        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '5px' }}>
            <span style={{ fontSize: '20px', color: '#27ae60' }}>📈</span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#27ae60' }}>Avg Daily</span>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '3px' }}>(平均日次)</div>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatNumber(avgDaily)} kWh</div>
        </div>

        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '5px' }}>
            <span style={{ fontSize: '20px', color: '#3498db' }}>⏱️</span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#3498db' }}>Shift 1 Total</span>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '3px' }}>(シフト1 合計)</div>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatNumber(totalShift1)} kWh</div>
        </div>

        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '5px' }}>
            <span style={{ fontSize: '20px', color: '#7f8c8d' }}>⏱️</span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#7f8c8d' }}>Shift 2 Total</span>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '3px' }}>(シフト2 合計)</div>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatNumber(totalShift2)} kWh</div>
        </div>

        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', textAlign: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '5px' }}>
            <span style={{ fontSize: '20px', color: '#e74c3c' }}>⬆️</span>
            <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#e74c3c' }}>Peak Value</span>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '3px' }}>(ピーク値)</div>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatNumber(peakValue)} kWh</div>
        </div>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '12px',
        marginTop: '14px',
        padding: '12px',
        backgroundColor: '#e3f2fd',
        borderRadius: '6px',
      }}>
        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '7px', marginBottom: '7px' }}>
            <span style={{ fontSize: '20px', color: '#e74c3c' }}>🔥</span>
            <h3 style={{ margin: 0, fontSize: '16px', color: '#e74c3c' }}>CO2 Emissions Summary</h3>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '9px' }}>(CO2排出量サマリー)</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px', flexWrap: 'wrap' }}>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: '14px', color: '#777' }}>Monthly</div>
              <div style={{ fontSize: '14px', color: '#777' }}>(月間)</div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatNumber(totalCo2)} kg</div>
            </div>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: '14px', color: '#777' }}>Daily Avg</div>
              <div style={{ fontSize: '14px', color: '#777' }}>(日平均)</div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{daysCount > 0 ? (totalCo2 / daysCount).toFixed(2) : '0.00'} kg</div>
            </div>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: '14px', color: '#777' }}>Yearly</div>
              <div style={{ fontSize: '14px', color: '#777' }}>(年間)</div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatNumber(Math.round(totalCo2 * 12))} kg</div>
            </div>
          </div>
        </div>

        <div style={{ backgroundColor: '#fff', padding: '12px', borderRadius: '6px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '7px', marginBottom: '7px' }}>
            <span style={{ fontSize: '20px', color: '#f39c12' }}>💰</span>
            <h3 style={{ margin: 0, fontSize: '16px', color: '#f39c12' }}>Cost Analysis</h3>
          </div>
          <div style={{ fontSize: '14px', color: '#777', marginBottom: '9px' }}>(コスト分析)</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '8px', flexWrap: 'wrap' }}>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: '14px', color: '#777' }}>Monthly</div>
              <div style={{ fontSize: '14px', color: '#777' }}>(月間)</div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatCurrency(totalCost)}</div>
            </div>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: '14px', color: '#777' }}>Daily Avg</div>
              <div style={{ fontSize: '14px', color: '#777' }}>(日平均)</div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{daysCount > 0 ? formatCurrency(Math.round(totalCost / daysCount)) : 'Rp 0'}</div>
            </div>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: '14px', color: '#777' }}>Per kWh</div>
              <div style={{ fontSize: '14px', color: '#777' }}>(kWhあたり)</div>
              <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#2c3e50' }}>{formatPerKwh(COST_PER_KWH)}</div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ width: '100%', height: '260px', border: '1px solid #ddd', borderRadius: '8px', marginTop: '14px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={shiftData} margin={{ top: 28, right: 18, left: 10, bottom: 0 }}>
            <defs>
              <linearGradient id="gradientShift1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#2edace" stopOpacity={1} />
                <stop offset="95%" stopColor="#2edace" stopOpacity={0.6} />
              </linearGradient>
              <linearGradient id="gradientShift2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#172fe5" stopOpacity={1} />
                <stop offset="95%" stopColor="#172fe5" stopOpacity={0.6} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="4 4" stroke="#eee" />
            <XAxis
              dataKey="date"
              tick={{ fontSize: 12 }}
              interval={0}
              angle={0}
              textAnchor="end"
              height={34}
              tickFormatter={(value) => {
                const parts = String(value).split(' ');
                if (parts.length >= 3) {
                  const day = parts[1];
                  const month = parts[2];
                  return `${month}-${day}`;
                }
                return value;
              }}
            />
            <YAxis
              tick={{ fontSize: 12 }}
              tickFormatter={formatNumber}
              label={{ value: 'kWh', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fontWeight: 'bold' } }}
            />
            <Tooltip
              formatter={(value, name) => {
                if (name === 'shift1') return [`${formatNumber(value)} kWh`, 'Shift 1'];
                if (name === 'shift2') return [`${formatNumber(value)} kWh`, 'Shift 2'];
                return [value, name];
              }}
              labelFormatter={(label) => `Tanggal: ${label}`}
              contentStyle={{ borderRadius: '8px', border: '1px solid #ddd' }}
            />
            <Legend
              verticalAlign="top"
              height={28}
              content={() => (
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '12px', fontSize: '14px', width: '100%', flexWrap: 'wrap' }}>
                  <span>
                    <span style={{ color: 'black', fontWeight: 'bold' }}>Total Shift 1: </span>
                    <span style={{ color: '#2edace', fontWeight: 'bold' }}>{formatNumber(totalShift1)} kWh</span>
                  </span>
                  <span>
                    <span style={{ color: 'black', fontWeight: 'bold' }}>Total Shift 2: </span>
                    <span style={{ color: '#172fe5', fontWeight: 'bold' }}>{formatNumber(totalShift2)} kWh</span>
                  </span>
                </div>
              )}
            />
            <Bar dataKey="shift1" fill="url(#gradientShift1)" name="Shift 1" radius={[4, 4, 0, 0]} />
            <Bar dataKey="shift2" fill="url(#gradientShift2)" name="Shift 2" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const MonthlyReport = () => {
  const [monthlyData, setMonthlyData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const controller = new AbortController();

    const fetchData = async () => {
      setLoading(true);
      setError('');

      try {
        const response = await axios.get(MONTHLY_API_URL, {
          signal: controller.signal,
          timeout: 15000,
        });

        if (!response?.data || response.data.success !== true || !Array.isArray(response.data.data)) {
          throw new Error('Format respons API tidak valid.');
        }

        const grouped = response.data.data.reduce((acc, item) => {
          const month = item?.month || '-';
          const year = String(item?.year || '-');
          const key = `${month}-${year}`;
          const totalWh = Number(item?.total_wh ?? 0);

          if (!acc[key]) {
            acc[key] = { month, year, totalWh: 0 };
          }

          acc[key].totalWh += Number.isFinite(totalWh) ? totalWh : 0;
          return acc;
        }, {});

        const formatted = Object.values(grouped)
          .map((item) => {
            const kwh = Math.round(item.totalWh / 1000);
            const cost = Math.round(kwh * COST_PER_KWH);
            const co2Kg = Math.round(kwh * CO2_EMISSION_FACTOR);

            return {
              period: `${item.month} ${item.year}`,
              month: item.month,
              year: item.year,
              kwh,
              cost,
              co2Kg,
            };
          })
          .sort(sortByMonthYear);

        setMonthlyData(formatted);
      } catch (err) {
        if (axios.isCancel(err) || err?.name === 'CanceledError' || err?.name === 'AbortError') {
          return;
        }

        const message =
          err?.response?.data?.message ||
          err?.message ||
          'Gagal memuat data dari server.';

        setError(message);
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    };

    fetchData();
    return () => controller.abort();
  }, []);

  const totals = useMemo(() => {
    return monthlyData.reduce(
      (acc, item) => {
        acc.kwh += item.kwh;
        acc.cost += item.cost;
        acc.co2Kg += item.co2Kg;
        return acc;
      },
      { kwh: 0, cost: 0, co2Kg: 0 }
    );
  }, [monthlyData]);

  if (loading) return <div style={{ padding: '14px', fontSize: '14px' }}>Memuat data...</div>;
  if (error) return <div style={{ padding: '14px', color: '#e74c3c', fontSize: '14px' }}>{error}</div>;
  if (!monthlyData.length) return <div style={{ padding: '14px', fontSize: '14px' }}>Data tidak tersedia.</div>;

  return (
    <div style={{ padding: '14px', fontFamily: 'Segoe UI, Arial, sans-serif', backgroundColor: '#ffffff' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', gap: '10px', flexWrap: 'wrap' }}>
        <h2 style={{ color: '#3498db', margin: 0, fontSize: '21px' }}>Laporan Konsumsi Energi Bulanan</h2>
        <div style={{ backgroundColor: '#e3f2fd', color: '#0d47a1', padding: '5px 10px', borderRadius: '5px', fontSize: '14px', fontWeight: 600 }}>
          Total: {formatNumber(totals.kwh)} kWh
        </div>
      </div>

      <div style={{ width: '100%', height: '320px', marginBottom: '14px' }}>
        <ResponsiveContainer>
          <BarChart data={monthlyData} margin={{ top: 18, right: 14, left: 6, bottom: 14 }}>
            <CartesianGrid strokeDasharray="4 4" stroke="#eee" />
            <XAxis
              dataKey="period"
              tick={{ fontSize: 12 }}
              angle={-20}
              textAnchor="end"
              interval={0}
              height={48}
            />
            <YAxis
              tick={{ fontSize: 12 }}
              tickFormatter={formatNumber}
              label={{
                value: 'kWh',
                angle: -90,
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontWeight: 'bold' },
              }}
            />
            <Tooltip
              formatter={(value, name) => {
                if (name === 'Konsumsi (kWh)') return [`${formatNumber(value)} kWh`, name];
                if (name === 'Biaya (Rp)') return [formatCurrency(value), name];
                if (name === 'CO₂ (kg)') return [`${formatNumber(value)} kg`, name];
                return [formatNumber(value), name];
              }}
              labelFormatter={(label) => `Periode: ${label}`}
              contentStyle={{ borderRadius: '8px', border: '1px solid #ddd' }}
            />
            <Legend wrapperStyle={{ fontSize: '14px' }} />
            <Bar dataKey="kwh" fill="#3498db" radius={[4, 4, 0, 0]} name="Konsumsi (kWh)">
              <LabelList
                dataKey="kwh"
                position="top"
                formatter={formatNumber}
                fill="#333"
                fontSize={11}
                fontWeight="bold"
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const MainDashboardListrik = () => {
  return (
    <Nais_Layout>
      <Container fluid className="p-1">
        <ShiftlyReport />
        <MonthlyReport />
      </Container>
    </Nais_Layout>
  );
};

export default MainDashboardListrik;
