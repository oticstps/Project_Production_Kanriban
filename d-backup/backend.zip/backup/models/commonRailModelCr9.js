// src/models/commonRailModelCr9.js

const pool = require("../config/db_core");


// Untuk common_rail_9
const getAllCr9 = async () => {
  const [rows] = await pool.query("SELECT * FROM common_rail_9_core ORDER BY idPrimary DESC");
  return rows;
};

const getByIdCr9 = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_9_core WHERE idPrimary = ?", [id]);
  return rows[0];
};


const getAllCr9Stop = async () => {
  const [rows] = await pool.query(
    "SELECT * FROM common_rail_9_core WHERE status = 'STOP' ORDER BY idPrimary DESC"
  );
  return rows;
};




// Untuk common_rail_9
// const getAllCr9Hourly = async () => {
//   const [rows] = await pool.query("SELECT * FROM common_rail_9_hourly ORDER BY idPrimary DESC");
//   return rows;
// };

// const getByIdCr9Hourly = async (id) => {
//   const [rows] = await pool.query("SELECT * FROM common_rail_9 WHERE idPrimary = ?", [id]);
//   return rows[0];
// };


// const getAllCr9StartStop = async () => {
//   const [rows] = await pool.query(`
//     SELECT * 
//     FROM common_rail_9
//     WHERE status IN ('STOP', 'START')
//     ORDER BY idPrimary DESC
//   `);
//   return rows;
// };



















// CRUD Functions
const create = async (data) => {
  const [result] = await pool.query("INSERT INTO common_rail_9_core SET ?", data);
  return { id: result.insertId, ...data };
};

const update = async (id, data) => {
  await pool.query("UPDATE common_rail_9_core SET ? WHERE idPrimary = ?", [data, id]);
  const [rows] = await pool.query("SELECT * FROM common_rail_9_core WHERE idPrimary = ?", [id]);
  return rows[0]; // Return data yang diperbarui
};

const remove = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_9_core WHERE idPrimary = ?", [id]);
  if (rows.length === 0) {
    throw new Error("Data not found");
  }
  await pool.query("DELETE FROM common_rail_9_core WHERE idPrimary = ?", [id]);
  return { message: "Deleted successfully" };
};

module.exports = {
  getAllCr9,
  getByIdCr9,
  getAllCr9Stop,
  create,
  update,
  remove
};