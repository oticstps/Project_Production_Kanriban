const express = require('express');
const app = express();

app.use(express.json());

const kubRoutes = require('./routes/kubRoutes');
app.use('/api/kub', kubRoutes);

module.exports = app;
