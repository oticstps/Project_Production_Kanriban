const pool = require('../config/db_core');

const TABLES = {
  shiftly: 'tb_kub1_shiftly',
  daily: 'tb_kub1_daily',
  weekly: 'tb_kub1_weekly',
  monthly: 'tb_kub1_monthly',
  source: 'tb_kub1_total_kwh'
};

async function getPowerMeters() {
  const [rows] = await pool.query(`
    SELECT DISTINCT power_meter
    FROM ${TABLES.source}
    WHERE power_meter IS NOT NULL
      AND TRIM(power_meter) <> ''
    ORDER BY power_meter ASC
  `);

  return rows;
}

async function getShiftlyByMeter(powerMeter) {
  const [rows] = await pool.query(`
    SELECT *
    FROM ${TABLES.shiftly}
    WHERE line_name = ?
    ORDER BY shift_date DESC,
             FIELD(shift, 'shift_1', 'shift_2'),
             idPrimary DESC
  `, [powerMeter]);

  return rows;
}

async function getDailyByMeter(powerMeter, year, month) {
  const params = [powerMeter, Number(year), Number(month)];
  const [rows] = await pool.query(`
    SELECT *
    FROM ${TABLES.daily}
    WHERE line_name = ?
      AND year = ?
      AND month = ?
    ORDER BY record_date DESC, idPrimary DESC
  `, params);

  return rows;
}

async function getWeeklyByMeter(powerMeter, year, week) {
  const params = [powerMeter, Number(year), Number(week)];
  const [rows] = await pool.query(`
    SELECT *
    FROM ${TABLES.weekly}
    WHERE line_name = ?
      AND year = ?
      AND week = ?
    ORDER BY week DESC, idPrimary DESC
  `, params);

  return rows;
}

async function getMonthlyByMeter(powerMeter, year, month = null) {
  let sql = `
    SELECT *
    FROM ${TABLES.monthly}
    WHERE line_name = ?
      AND year = ?
  `;

  const params = [powerMeter, Number(year)];

  if (month !== null && month !== undefined && month !== '') {
    sql += ' AND month = ?';
    params.push(Number(month));
  }

  sql += ' ORDER BY year DESC, month DESC, idPrimary DESC';

  const [rows] = await pool.query(sql, params);
  return rows;
}

module.exports = {
  TABLES,
  getPowerMeters,
  getShiftlyByMeter,
  getDailyByMeter,
  getWeeklyByMeter,
  getMonthlyByMeter,
};
