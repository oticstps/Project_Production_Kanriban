const pool = require('../config/db_core');
const moment = require('moment-timezone');

moment.tz.setDefault('Asia/Jakarta');

const CONFIG = {
  pm_type: 'POWER METER PUSAT',
  source_table: 'tb_kub1_total_kwh',
  target_tables: {
    shiftly: 'tb_kub1_shiftly',
    daily: 'tb_kub1_daily',
    weekly: 'tb_kub1_weekly',
    monthly: 'tb_kub1_monthly',
  },
};

function toNumber(value) {
  const num = parseFloat(value);
  return Number.isFinite(num) ? num : null;
}

async function getPowerMeters(connection, meterFilter = null) {
  let sql = `
    SELECT DISTINCT power_meter
    FROM ${CONFIG.source_table}
    WHERE power_meter IS NOT NULL
      AND TRIM(power_meter) <> ''
  `;

  const params = [];

  if (meterFilter) {
    sql += ' AND power_meter = ?';
    params.push(meterFilter);
  }

  sql += ' ORDER BY power_meter ASC';

  const [rows] = await connection.query(sql, params);
  return rows.map(row => row.power_meter);
}

async function getStartEndRow(connection, powerMeter, startTime, endTime) {
  const params = [
    powerMeter,
    startTime.format('YYYY-MM-DD HH:mm:ss'),
    endTime.format('YYYY-MM-DD HH:mm:ss')
  ];

  const [startRow] = await connection.query(`
    SELECT date_time, value
    FROM ${CONFIG.source_table}
    WHERE power_meter = ?
      AND date_time >= ?
      AND date_time < ?
    ORDER BY date_time ASC
    LIMIT 1
  `, params);

  const [endRow] = await connection.query(`
    SELECT date_time, value
    FROM ${CONFIG.source_table}
    WHERE power_meter = ?
      AND date_time >= ?
      AND date_time < ?
    ORDER BY date_time DESC
    LIMIT 1
  `, params);

  if (!startRow.length || !endRow.length) {
    return null;
  }

  const startValue = toNumber(startRow[0].value);
  const endValue = toNumber(endRow[0].value);

  if (startValue === null || endValue === null) {
    return null;
  }

  const totalValue = endValue - startValue;
  if (totalValue <= 0) {
    return null;
  }

  return {
    startDatetime: startRow[0].date_time,
    endDatetime: endRow[0].date_time,
    startValue,
    endValue,
    totalValue,
  };
}

async function upsertShiftly(connection, payload) {
  await connection.query(`
    INSERT INTO ${CONFIG.target_tables.shiftly} (
      pm_type,
      line_table,
      line_name,
      shift,
      shift_date,
      shift_start_datetime,
      shift_end_datetime,
      start_kwh,
      end_kwh,
      total_kwh,
      year,
      month,
      month_name,
      day,
      day_name,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      pm_type = VALUES(pm_type),
      shift_start_datetime = VALUES(shift_start_datetime),
      shift_end_datetime = VALUES(shift_end_datetime),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      year = VALUES(year),
      month = VALUES(month),
      month_name = VALUES(month_name),
      day = VALUES(day),
      day_name = VALUES(day_name),
      updated_at = NOW()
  `, [
    payload.pm_type,
    payload.line_table,
    payload.line_name,
    payload.shift,
    payload.shift_date,
    payload.shift_start_datetime,
    payload.shift_end_datetime,
    payload.start_kwh,
    payload.end_kwh,
    payload.total_kwh,
    payload.year,
    payload.month,
    payload.month_name,
    payload.day,
    payload.day_name,
  ]);
}

async function upsertDaily(connection, payload) {
  await connection.query(`
    INSERT INTO ${CONFIG.target_tables.daily} (
      pm_type,
      line_table,
      line_name,
      record_date,
      start_datetime,
      end_datetime,
      start_kwh,
      end_kwh,
      total_kwh,
      year,
      month,
      month_name,
      day,
      day_name,
      week,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      pm_type = VALUES(pm_type),
      start_datetime = VALUES(start_datetime),
      end_datetime = VALUES(end_datetime),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      year = VALUES(year),
      month = VALUES(month),
      month_name = VALUES(month_name),
      day = VALUES(day),
      day_name = VALUES(day_name),
      week = VALUES(week),
      updated_at = NOW()
  `, [
    payload.pm_type,
    payload.line_table,
    payload.line_name,
    payload.record_date,
    payload.start_datetime,
    payload.end_datetime,
    payload.start_kwh,
    payload.end_kwh,
    payload.total_kwh,
    payload.year,
    payload.month,
    payload.month_name,
    payload.day,
    payload.day_name,
    payload.week,
  ]);
}

async function upsertWeekly(connection, payload) {
  await connection.query(`
    INSERT INTO ${CONFIG.target_tables.weekly} (
      pm_type,
      line_table,
      line_name,
      year,
      week,
      week_start_date,
      week_end_date,
      start_datetime,
      end_datetime,
      start_kwh,
      end_kwh,
      total_kwh,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      pm_type = VALUES(pm_type),
      week_start_date = VALUES(week_start_date),
      week_end_date = VALUES(week_end_date),
      start_datetime = VALUES(start_datetime),
      end_datetime = VALUES(end_datetime),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      updated_at = NOW()
  `, [
    payload.pm_type,
    payload.line_table,
    payload.line_name,
    payload.year,
    payload.week,
    payload.week_start_date,
    payload.week_end_date,
    payload.start_datetime,
    payload.end_datetime,
    payload.start_kwh,
    payload.end_kwh,
    payload.total_kwh,
  ]);
}

async function upsertMonthly(connection, payload) {
  await connection.query(`
    INSERT INTO ${CONFIG.target_tables.monthly} (
      pm_type,
      line_table,
      line_name,
      year,
      month,
      month_name,
      month_start_date,
      month_end_date,
      start_datetime,
      end_datetime,
      start_kwh,
      end_kwh,
      total_kwh,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
      pm_type = VALUES(pm_type),
      month_name = VALUES(month_name),
      month_start_date = VALUES(month_start_date),
      month_end_date = VALUES(month_end_date),
      start_datetime = VALUES(start_datetime),
      end_datetime = VALUES(end_datetime),
      start_kwh = VALUES(start_kwh),
      end_kwh = VALUES(end_kwh),
      total_kwh = VALUES(total_kwh),
      updated_at = NOW()
  `, [
    payload.pm_type,
    payload.line_table,
    payload.line_name,
    payload.year,
    payload.month,
    payload.month_name,
    payload.month_start_date,
    payload.month_end_date,
    payload.start_datetime,
    payload.end_datetime,
    payload.start_kwh,
    payload.end_kwh,
    payload.total_kwh,
  ]);
}

async function rekapShiftly(meterFilter = null) {
  const connection = await pool.getConnection();
  const logs = [];

  try {
    const powerMeters = await getPowerMeters(connection, meterFilter);

    for (const powerMeter of powerMeters) {
      const [dates] = await connection.query(`
        SELECT DISTINCT
          DATE(date_time) AS shift_date,
          YEAR(date_time) AS year,
          MONTH(date_time) AS month,
          DAY(date_time) AS day
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time IS NOT NULL
        ORDER BY shift_date ASC
      `, [powerMeter]);

      for (const row of dates) {
        const shiftDate = moment(row.shift_date).format('YYYY-MM-DD');
        const dayName = moment(shiftDate).format('dddd');
        const monthName = moment(shiftDate).format('MMMM');

        const shift1Start = moment(shiftDate).set({ hour: 7, minute: 10, second: 0 });
        const shift1End = moment(shiftDate).set({ hour: 19, minute: 50, second: 0 });
        const shift2Start = moment(shiftDate).set({ hour: 19, minute: 50, second: 0 });
        const shift2End = moment(shiftDate).add(1, 'day').set({ hour: 7, minute: 10, second: 0 });

        const shift1Data = await getStartEndRow(connection, powerMeter, shift1Start, shift1End);
        if (shift1Data) {
          await upsertShiftly(connection, {
            pm_type: CONFIG.pm_type,
            line_table: CONFIG.source_table,
            line_name: powerMeter,
            shift: 'shift_1',
            shift_date: shiftDate,
            shift_start_datetime: shift1Data.startDatetime,
            shift_end_datetime: shift1Data.endDatetime,
            start_kwh: shift1Data.startValue,
            end_kwh: shift1Data.endValue,
            total_kwh: shift1Data.totalValue,
            year: row.year,
            month: row.month,
            month_name: monthName,
            day: row.day,
            day_name: dayName,
          });
          logs.push(`OK ${powerMeter} ${shiftDate} shift_1`);
        }

        const shift2Data = await getStartEndRow(connection, powerMeter, shift2Start, shift2End);
        if (shift2Data) {
          await upsertShiftly(connection, {
            pm_type: CONFIG.pm_type,
            line_table: CONFIG.source_table,
            line_name: powerMeter,
            shift: 'shift_2',
            shift_date: shiftDate,
            shift_start_datetime: shift2Data.startDatetime,
            shift_end_datetime: shift2Data.endDatetime,
            start_kwh: shift2Data.startValue,
            end_kwh: shift2Data.endValue,
            total_kwh: shift2Data.totalValue,
            year: row.year,
            month: row.month,
            month_name: monthName,
            day: row.day,
            day_name: dayName,
          });
          logs.push(`OK ${powerMeter} ${shiftDate} shift_2`);
        }
      }
    }

    return { success: true, message: 'Rekap shiftly selesai', logs };
  } finally {
    connection.release();
  }
}

async function rekapDaily(meterFilter = null) {
  const connection = await pool.getConnection();
  const logs = [];

  try {
    const powerMeters = await getPowerMeters(connection, meterFilter);

    for (const powerMeter of powerMeters) {
      const [dates] = await connection.query(`
        SELECT DISTINCT
          DATE(date_time) AS record_date,
          YEAR(date_time) AS year,
          MONTH(date_time) AS month,
          DAY(date_time) AS day,
          WEEK(date_time) AS week
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time IS NOT NULL
        ORDER BY record_date ASC
      `, [powerMeter]);

      for (const row of dates) {
        const recordDate = moment(row.record_date).format('YYYY-MM-DD');
        const startTime = moment(recordDate).startOf('day');
        const endTime = moment(recordDate).clone().add(1, 'day').startOf('day');

        const dailyData = await getStartEndRow(connection, powerMeter, startTime, endTime);
        if (!dailyData) continue;

        await upsertDaily(connection, {
          pm_type: CONFIG.pm_type,
          line_table: CONFIG.source_table,
          line_name: powerMeter,
          record_date: recordDate,
          start_datetime: dailyData.startDatetime,
          end_datetime: dailyData.endDatetime,
          start_kwh: dailyData.startValue,
          end_kwh: dailyData.endValue,
          total_kwh: dailyData.totalValue,
          year: row.year,
          month: row.month,
          month_name: moment(recordDate).format('MMMM'),
          day: row.day,
          day_name: moment(recordDate).format('dddd'),
          week: row.week,
        });

        logs.push(`OK ${powerMeter} ${recordDate}`);
      }
    }

    return { success: true, message: 'Rekap daily selesai', logs };
  } finally {
    connection.release();
  }
}

async function rekapWeekly(meterFilter = null) {
  const connection = await pool.getConnection();
  const logs = [];

  try {
    const powerMeters = await getPowerMeters(connection, meterFilter);

    for (const powerMeter of powerMeters) {
      const [periods] = await connection.query(`
        SELECT DISTINCT YEAR(date_time) AS year, WEEK(date_time) AS week
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time IS NOT NULL
        ORDER BY year ASC, week ASC
      `, [powerMeter]);

      for (const row of periods) {
        const [startRows] = await connection.query(`
          SELECT date_time, value
          FROM ${CONFIG.source_table}
          WHERE power_meter = ?
            AND YEAR(date_time) = ?
            AND WEEK(date_time) = ?
          ORDER BY date_time ASC
          LIMIT 1
        `, [powerMeter, row.year, row.week]);

        const [endRows] = await connection.query(`
          SELECT date_time, value
          FROM ${CONFIG.source_table}
          WHERE power_meter = ?
            AND YEAR(date_time) = ?
            AND WEEK(date_time) = ?
          ORDER BY date_time DESC
          LIMIT 1
        `, [powerMeter, row.year, row.week]);

        if (!startRows.length || !endRows.length) continue;

        const startValue = toNumber(startRows[0].value);
        const endValue = toNumber(endRows[0].value);
        if (startValue === null || endValue === null) continue;

        const totalValue = endValue - startValue;
        if (totalValue <= 0) continue;

        await upsertWeekly(connection, {
          pm_type: CONFIG.pm_type,
          line_table: CONFIG.source_table,
          line_name: powerMeter,
          year: row.year,
          week: row.week,
          week_start_date: moment(startRows[0].date_time).format('YYYY-MM-DD'),
          week_end_date: moment(endRows[0].date_time).format('YYYY-MM-DD'),
          start_datetime: startRows[0].date_time,
          end_datetime: endRows[0].date_time,
          start_kwh: startValue,
          end_kwh: endValue,
          total_kwh: totalValue,
        });

        logs.push(`OK ${powerMeter} year=${row.year} week=${row.week}`);
      }
    }

    return { success: true, message: 'Rekap weekly selesai', logs };
  } finally {
    connection.release();
  }
}

async function rekapMonthly(meterFilter = null) {
  const connection = await pool.getConnection();
  const logs = [];

  try {
    const powerMeters = await getPowerMeters(connection, meterFilter);

    for (const powerMeter of powerMeters) {
      const [periods] = await connection.query(`
        SELECT DISTINCT YEAR(date_time) AS year, MONTH(date_time) AS month
        FROM ${CONFIG.source_table}
        WHERE power_meter = ?
          AND date_time IS NOT NULL
        ORDER BY year ASC, month ASC
      `, [powerMeter]);

      for (const row of periods) {
        const [startRows] = await connection.query(`
          SELECT date_time, value
          FROM ${CONFIG.source_table}
          WHERE power_meter = ?
            AND YEAR(date_time) = ?
            AND MONTH(date_time) = ?
          ORDER BY date_time ASC
          LIMIT 1
        `, [powerMeter, row.year, row.month]);

        const [endRows] = await connection.query(`
          SELECT date_time, value
          FROM ${CONFIG.source_table}
          WHERE power_meter = ?
            AND YEAR(date_time) = ?
            AND MONTH(date_time) = ?
          ORDER BY date_time DESC
          LIMIT 1
        `, [powerMeter, row.year, row.month]);

        if (!startRows.length || !endRows.length) continue;

        const startValue = toNumber(startRows[0].value);
        const endValue = toNumber(endRows[0].value);
        if (startValue === null || endValue === null) continue;

        const totalValue = endValue - startValue;
        if (totalValue <= 0) continue;

        await upsertMonthly(connection, {
          pm_type: CONFIG.pm_type,
          line_table: CONFIG.source_table,
          line_name: powerMeter,
          year: row.year,
          month: row.month,
          month_name: moment(`${row.year}-${row.month}-01`, 'YYYY-M-D').format('MMMM'),
          month_start_date: moment(startRows[0].date_time).format('YYYY-MM-DD'),
          month_end_date: moment(endRows[0].date_time).format('YYYY-MM-DD'),
          start_datetime: startRows[0].date_time,
          end_datetime: endRows[0].date_time,
          start_kwh: startValue,
          end_kwh: endValue,
          total_kwh: totalValue,
        });

        logs.push(`OK ${powerMeter} year=${row.year} month=${row.month}`);
      }
    }

    return { success: true, message: 'Rekap monthly selesai', logs };
  } finally {
    connection.release();
  }
}

module.exports = {
  rekapShiftly,
  rekapDaily,
  rekapWeekly,
  rekapMonthly,
};
