import { useEffect, useState } from 'react';
import { getImportBatches, uploadImportFile } from './services/importService';

function App() {
  const [importDate, setImportDate] = useState('');
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);
  const [batches, setBatches] = useState([]);

  const canSubmit = Boolean(importDate && file && !loading);

  async function loadBatches() {
    try {
      const data = await getImportBatches();
      setBatches(data);
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(() => {
    loadBatches();
  }, []);

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setResult(null);

    if (!importDate) {
      setError('Tanggal wajib diisi sebelum upload/import data.');
      return;
    }

    if (!file) {
      setError('Pilih file CSV, XLS, atau XLSX terlebih dahulu.');
      return;
    }

    try {
      setLoading(true);
      const data = await uploadImportFile({ importDate, file });
      setResult(data);
      setFile(null);
      event.target.reset();
      await loadBatches();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="page">
      <section className="card">
        <div className="header">
          <p className="eyebrow">React Vite + Node.js + MySQL</p>
          <h1>Import Excel/CSV ke Database MySQL</h1>
          <p>
            User wajib mengisi tanggal manual terlebih dahulu. Backend juga memvalidasi tanggal,
            jadi data tidak akan masuk jika tanggal kosong.
          </p>
        </div>

        <form className="form" onSubmit={handleSubmit}>
          <label>
            Tanggal Import
            <input
              type="date"
              value={importDate}
              onChange={(event) => setImportDate(event.target.value)}
              required
            />
          </label>

          <label>
            File Excel/CSV
            <input
              type="file"
              accept=".csv,.xls,.xlsx"
              onChange={(event) => setFile(event.target.files?.[0] || null)}
              required
            />
          </label>

          <button type="submit" disabled={!canSubmit}>
            {loading ? 'Mengimport...' : 'Import ke MySQL'}
          </button>
        </form>

        {error && <div className="alert error">{error}</div>}

        {result && (
          <div className="alert success">
            <strong>{result.message}</strong>
            <p>Batch ID: {result.batchId}</p>
            <p>Tanggal Import: {result.importDate}</p>
            <p>Total Data: {result.insertedRows}</p>
          </div>
        )}
      </section>

      <section className="card">
        <h2>History Import</h2>
        {batches.length === 0 ? (
          <p className="muted">Belum ada history import.</p>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Tanggal Import</th>
                  <th>File</th>
                  <th>Total Row</th>
                  <th>Dibuat</th>
                </tr>
              </thead>
              <tbody>
                {batches.map((batch) => (
                  <tr key={batch.id}>
                    <td>{batch.id}</td>
                    <td>{batch.import_date}</td>
                    <td>{batch.original_filename}</td>
                    <td>{batch.total_rows}</td>
                    <td>{batch.created_at}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}

export default App;
