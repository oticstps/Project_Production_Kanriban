const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export async function uploadImportFile({ importDate, file }) {
  const formData = new FormData();
  formData.append('importDate', importDate);
  formData.append('file', file);

  const response = await fetch(`${API_URL}/imports`, {
    method: 'POST',
    body: formData
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Gagal import data.');
  }

  return data;
}

export async function getImportBatches() {
  const response = await fetch(`${API_URL}/imports/batches`);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Gagal mengambil history import.');
  }

  return data.data;
}
