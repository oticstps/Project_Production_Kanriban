# Excel/CSV to MySQL Importer

Project ini memakai:

- Backend: Node.js, Express, Multer, XLSX, MySQL2
- Frontend: React.js Vite
- Database: MySQL

Frontend wajib mengirim `importDate` dari input manual. Backend tetap melakukan validasi, sehingga data tidak akan diinsert jika tanggal kosong atau format tanggal tidak valid.

## Struktur

```text
backend/
  src/config/db.js
  src/controllers/import.controller.js
  src/models/importBatch.model.js
  src/models/importRecord.model.js
  src/routes/import.routes.js
  src/middleware/upload.middleware.js
  src/utils/fileParser.js
  src/sql/schema.sql
frontend/
  src/App.jsx
  src/services/importService.js
```

## Setup Database

Buka MySQL lalu jalankan:

```sql
SOURCE backend/src/sql/schema.sql;
```

Atau copy isi file `backend/src/sql/schema.sql` ke MySQL client seperti phpMyAdmin, DBeaver, TablePlus, atau MySQL Workbench.

## Setup Backend

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

Sesuaikan `.env`:

```env
PORT=5000
FRONTEND_URL=http://localhost:5173
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=password_mysql_anda
DB_NAME=excel_import_db
```

API utama:

```http
POST http://localhost:5000/api/imports
Content-Type: multipart/form-data

file: CSV/XLS/XLSX
importDate: YYYY-MM-DD
```

## Setup Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Buka:

```text
http://localhost:5173
```

## Cara Kerja Import

1. User pilih tanggal import manual di frontend.
2. User pilih file `.csv`, `.xls`, atau `.xlsx`.
3. Frontend mengirim `FormData` berisi `importDate` dan `file`.
4. Backend membaca file memakai package `xlsx`.
5. Backend membuat 1 record di tabel `import_batches`.
6. Semua row file disimpan ke tabel `import_records` dalam kolom JSON `payload`, plus `import_date`.

Model penyimpanan JSON ini fleksibel untuk berbagai bentuk Excel/CSV. Jika Anda ingin tabel fixed seperti `x`, `Pv Power`, `Inverter1`, `Inverter2`, lihat tabel contoh `solar_power_records` di `schema.sql`.
