CREATE DATABASE IF NOT EXISTS excel_import_db;
USE excel_import_db;

CREATE TABLE IF NOT EXISTS import_batches (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  import_date DATE NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  total_rows INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_import_batches_import_date (import_date)
);

CREATE TABLE IF NOT EXISTS import_records (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  batch_id BIGINT UNSIGNED NOT NULL,
  import_date DATE NOT NULL,
  row_number INT UNSIGNED NOT NULL,
  payload JSON NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_import_records_batch_id (batch_id),
  INDEX idx_import_records_import_date (import_date),
  CONSTRAINT fk_import_records_batch
    FOREIGN KEY (batch_id) REFERENCES import_batches(id)
    ON DELETE CASCADE
);

-- Opsional: contoh tabel khusus untuk CSV solar seperti file contoh Anda.
-- Gunakan tabel ini jika ingin menyimpan kolom secara fixed, bukan JSON fleksibel.
CREATE TABLE IF NOT EXISTS solar_power_records (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  import_date DATE NOT NULL,
  time_label VARCHAR(20) NOT NULL,
  pv_power DECIMAL(18,4) DEFAULT NULL,
  inverter1 DECIMAL(18,4) DEFAULT NULL,
  inverter2 DECIMAL(18,4) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_solar_power_records_import_date (import_date)
);
