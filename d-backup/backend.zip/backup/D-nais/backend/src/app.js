const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();

const importRoutes = require('./routes/import.routes');

const app = express();

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173'
}));
app.use(express.json());
app.use(morgan('dev'));

app.get('/', (req, res) => {
  res.json({ message: 'Excel/CSV MySQL Importer API aktif.' });
});

app.use('/api/imports', importRoutes);

app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    message: err.message || 'Terjadi kesalahan server.'
  });
});

module.exports = app;
