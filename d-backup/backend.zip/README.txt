BACKEND tb_kub1_total_kwh_shiftly

1. Jalankan sql/tb_kub1_total_kwh_shiftly.sql.
2. Salin model ke folder models.
3. Salin controller ke folder controllers.
4. Salin route ke folder routes.
5. Tambahkan isi app-snippet.js ke app.js.

Endpoint:
GET    /api/pm-shiftly-kub-kwh?limit=500
GET    /api/pm-shiftly-kub-kwh/date-range?startDate=2026-07-01&endDate=2026-07-31
GET    /api/pm-shiftly-kub-kwh/shift/:shift
GET    /api/pm-shiftly-kub-kwh/line-table/:line_table
GET    /api/pm-shiftly-kub-kwh/pm-type/:pm_type
GET    /api/pm-shiftly-kub-kwh/power-meter/:power_meter   (alias lama)
GET    /api/pm-shiftly-kub-kwh/:id
POST   /api/pm-shiftly-kub-kwh
PUT    /api/pm-shiftly-kub-kwh/:id
DELETE /api/pm-shiftly-kub-kwh/:id

Minimal body POST:
{
  "pm_type": "KWH",
  "line_table": "kub1",
  "line_name": "Line 1",
  "shift": "shift_1",
  "shift_date": "2026-07-17"
}
