// Fungsi mapping line_id ke line_name dan pg
function getLineInfo(line_id) {
    const lineMap = {
        "1": { name: "Common Rail 1", pg: "PG2.2" },
        "2": { name: "Common Rail 2", pg: "PG2.2" },
        "3": { name: "Common Rail 3", pg: "PG2.2" },
        "4": { name: "Common Rail 4", pg: "PG2.1" },
        "5": { name: "Common Rail 5", pg: "PG2.2" },
        "6": { name: "Common Rail 6", pg: "PG2.1" },
        "7": { name: "Common Rail 7", pg: "PG2.2" },
        "8": { name: "Common Rail 8", pg: "PG2.2" },
        "9": { name: "Common Rail 9", pg: "PG2.1" },
        "10": { name: "Common Rail 10", pg: "PG2.1" },
        "11": { name: "Common Rail 11", pg: "PG2.1" },
        "12": { name: "Common Rail 12", pg: "PG2.1" },
        "13": { name: "Cam housing", pg: "PG2.3" },
        "13A": { name: "Cam housing A", pg: "PG2.3" },
        "13B": { name: "Cam housing B", pg: "PG2.3" },
        "14": { name: "Cam housing", pg: "PG2.3" },
        "14A": { name: "Cam housing C", pg: "PG2.3" },
        "14B": { name: "Cam housing D", pg: "PG2.3" },
        "15": { name: "Cam housing", pg: "PG2.3" },
        "15A": { name: "Cam housing E NR", pg: "PG2.3" },
        "15B": { name: "Cam housing E D05E", pg: "PG2.3" },
        "16": { name: "Cam housing Assy A", pg: "PG2.3" },
        "17": { name: "Cam housing Assy B", pg: "PG2.3" },
        "18": { name: "Cam housing Assy", pg: "PG2.3" },
        "18A": { name: "Cam housing Assy C NR", pg: "PG2.3" },
        "18B": { name: "Cam housing Assy C D05E", pg: "PG2.3" },
        "19": { name: "Cam Cap 1A", pg: "PG2.3" },
        "20": { name: "Cam Cap 1B", pg: "PG2.3" },
        "21": { name: "Cam Cap 1", pg: "PG2.3" },
        "21A": { name: "Cam Cap 1C NR", pg: "PG2.3" },
        "21B": { name: "Cam Cap 1C D05E", pg: "PG2.3" },
        "22": { name: "Cam Cap 2", pg: "PG2.3" },
        "22A": { name: "Cam Cap 2 2MP", pg: "PG2.3" },
        "22B": { name: "Cam Cap 2 3MP", pg: "PG2.3" },
        "22C": { name: "Cam Cap 2 4MP", pg: "PG2.3" },
        "22D": { name: "Cam Cap 2 5MP", pg: "PG2.3" },
        "23": { name: "Cam Cap 3", pg: "PG2.3" },
        "23A": { name: "Cam Cap 3 2MP", pg: "PG2.3" },
        "23B": { name: "Cam Cap 3 3MP", pg: "PG2.3" },
        "23C": { name: "Cam Cap 3 4MP", pg: "PG2.3" },
        "23D": { name: "Cam Cap 3 5MP", pg: "PG2.3" },
        "24": { name: "Cam Cap 4", pg: "PG2.3" },
        "24A": { name: "Cam Cap 4 2MP", pg: "PG2.3" },
        "24B": { name: "Cam Cap 4 3MP", pg: "PG2.3" },
        "24C": { name: "Cam Cap 4 4MP", pg: "PG2.3" },
        "24D": { name: "Cam Cap 4 5MP", pg: "PG2.3" },
        "25": { name: "Cam Cap 2 & 3 D05E", pg: "PG2.3" },
        "26": { name: "Spacer Drive Gear", pg: "PG1.1" },
        "26A": { name: "Retainer", pg: "PG1.1" },
        "27": { name: "Connector", pg: "PG1.1" },
        "27A": { name: "Retainer", pg: "PG1.1" },
        "27B": { name: "Drive Gear", pg: "PG1.1" },
        "27C": { name: "Spacer Drive Gear", pg: "PG1.1" },
        "28": { name: "Housing", pg: "PG1.1" },
        "28A": { name: "Housing Inlet TR", pg: "PG1.1" },
        "28B": { name: "Housing Inlet D13E", pg: "PG1.1" },
        "29": { name: "Balance Shaft NO 1", pg: "PG1.1" },
        "29A": { name: "Balance Shaft NO 2", pg: "PG1.1" },
        "30": { name: "Roller Arm 1", pg: "PG1.1" },
        "30A": { name: "Roller Arm 1 A", pg: "PG1.1" },
        "30B": { name: "Roller Arm 1 B", pg: "PG1.1" },
        "30C": { name: "Roller Arm 1 C", pg: "PG1.1" },
        "30D": { name: "Roller Arm 1 D", pg: "PG1.1" },
        "30E": { name: "Roller Arm 1 E", pg: "PG1.1" },
        "31": { name: "Roller Arm 2", pg: "PG1.1" },
        "31A": { name: "Roller Arm 2 A", pg: "PG1.1" },
        "31B": { name: "Roller Arm 2 B", pg: "PG1.1" },
        "31C": { name: "Roller Arm 2 C", pg: "PG1.1" },
        "31D": { name: "Roller Arm 2 D", pg: "PG1.1" },
        "31E": { name: "Roller Arm 2 E", pg: "PG1.1" },
        "32": { name: "Hydraulic Lash Adjuster", pg: "PG1.1" },
        "32A": { name: "Hydraulic Lash Adjuster A", pg: "PG1.1" },
        "32B": { name: "Hydraulic Lash Adjuster B", pg: "PG1.1" },
        "32C": { name: "Hydraulic Lash Adjuster C", pg: "PG1.1" },
        "32D": { name: "Hydraulic Lash Adjuster D", pg: "PG1.1" },
        "32E": { name: "Hydraulic Lash Adjuster E", pg: "PG1.1" },
        "33": { name: "Housing Inlet Water", pg: "PG1.1" },
        "34": { name: "Packing Assy A", pg: "PG1.2" },
        "35": { name: "Packing Assy B", pg: "PG1.2" },
        "36": { name: "Packing Assy C", pg: "PG1.2" },
        "37": { name: "Packing IMV", pg: "PG1.2" },
        "38": { name: "Packing IMV", pg: "PG1.2" },
        "39": { name: "Packing IMV", pg: "PG1.2" },
        "40": { name: "Packing IMV", pg: "PG1.2" },
        "41": { name: "Packing IMV", pg: "PG1.2" },
        "42": { name: "Packing IMV", pg: "PG1.2" },
        "43": { name: "Packing IMV", pg: "PG1.2" },
        "44": { name: "Packing IMV", pg: "PG1.2" },
        "45": { name: "Packing IMV", pg: "PG1.2" },
        "46": { name: "Packing IMV", pg: "PG1.2" },
        "47": { name: "Packing IMV", pg: "PG1.2" },
        "48": { name: "Packing IMV", pg: "PG1.2" },
        "49": { name: "Packing IMV", pg: "PG1.2" },
        "50": { name: "Packing IMV", pg: "PG1.2" }
    };

    return lineMap[line_id] || null;
}

// Fungsi untuk mengubah line_name jadi format tabel
function toTableName(name) {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9 ]/g, '') // Hapus karakter aneh
        .replace(/\s+/g, '_');      // Ganti spasi jadi _
}

// Main logic
const payload = msg.payload;

if (payload.length < 12) {
    return null; // Data tidak lengkap
}

const line_id = payload[0];
const info = getLineInfo(line_id);

if (!info) {
    return null; // Tidak ada info untuk line_id ini
}

// Ekstrak semua field dari payload
const [
    , name_product, target, actual, loading_time, efficiency,
    delay, cycle_time, status_montiv, time_trouble,
    time_trouble_quality, andon
] = payload;

// Buat nama tabel dinamis
const tableName = toTableName(info.name); // e.g., "cam_cap_2_2mp"

// Bangun query SQL untuk tabel spesifik line
const specificLineQuery = `
INSERT INTO ${tableName} (
    line_id, pg, line_name, name_product, target, actual,
    loading_time, efficiency, delay, cycle_time, status,
    time_trouble, time_trouble_quality, andon
) VALUES (
    '${line_id}', '${info.pg}', '${info.name}', '${name_product}',
    '${target}', '${actual}', '${loading_time}', '${efficiency}',
    '${delay}', '${cycle_time}', '${status_montiv}', '${time_trouble}',
    '${time_trouble_quality}', '${andon}'
)`.replace(/\s+/g, ' ').trim();

// Bangun query SQL untuk tabel production_data
const productionDataQuery = `
INSERT INTO production_data (
    idPrimary, line_id, pg, line_name, name_product, target, actual,
    loading_time, efficiency, delay, cycle_time, status,
    time_trouble, time_trouble_quality, andon
) VALUES (
    NULL, '${line_id}', '${info.pg}', '${info.name}', '${name_product}',
    '${target}', '${actual}', '${loading_time}', '${efficiency}',
    '${delay}', '${cycle_time}', '${status_montiv}', '${time_trouble}',
    '${time_trouble_quality}', '${andon}'
)`.replace(/\s+/g, ' ').trim();

// Gabungkan kedua query dengan pemisah titik koma
msg.topic = `${specificLineQuery}; ${productionDataQuery}`;

return msg;