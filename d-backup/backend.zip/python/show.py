import requests
import json

def fetch_and_show_data(url):
    try:
        # Kirim permintaan GET
        response = requests.get(url)
        response.raise_for_status()  # Akan memunculkan exception jika status code bukan 200

        # Coba parse respons sebagai JSON
        data = response.json()

        # Tampilkan data dengan indentasi agar mudah dibaca
        print("Data dari URL:")
        print(json.dumps(data, indent=2, ensure_ascii=False))

    except requests.exceptions.RequestException as e:
        print(f"Terjadi kesalahan saat memanggil URL: {e}")
    except json.JSONDecodeError:
        print("Respons bukan format JSON yang valid. Tampilkan teks mentah:")
        print(response.text)

if __name__ == "__main__":
    url = "https://script.google.com/macros/s/AKfycbzNimPE58A9i04GXRR-2XeY6Myk0UB1-psu4a3_oCWPVOW8LeUQrt-Xwqmgw4A1O6OLHw/exec"
    fetch_and_show_data(url)



    https://script.google.com/macros/s/AKfycbwCvGJf-E8qAI1zsx1s6ppQbh8iYcvVReJCn-c0CV-PzN0kWWyJSAKoKi-zRxgAtVz1yg/exec