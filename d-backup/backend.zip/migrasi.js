require('dotenv').config();
const mysql = require('mysql2/promise');

// ─────────────────────────────────────────────
//  List of ALL tables to synchronise
// ─────────────────────────────────────────────
// const TABLES = [
//   'balance_shaft_no_1',
//   'balance_shaft_no_2',
//   'cam_cap',
//   'cam_cap_1',
//   'cam_cap_1a',
//   'cam_cap_1b',
//   'cam_cap_1c_d05e',
//   'cam_cap_1c_nr',
//   'cam_cap_2',
//   'cam_cap_3',
//   'cam_cap_4',
//   'cam_housing',
//   'cam_housing_a',
//   'cam_housing_assy',
//   'cam_housing_assy_a',
//   'cam_housing_assy_b',
//   'cam_housing_assy_c_d05e',
//   'cam_housing_assy_c_nr',
//   'cam_housing_b',
//   'cam_housing_c',
//   'cam_housing_d',
//   'cam_housing_e_d05e',
//   'cam_housing_e_nr',
//   'common_rail_1',
//   'common_rail_1_core',
//   'common_rail_1_transit_manhour',
//   'common_rail_2',
//   'common_rail_2_core',
//   'common_rail_2_transit_manhour',
//   'common_rail_3',
//   'common_rail_3_core',
//   'common_rail_3_transit_manhour',
//   'common_rail_4',
//   'common_rail_4_core',
//   'common_rail_4_transit_manhour',
//   'common_rail_5',
//   'common_rail_5_core',
//   'common_rail_5_transit_manhour',
//   'common_rail_6',
//   'common_rail_6_core',
//   'common_rail_6_transit_manhour',
//   'common_rail_7',
//   'common_rail_7_core',
//   'common_rail_7_transit_manhour',
//   'common_rail_8',
//   'common_rail_8_core',
//   'common_rail_8_transit_manhour',
//   'common_rail_9',
//   'common_rail_9_core',
//   'common_rail_9_transit_manhour',
//   'common_rail_10',
//   'common_rail_10_core',
//   'common_rail_10_transit_manhour',
//   'common_rail_11',
//   'common_rail_11_core',
//   'common_rail_11_transit_manhour',
//   'common_rail_12',
//   'common_rail_12_core',
//   'common_rail_12_transit_manhour',
//   'connector',
//   'drive_gear',
//   'hikitori_a',
//   'hikitori_b',
//   'hikitori_c',
//   'hikitori_d',
//   'hikitori_data',
//   'hikitori_e',
//   'hikitori_f',
//   'hikitori_g',
//   'hikitori_h',
//   'housing',
//   'housing_inlet_d13e',
//   'housing_inlet_tr',
//   'housing_inlet_water',
//   'hydraulic_lash_adjuster',
//   'Main_data',
//   'packing_assy_a',
//   'packing_assy_b',
//   'packing_assy_c',
//   'production_data',
//   'production_data_trial',
//   'retainer',
//   'roller_arm_1',
//   'roller_arm_1_a',
//   'roller_arm_1_b',
//   'roller_arm_1_c',
//   'roller_arm_1_d',
//   'roller_arm_1_e',
//   'roller_arm_2',
//   'roller_arm_2_a',
//   'roller_arm_2_b',
//   'roller_arm_2_c',
//   'roller_arm_2_d',
//   'roller_arm_2_e',
//   'spacer_drive_gear',
//   'tb_area_cr1cr2',
//   'tb_energy_snapshot',
//   'tb_kub1_active_power',
//   'tb_kub1_total_kwh',
//   'tb_kub2_63_active_power',
//   'tb_kub2_63_apparent_power',
//   'tb_kub2_63_current',
//   'tb_kub2_63_frequency',
//   'tb_kub2_63_power_factor',
//   'tb_kub2_63_reactive_power',
//   'tb_kub2_63_voltage_ll',
//   'tb_kub2_63_voltage_ln',
//   'tb_kub2_64_active_power',
//   'tb_kub2_64_apparent_power',
//   'tb_kub2_64_current',
//   'tb_kub2_64_frequency',
//   'tb_kub2_64_power_factor',
//   'tb_kub2_64_reactive_power',
//   'tb_kub2_64_voltage_ll',
//   'tb_kub2_64_voltage_ln',
//   'tb_kub2_panel63',
//   'tb_kub2_panel64',
//   'tb_kub_apparent_power',
//   'tb_kub_comp_19',
//   'tb_kub_comp_21',
//   'tb_kub_comp_24',
//   'tb_kub_current',
//   'tb_kub_frequency',
//   'tb_kub_panel_16_ap',
//   'tb_kub_panel_16_wh',
//   'tb_kub_panel_17_ap',
//   'tb_kub_panel_17_wh',
//   'tb_kub_panel_20_ap',
//   'tb_kub_panel_20_wh',
//   'tb_kub_power_factor',
//   'tb_kub_reactive_power',
//   'tb_kub_voltage_ll',
//   'tb_kub_voltage_ln',
//   'tb_lpdmtc',
//   'tb_lpf1',
//   'tb_lpf2',
//   'tb_lpqad',
//   'tb_lpsec',
//   'tb_lputils',
//   'tb_pm200_bs1',
//   'tb_pm200_bs2',
//   'tb_pm200_cc1',
//   'tb_pm200_cc234',
//   'tb_pm200_chab',
//   'tb_pm200_chcd',
//   'tb_pm200_chef',
//   'tb_pm200_chsaa',
//   'tb_pm200_chsab',
//   'tb_pm200_chsac',
//   'tb_pm200_conn',
//   'tb_pm200_cr1',
//   'tb_pm200_cr2',
//   'tb_pm200_cr3',
//   'tb_pm200_cr4',
//   'tb_pm200_cr5',
//   'tb_pm200_cr6',
//   'tb_pm200_cr7',
//   'tb_pm200_cr8',
//   'tb_pm200_cr9',
//   'tb_pm200_cr10',
//   'tb_pm200_cr11',
//   'tb_pm200_cr12',
//   'tb_pm200_ct',
//   'tb_pm200_hla',
//   'tb_pm200_ra',
//   'tb_pm200_ret',
//   'tb_pm200_weng',
//   'tb_pm220_bs1',
//   'tb_pm220_bs2',
//   'tb_pm220_cc1',
//   'tb_pm220_cc234',
//   'tb_pm220_chab',
//   'tb_pm220_chcd',
//   'tb_pm220_chef',
//   'tb_pm220_chsaa',
//   'tb_pm220_chsab',
//   'tb_pm220_chsac',
//   'tb_pm220_conn',
//   'tb_pm220_cr1',
//   'tb_pm220_cr2',
//   'tb_pm220_cr3',
//   'tb_pm220_cr4',
//   'tb_pm220_cr5',
//   'tb_pm220_cr6',
//   'tb_pm220_cr7',
//   'tb_pm220_cr8',
//   'tb_pm220_cr9',
//   'tb_pm220_cr10',
//   'tb_pm220_cr11',
//   'tb_pm220_cr12',
//   'tb_pm220_ct',
//   'tb_pm220_hla',
//   'tb_pm220_lpf3',
//   'tb_pm220_ra',
//   'tb_pm220_ret',
//   'tb_pm_daily_report',
//   'tb_pm_hourly_report',
//   'tb_pm_monthly_kub_report',
//   'tb_pm_monthly_report',
//   'tb_pm_shiftly_kub_report',
//   'tb_pm_shiftly_report',
//   'tb_pm_weekly_report',
//   'tb_realtime_comp_19',
//   'tb_realtime_comp_21',
//   'tb_realtime_comp_24',
//   'users',
// ];











const TABLES = [
  // 'balance_shaft_no_1',
  // 'balance_shaft_no_2',
  // 'cam_cap',
  // 'cam_cap_1',
  // 'cam_cap_1a',
  // 'cam_cap_1b',
  // 'cam_cap_1c_d05e',
  // 'cam_cap_1c_nr',
  // 'cam_cap_2',
  // 'cam_cap_3',
  // 'cam_cap_4',
  // 'cam_housing',
  // 'cam_housing_a',
  // 'cam_housing_assy',
  // 'cam_housing_assy_a',
  // 'cam_housing_assy_b',
  // 'cam_housing_assy_c_d05e',
  // 'cam_housing_assy_c_nr',
  // 'cam_housing_b',
  // 'cam_housing_c',
  // 'cam_housing_d',
  // 'cam_housing_e_d05e',
  // 'cam_housing_e_nr',
  // 'common_rail_1',
  // 'common_rail_1_core',
  // 'common_rail_1_transit_manhour',
  // 'common_rail_2',
  // 'common_rail_2_core',
  // 'common_rail_2_transit_manhour',
  // 'common_rail_3',
  // 'common_rail_3_core',
  // 'common_rail_3_transit_manhour',
  // 'common_rail_4',
  // 'common_rail_4_core',
  // 'common_rail_4_transit_manhour',
  // 'common_rail_5',
  // 'common_rail_5_core',
  // 'common_rail_5_transit_manhour',
  // 'common_rail_6',
  // 'common_rail_6_core',
  // 'common_rail_6_transit_manhour',
  // 'common_rail_7',
  // 'common_rail_7_core',
  // 'common_rail_7_transit_manhour',
  // 'common_rail_8',
  // 'common_rail_8_core',
  // 'common_rail_8_transit_manhour',
  // 'common_rail_9',
  // 'common_rail_9_core',
  // 'common_rail_9_transit_manhour',
  // 'common_rail_10',
  // 'common_rail_10_core',
  // 'common_rail_10_transit_manhour',
  // 'common_rail_11',
  // 'common_rail_11_core',
  // 'common_rail_11_transit_manhour',
  // 'common_rail_12',
  // 'common_rail_12_core',
  // 'common_rail_12_transit_manhour',
  // 'connector',
  // 'drive_gear',
  // 'hikitori_a',
  // 'hikitori_b',
  // 'hikitori_c',
  // 'hikitori_d',
  // 'hikitori_data',
  // 'hikitori_e',
  // 'hikitori_f',
  // 'hikitori_g',
  // 'hikitori_h',
  // 'housing',
  // 'housing_inlet_d13e',
  // 'housing_inlet_tr',
  // 'housing_inlet_water',
  // 'hydraulic_lash_adjuster',
  // 'Main_data',
  // 'packing_assy_a',
  // 'packing_assy_b',
  // 'packing_assy_c',




  // 'production_data',
  // 'production_data_trial',


  // 'retainer',
  // 'roller_arm_1',
  // 'roller_arm_1_a',
  // 'roller_arm_1_b',
  // 'roller_arm_1_c',
  // 'roller_arm_1_d',
  // 'roller_arm_1_e',
  // 'roller_arm_2',
  // 'roller_arm_2_a',
  // 'roller_arm_2_b',
  // 'roller_arm_2_c',
  // 'roller_arm_2_d',
  // 'roller_arm_2_e',
  // 'spacer_drive_gear',



  
  // 'tb_area_cr1cr2',
  // 'tb_energy_snapshot',
  // 'tb_kub1_active_power',




  // 'tb_kub1_total_kwh',
  // 'tb_kub2_63_active_power',
  // 'tb_kub2_63_apparent_power',
  // 'tb_kub2_63_current',
  // 'tb_kub2_63_frequency',
  // 'tb_kub2_63_power_factor',
  // 'tb_kub2_63_reactive_power',
  // 'tb_kub2_63_voltage_ll',
  // 'tb_kub2_63_voltage_ln',
  // 'tb_kub2_64_active_power',
  // 'tb_kub2_64_apparent_power',
  // 'tb_kub2_64_current',
  // 'tb_kub2_64_frequency',
  // 'tb_kub2_64_power_factor',
  // 'tb_kub2_64_reactive_power',
  // 'tb_kub2_64_voltage_ll',
  // 'tb_kub2_64_voltage_ln',
  // 'tb_kub2_panel63',
  // 'tb_kub2_panel64',
  // 'tb_kub_apparent_power',
  // 'tb_kub_comp_19',
  // 'tb_kub_comp_21',
  // 'tb_kub_comp_24',
  // 'tb_kub_current',
  // 'tb_kub_frequency',



  // 'tb_kub_panel_16_ap',
  // 'tb_kub_panel_16_wh',
  // 'tb_kub_panel_17_ap',
  // 'tb_kub_panel_17_wh',
  // 'tb_kub_panel_20_ap',
  // 'tb_kub_panel_20_wh',




  // 'tb_kub_power_factor',
  // 'tb_kub_reactive_power',
  // 'tb_kub_voltage_ll',
  // 'tb_kub_voltage_ln',
  
  
  // 'tb_lpdmtc',
  
  
  // 'tb_lpf1',
  // 'tb_lpf2',
  // 'tb_lpqad',
  // 'tb_lpsec',
  // 'tb_lputils',
  // 'tb_pm200_bs1',
  // 'tb_pm200_bs2',
  // 'tb_pm200_cc1',
  // 'tb_pm200_cc234',
  // 'tb_pm200_chab',
  // 'tb_pm200_chcd',
  // 'tb_pm200_chef',
  // 'tb_pm200_chsaa',
  // 'tb_pm200_chsab',
  // 'tb_pm200_chsac',
  // 'tb_pm200_conn',
  // 'tb_pm200_cr1',
  // 'tb_pm200_cr2',
  // 'tb_pm200_cr3',
  // 'tb_pm200_cr4',
  // 'tb_pm200_cr5',
  // 'tb_pm200_cr6',
  // 'tb_pm200_cr7',
  // 'tb_pm200_cr8',
  // 'tb_pm200_cr9',
  // 'tb_pm200_cr10',
  // 'tb_pm200_cr11',
  // 'tb_pm200_cr12',
  // 'tb_pm200_ct',
  // 'tb_pm200_hla',
  // 'tb_pm200_ra',
  // 'tb_pm200_ret',
  // 'tb_pm200_weng',
  // 'tb_pm220_bs1',
  // 'tb_pm220_bs2',
  // 'tb_pm220_cc1',
  // 'tb_pm220_cc234',
  // 'tb_pm220_chab',
  // 'tb_pm220_chcd',
  // 'tb_pm220_chef',
  // 'tb_pm220_chsaa',
  // 'tb_pm220_chsab',
  // 'tb_pm220_chsac',
  // 'tb_pm220_conn',
  // 'tb_pm220_cr1',
  // 'tb_pm220_cr2',
  // 'tb_pm220_cr3',
  // 'tb_pm220_cr4',
  // 'tb_pm220_cr5',
  // 'tb_pm220_cr6',
  // 'tb_pm220_cr7',
  // 'tb_pm220_cr8',
  // 'tb_pm220_cr9',
  // 'tb_pm220_cr10',
  // 'tb_pm220_cr11',
  // 'tb_pm220_cr12',
  // 'tb_pm220_ct',
  // 'tb_pm220_hla',
  // 'tb_pm220_lpf3',
  // 'tb_pm220_ra',
  // 'tb_pm220_ret',
  // 'tb_pm_daily_report',
  // 'tb_pm_hourly_report',
  // 'tb_pm_monthly_kub_report',
  // 'tb_pm_monthly_report',
  // 'tb_pm_shiftly_kub_report',
  // 'tb_pm_shiftly_report',
  // 'tb_pm_weekly_report',
  // 'tb_realtime_comp_19',
  // 'tb_realtime_comp_21',
  // 'tb_realtime_comp_24',
  // 'users',

  // 'tb_realtime_kubikal',

  // 'tb_kub_active_power',
  'tb_kub2_panel63',
  'tb_kub2_panel64',



];























// ─────────────────────────────────────────────
//  Config: batch size for bulk inserts/updates
// ─────────────────────────────────────────────





const BATCH_SIZE = 500;

// Connection pools
let srcPool, dstPool;

// Summary counters
const summary = { inserts: 0, updates: 0, unchanged: 0, skipped: 0 };

// ─────────────────────────────────────────────
//  Init connection pools
// ─────────────────────────────────────────────
async function init() {
  srcPool = mysql.createPool({
    host: process.env.SRC_HOST,
    user: process.env.SRC_USER,
    password: process.env.SRC_PASS,
    database: process.env.SRC_DB,
    waitForConnections: true,
    connectionLimit: 10,
    enableKeepAlive: true,
  });

  dstPool = mysql.createPool({
    host: process.env.DST_HOST,
    user: process.env.DST_USER,
    password: process.env.DST_PASS,
    database: process.env.DST_DB,
    waitForConnections: true,
    connectionLimit: 10,
    enableKeepAlive: true,
  });
}

// ─────────────────────────────────────────────
//  Get column names for a table from a given pool
// ─────────────────────────────────────────────



async function getColumns(pool, table) {
  const [rows] = await pool.query(`SHOW COLUMNS FROM \`${table}\``);
  return rows.map((col) => col.Field);
}

// ─────────────────────────────────────────────
//  Detect primary key column from a given pool
//  Priority: id_uuid → any PK → first column
// ─────────────────────────────────────────────



async function getPrimaryKey(pool, table) {
  const [rows] = await pool.query(`SHOW KEYS FROM \`${table}\` WHERE Key_name = 'PRIMARY'`);
  if (rows.length > 0) return rows[0].Column_name;
  const cols = await getColumns(pool, table);
  return cols[0];
}



// ─────────────────────────────────────────────
//  Compare two rows; return true if different
// ─────────────────────────────────────────────



function isDifferent(srcRow, dstRow, columnsToCompare) {
  for (const col of columnsToCompare) {
    const srcVal = srcRow[col] ?? null;
    const dstVal = dstRow[col] ?? null;
    // Compare as strings to avoid type mismatches (e.g. Date objects vs strings)
    if (String(srcVal) !== String(dstVal)) return true;
  }
  return false;
}

// ─────────────────────────────────────────────
//  Check if table exists in destination
// ─────────────────────────────────────────────
async function tableExistsInDst(table) {
  const [rows] = await dstPool.query(
    `SELECT COUNT(*) AS cnt FROM information_schema.tables
     WHERE table_schema = DATABASE() AND table_name = ?`,
    [table]
  );
  return rows[0].cnt > 0;
}

// ─────────────────────────────────────────────
//  Sync a single table
// ─────────────────────────────────────────────
async function syncTable(table) {
  process.stdout.write(`\n🔄 [${table}] `);

  // Skip if table doesn't exist in destination
  if (!(await tableExistsInDst(table))) {
    console.log(`⚠️  Table not found in destination — SKIPPED`);
    summary.skipped++;
    return;
  }

  // Get columns from BOTH source and destination, use only the intersection
  const srcColumns = await getColumns(srcPool, table);
  const dstColumns = await getColumns(dstPool, table);
  const dstColSet = new Set(dstColumns);
  const srcColSet = new Set(srcColumns);

  const columns = srcColumns.filter((col) => dstColSet.has(col));

  if (columns.length === 0) {
    console.log(`⚠️  No matching columns between source and destination — SKIPPED`);
    summary.skipped++;
    return;
  }

  // Warn about column mismatches
  const srcOnly = srcColumns.filter((c) => !dstColSet.has(c));
  const dstOnly = dstColumns.filter((c) => !srcColSet.has(c));
  if (srcOnly.length > 0) process.stdout.write(`[src-only cols: ${srcOnly.join(',')}] `);
  if (dstOnly.length > 0) process.stdout.write(`[dst-only cols: ${dstOnly.join(',')}] `);

  // Detect PK: use src PK if it exists in dst, otherwise use dst PK
  const srcPk = await getPrimaryKey(srcPool, table);
  const pkCol = dstColSet.has(srcPk) ? srcPk : await getPrimaryKey(dstPool, table);

  const compareColumns = columns.filter((col) => col !== pkCol);

  // Read ALL source rows (only shared columns)
  const colSelect = columns.map((c) => `\`${c}\``).join(',');
  const [srcRows] = await srcPool.query(`SELECT ${colSelect} FROM \`${table}\``);
  process.stdout.write(`src=${srcRows.length} rows → `);

  if (srcRows.length === 0) {
    console.log('nothing to do.');
    return;
  }

  // Build a map of destination rows keyed by primary key for fast lookup
  const [dstRows] = await dstPool.query(`SELECT ${colSelect} FROM \`${table}\``);
  const dstMap = new Map();
  for (const row of dstRows) {
    dstMap.set(String(row[pkCol]), row);
  }

  // Separate rows into inserts and updates
  const toInsert = [];
  const toUpdate = [];

  for (const srcRow of srcRows) {
    const pkVal = String(srcRow[pkCol]);
    const dstRow = dstMap.get(pkVal);

    if (!dstRow) {
      toInsert.push(srcRow);
    } else if (isDifferent(srcRow, dstRow, compareColumns)) {
      toUpdate.push(srcRow);
    } else {
      summary.unchanged++;
    }
  }

  // ── Bulk INSERT in batches ──
  if (toInsert.length > 0) {
    const colList = columns.map((c) => `\`${c}\``).join(',');
    for (let i = 0; i < toInsert.length; i += BATCH_SIZE) {
      const batch = toInsert.slice(i, i + BATCH_SIZE);
      const placeholders = batch.map(() => `(${columns.map(() => '?').join(',')})`).join(',');
      const values = batch.flatMap((row) => columns.map((col) => row[col] ?? null));
      await dstPool.query(
        `INSERT INTO \`${table}\` (${colList}) VALUES ${placeholders}`,
        values
      );
    }
    summary.inserts += toInsert.length;
  }

  // ── UPDATE row by row (can't batch easily without CASE WHEN) ──
  if (toUpdate.length > 0) {
    const setClause = compareColumns.map((col) => `\`${col}\` = ?`).join(',');
    for (const srcRow of toUpdate) {
      const setValues = compareColumns.map((col) => srcRow[col] ?? null);
      await dstPool.query(
        `UPDATE \`${table}\` SET ${setClause} WHERE \`${pkCol}\` = ?`,
        [...setValues, srcRow[pkCol]]
      );
    }
    summary.updates += toUpdate.length;
  }

  console.log(
    `✅ insert=${toInsert.length} update=${toUpdate.length} unchanged=${srcRows.length - toInsert.length - toUpdate.length}`
  );
}

// ─────────────────────────────────────────────
//  Main
// ─────────────────────────────────────────────
async function runSync() {
  const startTime = Date.now();

  try {
    await init();
    console.log('🚀 Starting synchronisation...');
    console.log(`   Tables  : ${TABLES.length}`);
    console.log(`   Source  : ${process.env.SRC_HOST}/${process.env.SRC_DB}`);
    console.log(`   Dest    : ${process.env.DST_HOST}/${process.env.DST_DB}`);
    console.log(`   Batch   : ${BATCH_SIZE} rows/insert\n`);

    for (const table of TABLES) {
      await syncTable(table);
    }

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log('\n─────────────────────────────────────────');
    console.log('🎉 Synchronisation complete!');
    console.log(`   ⏱  Time     : ${elapsed}s`);
    console.log(`   ➕ Inserts  : ${summary.inserts}`);
    console.log(`   ✏️  Updates  : ${summary.updates}`);
    console.log(`   ✔️  Unchanged: ${summary.unchanged}`);
    console.log(`   ⚠️  Skipped  : ${summary.skipped}`);
    console.log('─────────────────────────────────────────');
  } catch (err) {
    console.error('\n❌ Synchronisation failed:', err);
    process.exit(1);
  } finally {
    if (srcPool) await srcPool.end();
    if (dstPool) await dstPool.end();
  }
}

runSync();