

// REKAP DATA 15 HARI TERBARU


const pool = require("../config/db_core");
const moment = require("moment-timezone");
const cron = require("node-cron");

moment.tz.setDefault("Asia/Jakarta");


const lineTables = [
    // PM 200

    { pm_type: "DA_01", source_table: "tb_kub1_total_kwh", target_table: "tb_kub1_total_kwh_shiftly", line_name: "kubikal_1" },
    
    
    
    
    { pm_type: "PM 200", source_table: "tb_pm200_bs1", target_table: "tb_pm200_bs1_shiftly", line_name: "BS1" },
    { pm_type: "PM 200", source_table: "tb_pm200_bs2", target_table: "tb_pm200_bs2_shiftly", line_name: "BS2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cc1", target_table: "tb_pm200_cc1_shiftly", line_name: "CC1" },
    { pm_type: "PM_200V", source_table: "tb_pm200_cc234", target_table: "tb_pm200_cc234_shiftly", line_name: "CC234" },
    { pm_type: "PM-200V", source_table: "tb_pm200_chab", target_table: "tb_pm200_chab_shiftly", line_name: "CHAB" },
    { pm_type: "PM-3F", source_table: "tb_pm200_chcd", target_table: "tb_pm200_chcd_shiftly", line_name: "CHCD" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chef", target_table: "tb_pm200_chef_shiftly", line_name: "CHEF" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsaa", target_table: "tb_pm200_chsaa_shiftly", line_name: "CHSAA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsac", target_table: "tb_pm200_chsac_shiftly", line_name: "CHSAC" },
    { pm_type: "PM 200", source_table: "tb_pm200_conn", target_table: "tb_pm200_conn_shiftly", line_name: "CONN" },

    { pm_type: "PM 200", source_table: "tb_pm200_cr1", target_table: "tb_pm200_cr1_shiftly", line_name: "CR1" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr2", target_table: "tb_pm200_cr2_shiftly", line_name: "CR2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr3", target_table: "tb_pm200_cr3_shiftly", line_name: "CR3" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr4", target_table: "tb_pm200_cr4_shiftly", line_name: "CR4" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr5", target_table: "tb_pm200_cr5_shiftly", line_name: "CR5" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr6", target_table: "tb_pm200_cr6_shiftly", line_name: "CR6" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr7", target_table: "tb_pm200_cr7_shiftly", line_name: "CR7" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr8", target_table: "tb_pm200_cr8_shiftly", line_name: "CR8" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr9", target_table: "tb_pm200_cr9_shiftly", line_name: "CR9" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr10", target_table: "tb_pm200_cr10_shiftly", line_name: "CR10" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr11", target_table: "tb_pm200_cr11_shiftly", line_name: "CR11" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr12", target_table: "tb_pm200_cr12_shiftly", line_name: "CR12" },

    { pm_type: "PM_200V", source_table: "tb_pm200_ct", target_table: "tb_pm200_ct_shiftly", line_name: "CT" },
    { pm_type: "PM_200V", source_table: "tb_pm200_hla", target_table: "tb_pm200_hla_shiftly", line_name: "HLA" },
    { pm_type: "PM 200", source_table: "tb_pm200_ra", target_table: "tb_pm200_ra_shiftly", line_name: "RA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ret", target_table: "tb_pm200_ret_shiftly", line_name: "RET" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsab", target_table: "tb_pm200_chsab_shiftly", line_name: "CHSAB" },

    // PM 220
    { pm_type: "PM 220", source_table: "tb_pm220_bs1", target_table: "tb_pm220_bs1_shiftly", line_name: "BS1" },
    { pm_type: "PM 220", source_table: "tb_pm220_bs2", target_table: "tb_pm220_bs2_shiftly", line_name: "BS2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cc1", target_table: "tb_pm220_cc1_shiftly", line_name: "CC1" },
    { pm_type: "PM_220V", source_table: "tb_pm220_cc234", target_table: "tb_pm220_cc234_shiftly", line_name: "CC234" },
    { pm_type: "PM-220V", source_table: "tb_pm220_chab", target_table: "tb_pm220_chab_shiftly", line_name: "CHAB" },
    { pm_type: "PM-1F", source_table: "tb_pm220_chcd", target_table: "tb_pm220_chcd_shiftly", line_name: "CHCD" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chef", target_table: "tb_pm220_chef_shiftly", line_name: "CHEF" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsaa", target_table: "tb_pm220_chsaa_shiftly", line_name: "CHSAA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsac", target_table: "tb_pm220_chsac_shiftly", line_name: "CHSAC" },
    { pm_type: "PM 220", source_table: "tb_pm220_conn", target_table: "tb_pm220_conn_shiftly", line_name: "CONN" },

    { pm_type: "PM 220", source_table: "tb_pm220_cr1", target_table: "tb_pm220_cr1_shiftly", line_name: "CR1" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr2", target_table: "tb_pm220_cr2_shiftly", line_name: "CR2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr3", target_table: "tb_pm220_cr3_shiftly", line_name: "CR3" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr4", target_table: "tb_pm220_cr4_shiftly", line_name: "CR4" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr5", target_table: "tb_pm220_cr5_shiftly", line_name: "CR5" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr6", target_table: "tb_pm220_cr6_shiftly", line_name: "CR6" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr7", target_table: "tb_pm220_cr7_shiftly", line_name: "CR7" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr8", target_table: "tb_pm220_cr8_shiftly", line_name: "CR8" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr9", target_table: "tb_pm220_cr9_shiftly", line_name: "CR9" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr10", target_table: "tb_pm220_cr10_shiftly", line_name: "CR10" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr11", target_table: "tb_pm220_cr11_shiftly", line_name: "CR11" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr12", target_table: "tb_pm220_cr12_shiftly", line_name: "CR12" },

    { pm_type: "PM_220V", source_table: "tb_pm220_ct", target_table: "tb_pm220_ct_shiftly", line_name: "CT" },
    { pm_type: "PM 220", source_table: "tb_pm220_hla", target_table: "tb_pm220_hla_shiftly", line_name: "HLA" },
    { pm_type: "PM 220", source_table: "tb_pm220_ra", target_table: "tb_pm220_ra_shiftly", line_name: "RA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ret", target_table: "tb_pm220_ret_shiftly", line_name: "RET" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsab", target_table: "tb_pm220_chsab_shiftly", line_name: "CHSAB" },
];







/**
 * Konfigurasi proses.
 */
const APP_TIMEZONE = "Asia/Jakarta";
const PROCESS_LOCK_NAME = "rekap_shiftly_latest_15";
const REQUIRED_UNIQUE_COLUMNS = ["line_table", "shift_date", "shift"];
const AUTO_CREATE_UNIQUE_KEY = true;
const UNIQUE_INDEX_BASE_NAME = "uq_line_shift_date_shift";

/**
 * Jumlah maksimum data shift valid terbaru yang diperbarui pada setiap tabel.
 * Satu data berarti satu kombinasi: line_table + shift_date + shift.
 */
const LATEST_UPDATE_LIMIT = 15;

/**
 * Jumlah tanggal terakhir yang dipindai dari tabel sumber.
 * Nilai dibuat lebih besar dari batas update agar data kosong atau anomali
 * dapat dilewati tanpa mengurangi peluang memperoleh 15 data valid.
 */
const RECENT_DATE_SCAN_LIMIT = Math.max(LATEST_UPDATE_LIMIT * 3, 30);

/**
 * Pengaman nama tabel agar query dinamis tidak rawan SQL injection.
 */
function escapeIdentifier(identifier) {
    if (!/^[a-zA-Z0-9_]+$/.test(identifier)) {
        throw new Error(`Invalid table name: ${identifier}`);
    }

    return `\`${identifier}\``;
}

/**
 * Format datetime agar aman masuk ke kolom DATETIME MySQL.
 */
function formatDateTime(value) {
    return moment(value).tz(APP_TIMEZONE).format("YYYY-MM-DD HH:mm:ss");
}

/**
 * Cegah dua instance program berjalan bersamaan.
 * Unique key tetap menjadi pengaman utama terhadap duplikasi data.
 */
async function acquireProcessLock(connection) {
    const [rows] = await connection.query(
        "SELECT GET_LOCK(?, 0) AS acquired",
        [PROCESS_LOCK_NAME]
    );

    if (!rows.length || Number(rows[0].acquired) !== 1) {
        throw new Error(
            "Proses rekap shiftly lain masih berjalan. Eksekusi ini dihentikan agar tidak overlap."
        );
    }
}

async function releaseProcessLock(connection) {
    try {
        await connection.query("SELECT RELEASE_LOCK(?)", [PROCESS_LOCK_NAME]);
    } catch (error) {
        console.error("⚠️ Gagal melepas process lock:", error.message);
    }
}

/**
 * Pastikan tabel target tersedia dan memiliki kolom yang dibutuhkan.
 */
async function assertTargetStructure(connection, targetTable) {
    const [tableRows] = await connection.query(`
        SELECT TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
        LIMIT 1
    `, [targetTable]);

    if (!tableRows.length) {
        throw new Error(`Tabel target ${targetTable} tidak ditemukan.`);
    }

    const requiredColumns = [
        "pm_type",
        "line_table",
        "line_name",
        "shift",
        "shift_date",
        "shift_start_datetime",
        "shift_end_datetime",
        "start_kwh",
        "end_kwh",
        "total_kwh",
        "year",
        "month",
        "month_name",
        "day",
        "day_name",
        "created_at",
        "updated_at"
    ];

    const [columnRows] = await connection.query(`
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
    `, [targetTable]);

    const existingColumns = new Set(
        columnRows.map(row => String(row.COLUMN_NAME).toLowerCase())
    );

    const missingColumns = requiredColumns.filter(
        column => !existingColumns.has(column.toLowerCase())
    );

    if (missingColumns.length) {
        throw new Error(
            `Tabel target ${targetTable} belum memiliki kolom: ` +
            missingColumns.join(", ")
        );
    }
}

/**
 * Ambil daftar indeks pada tabel target.
 */
async function getTargetIndexes(connection, targetTable) {
    const [rows] = await connection.query(`
        SELECT
            INDEX_NAME,
            NON_UNIQUE,
            COLUMN_NAME,
            SEQ_IN_INDEX
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
        ORDER BY INDEX_NAME, SEQ_IN_INDEX
    `, [targetTable]);

    const indexes = new Map();

    for (const row of rows) {
        const indexName = String(row.INDEX_NAME);

        if (!indexes.has(indexName)) {
            indexes.set(indexName, {
                name: indexName,
                nonUnique: Number(row.NON_UNIQUE),
                columns: []
            });
        }

        indexes.get(indexName).columns.push(
            String(row.COLUMN_NAME).toLowerCase()
        );
    }

    return [...indexes.values()];
}

/**
 * UNIQUE KEY dianggap sesuai jika memuat tepat tiga kolom yang diwajibkan.
 * Urutan kolom pada indeks tidak dipaksakan.
 */
function hasRequiredUniqueKey(indexes) {
    const required = [...REQUIRED_UNIQUE_COLUMNS]
        .map(column => column.toLowerCase())
        .sort();

    return indexes.some(index => {
        if (index.nonUnique !== 0) {
            return false;
        }

        const columns = [...index.columns].sort();

        return columns.length === required.length &&
            columns.every((column, position) => column === required[position]);
    });
}

/**
 * Cari nama indeks yang belum digunakan pada tabel tersebut.
 */
function buildAvailableIndexName(indexes) {
    const usedNames = new Set(
        indexes.map(index => index.name.toLowerCase())
    );

    if (!usedNames.has(UNIQUE_INDEX_BASE_NAME.toLowerCase())) {
        return UNIQUE_INDEX_BASE_NAME;
    }

    for (let suffix = 2; suffix <= 99; suffix += 1) {
        const candidate = `${UNIQUE_INDEX_BASE_NAME}_${suffix}`;

        if (!usedNames.has(candidate.toLowerCase())) {
            return candidate;
        }
    }

    throw new Error("Tidak dapat menentukan nama UNIQUE KEY yang tersedia.");
}

/**
 * Pastikan tidak ada data ganda sebelum UNIQUE KEY dibuat.
 * Program tidak menghapus data lama secara otomatis.
 */
async function assertNoDuplicateShiftRows(connection, targetTable) {
    const safeTargetTable = escapeIdentifier(targetTable);

    const [duplicateRows] = await connection.query(`
        SELECT
            line_table,
            shift_date,
            shift,
            COUNT(*) AS duplicate_count
        FROM ${safeTargetTable}
        WHERE line_table IS NOT NULL
          AND shift_date IS NOT NULL
          AND shift IS NOT NULL
        GROUP BY line_table, shift_date, shift
        HAVING COUNT(*) > 1
        ORDER BY duplicate_count DESC
        LIMIT 5
    `);

    if (!duplicateRows.length) {
        return;
    }

    const samples = duplicateRows.map(row =>
        `${row.line_table}/${formatDateOnly(row.shift_date)}/${row.shift}` +
        `=${row.duplicate_count} baris`
    ).join("; ");

    throw new Error(
        `UNIQUE KEY tidak dapat dibuat pada ${targetTable} karena masih ada ` +
        `data duplikat. Contoh: ${samples}. Bersihkan duplikat terlebih dahulu.`
    );
}

/**
 * Format tanggal untuk pesan log tanpa terpengaruh tipe data driver MySQL.
 */
function formatDateOnly(value) {
    if (moment.isMoment(value)) {
        return value.format("YYYY-MM-DD");
    }

    const parsed = moment(value);
    return parsed.isValid() ? parsed.format("YYYY-MM-DD") : String(value);
}

/**
 * Pastikan target memiliki UNIQUE KEY (line_table, shift_date, shift).
 * Bila belum ada dan tabel bebas duplikat, indeks dibuat otomatis.
 */
async function ensureTargetUniqueKey(connection, targetTable) {
    await assertTargetStructure(connection, targetTable);

    let indexes = await getTargetIndexes(connection, targetTable);

    if (hasRequiredUniqueKey(indexes)) {
        console.log(
            `🔐 UNIQUE KEY tersedia: ${targetTable} ` +
            `(line_table, shift_date, shift)`
        );
        return;
    }

    if (!AUTO_CREATE_UNIQUE_KEY) {
        throw new Error(
            `Target ${targetTable} belum memiliki UNIQUE KEY ` +
            `(line_table, shift_date, shift).`
        );
    }

    await assertNoDuplicateShiftRows(connection, targetTable);

    const safeTargetTable = escapeIdentifier(targetTable);
    const indexName = buildAvailableIndexName(indexes);
    const safeIndexName = escapeIdentifier(indexName);

    try {
        await connection.query(`
            ALTER TABLE ${safeTargetTable}
            ADD UNIQUE KEY ${safeIndexName} (
                line_table,
                shift_date,
                shift
            )
        `);
    } catch (error) {
        /*
         * Antisipasi race condition jika instance lain membuat indeks
         * pada waktu yang hampir bersamaan.
         */
        indexes = await getTargetIndexes(connection, targetTable);

        if (!hasRequiredUniqueKey(indexes)) {
            throw new Error(
                `Gagal membuat UNIQUE KEY pada ${targetTable}: ${error.message}`
            );
        }
    }

    console.log(
        `🛠️ UNIQUE KEY dibuat otomatis: ${targetTable} ` +
        `(line_table, shift_date, shift)`
    );
}

/**
 * Ambil data awal dan akhir berdasarkan rentang waktu shift.
 */
async function getShiftData(connection, tableName, startTime, endTime) {
    const safeTable = escapeIdentifier(tableName);

    const startTimeString = startTime.format("YYYY-MM-DD HH:mm:ss");
    const endTimeString = endTime.format("YYYY-MM-DD HH:mm:ss");

    const [startRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time ASC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    const [endRow] = await connection.query(`
        SELECT date_time, value
        FROM ${safeTable}
        WHERE date_time >= ?
          AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time DESC
        LIMIT 1
    `, [startTimeString, endTimeString]);

    if (!startRow.length || !endRow.length) {
        return null;
    }

    const startValue = Number(startRow[0].value);
    const endValue = Number(endRow[0].value);

    if (!Number.isFinite(startValue) || !Number.isFinite(endValue)) {
        return null;
    }

    const totalValue = Number((endValue - startValue).toFixed(3));

    /**
     * Abaikan data anomali:
     * - total 0
     * - total negatif
     * - meter reset / nilai turun
     */
    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: formatDateTime(startRow[0].date_time),
        endDatetime: formatDateTime(endRow[0].date_time),
        startValue,
        endValue,
        totalValue
    };
}

/**
 * Insert data baru atau update data yang sudah ada.
 * Tidak melakukan DELETE dan tidak melakukan TRUNCATE.
 */
async function upsertShiftlyToTable(connection, line, data) {
    const safeTargetTable = escapeIdentifier(line.target_table);

    const [result] = await connection.query(`
        INSERT INTO ${safeTargetTable} (
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_name = VALUES(line_name),
            shift_start_datetime = VALUES(shift_start_datetime),
            shift_end_datetime = VALUES(shift_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            year = VALUES(year),
            month = VALUES(month),
            month_name = VALUES(month_name),
            day = VALUES(day),
            day_name = VALUES(day_name),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.shift,
        data.shift_date,
        data.shift_start_datetime,
        data.shift_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh,
        data.year,
        data.month,
        data.month_name,
        data.day,
        data.day_name
    ]);

    let action = "No Change";

    if (result.affectedRows === 1) {
        action = "Insert";
    } else if (result.affectedRows === 2) {
        action = "Update";
    }

    console.log(
        `✅ ${action}: ${line.target_table} | ${data.shift} | ` +
        `${data.shift_date} | ${data.total_kwh} kWh`
    );
}

/**
 * Ambil sejumlah tanggal terbaru yang tersedia dari tabel sumber.
 * Data tidak dibatasi bulan berjalan agar 15 data terakhir tetap dapat
 * diperbarui meskipun melintasi pergantian bulan.
 */
async function getRecentAvailableDates(
    connection,
    sourceTable,
    now,
    maxDates = RECENT_DATE_SCAN_LIMIT
) {
    const safeSourceTable = escapeIdentifier(sourceTable);
    const safeLimit = Number(maxDates);

    if (!Number.isInteger(safeLimit) || safeLimit <= 0) {
        throw new Error(`Batas tanggal tidak valid: ${maxDates}`);
    }

    const [rows] = await connection.query(`
        SELECT DISTINCT
            DATE_FORMAT(date_time, '%Y-%m-%d') AS shift_date
        FROM ${safeSourceTable}
        WHERE date_time <= ?
        ORDER BY shift_date DESC
        LIMIT ${safeLimit}
    `, [now.format("YYYY-MM-DD HH:mm:ss")]);

    return rows.map(row => row.shift_date);
}

/**
 * Bentuk daftar kandidat shift yang sudah selesai, lalu urutkan dari terbaru.
 */
function buildCompletedShiftCandidates(availableDates, now) {
    const candidates = [];

    for (const shiftDate of availableDates) {
        const dateObj = moment.tz(shiftDate, "YYYY-MM-DD", APP_TIMEZONE);

        const dateMetadata = {
            year: Number(dateObj.format("YYYY")),
            month: Number(dateObj.format("M")),
            month_name: dateObj.format("MMMM"),
            day: Number(dateObj.format("D")),
            day_name: dateObj.format("dddd")
        };

        const shift1Start = dateObj.clone().set({
            hour: 7,
            minute: 10,
            second: 0,
            millisecond: 0
        });

        const shift1End = dateObj.clone().set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        const shift2Start = dateObj.clone().set({
            hour: 19,
            minute: 50,
            second: 0,
            millisecond: 0
        });

        const shift2End = dateObj.clone().add(1, "day").set({
            hour: 7,
            minute: 10,
            second: 0,
            millisecond: 0
        });

        if (!now.isBefore(shift1End)) {
            candidates.push({
                shiftName: "shift_1",
                shiftDate,
                shiftStart: shift1Start,
                shiftEnd: shift1End,
                dateMetadata
            });
        }

        if (!now.isBefore(shift2End)) {
            candidates.push({
                shiftName: "shift_2",
                shiftDate,
                shiftStart: shift2Start,
                shiftEnd: shift2End,
                dateMetadata
            });
        }
    }

    return candidates.sort((a, b) => b.shiftEnd.valueOf() - a.shiftEnd.valueOf());
}

/**
 * Proses satu shift hanya jika waktu akhirnya sudah terlewati.
 * Ini mencegah shift hari ini yang belum selesai ikut tersimpan sebagai data parsial.
 */
async function processCompletedShift(
    connection,
    line,
    shiftName,
    shiftDate,
    shiftStart,
    shiftEnd,
    now,
    dateMetadata
) {
    if (now.isBefore(shiftEnd)) {
        console.log(
            `⏭️ Belum selesai: ${line.target_table} | ${shiftName} | ` +
            `${shiftDate} | berakhir ${shiftEnd.format("YYYY-MM-DD HH:mm:ss")}`
        );
        return false;
    }

    const shiftData = await getShiftData(
        connection,
        line.source_table,
        shiftStart,
        shiftEnd
    );

    if (!shiftData) {
        console.log(
            `⚠️ Skip: ${line.target_table} | ${shiftName} | ${shiftDate} | ` +
            `data kosong / 0 / negatif`
        );
        return false;
    }

    await upsertShiftlyToTable(connection, line, {
        shift: shiftName,
        shift_date: shiftDate,
        shift_start_datetime: shiftData.startDatetime,
        shift_end_datetime: shiftData.endDatetime,
        start_kwh: shiftData.startValue,
        end_kwh: shiftData.endValue,
        total_kwh: shiftData.totalValue,
        ...dateMetadata
    });

    return true;
}

/**
 * Proses satu line/tabel untuk maksimal 15 data shift valid terbaru.
 */
async function processLine(connection, line, now) {
    console.log(`
🔍 Proses Shiftly: ${line.source_table} -> ${line.target_table}`);

    await ensureTargetUniqueKey(connection, line.target_table);

    const availableDates = await getRecentAvailableDates(
        connection,
        line.source_table,
        now
    );

    if (!availableDates.length) {
        console.log(
            `⚠️ Tidak ada data pada tabel sumber: ${line.source_table}`
        );
        return;
    }

    const candidates = buildCompletedShiftCandidates(availableDates, now);

    if (!candidates.length) {
        console.log(
            `⚠️ Belum ada shift yang selesai pada tabel sumber: ${line.source_table}`
        );
        return;
    }

    let updatedCount = 0;
    let checkedCount = 0;

    for (const candidate of candidates) {
        if (updatedCount >= LATEST_UPDATE_LIMIT) {
            break;
        }

        checkedCount += 1;

        const updated = await processCompletedShift(
            connection,
            line,
            candidate.shiftName,
            candidate.shiftDate,
            candidate.shiftStart,
            candidate.shiftEnd,
            now,
            candidate.dateMetadata
        );

        if (updated) {
            updatedCount += 1;
        }
    }

    console.log(
        `📊 Ringkasan ${line.target_table}: ${updatedCount} data valid ` +
        `diperbarui dari ${checkedCount} kandidat shift terbaru.`
    );

    if (updatedCount < LATEST_UPDATE_LIMIT) {
        console.log(
            `⚠️ Hanya ditemukan ${updatedCount} data valid. ` +
            `Batas maksimum adalah ${LATEST_UPDATE_LIMIT} data.`
        );
    }
}

/**
 * Program utama.
 */
async function rekapShiftly() {
    const connection = await pool.getConnection();
    let lockAcquired = false;

    const now = moment.tz(APP_TIMEZONE);

    try {
        console.log("🚀 Mulai rekap 15 data shift terbaru...");
        console.log(`🕒 Waktu proses: ${now.format("YYYY-MM-DD HH:mm:ss z")}`);
        console.log(
            `📌 Batas update: maksimal ${LATEST_UPDATE_LIMIT} data valid terbaru per tabel.`
        );
        console.log(
            `🔎 Pemindaian: maksimal ${RECENT_DATE_SCAN_LIMIT} tanggal terbaru per tabel sumber.`
        );
        console.log("🔐 Mode: UPSERT + auto UNIQUE KEY + process lock.");

        await acquireProcessLock(connection);
        lockAcquired = true;

        if (!lineTables.length) {
            throw new Error(
                "Tidak ada mapping tabel aktif pada lineTables. Aktifkan minimal satu tabel."
            );
        }

        const failedLines = [];

        for (const line of lineTables) {
            try {
                await processLine(connection, line, now);
            } catch (lineError) {
                failedLines.push({
                    sourceTable: line.source_table,
                    targetTable: line.target_table,
                    message: lineError.message
                });

                console.error(
                    `❌ Error pada line ${line.source_table} -> ` +
                    `${line.target_table}: ${lineError.message}`
                );
            }
        }

        if (failedLines.length > 0) {
            const failedTableNames = failedLines
                .map(item => item.targetTable)
                .join(", ");

            throw new Error(
                `${failedLines.length} tabel gagal diproses: ${failedTableNames}`
            );
        }

        console.log("\n🎉 Rekap 15 data shift terbaru selesai tanpa error.");
    } catch (err) {
        console.error("❌ Error utama rekap shiftly:", err.message);
        throw err;
    } finally {
        if (lockAcquired) {
            await releaseProcessLock(connection);
        }

        connection.release();
        console.log("🔚 Koneksi database dilepas.");
    }
}

/**
 * Status eksekusi pada level aplikasi.
 * Process lock MySQL tetap menjadi pengaman utama jika ada beberapa instance.
 */
let jobIsRunning = false;
let activeJobPromise = null;
let shuttingDown = false;

/**
 * Jalankan rekap dengan pengaman agar jadwal tidak menimpa proses sebelumnya.
 */
function runRekapJob(trigger = "manual") {
    if (shuttingDown) {
        console.log(
            `⏭️ Trigger ${trigger} diabaikan karena aplikasi sedang dihentikan.`
        );
        return Promise.resolve();
    }

    if (jobIsRunning) {
        console.log(
            `⏭️ Trigger ${trigger} dilewati karena proses rekap sebelumnya masih berjalan.`
        );
        return activeJobPromise || Promise.resolve();
    }

    jobIsRunning = true;

    activeJobPromise = (async () => {
        try {
            console.log("\n============================================================");
            console.log(`⏰ Menjalankan rekap shiftly. Trigger: ${trigger}`);
            console.log(
                `🕒 Waktu trigger: ${moment.tz(APP_TIMEZONE).format(
                    "YYYY-MM-DD HH:mm:ss z"
                )}`
            );
            console.log("============================================================");

            await rekapShiftly();

            console.log(`✅ Rekap shiftly dari trigger ${trigger} selesai.`);
        } catch (error) {
            console.error(
                `❌ Rekap shiftly dari trigger ${trigger} gagal:`,
                error.message
            );
        } finally {
            jobIsRunning = false;
            activeJobPromise = null;
        }
    })();

    return activeJobPromise;
}

/**
 * Jadwal harian pukul 07:30 WIB.
 * Format cron: menit jam tanggal bulan hari
 */
const dailyScheduler = cron.schedule(
    "30 7 * * *",
    () => {
        void runRekapJob("jadwal-harian-07:30");
    },
    {
        timezone: APP_TIMEZONE
    }
);

console.log("🚀 Aplikasi rekap shiftly aktif.");
console.log(
    `📅 Scheduler aktif: setiap hari pukul 07:30 (${APP_TIMEZONE}).`
);
console.log("▶️ Rekap maksimal 15 data shift terbaru akan dijalankan saat startup.");

/**
 * Jalankan satu kali saat aplikasi pertama kali aktif.
 * Tidak memakai process.exit agar scheduler tetap hidup.
 */
void runRekapJob("startup");

/**
 * Hentikan scheduler, tunggu job aktif selesai, lalu tutup pool database.
 */
async function gracefulShutdown(signal) {
    if (shuttingDown) {
        return;
    }

    shuttingDown = true;
    console.log(`\n🛑 Menerima ${signal}. Menghentikan aplikasi...`);

    try {
        dailyScheduler.stop();
        console.log("⏹️ Scheduler dihentikan.");

        const runningJob = activeJobPromise;

        if (runningJob) {
            console.log("⌛ Menunggu proses rekap yang sedang aktif selesai...");
            await runningJob;
        }

        await pool.end();
        console.log("🔚 Pool database ditutup.");
        process.exit(0);
    } catch (error) {
        console.error(
            "❌ Gagal menghentikan aplikasi dengan tertib:",
            error.message
        );
        process.exit(1);
    }
}

process.on("SIGINT", () => {
    void gracefulShutdown("SIGINT");
});

process.on("SIGTERM", () => {
    void gracefulShutdown("SIGTERM");
});

process.on("unhandledRejection", (reason) => {
    console.error("❌ Unhandled promise rejection:", reason);
});

process.on("uncaughtException", (error) => {
    console.error("❌ Uncaught exception:", error);
    void gracefulShutdown("uncaughtException");
});
