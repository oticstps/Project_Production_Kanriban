const pool = require("../config/db_core");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

const lineTables = [
    // PM 200
    { pm_type: "PM 200", source_table: "tb_pm200_bs1", target_table: "tb_pm200_bs1_monthly", line_name: "BS1" },
    { pm_type: "PM 200", source_table: "tb_pm200_bs2", target_table: "tb_pm200_bs2_monthly", line_name: "BS2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cc1", target_table: "tb_pm200_cc1_monthly", line_name: "CC1" },
    { pm_type: "PM_200V", source_table: "tb_pm200_cc234", target_table: "tb_pm200_cc234_monthly", line_name: "CC234" },
    { pm_type: "PM-200V", source_table: "tb_pm200_chab", target_table: "tb_pm200_chab_monthly", line_name: "CHAB" },
    { pm_type: "PM-3F", source_table: "tb_pm200_chcd", target_table: "tb_pm200_chcd_monthly", line_name: "CHCD" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chef", target_table: "tb_pm200_chef_monthly", line_name: "CHEF" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsaa", target_table: "tb_pm200_chsaa_monthly", line_name: "CHSAA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsac", target_table: "tb_pm200_chsac_monthly", line_name: "CHSAC" },
    { pm_type: "PM 200", source_table: "tb_pm200_conn", target_table: "tb_pm200_conn_monthly", line_name: "CONN" },

    { pm_type: "PM 200", source_table: "tb_pm200_cr1", target_table: "tb_pm200_cr1_monthly", line_name: "CR1" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr2", target_table: "tb_pm200_cr2_monthly", line_name: "CR2" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr3", target_table: "tb_pm200_cr3_monthly", line_name: "CR3" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr4", target_table: "tb_pm200_cr4_monthly", line_name: "CR4" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr5", target_table: "tb_pm200_cr5_monthly", line_name: "CR5" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr6", target_table: "tb_pm200_cr6_monthly", line_name: "CR6" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr7", target_table: "tb_pm200_cr7_monthly", line_name: "CR7" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr8", target_table: "tb_pm200_cr8_monthly", line_name: "CR8" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr9", target_table: "tb_pm200_cr9_monthly", line_name: "CR9" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr10", target_table: "tb_pm200_cr10_monthly", line_name: "CR10" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr11", target_table: "tb_pm200_cr11_monthly", line_name: "CR11" },
    { pm_type: "PM 200", source_table: "tb_pm200_cr12", target_table: "tb_pm200_cr12_monthly", line_name: "CR12" },

    { pm_type: "PM_200V", source_table: "tb_pm200_ct", target_table: "tb_pm200_ct_monthly", line_name: "CT" },
    { pm_type: "PM_200V", source_table: "tb_pm200_hla", target_table: "tb_pm200_hla_monthly", line_name: "HLA" },
    { pm_type: "PM 200", source_table: "tb_pm200_ra", target_table: "tb_pm200_ra_monthly", line_name: "RA" },
    { pm_type: "PM_200V", source_table: "tb_pm200_ret", target_table: "tb_pm200_ret_monthly", line_name: "RET" },
    { pm_type: "PM_200V", source_table: "tb_pm200_chsab", target_table: "tb_pm200_chsab_monthly", line_name: "CHSAB" },

    // PM 220
    { pm_type: "PM 220", source_table: "tb_pm220_bs1", target_table: "tb_pm220_bs1_monthly", line_name: "BS1" },
    { pm_type: "PM 220", source_table: "tb_pm220_bs2", target_table: "tb_pm220_bs2_monthly", line_name: "BS2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cc1", target_table: "tb_pm220_cc1_monthly", line_name: "CC1" },
    { pm_type: "PM_220V", source_table: "tb_pm220_cc234", target_table: "tb_pm220_cc234_monthly", line_name: "CC234" },
    { pm_type: "PM-220V", source_table: "tb_pm220_chab", target_table: "tb_pm220_chab_monthly", line_name: "CHAB" },
    { pm_type: "PM-1F", source_table: "tb_pm220_chcd", target_table: "tb_pm220_chcd_monthly", line_name: "CHCD" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chef", target_table: "tb_pm220_chef_monthly", line_name: "CHEF" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsaa", target_table: "tb_pm220_chsaa_monthly", line_name: "CHSAA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsac", target_table: "tb_pm220_chsac_monthly", line_name: "CHSAC" },
    { pm_type: "PM 220", source_table: "tb_pm220_conn", target_table: "tb_pm220_conn_monthly", line_name: "CONN" },

    { pm_type: "PM 220", source_table: "tb_pm220_cr1", target_table: "tb_pm220_cr1_monthly", line_name: "CR1" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr2", target_table: "tb_pm220_cr2_monthly", line_name: "CR2" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr3", target_table: "tb_pm220_cr3_monthly", line_name: "CR3" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr4", target_table: "tb_pm220_cr4_monthly", line_name: "CR4" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr5", target_table: "tb_pm220_cr5_monthly", line_name: "CR5" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr6", target_table: "tb_pm220_cr6_monthly", line_name: "CR6" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr7", target_table: "tb_pm220_cr7_monthly", line_name: "CR7" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr8", target_table: "tb_pm220_cr8_monthly", line_name: "CR8" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr9", target_table: "tb_pm220_cr9_monthly", line_name: "CR9" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr10", target_table: "tb_pm220_cr10_monthly", line_name: "CR10" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr11", target_table: "tb_pm220_cr11_monthly", line_name: "CR11" },
    { pm_type: "PM 220", source_table: "tb_pm220_cr12", target_table: "tb_pm220_cr12_monthly", line_name: "CR12" },

    { pm_type: "PM_220V", source_table: "tb_pm220_ct", target_table: "tb_pm220_ct_monthly", line_name: "CT" },
    { pm_type: "PM 220", source_table: "tb_pm220_hla", target_table: "tb_pm220_hla_monthly", line_name: "HLA" },
    { pm_type: "PM 220", source_table: "tb_pm220_ra", target_table: "tb_pm220_ra_monthly", line_name: "RA" },
    { pm_type: "PM_220V", source_table: "tb_pm220_ret", target_table: "tb_pm220_ret_monthly", line_name: "RET" },
    { pm_type: "PM_220V", source_table: "tb_pm220_chsab", target_table: "tb_pm220_chsab_monthly", line_name: "CHSAB" },
];


const TIMEZONE = "Asia/Jakarta";
const DATE_TIME_FORMAT = "YYYY-MM-DD HH:mm:ss";
const JOB_LOCK_NAME = "rekap_monthly_cron_job";
const IDENTIFIER_PATTERN = /^[A-Za-z0-9_]+$/;

moment.tz.setDefault(TIMEZONE);

function validateIdentifier(identifier, fieldName) {
    if (!IDENTIFIER_PATTERN.test(identifier)) {
        throw new Error(`${fieldName} tidak valid: ${identifier}`);
    }
}

function validateConfiguration() {
    if (!Array.isArray(lineTables) || lineTables.length === 0) {
        throw new Error("Tidak ada line aktif di dalam lineTables.");
    }

    for (const line of lineTables) {
        validateIdentifier(line.source_table, "source_table");
        validateIdentifier(line.target_table, "target_table");
    }
}

async function getMonthlyData(connection, tableName, startTime, endTime) {
    const params = [
        startTime.format(DATE_TIME_FORMAT),
        endTime.format(DATE_TIME_FORMAT)
    ];

    const [startRows] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time ASC
        LIMIT 1
    `, params);

    const [endRows] = await connection.query(`
        SELECT date_time, value
        FROM ${tableName}
        WHERE date_time >= ? AND date_time < ?
          AND value IS NOT NULL
        ORDER BY date_time DESC
        LIMIT 1
    `, params);

    if (!startRows.length || !endRows.length) {
        return null;
    }

    const startValue = Number.parseFloat(startRows[0].value);
    const endValue = Number.parseFloat(endRows[0].value);

    if (!Number.isFinite(startValue) || !Number.isFinite(endValue)) {
        return null;
    }

    const totalValue = endValue - startValue;

    if (totalValue <= 0) {
        return null;
    }

    return {
        startDatetime: startRows[0].date_time,
        endDatetime: endRows[0].date_time,
        startValue,
        endValue,
        totalValue
    };
}

async function upsertMonthlyToTable(connection, line, data) {
    await connection.query(`
        INSERT INTO ${line.target_table} (
            pm_type,
            line_table,
            line_name,
            year,
            month,
            month_name,
            month_start_date,
            month_end_date,
            month_start_datetime,
            month_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            pm_type = VALUES(pm_type),
            line_name = VALUES(line_name),
            month_name = VALUES(month_name),
            month_start_date = VALUES(month_start_date),
            month_end_date = VALUES(month_end_date),
            month_start_datetime = VALUES(month_start_datetime),
            month_end_datetime = VALUES(month_end_datetime),
            start_kwh = VALUES(start_kwh),
            end_kwh = VALUES(end_kwh),
            total_kwh = VALUES(total_kwh),
            updated_at = NOW()
    `, [
        line.pm_type,
        line.source_table,
        line.line_name,
        data.year,
        data.month,
        data.month_name,
        data.month_start_date,
        data.month_end_date,
        data.month_start_datetime,
        data.month_end_datetime,
        data.start_kwh,
        data.end_kwh,
        data.total_kwh
    ]);

    console.log(
        `✅ Upsert Monthly: ${line.target_table} | ${data.year}-${String(data.month).padStart(2, "0")} | ${data.total_kwh} kWh`
    );
}

async function acquireJobLock(connection) {
    const [rows] = await connection.query(
        "SELECT GET_LOCK(?, 0) AS acquired",
        [JOB_LOCK_NAME]
    );

    return Number(rows[0]?.acquired) === 1;
}

async function releaseJobLock(connection) {
    try {
        await connection.query("SELECT RELEASE_LOCK(?) AS released", [JOB_LOCK_NAME]);
    } catch (error) {
        console.error("⚠️ Gagal melepas job lock:", error.message);
    }
}

async function rekapMonthly() {
    validateConfiguration();

    const connection = await pool.getConnection();
    let lockAcquired = false;
    let successCount = 0;
    let skippedCount = 0;

    try {
        lockAcquired = await acquireJobLock(connection);

        if (!lockAcquired) {
            console.log("⚠️ Proses rekap monthly sebelumnya masih berjalan. Eksekusi cron ini dilewati.");
            return;
        }

        console.log(
            `🚀 Rekap monthly dimulai: ${moment.tz(TIMEZONE).format("YYYY-MM-DD HH:mm:ss z")}`
        );

        for (const line of lineTables) {
            console.log(`\n🔍 Proses Monthly: ${line.source_table} -> ${line.target_table}`);

            const [months] = await connection.query(`
                SELECT DISTINCT
                    YEAR(date_time) AS year_num,
                    MONTH(date_time) AS month_num
                FROM ${line.source_table}
                WHERE date_time IS NOT NULL
                ORDER BY year_num, month_num
            `);

            if (months.length === 0) {
                console.log(`⚠️ Tidak ada data bulan pada ${line.source_table}.`);
                continue;
            }

            for (const { year_num, month_num } of months) {
                const year = Number(year_num);
                const month = Number(month_num);
                const monthLabel = `${year}-${String(month).padStart(2, "0")}`;
                const monthStart = moment.tz(
                    `${monthLabel}-01 00:00:00`,
                    DATE_TIME_FORMAT,
                    TIMEZONE
                );
                const monthEnd = monthStart.clone().add(1, "month");

                const data = await getMonthlyData(
                    connection,
                    line.source_table,
                    monthStart,
                    monthEnd
                );

                if (!data) {
                    skippedCount += 1;
                    console.log(
                        `⚠️ Skip Monthly: ${line.target_table} | ${monthLabel} | data kosong, tidak valid, nol, atau negatif`
                    );
                    continue;
                }

                await upsertMonthlyToTable(connection, line, {
                    year,
                    month,
                    month_name: monthStart.format("MMMM"),
                    month_start_date: monthStart.format("YYYY-MM-DD"),
                    month_end_date: monthEnd.clone().subtract(1, "day").format("YYYY-MM-DD"),
                    month_start_datetime: data.startDatetime,
                    month_end_datetime: data.endDatetime,
                    start_kwh: data.startValue,
                    end_kwh: data.endValue,
                    total_kwh: data.totalValue
                });

                successCount += 1;
            }
        }

        console.log("\n🎉 Rekap monthly selesai.");
        console.log(`✅ Berhasil di-upsert: ${successCount}`);
        console.log(`⚠️ Dilewati: ${skippedCount}`);
        console.log(
            `🕒 Waktu selesai: ${moment.tz(TIMEZONE).format("YYYY-MM-DD HH:mm:ss z")}`
        );
    } finally {
        if (lockAcquired) {
            await releaseJobLock(connection);
        }

        connection.release();
    }
}

async function closePool() {
    if (typeof pool.end === "function") {
        await pool.end();
    }
}

async function main() {
    try {
        await rekapMonthly();
        process.exitCode = 0;
    } catch (error) {
        console.error("❌ Error rekap monthly:", error);
        process.exitCode = 1;
    } finally {
        try {
            await closePool();
        } catch (error) {
            console.error("⚠️ Gagal menutup pool database:", error.message);
            process.exitCode = 1;
        }
    }
}

main();
