- monitoring start - stop kondisi genba

name tabel : tb_monitoring_manhour_plant_1



struktur nya :


idPrimary INT PRIMARY KEY AUTO_INCREMENT,
status_cr1_start
date_time_cr1_start
status_cr1_stop
date_time_cr1_stop
status_cr2_start
date_time_cr2_start
status_cr2_stop
date_time_cr2_stop
status_cr3_start
date_time_cr3_start
status_cr3_stop
date_time_cr3_stop
status_cr4_start
date_time_cr4_start
cr4_stop
date_time_cr4_stop
cr5_start
date_time_cr5_start
cr5_stop
date_time_cr5_stop
cr6_start
date_time_cr6_start
cr6_stop
date_time_cr6_stop
cr7_start
date_time_cr7_start
cr7_stop
date_time_cr7_stop
cr8_start
date_time_cr8_start
cr8_stop
date_time_cr8_stop
cr9_start
date_time_cr9_start
cr9_stop
date_time_cr9_stop
cr10_start
date_time_cr10_start
cr10_stop
date_time_cr10_stop
cr11_start
date_time_cr11_start
cr11_stop
date_time_cr11_stop
cr12_start
date_time_cr12_start
cr12_stop
date_time_cr12_stop

