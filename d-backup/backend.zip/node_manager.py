import os
import json
import uuid
import signal
import queue
import threading
import subprocess
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText


CONFIG_FILE = "node_projects.json"


class NodeManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Node.js Program Manager")
        self.root.geometry("1200x700")

        self.projects = []
        self.processes = {}
        self.run_tokens = {}
        self.logs = {}
        self.log_queue = queue.Queue()
        self.selected_project_id = None

        self.load_projects()
        self.build_ui()
        self.refresh_tree()
        self.poll_log_queue()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    # =========================
    # DATA
    # =========================

    def load_projects(self):
        if not os.path.exists(CONFIG_FILE):
            self.projects = []
            return

        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                self.projects = json.load(f)
        except Exception:
            self.projects = []

    def save_projects(self):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(self.projects, f, indent=4, ensure_ascii=False)

    def get_project(self, project_id):
        for project in self.projects:
            if project["id"] == project_id:
                return project
        return None

    def get_status(self, project_id):
        proc = self.processes.get(project_id)

        if proc is None:
            return "STOPPED"

        if proc.poll() is None:
            return "RUNNING"

        return "STOPPED"

    # =========================
    # UI
    # =========================

    def build_ui(self):
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill="both", expand=True)

        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side="left", fill="both", expand=True)

        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side="right", fill="both", expand=True, padx=(10, 0))

        # Tree project
        tree_label = ttk.Label(left_frame, text="Daftar Program Node.js")
        tree_label.pack(anchor="w")

        columns = ("name", "status", "command", "path")
        self.tree = ttk.Treeview(
            left_frame,
            columns=columns,
            show="headings",
            height=18
        )

        self.tree.heading("name", text="Nama")
        self.tree.heading("status", text="Status")
        self.tree.heading("command", text="Command")
        self.tree.heading("path", text="Folder")

        self.tree.column("name", width=180)
        self.tree.column("status", width=90)
        self.tree.column("command", width=180)
        self.tree.column("path", width=300)

        self.tree.pack(fill="both", expand=True, pady=(5, 5))
        self.tree.bind("<<TreeviewSelect>>", self.on_select_project)

        # Tombol kontrol proses
        control_frame = ttk.Frame(left_frame)
        control_frame.pack(fill="x", pady=5)

        ttk.Button(control_frame, text="Start", command=self.start_selected).pack(side="left", padx=2)
        ttk.Button(control_frame, text="Stop", command=self.stop_selected).pack(side="left", padx=2)
        ttk.Button(control_frame, text="Restart", command=self.restart_selected).pack(side="left", padx=2)
        ttk.Button(control_frame, text="Start All", command=self.start_all).pack(side="left", padx=2)
        ttk.Button(control_frame, text="Stop All", command=self.stop_all).pack(side="left", padx=2)

        # Form project
        form_label = ttk.Label(right_frame, text="Detail Program")
        form_label.pack(anchor="w")

        form_frame = ttk.Frame(right_frame)
        form_frame.pack(fill="x", pady=(5, 10))

        ttk.Label(form_frame, text="Nama Program").grid(row=0, column=0, sticky="w", pady=3)
        self.name_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.name_var).grid(row=0, column=1, sticky="ew", pady=3)

        ttk.Label(form_frame, text="Folder Project").grid(row=1, column=0, sticky="w", pady=3)
        self.path_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.path_var).grid(row=1, column=1, sticky="ew", pady=3)
        ttk.Button(form_frame, text="Browse", command=self.browse_folder).grid(row=1, column=2, padx=5)

        ttk.Label(form_frame, text="Command").grid(row=2, column=0, sticky="w", pady=3)
        self.command_var = tk.StringVar(value="npm start")
        ttk.Entry(form_frame, textvariable=self.command_var).grid(row=2, column=1, sticky="ew", pady=3)

        form_frame.columnconfigure(1, weight=1)

        form_button_frame = ttk.Frame(right_frame)
        form_button_frame.pack(fill="x", pady=(0, 10))

        ttk.Button(form_button_frame, text="Project Baru", command=self.new_project).pack(side="left", padx=2)
        ttk.Button(form_button_frame, text="Simpan", command=self.save_project_form).pack(side="left", padx=2)
        ttk.Button(form_button_frame, text="Hapus", command=self.delete_selected).pack(side="left", padx=2)
        ttk.Button(form_button_frame, text="Clear Log", command=self.clear_current_log).pack(side="left", padx=2)

        # Log
        log_label = ttk.Label(right_frame, text="Log Output")
        log_label.pack(anchor="w")

        self.log_text = ScrolledText(right_frame, height=25, wrap="word")
        self.log_text.pack(fill="both", expand=True)

        hint = (
            "Contoh command:\n"
            "- npm start\n"
            "- npm run dev\n"
            "- node app.js\n"
            "- node server.js\n"
            "- npx nodemon index.js\n"
        )
        self.log_text.insert("end", hint)

    def refresh_tree(self):
        selected = self.selected_project_id

        for item in self.tree.get_children():
            self.tree.delete(item)

        for project in self.projects:
            project_id = project["id"]
            status = self.get_status(project_id)

            self.tree.insert(
                "",
                "end",
                iid=project_id,
                values=(
                    project.get("name", ""),
                    status,
                    project.get("command", ""),
                    project.get("path", "")
                )
            )

        if selected and self.tree.exists(selected):
            self.tree.selection_set(selected)

    def on_select_project(self, event=None):
        selected = self.tree.selection()
        if not selected:
            return

        project_id = selected[0]
        project = self.get_project(project_id)

        if not project:
            return

        self.selected_project_id = project_id

        self.name_var.set(project.get("name", ""))
        self.path_var.set(project.get("path", ""))
        self.command_var.set(project.get("command", "npm start"))

        self.show_project_log(project_id)

    def show_project_log(self, project_id):
        self.log_text.delete("1.0", "end")

        log_lines = self.logs.get(project_id, [])

        if not log_lines:
            self.log_text.insert("end", "Belum ada log untuk program ini.\n")
            return

        self.log_text.insert("end", "\n".join(log_lines) + "\n")
        self.log_text.see("end")

    def browse_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.path_var.set(folder)

    def new_project(self):
        self.selected_project_id = None
        self.tree.selection_remove(self.tree.selection())

        self.name_var.set("")
        self.path_var.set("")
        self.command_var.set("npm start")

        self.log_text.delete("1.0", "end")
        self.log_text.insert("end", "Isi data program baru, lalu klik Simpan.\n")

    def save_project_form(self):
        name = self.name_var.get().strip()
        path = self.path_var.get().strip()
        command = self.command_var.get().strip()

        if not name:
            messagebox.showwarning("Validasi", "Nama program belum diisi.")
            return

        if not path:
            messagebox.showwarning("Validasi", "Folder project belum dipilih.")
            return

        if not os.path.isdir(path):
            messagebox.showwarning("Validasi", "Folder project tidak ditemukan.")
            return

        if not command:
            messagebox.showwarning("Validasi", "Command belum diisi.")
            return

        if self.selected_project_id:
            project = self.get_project(self.selected_project_id)
            if project:
                project["name"] = name
                project["path"] = path
                project["command"] = command
        else:
            project_id = str(uuid.uuid4())
            self.projects.append({
                "id": project_id,
                "name": name,
                "path": path,
                "command": command
            })
            self.selected_project_id = project_id

        self.save_projects()
        self.refresh_tree()
        messagebox.showinfo("Berhasil", "Data program berhasil disimpan.")

    def delete_selected(self):
        project_id = self.selected_project_id

        if not project_id:
            messagebox.showwarning("Peringatan", "Pilih program yang ingin dihapus.")
            return

        project = self.get_project(project_id)
        if not project:
            return

        if self.get_status(project_id) == "RUNNING":
            messagebox.showwarning("Peringatan", "Stop program terlebih dahulu sebelum menghapus.")
            return

        confirm = messagebox.askyesno(
            "Konfirmasi",
            f"Hapus program '{project.get('name')}' dari daftar?"
        )

        if not confirm:
            return

        self.projects = [p for p in self.projects if p["id"] != project_id]
        self.logs.pop(project_id, None)
        self.selected_project_id = None

        self.save_projects()
        self.refresh_tree()
        self.new_project()

    # =========================
    # PROCESS MANAGEMENT
    # =========================

    def start_selected(self):
        if not self.selected_project_id:
            messagebox.showwarning("Peringatan", "Pilih program terlebih dahulu.")
            return

        self.start_project(self.selected_project_id)

    def stop_selected(self):
        if not self.selected_project_id:
            messagebox.showwarning("Peringatan", "Pilih program terlebih dahulu.")
            return

        self.stop_project(self.selected_project_id)

    def restart_selected(self):
        if not self.selected_project_id:
            messagebox.showwarning("Peringatan", "Pilih program terlebih dahulu.")
            return

        self.restart_project(self.selected_project_id)

    def start_all(self):
        for project in self.projects:
            self.start_project(project["id"])

    def stop_all(self):
        for project_id in list(self.processes.keys()):
            self.stop_project(project_id)

    def restart_project(self, project_id):
        self.stop_project(project_id)
        self.root.after(800, lambda: self.start_project(project_id))

    def start_project(self, project_id):
        project = self.get_project(project_id)

        if not project:
            return

        current_proc = self.processes.get(project_id)
        if current_proc and current_proc.poll() is None:
            self.add_log(project_id, "[INFO] Program sudah berjalan.")
            return

        path = project.get("path", "")
        command = project.get("command", "")

        if not os.path.isdir(path):
            messagebox.showerror("Error", f"Folder tidak ditemukan:\n{path}")
            return

        token = str(uuid.uuid4())
        self.run_tokens[project_id] = token

        try:
            if os.name == "nt":
                creationflags = subprocess.CREATE_NEW_PROCESS_GROUP
                proc = subprocess.Popen(
                    command,
                    cwd=path,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    shell=True,
                    text=True,
                    bufsize=1,
                    creationflags=creationflags
                )
            else:
                proc = subprocess.Popen(
                    command,
                    cwd=path,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    stdin=subprocess.DEVNULL,
                    shell=True,
                    text=True,
                    bufsize=1,
                    preexec_fn=os.setsid
                )

            self.processes[project_id] = proc

            self.add_log(project_id, f"[START] {self.timestamp()} | Command: {command}")
            self.add_log(project_id, f"[PID] {proc.pid}")

            thread = threading.Thread(
                target=self.read_process_output,
                args=(project_id, token, proc),
                daemon=True
            )
            thread.start()

            self.refresh_tree()

        except Exception as e:
            self.add_log(project_id, f"[ERROR] Gagal menjalankan program: {e}")
            messagebox.showerror("Error", f"Gagal menjalankan program:\n{e}")

    def stop_project(self, project_id):
        proc = self.processes.get(project_id)

        if not proc or proc.poll() is not None:
            self.add_log(project_id, "[INFO] Program tidak sedang berjalan.")
            self.refresh_tree()
            return

        self.add_log(project_id, f"[STOP] {self.timestamp()} | Menghentikan proses...")

        try:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            else:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)

        except Exception:
            try:
                proc.terminate()
            except Exception as e:
                self.add_log(project_id, f"[ERROR] Gagal menghentikan proses: {e}")

        self.refresh_tree()

    def read_process_output(self, project_id, token, proc):
        try:
            if proc.stdout:
                for line in proc.stdout:
                    line = line.rstrip("\n")
                    self.log_queue.put(("log", project_id, token, line))

            return_code = proc.wait()
            self.log_queue.put(("exit", project_id, token, return_code))

        except Exception as e:
            self.log_queue.put(("log", project_id, token, f"[ERROR] {e}"))

    # =========================
    # LOG
    # =========================

    def poll_log_queue(self):
        try:
            while True:
                item = self.log_queue.get_nowait()

                event_type = item[0]

                if event_type == "log":
                    _, project_id, token, text = item
                    if self.run_tokens.get(project_id) == token:
                        self.add_log(project_id, text, from_queue=True)

                elif event_type == "exit":
                    _, project_id, token, return_code = item

                    if self.run_tokens.get(project_id) == token:
                        self.add_log(
                            project_id,
                            f"[EXIT] {self.timestamp()} | Process selesai. Return code: {return_code}",
                            from_queue=True
                        )

                        proc = self.processes.get(project_id)
                        if proc and proc.poll() is not None:
                            self.processes.pop(project_id, None)

                        self.refresh_tree()

        except queue.Empty:
            pass

        self.root.after(150, self.poll_log_queue)

    def add_log(self, project_id, text, from_queue=False):
        if not project_id:
            return

        if project_id not in self.logs:
            self.logs[project_id] = []

        self.logs[project_id].append(text)

        # Batasi log agar aplikasi tetap ringan
        if len(self.logs[project_id]) > 2000:
            self.logs[project_id] = self.logs[project_id][-2000:]

        if self.selected_project_id == project_id:
            self.log_text.insert("end", text + "\n")
            self.log_text.see("end")

    def clear_current_log(self):
        if not self.selected_project_id:
            return

        self.logs[self.selected_project_id] = []
        self.log_text.delete("1.0", "end")
        self.log_text.insert("end", "Log dibersihkan.\n")

    def timestamp(self):
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # =========================
    # CLOSE
    # =========================

    def on_close(self):
        running = [
            p for p in self.projects
            if self.get_status(p["id"]) == "RUNNING"
        ]

        if running:
            confirm = messagebox.askyesno(
                "Konfirmasi Keluar",
                "Masih ada program Node.js yang berjalan.\nStop semua proses dan keluar?"
            )

            if not confirm:
                return

            self.stop_all()

        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = NodeManagerApp(root)
    root.mainloop()