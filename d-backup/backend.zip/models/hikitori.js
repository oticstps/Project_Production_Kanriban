const db = require('../config/db_core');

const hikitori = {
  // Ambil data dengan filter opsional
  async getAll(filters = {}) {
    let sql = 'SELECT * FROM hikitori_data WHERE 1=1';
    const params = [];

    if (filters.name_hikitori) {
      sql += ' AND name_hikitori = ?';
      params.push(filters.name_hikitori);
    }
    if (filters.status) {
      sql += ' AND status = ?';
      params.push(filters.status);
    }
    if (filters.startDate) {
      sql += ' AND DATE(date_time) >= ?';
      params.push(filters.startDate);
    }
    if (filters.endDate) {
      sql += ' AND DATE(date_time) <= ?';
      params.push(filters.endDate);
    }

    sql += ' ORDER BY id DESC LIMIT 100'; // batasi untuk performa
    const [rows] = await db.query(sql, params);
    return rows;
  },

  // Ringkasan statistik
  async getSummary(filters = {}) {
    let sql = `
      SELECT 
        COUNT(*) AS total_trips,
        SUM(CASE WHEN status = 'ABNORMAL' THEN 1 ELSE 0 END) AS abnormal_count,
        AVG(
          CAST(SUBSTRING_INDEX(loading_time, ':', 1) AS UNSIGNED) * 60 +
          CAST(SUBSTRING_INDEX(loading_time, ':', -1) AS UNSIGNED)
        ) AS avg_loading_seconds,
        SUM(CAST(cycle_normal AS UNSIGNED)) AS total_cycles
      FROM hikitori_data
      WHERE 1=1
    `;
    const params = [];

    if (filters.name_hikitori) {
      sql += ' AND name_hikitori = ?';
      params.push(filters.name_hikitori);
    }
    if (filters.startDate) {
      sql += ' AND DATE(date_time) >= ?';
      params.push(filters.startDate);
    }
    if (filters.endDate) {
      sql += ' AND DATE(date_time) <= ?';
      params.push(filters.endDate);
    }

    const [rows] = await db.query(sql, params);
    const summary = rows[0];

    // Konversi detik rata-rata ke format mm:dd
    if (summary.avg_loading_seconds) {
      const minutes = Math.floor(summary.avg_loading_seconds / 60);
      const seconds = Math.round(summary.avg_loading_seconds % 60);
      summary.avg_loading_time = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    } else {
      summary.avg_loading_time = '0:00';
    }
    return summary;
  }
};

module.exports = hikitori;