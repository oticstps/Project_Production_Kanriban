const db = require('../config/db_core');
const { WEEKLY_TABLES } = require('../constants/reportTables');
const validateTable = require('../helpers/validateTable');

const WeeklyReportModel = {
    getAll: async (tableName, limit = 500) => {
        validateTable(tableName, WEEKLY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName} ORDER BY year DESC, week DESC LIMIT ?`,
            [limit]
        );
        return rows;
    },

    getByComposite: async (tableName, pm_type, line_table, year, week) => {
        validateTable(tableName, WEEKLY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE pm_type = ? AND line_table = ? AND year = ? AND week = ?`,
            [pm_type, line_table, year, week]
        );
        return rows[0];
    },

    create: async (tableName, data) => {
        validateTable(tableName, WEEKLY_TABLES);

        const {
            pm_type, line_table, line_name, week,
            week_start_date, week_end_date,
            week_start_datetime, week_end_datetime,
            start_kwh, end_kwh, total_kwh,
            year, month, month_name
        } = data;

        await db.execute(
            `INSERT INTO ${tableName}
            (pm_type, line_table, line_name, week,
             week_start_date, week_end_date,
             week_start_datetime, week_end_datetime,
             start_kwh, end_kwh, total_kwh,
             year, month, month_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [
                pm_type, line_table, line_name, week,
                week_start_date, week_end_date,
                week_start_datetime, week_end_datetime,
                start_kwh, end_kwh, total_kwh,
                year, month, month_name
            ]
        );

        return { pm_type, line_table, year, week };
    },

    update: async (tableName, pm_type, line_table, year, week, data) => {
        validateTable(tableName, WEEKLY_TABLES);

        const {
            line_name, week_start_date, week_end_date,
            week_start_datetime, week_end_datetime,
            start_kwh, end_kwh, total_kwh,
            month, month_name
        } = data;

        const [result] = await db.execute(
            `UPDATE ${tableName}
             SET line_name = ?, week_start_date = ?, week_end_date = ?,
                 week_start_datetime = ?, week_end_datetime = ?,
                 start_kwh = ?, end_kwh = ?, total_kwh = ?,
                 month = ?, month_name = ?, updated_at = NOW()
             WHERE pm_type = ? AND line_table = ? AND year = ? AND week = ?`,
            [
                line_name, week_start_date, week_end_date,
                week_start_datetime, week_end_datetime,
                start_kwh, end_kwh, total_kwh,
                month, month_name,
                pm_type, line_table, year, week
            ]
        );

        return result.affectedRows;
    },

    delete: async (tableName, pm_type, line_table, year, week) => {
        validateTable(tableName, WEEKLY_TABLES);
        const [result] = await db.execute(
            `DELETE FROM ${tableName}
             WHERE pm_type = ? AND line_table = ? AND year = ? AND week = ?`,
            [pm_type, line_table, year, week]
        );
        return result.affectedRows;
    },

    getByYear: async (tableName, year) => {
        validateTable(tableName, WEEKLY_TABLES);
        const [rows] = await db.execute(
            `SELECT * FROM ${tableName}
             WHERE year = ?
             ORDER BY week DESC`,
            [year]
        );
        return rows;
    }
};

module.exports = WeeklyReportModel;