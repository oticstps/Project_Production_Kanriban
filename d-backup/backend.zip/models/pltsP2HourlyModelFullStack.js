const db = require('../config/db_core');

const TABLE_NAME = 'tb_plts_p2_hourly';

function normalizeDateTime(value) {
  if (!value) return null;
  return String(value).replace('T', ' ').slice(0, 19);
}

function normalizeDate(value) {
  if (!value) return null;
  return String(value).slice(0, 10);
}

function toDecimalOrNull(value) {
  if (value === undefined || value === null || value === '') return null;
  const numberValue = Number(value);
  if (!Number.isFinite(numberValue)) return null;
  return numberValue;
}

function getGeneratedByPvValue(data = {}) {
  return toDecimalOrNull(
    data.generated_by_pv_kwh ??
      data.plts_production_kwh ??
      data.production_kwh
  );
}

class PltsP2HourlyModelFullStack {
  static selectColumns() {
    return `
      DATE_FORMAT(energy_date, '%Y-%m-%d %H:%i:%s') AS energy_date,
      DATE_FORMAT(DATE(energy_date), '%Y-%m-%d') AS date_custom,
      purchased_from_grid_kwh,
      generated_by_pv_kwh,
      generated_by_pv_kwh AS plts_production_kwh,
      fed_to_grid_kwh,
      consumed_by_appliances_kwh
    `;
  }

  static buildWhere(filters = {}) {
    const { date, startDate, endDate } = filters;
    const where = [];
    const params = [];

    if (date) {
      where.push('DATE(energy_date) = ?');
      params.push(normalizeDate(date));
    }

    if (startDate && endDate) {
      where.push('energy_date BETWEEN ? AND ?');
      params.push(normalizeDateTime(startDate), normalizeDateTime(endDate));
    } else if (startDate) {
      where.push('energy_date >= ?');
      params.push(normalizeDateTime(startDate));
    } else if (endDate) {
      where.push('energy_date <= ?');
      params.push(normalizeDateTime(endDate));
    }

    return { where, params };
  }

  static async getAll(filters = {}) {
    const { limit = 5000, offset = 0, order = 'ASC' } = filters;
    const { where, params } = this.buildWhere(filters);

    const safeLimit = Math.min(Math.max(Number(limit) || 5000, 1), 20000);
    const safeOffset = Math.max(Number(offset) || 0, 0);
    const safeOrder = String(order).toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    const sql = `
      SELECT ${this.selectColumns()}
      FROM ${TABLE_NAME}
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY energy_date ${safeOrder}
      LIMIT ? OFFSET ?
    `;

    const [rows] = await db.execute(sql, [...params, safeLimit, safeOffset]);
    return rows;
  }

  static async count(filters = {}) {
    const { where, params } = this.buildWhere(filters);

    const sql = `
      SELECT COUNT(*) AS total
      FROM ${TABLE_NAME}
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    `;

    const [rows] = await db.execute(sql, params);
    return Number(rows[0]?.total || 0);
  }

  static async findByEnergyDate(energyDate) {
    const sql = `
      SELECT ${this.selectColumns()}
      FROM ${TABLE_NAME}
      WHERE energy_date = ?
      LIMIT 1
    `;

    const [rows] = await db.execute(sql, [normalizeDateTime(energyDate)]);
    return rows[0] || null;
  }

  static async getLatest() {
    const sql = `
      SELECT ${this.selectColumns()}
      FROM ${TABLE_NAME}
      ORDER BY energy_date DESC
      LIMIT 1
    `;

    const [rows] = await db.execute(sql);
    return rows[0] || null;
  }

  static async dailySummary(date) {
    const sql = `
      SELECT
        DATE_FORMAT(DATE(energy_date), '%Y-%m-%d') AS date_custom,
        COUNT(*) AS total_record,
        SUM(purchased_from_grid_kwh) AS total_purchased_from_grid_kwh,
        SUM(generated_by_pv_kwh) AS total_generated_by_pv_kwh,
        SUM(generated_by_pv_kwh) AS total_plts_production_kwh,
        SUM(fed_to_grid_kwh) AS total_fed_to_grid_kwh,
        SUM(consumed_by_appliances_kwh) AS total_consumed_by_appliances_kwh,
        AVG(generated_by_pv_kwh) AS avg_generated_by_pv_kwh,
        AVG(generated_by_pv_kwh) AS avg_plts_production_kwh,
        MAX(generated_by_pv_kwh) AS max_generated_by_pv_kwh,
        MAX(generated_by_pv_kwh) AS max_plts_production_kwh,
        MIN(generated_by_pv_kwh) AS min_generated_by_pv_kwh,
        MIN(generated_by_pv_kwh) AS min_plts_production_kwh
      FROM ${TABLE_NAME}
      WHERE DATE(energy_date) = ?
      GROUP BY DATE(energy_date)
      LIMIT 1
    `;

    const [rows] = await db.execute(sql, [normalizeDate(date)]);
    return rows[0] || null;
  }

  static async create(data) {
    const energyDate = normalizeDateTime(data.energy_date);

    const sql = `
      INSERT INTO ${TABLE_NAME} (
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      )
      VALUES (?, ?, ?, ?, ?)
    `;

    await db.execute(sql, [
      energyDate,
      toDecimalOrNull(data.purchased_from_grid_kwh),
      getGeneratedByPvValue(data),
      toDecimalOrNull(data.fed_to_grid_kwh),
      toDecimalOrNull(data.consumed_by_appliances_kwh),
    ]);

    return this.findByEnergyDate(energyDate);
  }

  static async upsert(data) {
    const energyDate = normalizeDateTime(data.energy_date);

    const sql = `
      INSERT INTO ${TABLE_NAME} (
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      )
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        purchased_from_grid_kwh = VALUES(purchased_from_grid_kwh),
        generated_by_pv_kwh = VALUES(generated_by_pv_kwh),
        fed_to_grid_kwh = VALUES(fed_to_grid_kwh),
        consumed_by_appliances_kwh = VALUES(consumed_by_appliances_kwh)
    `;

    await db.execute(sql, [
      energyDate,
      toDecimalOrNull(data.purchased_from_grid_kwh),
      getGeneratedByPvValue(data),
      toDecimalOrNull(data.fed_to_grid_kwh),
      toDecimalOrNull(data.consumed_by_appliances_kwh),
    ]);

    return this.findByEnergyDate(energyDate);
  }

  static async update(energyDate, data) {
    const fields = [];
    const params = [];

    if (Object.prototype.hasOwnProperty.call(data, 'purchased_from_grid_kwh')) {
      fields.push('purchased_from_grid_kwh = ?');
      params.push(toDecimalOrNull(data.purchased_from_grid_kwh));
    }

    if (
      Object.prototype.hasOwnProperty.call(data, 'generated_by_pv_kwh') ||
      Object.prototype.hasOwnProperty.call(data, 'plts_production_kwh') ||
      Object.prototype.hasOwnProperty.call(data, 'production_kwh')
    ) {
      fields.push('generated_by_pv_kwh = ?');
      params.push(getGeneratedByPvValue(data));
    }

    if (Object.prototype.hasOwnProperty.call(data, 'fed_to_grid_kwh')) {
      fields.push('fed_to_grid_kwh = ?');
      params.push(toDecimalOrNull(data.fed_to_grid_kwh));
    }

    if (Object.prototype.hasOwnProperty.call(data, 'consumed_by_appliances_kwh')) {
      fields.push('consumed_by_appliances_kwh = ?');
      params.push(toDecimalOrNull(data.consumed_by_appliances_kwh));
    }

    if (!fields.length) return this.findByEnergyDate(energyDate);

    const sql = `
      UPDATE ${TABLE_NAME}
      SET ${fields.join(', ')}
      WHERE energy_date = ?
    `;

    await db.execute(sql, [...params, normalizeDateTime(energyDate)]);
    return this.findByEnergyDate(energyDate);
  }

  static async delete(energyDate) {
    const existing = await this.findByEnergyDate(energyDate);
    if (!existing) return null;

    await db.execute(`DELETE FROM ${TABLE_NAME} WHERE energy_date = ?`, [normalizeDateTime(energyDate)]);
    return existing;
  }
}

module.exports = PltsP2HourlyModelFullStack;
