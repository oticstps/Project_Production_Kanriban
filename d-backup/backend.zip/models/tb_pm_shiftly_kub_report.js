const db = require('../config/db_core');

const TABLE_NAME = 'tb_kub1_total_kwh_shiftly';

const TbShiftlyKubWh = {
    // Mendapatkan semua data
    getAll: async (limit = 500) => {
        const safeLimit = Number.parseInt(limit, 10);

        const finalLimit =
            Number.isInteger(safeLimit) && safeLimit > 0
                ? safeLimit
                : 500;

        const [rows] = await db.execute(
            `SELECT *
             FROM ${TABLE_NAME}
             ORDER BY shift_date DESC, shift ASC
             LIMIT ?`,
            [finalLimit]
        );

        return rows;
    },

    // Mendapatkan satu data berdasarkan ID
    getById: async (id) => {
        const [rows] = await db.execute(
            `SELECT *
             FROM ${TABLE_NAME}
             WHERE id = ?
             LIMIT 1`,
            [id]
        );

        return rows[0] || null;
    },

    // Mendapatkan data berdasarkan kombinasi kolom
    getByComposite: async (
        pm_type,
        line_table,
        line_name,
        shift_date,
        shift
    ) => {
        const [rows] = await db.execute(
            `SELECT *
             FROM ${TABLE_NAME}
             WHERE pm_type = ?
               AND line_table = ?
               AND line_name = ?
               AND shift_date = ?
               AND shift = ?
             LIMIT 1`,
            [
                pm_type,
                line_table,
                line_name,
                shift_date,
                shift
            ]
        );

        return rows[0] || null;
    },

    // Membuat data baru
    create: async (data) => {
        const {
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name
        } = data;

        const [result] = await db.execute(
            `INSERT INTO ${TABLE_NAME} (
                pm_type,
                line_table,
                line_name,
                shift,
                shift_date,
                shift_start_datetime,
                shift_end_datetime,
                start_kwh,
                end_kwh,
                total_kwh,
                year,
                month,
                month_name,
                day,
                day_name
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                pm_type,
                line_table,
                line_name,
                shift,
                shift_date,
                shift_start_datetime,
                shift_end_datetime,
                start_kwh,
                end_kwh,
                total_kwh,
                year,
                month,
                month_name,
                day,
                day_name
            ]
        );

        return {
            id: result.insertId,
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date
        };
    },

    // Memperbarui data berdasarkan ID
    update: async (id, data) => {
        const {
            pm_type,
            line_table,
            line_name,
            shift,
            shift_date,
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name
        } = data;

        const [result] = await db.execute(
            `UPDATE ${TABLE_NAME}
             SET pm_type = ?,
                 line_table = ?,
                 line_name = ?,
                 shift = ?,
                 shift_date = ?,
                 shift_start_datetime = ?,
                 shift_end_datetime = ?,
                 start_kwh = ?,
                 end_kwh = ?,
                 total_kwh = ?,
                 year = ?,
                 month = ?,
                 month_name = ?,
                 day = ?,
                 day_name = ?
             WHERE id = ?`,
            [
                pm_type,
                line_table,
                line_name,
                shift,
                shift_date,
                shift_start_datetime,
                shift_end_datetime,
                start_kwh,
                end_kwh,
                total_kwh,
                year,
                month,
                month_name,
                day,
                day_name,
                id
            ]
        );

        return result.affectedRows;
    },

    // Memperbarui data berdasarkan kombinasi kolom
    updateByComposite: async (
        pm_type,
        line_table,
        line_name,
        shift_date,
        shift,
        data
    ) => {
        const {
            shift_start_datetime,
            shift_end_datetime,
            start_kwh,
            end_kwh,
            total_kwh,
            year,
            month,
            month_name,
            day,
            day_name
        } = data;

        const [result] = await db.execute(
            `UPDATE ${TABLE_NAME}
             SET shift_start_datetime = ?,
                 shift_end_datetime = ?,
                 start_kwh = ?,
                 end_kwh = ?,
                 total_kwh = ?,
                 year = ?,
                 month = ?,
                 month_name = ?,
                 day = ?,
                 day_name = ?
             WHERE pm_type = ?
               AND line_table = ?
               AND line_name = ?
               AND shift_date = ?
               AND shift = ?`,
            [
                shift_start_datetime,
                shift_end_datetime,
                start_kwh,
                end_kwh,
                total_kwh,
                year,
                month,
                month_name,
                day,
                day_name,
                pm_type,
                line_table,
                line_name,
                shift_date,
                shift
            ]
        );

        return result.affectedRows;
    },

    // Menghapus data berdasarkan ID
    delete: async (id) => {
        const [result] = await db.execute(
            `DELETE FROM ${TABLE_NAME}
             WHERE id = ?`,
            [id]
        );

        return result.affectedRows;
    },

    // Menghapus data berdasarkan kombinasi kolom
    deleteByComposite: async (
        pm_type,
        line_table,
        line_name,
        shift_date,
        shift
    ) => {
        const [result] = await db.execute(
            `DELETE FROM ${TABLE_NAME}
             WHERE pm_type = ?
               AND line_table = ?
               AND line_name = ?
               AND shift_date = ?
               AND shift = ?`,
            [
                pm_type,
                line_table,
                line_name,
                shift_date,
                shift
            ]
        );

        return result.affectedRows;
    },

    // Mendapatkan data berdasarkan rentang tanggal
    getByDateRange: async (startDate, endDate) => {
        const [rows] = await db.execute(
            `SELECT *
             FROM ${TABLE_NAME}
             WHERE shift_date BETWEEN ? AND ?
             ORDER BY shift_date DESC, shift ASC`,
            [startDate, endDate]
        );

        return rows;
    },

    // Mendapatkan data berdasarkan shift
    getByShift: async (shift) => {
        const [rows] = await db.execute(
            `SELECT *
             FROM ${TABLE_NAME}
             WHERE shift = ?
             ORDER BY shift_date DESC`,
            [shift]
        );

        return rows;
    },

    // Mendapatkan data berdasarkan line_table
    getByLineTable: async (line_table) => {
        const [rows] = await db.execute(
            `SELECT *
             FROM ${TABLE_NAME}
             WHERE line_table = ?
             ORDER BY shift_date DESC, shift ASC`,
            [line_table]
        );

        return rows;
    },

    // Mendapatkan data berdasarkan pm_type
    getByPmType: async (pm_type) => {
        const [rows] = await db.execute(
            `SELECT *
             FROM ${TABLE_NAME}
             WHERE pm_type = ?
             ORDER BY shift_date DESC, shift ASC`,
            [pm_type]
        );

        return rows;
    }
};

module.exports = TbShiftlyKubWh;