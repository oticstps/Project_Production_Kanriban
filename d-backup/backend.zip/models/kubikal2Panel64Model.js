const db = require('../config/db_core');

class kubikal1Model {
    // Ambil data terkini (hanya baris dengan id=1)
    static async getCurrent() {
        const [rows] = await db.query('SELECT * FROM tb_realtime_kubikal_p64 WHERE id = 1');
        return rows.length ? rows[0] : null;
    }

    // Update umum (partial) – field dikirim dalam objek
    static async update(data) {
        delete data.id; // jangan ubah primary key
        const fields = Object.keys(data);
        if (fields.length === 0) return null;

        const placeholders = fields.map(() => '?').join(', ');
        const updates = fields.map(f => `${f} = VALUES(${f})`).join(', ');

        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 (id, ${fields.join(', ')})
            VALUES (1, ${placeholders})
            ON DUPLICATE KEY UPDATE ${updates}
        `;
        const values = fields.map(f => data[f]);
        const [result] = await db.query(sql, values);
        return result;
    }

    // 1. Arus (Current)
    static async updateCurrent(data) {
        const { panel, current_avg, current_a, current_b, current_c, current_n } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, current_avg, current_a, current_b, current_c, current_n)
            VALUES (1, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                current_avg = VALUES(current_avg),
                current_a = VALUES(current_a),
                current_b = VALUES(current_b),
                current_c = VALUES(current_c),
                current_n = VALUES(current_n)
        `;
        const values = [panel, current_avg, current_a, current_b, current_c, current_n];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 2. Tegangan Line‑to‑Line (Voltage LL)
    static async updateVoltageLL(data) {
        const { panel, voltage_ll_avg, voltage_ab, voltage_bc, voltage_ca } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, voltage_ll_avg, voltage_ab, voltage_bc, voltage_ca)
            VALUES (1, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                voltage_ll_avg = VALUES(voltage_ll_avg),
                voltage_ab = VALUES(voltage_ab),
                voltage_bc = VALUES(voltage_bc),
                voltage_ca = VALUES(voltage_ca)
        `;
        const values = [panel, voltage_ll_avg, voltage_ab, voltage_bc, voltage_ca];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 3. Tegangan Line‑to‑Neutral (Voltage LN)
    static async updateVoltageLN(data) {
        const { panel, voltage_ln_avg, voltage_an, voltage_bn, voltage_cn } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, voltage_ln_avg, voltage_an, voltage_bn, voltage_cn)
            VALUES (1, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                voltage_ln_avg = VALUES(voltage_ln_avg),
                voltage_an = VALUES(voltage_an),
                voltage_bn = VALUES(voltage_bn),
                voltage_cn = VALUES(voltage_cn)
        `;
        const values = [panel, voltage_ln_avg, voltage_an, voltage_bn, voltage_cn];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 4. Daya Aktif (Active Power)
    static async updateActivePower(data) {
        const { panel, active_power_total, active_power_a, active_power_b, active_power_c } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, active_power_total, active_power_a, active_power_b, active_power_c)
            VALUES (1, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                active_power_total = VALUES(active_power_total),
                active_power_a = VALUES(active_power_a),
                active_power_b = VALUES(active_power_b),
                active_power_c = VALUES(active_power_c)
        `;
        const values = [panel, active_power_total, active_power_a, active_power_b, active_power_c];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 5. Daya Semu (Apparent Power)
    static async updateApparentPower(data) {
        const { panel, apparent_power_total, apparent_power_a, apparent_power_b, apparent_power_c } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, apparent_power_total, apparent_power_a, apparent_power_b, apparent_power_c)
            VALUES (1, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                apparent_power_total = VALUES(apparent_power_total),
                apparent_power_a = VALUES(apparent_power_a),
                apparent_power_b = VALUES(apparent_power_b),
                apparent_power_c = VALUES(apparent_power_c)
        `;
        const values = [panel, apparent_power_total, apparent_power_a, apparent_power_b, apparent_power_c];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 6. Faktor Daya (Power Factor)
    static async updatePowerFactor(data) {
        const { panel, power_factor_total, power_factor_a, power_factor_b, power_factor_c } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, power_factor_total, power_factor_a, power_factor_b, power_factor_c)
            VALUES (1, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                power_factor_total = VALUES(power_factor_total),
                power_factor_a = VALUES(power_factor_a),
                power_factor_b = VALUES(power_factor_b),
                power_factor_c = VALUES(power_factor_c)
        `;
        const values = [panel, power_factor_total, power_factor_a, power_factor_b, power_factor_c];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 7. Daya Reaktif (Reactive Power)
    static async updateReactivePower(data) {
        const { panel, reactive_power_total, reactive_power_a, reactive_power_b, reactive_power_c } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, reactive_power_total, reactive_power_a, reactive_power_b, reactive_power_c)
            VALUES (1, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                reactive_power_total = VALUES(reactive_power_total),
                reactive_power_a = VALUES(reactive_power_a),
                reactive_power_b = VALUES(reactive_power_b),
                reactive_power_c = VALUES(reactive_power_c)
        `;
        const values = [panel, reactive_power_total, reactive_power_a, reactive_power_b, reactive_power_c];
        const [result] = await db.query(sql, values);
        return result;
    }

    // 8. Frekuensi (Frequency)
    static async updateFrequency(data) {
        const { panel, data_freq } = data;
        const sql = `
            INSERT INTO tb_realtime_kubikal_p64 
                (id, panel, data_freq)
            VALUES (1, ?, ?)
            ON DUPLICATE KEY UPDATE
                panel = VALUES(panel),
                data_freq = VALUES(data_freq)
        `;
        const values = [panel, data_freq];
        const [result] = await db.query(sql, values);
        return result;
    }

    // Hapus data (opsional)
    static async delete() {
        const sql = 'DELETE FROM tb_realtime_kubikal_p64 WHERE id = 1';
        const [result] = await db.query(sql);
        return result;
    }
}

module.exports = kubikal1Model;