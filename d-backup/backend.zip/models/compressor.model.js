const db = require('../config/db_core');

const panelTables = [
  {
    pm_type: 'PANEL COMPRESSOR',
    source_table: 'tb_panel_24_energy_vah_wh',
    line_name: 'PANEL 24',
    shiftly_table: 'tb_panel_24_energy_vah_wh_shiftly',
    daily_table: 'tb_panel_24_energy_vah_wh_daily',
    weekly_table: 'tb_panel_24_energy_vah_wh_weekly',
    monthly_table: 'tb_panel_24_energy_vah_wh_monthly',
  },
  {
    pm_type: 'PANEL COMPRESSOR',
    source_table: 'tb_panel_21_energy_vah_wh',
    line_name: 'PANEL 21',
    shiftly_table: 'tb_panel_21_energy_vah_wh_shiftly',
    daily_table: 'tb_panel_21_energy_vah_wh_daily',
    weekly_table: 'tb_panel_21_energy_vah_wh_weekly',
    monthly_table: 'tb_panel_21_energy_vah_wh_monthly',
  },
  {
    pm_type: 'PANEL COMPRESSOR',
    source_table: 'tb_panel_19_energy_vah_wh',
    line_name: 'PANEL 19',
    shiftly_table: 'tb_panel_19_energy_vah_wh_shiftly',
    daily_table: 'tb_panel_19_energy_vah_wh_daily',
    weekly_table: 'tb_panel_19_energy_vah_wh_weekly',
    monthly_table: 'tb_panel_19_energy_vah_wh_monthly',
  },
  {
    pm_type: 'PANEL COMPRESSOR',
    source_table: 'tb_kub_panel_20_wh',
    line_name: 'PANEL 20',
    shiftly_table: 'tb_kub_panel_20_wh_shiftly',
    daily_table: 'tb_kub_panel_20_wh_daily',
    weekly_table: 'tb_kub_panel_20_wh_weekly',
    monthly_table: 'tb_kub_panel_20_wh_monthly',
  },
];

const CompressorModel = {
  getPool() {
    return db;
  },

  getPanelTables() {
    return panelTables;
  },

  async getConnection() {
    return await db.getConnection();
  },

  async getDistinctDates(connection, sourceTable) {
    const [rows] = await connection.query(`
      SELECT DISTINCT DATE(date_time) AS period_date
      FROM ${sourceTable}
      WHERE date_time IS NOT NULL
      ORDER BY period_date ASC
    `);

    return rows;
  },

  async getFirstRowInRange(connection, tableName, startTime, endTime) {
    const [rows] = await connection.query(
      `
      SELECT
        date_time,
        CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
      FROM ${tableName}
      WHERE date_time >= ? AND date_time < ?
        AND wh IS NOT NULL
        AND TRIM(CAST(wh AS CHAR)) <> ''
      ORDER BY date_time ASC
      LIMIT 1
      `,
      [startTime, endTime]
    );

    return rows[0] || null;
  },

  async getLastRowInRange(connection, tableName, startTime, endTime) {
    const [rows] = await connection.query(
      `
      SELECT
        date_time,
        CAST(REPLACE(TRIM(CAST(wh AS CHAR)), ',', '') AS DECIMAL(15,3)) AS wh_value
      FROM ${tableName}
      WHERE date_time >= ? AND date_time < ?
        AND wh IS NOT NULL
        AND TRIM(CAST(wh AS CHAR)) <> ''
      ORDER BY date_time DESC
      LIMIT 1
      `,
      [startTime, endTime]
    );

    return rows[0] || null;
  },

  async upsertShiftly(connection, targetTable, payload) {
    const sql = `
      INSERT INTO ${targetTable} (
        pm_type,
        line_table,
        line_name,
        shift,
        shift_date,
        shift_start_datetime,
        shift_end_datetime,
        start_kwh,
        end_kwh,
        total_kwh,
        year,
        month,
        month_name,
        day,
        day_name,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        line_name = VALUES(line_name),
        shift_start_datetime = VALUES(shift_start_datetime),
        shift_end_datetime = VALUES(shift_end_datetime),
        start_kwh = VALUES(start_kwh),
        end_kwh = VALUES(end_kwh),
        total_kwh = VALUES(total_kwh),
        year = VALUES(year),
        month = VALUES(month),
        month_name = VALUES(month_name),
        day = VALUES(day),
        day_name = VALUES(day_name),
        updated_at = NOW()
    `;

    const values = [
      payload.pm_type,
      payload.line_table,
      payload.line_name,
      payload.shift,
      payload.shift_date,
      payload.shift_start_datetime,
      payload.shift_end_datetime,
      payload.start_kwh,
      payload.end_kwh,
      payload.total_kwh,
      payload.year,
      payload.month,
      payload.month_name,
      payload.day,
      payload.day_name,
    ];

    return await connection.query(sql, values);
  },

  async upsertDaily(connection, targetTable, payload) {
    const sql = `
      INSERT INTO ${targetTable} (
        pm_type,
        line_table,
        line_name,
        shift,
        shift_date,
        shift_start_datetime,
        shift_end_datetime,
        start_kwh,
        end_kwh,
        total_kwh,
        year,
        month,
        month_name,
        day,
        day_name,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        line_name = VALUES(line_name),
        shift_start_datetime = VALUES(shift_start_datetime),
        shift_end_datetime = VALUES(shift_end_datetime),
        start_kwh = VALUES(start_kwh),
        end_kwh = VALUES(end_kwh),
        total_kwh = VALUES(total_kwh),
        year = VALUES(year),
        month = VALUES(month),
        month_name = VALUES(month_name),
        day = VALUES(day),
        day_name = VALUES(day_name),
        updated_at = NOW()
    `;

    const values = [
      payload.pm_type,
      payload.line_table,
      payload.line_name,
      payload.shift,
      payload.shift_date,
      payload.shift_start_datetime,
      payload.shift_end_datetime,
      payload.start_kwh,
      payload.end_kwh,
      payload.total_kwh,
      payload.year,
      payload.month,
      payload.month_name,
      payload.day,
      payload.day_name,
    ];

    return await connection.query(sql, values);
  },

  async upsertWeekly(connection, targetTable, payload) {
    const sql = `
      INSERT INTO ${targetTable} (
        pm_type,
        line_table,
        line_name,
        week,
        week_start_date,
        week_end_date,
        week_start_datetime,
        week_end_datetime,
        start_kwh,
        end_kwh,
        total_kwh,
        year,
        month,
        month_name,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        line_name = VALUES(line_name),
        week_start_date = VALUES(week_start_date),
        week_end_date = VALUES(week_end_date),
        week_start_datetime = VALUES(week_start_datetime),
        week_end_datetime = VALUES(week_end_datetime),
        start_kwh = VALUES(start_kwh),
        end_kwh = VALUES(end_kwh),
        total_kwh = VALUES(total_kwh),
        month = VALUES(month),
        month_name = VALUES(month_name),
        updated_at = NOW()
    `;

    const values = [
      payload.pm_type,
      payload.line_table,
      payload.line_name,
      payload.week,
      payload.week_start_date,
      payload.week_end_date,
      payload.week_start_datetime,
      payload.week_end_datetime,
      payload.start_kwh,
      payload.end_kwh,
      payload.total_kwh,
      payload.year,
      payload.month,
      payload.month_name,
    ];

    return await connection.query(sql, values);
  },

  async upsertMonthly(connection, targetTable, payload) {
    const sql = `
      INSERT INTO ${targetTable} (
        pm_type,
        line_table,
        line_name,
        start_kwh,
        end_kwh,
        total_kwh,
        year,
        month,
        month_name,
        month_start_date,
        month_end_date,
        month_start_datetime,
        month_end_datetime,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE
        line_name = VALUES(line_name),
        start_kwh = VALUES(start_kwh),
        end_kwh = VALUES(end_kwh),
        total_kwh = VALUES(total_kwh),
        month_name = VALUES(month_name),
        month_start_date = VALUES(month_start_date),
        month_end_date = VALUES(month_end_date),
        month_start_datetime = VALUES(month_start_datetime),
        month_end_datetime = VALUES(month_end_datetime),
        updated_at = NOW()
    `;

    const values = [
      payload.pm_type,
      payload.line_table,
      payload.line_name,
      payload.start_kwh,
      payload.end_kwh,
      payload.total_kwh,
      payload.year,
      payload.month,
      payload.month_name,
      payload.month_start_date,
      payload.month_end_date,
      payload.month_start_datetime,
      payload.month_end_datetime,
    ];

    return await connection.query(sql, values);
  },

  async getData(targetTable, filters = {}) {
    const clauses = [];
    const values = [];

    if (filters.year) {
      clauses.push(`year = ?`);
      values.push(filters.year);
    }

    if (filters.month) {
      clauses.push(`month = ?`);
      values.push(filters.month);
    }

    if (filters.shift_date) {
      clauses.push(`shift_date = ?`);
      values.push(filters.shift_date);
    }

    if (filters.week) {
      clauses.push(`week = ?`);
      values.push(filters.week);
    }

    const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    const sql = `SELECT * FROM ${targetTable} ${where} ORDER BY created_at DESC`;

    const [rows] = await db.query(sql, values);
    return rows;
  },
};

module.exports = CompressorModel;