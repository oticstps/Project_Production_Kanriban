const pool = require('../config/db_core');

const tableName = 'tb_plts_p2_daily';

const PltsP2DailyModelFullStack = {
  async getAll() {
    const [rows] = await pool.query(`
      SELECT 
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      FROM ${tableName}
      ORDER BY energy_date ASC
    `);

    return rows;
  },

  async getByDate(energy_date) {
    const [rows] = await pool.query(
      `
      SELECT 
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      FROM ${tableName}
      WHERE energy_date = ?
      `,
      [energy_date]
    );

    return rows[0];
  },

  async create(data) {
    const {
      energy_date,
      purchased_from_grid_kwh,
      generated_by_pv_kwh,
      fed_to_grid_kwh,
      consumed_by_appliances_kwh
    } = data;

    const [result] = await pool.query(
      `
      INSERT INTO ${tableName}
      (
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      )
      VALUES (?, ?, ?, ?, ?)
      `,
      [
        energy_date,
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh
      ]
    );

    return result;
  },

  async update(energy_date, data) {
    const {
      purchased_from_grid_kwh,
      generated_by_pv_kwh,
      fed_to_grid_kwh,
      consumed_by_appliances_kwh
    } = data;

    const [result] = await pool.query(
      `
      UPDATE ${tableName}
      SET
        purchased_from_grid_kwh = ?,
        generated_by_pv_kwh = ?,
        fed_to_grid_kwh = ?,
        consumed_by_appliances_kwh = ?
      WHERE energy_date = ?
      `,
      [
        purchased_from_grid_kwh,
        generated_by_pv_kwh,
        fed_to_grid_kwh,
        consumed_by_appliances_kwh,
        energy_date
      ]
    );

    return result;
  },

  async delete(energy_date) {
    const [result] = await pool.query(
      `
      DELETE FROM ${tableName}
      WHERE energy_date = ?
      `,
      [energy_date]
    );

    return result;
  }
};

module.exports = PltsP2DailyModelFullStack;