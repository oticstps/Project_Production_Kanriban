const db = require('../config/db_core');

const TABLE_NAME = 'tb_plts_p1';

class FullTextModel_p1 {
  static async getAll() {
    const [rows] = await db.query(`
      SELECT 
        id,
        power,
        power_unit,
        phase_1,
        phase_1_unit,
        pv_energy,
        pv_energy_unit,
        irradiation,
        irradiation_unit,
        pr,
        pr_unit,
        weather_for_cikarang,
        weather_unit,
        co2_reduced,
        co2_reduced_unit,
        status_pv,
        last_update,
        created_at
      FROM ${TABLE_NAME}
      ORDER BY id DESC
    `);
    return rows;
  }

  static async getLatest() {
    const [rows] = await db.query(`
      SELECT 
        id,
        power,
        power_unit,
        phase_1,
        phase_1_unit,
        pv_energy,
        pv_energy_unit,
        irradiation,
        irradiation_unit,
        pr,
        pr_unit,
        weather_for_cikarang,
        weather_unit,
        co2_reduced,
        co2_reduced_unit,
        status_pv,
        last_update,
        created_at
      FROM ${TABLE_NAME}
      ORDER BY id DESC
      LIMIT 1
    `);
    return rows[0];
  }

  static async getById(id) {
    const [rows] = await db.query(`
      SELECT 
        id,
        power,
        power_unit,
        phase_1,
        phase_1_unit,
        pv_energy,
        pv_energy_unit,
        irradiation,
        irradiation_unit,
        pr,
        pr_unit,
        weather_for_cikarang,
        weather_unit,
        co2_reduced,
        co2_reduced_unit,
        status_pv,
        last_update,
        created_at
      FROM ${TABLE_NAME}
      WHERE id = ?
      LIMIT 1
    `, [id]);

    return rows[0];
  }

  static async create(data) {
    const {
      power,
      power_unit,
      phase_1,
      phase_1_unit,
      pv_energy,
      pv_energy_unit,
      irradiation,
      irradiation_unit,
      pr,
      pr_unit,
      weather_for_cikarang,
      weather_unit,
      co2_reduced,
      co2_reduced_unit,
      status_pv,
      last_update
    } = data;

    const [result] = await db.query(`
      INSERT INTO ${TABLE_NAME} (
        power,
        power_unit,
        phase_1,
        phase_1_unit,
        pv_energy,
        pv_energy_unit,
        irradiation,
        irradiation_unit,
        pr,
        pr_unit,
        weather_for_cikarang,
        weather_unit,
        co2_reduced,
        co2_reduced_unit,
        status_pv,
        last_update
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      power ?? null,
      power_unit ?? null,
      phase_1 ?? null,
      phase_1_unit ?? null,
      pv_energy ?? null,
      pv_energy_unit ?? null,
      irradiation ?? null,
      irradiation_unit ?? null,
      pr ?? null,
      pr_unit ?? null,
      weather_for_cikarang ?? null,
      weather_unit ?? null,
      co2_reduced ?? null,
      co2_reduced_unit ?? null,
      status_pv ?? null,
      last_update ?? null
    ]);

    return result.insertId;
  }

  static async update(id, data) {
    const {
      power,
      power_unit,
      phase_1,
      phase_1_unit,
      pv_energy,
      pv_energy_unit,
      irradiation,
      irradiation_unit,
      pr,
      pr_unit,
      weather_for_cikarang,
      weather_unit,
      co2_reduced,
      co2_reduced_unit,
      status_pv,
      last_update
    } = data;

    const [result] = await db.query(`
      UPDATE ${TABLE_NAME}
      SET
        power = ?,
        power_unit = ?,
        phase_1 = ?,
        phase_1_unit = ?,
        pv_energy = ?,
        pv_energy_unit = ?,
        irradiation = ?,
        irradiation_unit = ?,
        pr = ?,
        pr_unit = ?,
        weather_for_cikarang = ?,
        weather_unit = ?,
        co2_reduced = ?,
        co2_reduced_unit = ?,
        status_pv = ?,
        last_update = ?
      WHERE id = ?
    `, [
      power ?? null,
      power_unit ?? null,
      phase_1 ?? null,
      phase_1_unit ?? null,
      pv_energy ?? null,
      pv_energy_unit ?? null,
      irradiation ?? null,
      irradiation_unit ?? null,
      pr ?? null,
      pr_unit ?? null,
      weather_for_cikarang ?? null,
      weather_unit ?? null,
      co2_reduced ?? null,
      co2_reduced_unit ?? null,
      status_pv ?? null,
      last_update ?? null,
      id
    ]);

    return result.affectedRows;
  }

  static async delete(id) {
    const [result] = await db.query(`
      DELETE FROM ${TABLE_NAME}
      WHERE id = ?
    `, [id]);

    return result.affectedRows;
  }
}

module.exports = FullTextModel_p1;