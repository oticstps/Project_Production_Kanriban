const db = require('../config/db_core');

const TbHourlyWh = {
    // Mendapatkan semua data, diurutkan berdasarkan jam terbaru
    getAll: async (limit = 500) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_hourly_report ORDER BY hour_start_datetime DESC LIMIT ?',
            [limit]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan kombinasi unik (primary key komposit)
    getByComposite: async (pm_type, line_table, hour_start_datetime) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_hourly_report WHERE pm_type = ? AND line_table = ? AND hour_start_datetime = ?',
            [pm_type, line_table, hour_start_datetime]
        );
        return rows[0];
    },

    // Membuat data baru
    create: async (data) => {
        const { 
            pm_type, line_table, line_name,
            hour_start_datetime, hour_end_datetime,
            start_kwh, end_kwh, total_kwh,
            date, year, month, month_name, day, day_name, hour_of_day
        } = data;
        
        const [result] = await db.execute(
            `INSERT INTO tb_pm_hourly_report 
            (pm_type, line_table, line_name, hour_start_datetime, hour_end_datetime,
             start_kwh, end_kwh, total_kwh, date, year, month, month_name, day, day_name, hour_of_day, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [pm_type, line_table, line_name, hour_start_datetime, hour_end_datetime,
             start_kwh, end_kwh, total_kwh, date, year, month, month_name, day, day_name, hour_of_day]
        );
        
        // Mengembalikan objek berisi kombinasi unik
        return { pm_type, line_table, hour_start_datetime };
    },

    // Memperbarui data berdasarkan kombinasi unik
    update: async (pm_type, line_table, hour_start_datetime, data) => {
        const { 
            line_name, hour_end_datetime,
            start_kwh, end_kwh, total_kwh,
            month_name, day_name
        } = data;
        
        const [result] = await db.execute(
            `UPDATE tb_pm_hourly_report 
            SET line_name = ?, hour_end_datetime = ?,
                start_kwh = ?, end_kwh = ?, total_kwh = ?,
                month_name = ?, day_name = ?, created_at = NOW()
            WHERE pm_type = ? AND line_table = ? AND hour_start_datetime = ?`,
            [line_name, hour_end_datetime, start_kwh, end_kwh, total_kwh,
             month_name, day_name, pm_type, line_table, hour_start_datetime]
        );
        return result.affectedRows;
    },

    // Menghapus data berdasarkan kombinasi unik
    delete: async (pm_type, line_table, hour_start_datetime) => {
        const [result] = await db.execute(
            'DELETE FROM tb_pm_hourly_report WHERE pm_type = ? AND line_table = ? AND hour_start_datetime = ?',
            [pm_type, line_table, hour_start_datetime]
        );
        return result.affectedRows;
    },

    // Mendapatkan data berdasarkan rentang waktu (hour_start_datetime)
    getByDateRange: async (startDate, endDate) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_hourly_report WHERE hour_start_datetime BETWEEN ? AND ? ORDER BY hour_start_datetime DESC',
            [startDate, endDate]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan line_table
    getByLineTable: async (line_table) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_hourly_report WHERE line_table = ? ORDER BY hour_start_datetime DESC',
            [line_table]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan pm_type
    getByPmType: async (pm_type) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_hourly_report WHERE pm_type = ? ORDER BY hour_start_datetime DESC',
            [pm_type]
        );
        return rows;
    },

    // Mendapatkan data berdasarkan tanggal tertentu (format YYYY-MM-DD)
    getByDate: async (date) => {
        const [rows] = await db.execute(
            'SELECT * FROM tb_pm_hourly_report WHERE date = ? ORDER BY hour_of_day ASC',
            [date]
        );
        return rows;
    }
};

module.exports = TbHourlyWh;