const pool = require('../config/db_core');

const tableName = 'tb_plts_p1_daily';

const PltsP1DailyModelFullStack = {
  async getAll() {
    const [rows] = await pool.query(`
      SELECT 
        energy_date,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      FROM ${tableName}
      ORDER BY energy_date ASC
    `);

    return rows;
  },

  async getByDate(energy_date) {
    const [rows] = await pool.query(
      `
      SELECT 
        energy_date,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      FROM ${tableName}
      WHERE energy_date = ?
      `,
      [energy_date]
    );

    return rows[0];
  },

  async create(data) {
    const {
      energy_date,
      production_kwh,
      inverter1_kwh,
      inverter2_kwh
    } = data;

    const [result] = await pool.query(
      `
      INSERT INTO ${tableName}
      (
        energy_date,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      )
      VALUES (?, ?, ?, ?)
      `,
      [
        energy_date,
        production_kwh,
        inverter1_kwh,
        inverter2_kwh
      ]
    );

    return result;
  },

  async update(energy_date, data) {
    const {
      production_kwh,
      inverter1_kwh,
      inverter2_kwh
    } = data;

    const [result] = await pool.query(
      `
      UPDATE ${tableName}
      SET
        production_kwh = ?,
        inverter1_kwh = ?,
        inverter2_kwh = ?
      WHERE energy_date = ?
      `,
      [
        production_kwh,
        inverter1_kwh,
        inverter2_kwh,
        energy_date
      ]
    );

    return result;
  },

  async delete(energy_date) {
    const [result] = await pool.query(
      `
      DELETE FROM ${tableName}
      WHERE energy_date = ?
      `,
      [energy_date]
    );

    return result;
  }
};

module.exports = PltsP1DailyModelFullStack;