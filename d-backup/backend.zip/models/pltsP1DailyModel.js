const pool = require("../config/db_core");

const TABLE_NAME = "tb_plts_p1_daily";

const normalizeDecimal = (value) => {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  let text = String(value).trim();

  if (/^\d{1,3}(\.\d{3})*,\d+$/.test(text)) {
    text = text.replace(/\./g, "").replace(",", ".");
  } else if (text.includes(",") && !text.includes(".")) {
    text = text.replace(",", ".");
  } else {
    text = text.replace(/,/g, "");
  }

  const number = Number(text);
  return Number.isNaN(number) ? null : number;
};

const normalizeDate = (value) => {
  if (!value) return null;

  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value.toISOString().slice(0, 10);
  }

  if (typeof value === "number") {
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const date = new Date(excelEpoch.getTime() + value * 24 * 60 * 60 * 1000);
    return date.toISOString().slice(0, 10);
  }

  const text = String(value).trim();

  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    return text;
  }

  // Format Excel Anda: M/D/YYYY, contoh 4/1/2026 = 2026-04-01
  const mdy = text.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (mdy) {
    const month = mdy[1].padStart(2, "0");
    const day = mdy[2].padStart(2, "0");
    const year = mdy[3];

    return `${year}-${month}-${day}`;
  }

  const parsedDate = new Date(text);
  if (!Number.isNaN(parsedDate.getTime())) {
    return parsedDate.toISOString().slice(0, 10);
  }

  return null;
};

const normalizeRow = (row) => {
  return {
    energy_date: normalizeDate(row.energy_date),
    production_kwh: normalizeDecimal(row.production_kwh),
    inverter1_kwh: normalizeDecimal(row.inverter1_kwh),
    inverter2_kwh: normalizeDecimal(row.inverter2_kwh),
  };
};

const getAll = async ({ startDate, endDate, limit = 100, offset = 0 }) => {
  let sql = `SELECT * FROM ${TABLE_NAME}`;
  const params = [];

  if (startDate && endDate) {
    sql += " WHERE energy_date BETWEEN ? AND ?";
    params.push(startDate, endDate);
  } else if (startDate) {
    sql += " WHERE energy_date >= ?";
    params.push(startDate);
  } else if (endDate) {
    sql += " WHERE energy_date <= ?";
    params.push(endDate);
  }

  sql += " ORDER BY energy_date DESC LIMIT ? OFFSET ?";
  params.push(Number(limit), Number(offset));

  const [rows] = await pool.query(sql, params);
  return rows;
};

const getByDate = async (energyDate) => {
  const [rows] = await pool.query(
    `SELECT * FROM ${TABLE_NAME} WHERE energy_date = ?`,
    [energyDate]
  );

  return rows[0] || null;
};

const upsert = async (payload) => {
  const data = normalizeRow(payload);

  if (!data.energy_date) {
    throw new Error("energy_date wajib diisi dengan format tanggal yang valid.");
  }

  const sql = `
    INSERT INTO ${TABLE_NAME} (
      energy_date,
      production_kwh,
      inverter1_kwh,
      inverter2_kwh
    )
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      production_kwh = VALUES(production_kwh),
      inverter1_kwh = VALUES(inverter1_kwh),
      inverter2_kwh = VALUES(inverter2_kwh)
  `;

  const [result] = await pool.query(sql, [
    data.energy_date,
    data.production_kwh,
    data.inverter1_kwh,
    data.inverter2_kwh,
  ]);

  return result;
};

const bulkUpsert = async (rows) => {
  if (!Array.isArray(rows)) {
    throw new Error("Data harus berupa array.");
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    let successCount = 0;
    const failedRows = [];

    for (let index = 0; index < rows.length; index++) {
      try {
        const data = normalizeRow(rows[index]);

        if (!data.energy_date) {
          failedRows.push({
            index,
            row: rows[index],
            error: "energy_date tidak valid.",
          });
          continue;
        }

        const sql = `
          INSERT INTO ${TABLE_NAME} (
            energy_date,
            production_kwh,
            inverter1_kwh,
            inverter2_kwh
          )
          VALUES (?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            production_kwh = VALUES(production_kwh),
            inverter1_kwh = VALUES(inverter1_kwh),
            inverter2_kwh = VALUES(inverter2_kwh)
        `;

        await connection.query(sql, [
          data.energy_date,
          data.production_kwh,
          data.inverter1_kwh,
          data.inverter2_kwh,
        ]);

        successCount++;
      } catch (error) {
        failedRows.push({
          index,
          row: rows[index],
          error: error.message,
        });
      }
    }

    await connection.commit();

    return {
      successCount,
      failedCount: failedRows.length,
      failedRows,
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

const updateByDate = async (energyDate, payload) => {
  const data = normalizeRow({
    ...payload,
    energy_date: energyDate,
  });

  const sql = `
    UPDATE ${TABLE_NAME}
    SET
      production_kwh = ?,
      inverter1_kwh = ?,
      inverter2_kwh = ?
    WHERE energy_date = ?
  `;

  const [result] = await pool.query(sql, [
    data.production_kwh,
    data.inverter1_kwh,
    data.inverter2_kwh,
    data.energy_date,
  ]);

  return result;
};

const deleteByDate = async (energyDate) => {
  const [result] = await pool.query(
    `DELETE FROM ${TABLE_NAME} WHERE energy_date = ?`,
    [energyDate]
  );

  return result;
};

module.exports = {
  getAll,
  getByDate,
  upsert,
  bulkUpsert,
  updateByDate,
  deleteByDate,
};