const db = require("../config/db_core");

const TABLE_NAME = "tb_plts";

const FullTextModel = {
  async getAll() {
    const [rows] = await db.query(
      `SELECT * FROM ${TABLE_NAME} ORDER BY id DESC`
    );
    return rows;
  },

  async getLatest() {
    const [rows] = await db.query(
      `SELECT * FROM ${TABLE_NAME} ORDER BY id DESC LIMIT 1`
    );
    return rows[0] || null;
  },

  async getById(id) {
    const [rows] = await db.query(
      `SELECT * FROM ${TABLE_NAME} WHERE id = ? LIMIT 1`,
      [id]
    );
    return rows[0] || null;
  },

  async create(data) {
    const sql = `
      INSERT INTO ${TABLE_NAME} (
        area1_value, area1_label, area1_unit,
        area2_value, area2_label, area2_unit,
        area3_value, area3_label, area3_unit,
        area4_value, area4_label, area4_unit,
        area5_value, area5_label, area5_unit,
        area6_value, area6_label, area6_unit,
        area7_value, area7_label, area7_unit
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
      data.area1_value, data.area1_label, data.area1_unit,
      data.area2_value, data.area2_label, data.area2_unit,
      data.area3_value, data.area3_label, data.area3_unit,
      data.area4_value, data.area4_label, data.area4_unit,
      data.area5_value, data.area5_label, data.area5_unit,
      data.area6_value, data.area6_label, data.area6_unit,
      data.area7_value, data.area7_label, data.area7_unit
    ];

    const [result] = await db.query(sql, values);
    return this.getById(result.insertId);
  },

  async update(id, data) {
    const sql = `
      UPDATE ${TABLE_NAME}
      SET
        area1_value = ?, area1_label = ?, area1_unit = ?,
        area2_value = ?, area2_label = ?, area2_unit = ?,
        area3_value = ?, area3_label = ?, area3_unit = ?,
        area4_value = ?, area4_label = ?, area4_unit = ?,
        area5_value = ?, area5_label = ?, area5_unit = ?,
        area6_value = ?, area6_label = ?, area6_unit = ?,
        area7_value = ?, area7_label = ?, area7_unit = ?
      WHERE id = ?
    `;

    const values = [
      data.area1_value, data.area1_label, data.area1_unit,
      data.area2_value, data.area2_label, data.area2_unit,
      data.area3_value, data.area3_label, data.area3_unit,
      data.area4_value, data.area4_label, data.area4_unit,
      data.area5_value, data.area5_label, data.area5_unit,
      data.area6_value, data.area6_label, data.area6_unit,
      data.area7_value, data.area7_label, data.area7_unit,
      id
    ];

    const [result] = await db.query(sql, values);

    if (result.affectedRows === 0) {
      return null;
    }

    return this.getById(id);
  },

  async delete(id) {
    const [result] = await db.query(
      `DELETE FROM ${TABLE_NAME} WHERE id = ?`,
      [id]
    );
    return result.affectedRows > 0;
  }
};

module.exports = FullTextModel;