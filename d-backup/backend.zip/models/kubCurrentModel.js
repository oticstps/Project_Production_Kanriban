// models/kubCurrentModel.js
const db = require('../config/db_core');

class kubCurrentModel {
    // Mengambil semua data
    static async getAll() {
        const [rows] = await db.query('SELECT * FROM tb_kub_current_update ORDER BY date_time DESC');
        return rows;
    }

    // Menambahkan data baru
    static async create(data) {
        const { panel, current_avg, current_a, current_b, current_c, current_n } = data;
        
        // date_time akan otomatis terisi current_timestamp() dari DB jika NULL
        const sql = `INSERT INTO tb_kub_current_update 
                    (panel, current_avg, current_a, current_b, current_c, current_n) 
                    VALUES (?, ?, ?, ?, ?, ?)`;
        
        const values = [panel, current_avg, current_a, current_b, current_c, current_n];
        
        const [result] = await db.query(sql, values);
        return result;
    }

    // Menghapus data berdasarkan date_time (karena tidak ada ID integer di schema)
    static async deleteByDateTime(dateTime) {
        const sql = 'DELETE FROM tb_kub_current_update WHERE date_time = ?';
        const [result] = await db.query(sql, [dateTime]);
        return result;
    }
    
    // Update data (Contoh Edit)
    static async update(dateTime, newData) {
        const { panel, current_avg, current_a, current_b, current_c, current_n } = newData;
        const sql = `UPDATE tb_kub_current_update 
                     SET panel=?, current_avg=?, current_a=?, current_b=?, current_c=?, current_n=? 
                     WHERE date_time=?`;
        const values = [panel, current_avg, current_a, current_b, current_c, current_n, dateTime];
        const [result] = await db.query(sql, values);
        return result;
    }
}

module.exports = kubCurrentModel;