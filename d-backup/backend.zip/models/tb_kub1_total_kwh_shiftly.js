const db = require('../config/db_core');

const TABLE_NAME = 'tb_kub1_total_kwh_shiftly';

const WRITABLE_FIELDS = [
  'pm_type',
  'line_table',
  'line_name',
  'shift',
  'shift_date',
  'shift_start_datetime',
  'shift_end_datetime',
  'start_kwh',
  'end_kwh',
  'total_kwh',
  'year',
  'month',
  'month_name',
  'day',
  'day_name'
];

const TbKub1TotalKwhShiftly = {
  getAll: async (limit = 500) => {
    const parsedLimit = Number.parseInt(limit, 10);
    const safeLimit = Number.isInteger(parsedLimit)
      ? Math.min(Math.max(parsedLimit, 1), 5000)
      : 500;

    const [rows] = await db.execute(
      `SELECT *
       FROM \`${TABLE_NAME}\`
       ORDER BY shift_date DESC, shift DESC, id DESC
       LIMIT ${safeLimit}`
    );

    return rows;
  },

  getById: async (id) => {
    const [rows] = await db.execute(
      `SELECT * FROM \`${TABLE_NAME}\` WHERE id = ? LIMIT 1`,
      [id]
    );

    return rows[0] || null;
  },

  create: async (data) => {
    const fields = WRITABLE_FIELDS;
    const values = fields.map((field) => data[field] ?? null);
    const placeholders = fields.map(() => '?').join(', ');
    const columns = fields.map((field) => `\`${field}\``).join(', ');

    const [result] = await db.execute(
      `INSERT INTO \`${TABLE_NAME}\` (${columns}) VALUES (${placeholders})`,
      values
    );

    return result.insertId;
  },

  updateById: async (id, data) => {
    const fields = WRITABLE_FIELDS.filter((field) =>
      Object.prototype.hasOwnProperty.call(data, field)
    );

    if (fields.length === 0) {
      return {
        affectedRows: 0,
        changedRows: 0,
        noFields: true
      };
    }

    const setClause = fields.map((field) => `\`${field}\` = ?`).join(', ');
    const values = fields.map((field) => data[field]);

    const [result] = await db.execute(
      `UPDATE \`${TABLE_NAME}\`
       SET ${setClause}
       WHERE id = ?`,
      [...values, id]
    );

    return {
      affectedRows: result.affectedRows,
      changedRows: result.changedRows,
      noFields: false
    };
  },

  deleteById: async (id) => {
    const [result] = await db.execute(
      `DELETE FROM \`${TABLE_NAME}\` WHERE id = ?`,
      [id]
    );

    return result.affectedRows;
  },

  getByDateRange: async (startDate, endDate) => {
    const [rows] = await db.execute(
      `SELECT *
       FROM \`${TABLE_NAME}\`
       WHERE shift_date BETWEEN ? AND ?
       ORDER BY shift_date DESC, shift DESC, id DESC`,
      [startDate, endDate]
    );

    return rows;
  },

  getByShift: async (shift) => {
    const [rows] = await db.execute(
      `SELECT *
       FROM \`${TABLE_NAME}\`
       WHERE shift = ?
       ORDER BY shift_date DESC, id DESC`,
      [shift]
    );

    return rows;
  },

  getByLineTable: async (lineTable) => {
    const [rows] = await db.execute(
      `SELECT *
       FROM \`${TABLE_NAME}\`
       WHERE line_table = ?
       ORDER BY shift_date DESC, shift DESC, id DESC`,
      [lineTable]
    );

    return rows;
  },

  getByPmType: async (pmType) => {
    const [rows] = await db.execute(
      `SELECT *
       FROM \`${TABLE_NAME}\`
       WHERE pm_type = ?
       ORDER BY shift_date DESC, shift DESC, id DESC`,
      [pmType]
    );

    return rows;
  }
};

module.exports = TbKub1TotalKwhShiftly;
