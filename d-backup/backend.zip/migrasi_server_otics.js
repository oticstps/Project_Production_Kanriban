require('dotenv').config();
const mysql = require('mysql2/promise');

// List of tables to synchronise
const TABLES = Array.from({ length: 12 }, (_, i) => `common_rail_${i + 1}_core`);

// Connection pools
let srcPool, dstPool;

async function init() {
  srcPool = mysql.createPool({
    host: process.env.SRC_HOST,
    user: process.env.SRC_USER,
    password: process.env.SRC_PASS,
    database: process.env.SRC_DB,
    waitForConnections: true,
    connectionLimit: 10,
    enableKeepAlive: true,
  });

  dstPool = mysql.createPool({
    host: process.env.DST_HOST,
    user: process.env.DST_USER,
    password: process.env.DST_PASS,
    database: process.env.DST_DB,
    waitForConnections: true,
    connectionLimit: 10,
    enableKeepAlive: true,
  });
}

/**
 * Get all column names of a table (excluding id_uuid and optionally created_at)
 * We keep created_at for comparison because it can be different if rows are updated later.
 */
async function getColumns(table, exclude = []) {
  const [rows] = await srcPool.query(`SHOW COLUMNS FROM \`${table}\``);
  return rows
    .map((col) => col.Field)
    .filter((col) => !exclude.includes(col));
}

/**
 * Compare two rows (object) and return true if they differ.
 * Exclude primary key from comparison.
 */
function isDifferent(srcRow, dstRow, columnsToCompare) {
  for (const col of columnsToCompare) {
    // Handle null vs undefined / default values
    const srcVal = srcRow[col] ?? null;
    const dstVal = dstRow[col] ?? null;
    if (srcVal !== dstVal) {
      return true;
    }
  }
  return false;
}

/**
 * Sync a single table: read all rows from source, upsert into destination.
 */
async function syncTable(table) {
  console.log(`\n🔄 Syncing ${table} ...`);

  // Get all columns except primary key (id_uuid) – we keep it for the WHERE clause
  const columns = await getColumns(table, []); // we will exclude id_uuid later in comparison
  const compareColumns = columns.filter((col) => col !== 'id_uuid');

  // Read all source rows
  const [srcRows] = await srcPool.query(`SELECT * FROM \`${table}\``);
  console.log(`   Source: ${srcRows.length} rows`);

  let inserts = 0;
  let updates = 0;
  let unchanged = 0;

  for (const srcRow of srcRows) {
    const uuid = srcRow.id_uuid;

    // Check if row exists in destination
    const [dstRows] = await dstPool.query(
      `SELECT * FROM \`${table}\` WHERE id_uuid = ?`,
      [uuid]
    );

    if (dstRows.length === 0) {
      // INSERT
      const placeholders = columns.map(() => '?').join(',');
      const values = columns.map((col) => srcRow[col] ?? null);
      await dstPool.query(
        `INSERT INTO \`${table}\` (${columns.map((c) => `\`${c}\``).join(',')}) VALUES (${placeholders})`,
        values
      );
      inserts++;
    } else {
      // Row exists – compare all non‑key columns
      const dstRow = dstRows[0];
      if (isDifferent(srcRow, dstRow, compareColumns)) {
        // Build UPDATE SET ...
        const setClause = compareColumns.map((col) => `\`${col}\` = ?`).join(',');
        const setValues = compareColumns.map((col) => srcRow[col] ?? null);
        await dstPool.query(
          `UPDATE \`${table}\` SET ${setClause} WHERE id_uuid = ?`,
          [...setValues, uuid]
        );
        updates++;
      } else {
        unchanged++;
      }
    }
  }

  console.log(`   ✅ Insert: ${inserts}, Update: ${updates}, Unchanged: ${unchanged}`);
}

/**
 * Main synchronisation routine.
 */
async function runSync() {
  try {
    await init();
    console.log('🚀 Starting synchronisation ...\n');

    for (const table of TABLES) {
      await syncTable(table);
    }

    console.log('\n🎉 All tables synchronised successfully.');
  } catch (err) {
    console.error('❌ Synchronisation failed:', err);
  } finally {
    if (srcPool) await srcPool.end();
    if (dstPool) await dstPool.end();
  }
}

runSync();